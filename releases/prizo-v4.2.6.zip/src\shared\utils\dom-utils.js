/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * DOM Utils - Enhanced DOM manipulation utilities
 */
class DOMUtils {
  static validateElement(element, context = 'unknown') {
    if (!element) {
      console.warn(`Element is null/undefined in context: ${context}`);
      return false;
    }
    if (!element.parentNode) {
      console.warn(`Element is detached from DOM in context: ${context}`);
      return false;
    }
    return true;
  }

  static safeQuerySelector(parent, selector, context = 'unknown') {
    try {
      const element = parent.querySelector(selector);
      if (!element) {
        console.debug(`Element not found with selector "${selector}" in context: ${context}`);
      }
      return element;
    } catch (error) {
      console.error(`Invalid selector "${selector}" in context: ${context}`, error);
      return null;
    }
  }

  static safeQuerySelectorAll(parent, selector, context = 'unknown') {
    try {
      return Array.from(parent.querySelectorAll(selector));
    } catch (error) {
      console.error(`Invalid selector "${selector}" in context: ${context}`, error);
      return [];
    }
  }

  static createSafeElement(tagName, options = {}) {
    const element = document.createElement(tagName);
    
    if (options.text) {
      element.textContent = this.sanitizeText(options.text);
    }
    
    if (options.className) {
      element.className = options.className;
    }
    
    if (options.style) {
      this.setSafeCSSText(element, options.style);
    }
    
    if (options.attributes) {
      for (const [name, value] of Object.entries(options.attributes)) {
        if (this.isSafeAttribute(name)) {
          element.setAttribute(name, value);
        }
      }
    }
    
    return element;
  }

  static setSafeCSSText(element, cssText) {
    try {
      const sanitizedCSS = cssText.replace(/javascript:|expression\s*\(|@import|behavior\s*:/gi, '');
      element.style.cssText = sanitizedCSS;
    } catch (error) {
      console.warn('Failed to set CSS text:', error);
    }
  }

  static isSafeAttribute(attributeName) {
    const allowedAttributes = [
      'class', 'id', 'style', 'title', 'alt', 'src', 'href', 'data-*',
      'role', 'aria-*', 'tabindex', 'dir', 'lang'
    ];
    return allowedAttributes.some(attr => 
      attr === attributeName || 
      (attr.endsWith('*') && attributeName.startsWith(attr.slice(0, -1)))
    );
  }

  static sanitizeText(text) {
    if (typeof text !== 'string') {
      return String(text || '');
    }
    return text.replace(/[<>]/g, match => match === '<' ? '&lt;' : '&gt;');
  }

  static isElementVisible(element) {
    if (!element) return false;
    
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    
    return rect.width > 0 && 
           rect.height > 0 && 
           style.display !== 'none' && 
           style.visibility !== 'hidden' && 
           style.opacity !== '0';
  }

  static isElementInViewport(element, buffer = 0) {
    const rect = element.getBoundingClientRect();
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    const windowWidth = window.innerWidth || document.documentElement.clientWidth;
    
    return rect.top < windowHeight + buffer &&
           rect.bottom > -buffer &&
           rect.left < windowWidth + buffer &&
           rect.right > -buffer;
  }

  static waitForElement(selector, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const element = document.querySelector(selector);
      if (element) {
        resolve(element);
        return;
      }

      const observer = new MutationObserver((mutations) => {
        const element = document.querySelector(selector);
        if (element) {
          observer.disconnect();
          resolve(element);
        }
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });

      setTimeout(() => {
        observer.disconnect();
        reject(new Error(`Element ${selector} not found within ${timeout}ms`));
      }, timeout);
    });
  }

  static debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  static throttle(func, limit) {
    let inThrottle;
    return function(...args) {
      if (!inThrottle) {
        func.apply(this, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }

  static removeAllBySelector(selector) {
    const elements = document.querySelectorAll(selector);
    elements.forEach(element => element.remove());
    return elements.length;
  }

  static insertAfter(newElement, referenceElement) {
    referenceElement.parentNode.insertBefore(newElement, referenceElement.nextSibling);
  }

  static insertBefore(newElement, referenceElement) {
    referenceElement.parentNode.insertBefore(newElement, referenceElement);
  }

  static getElementPosition(element) {
    const rect = element.getBoundingClientRect();
    return {
      top: rect.top + window.pageYOffset,
      left: rect.left + window.pageXOffset,
      width: rect.width,
      height: rect.height
    };
  }

  static scrollToElement(element, behavior = 'smooth', block = 'center') {
    element.scrollIntoView({
      behavior,
      block,
      inline: 'nearest'
    });
  }

  static findClosestParent(element, selector) {
    return element.closest(selector);
  }

  static hasClass(element, className) {
    return element.classList.contains(className);
  }

  static addClass(element, className) {
    element.classList.add(className);
  }

  static removeClass(element, className) {
    element.classList.remove(className);
  }

  static toggleClass(element, className) {
    return element.classList.toggle(className);
  }
}

window.DOMUtils = DOMUtils;