/**
 * Contact Modal Functionality
 * Handles contact form modal, validation, and submission
 */

class ContactManager {
  constructor() {
    this.modal = null;
    this.form = null;
    this.isSubmitting = false;

    this.init();
  }

  async init() {
    // Wait for template loader to load the contact modal
    await this.waitForTemplate();
    this.setupModalElements();
    this.setupEventListeners();
  }

  async waitForTemplate() {
    // Wait for template loader to be available and load the contact modal
    let attempts = 0;
    const maxAttempts = 50; // 5 seconds max wait

    while (attempts < maxAttempts) {
      if (window.templateLoader && document.getElementById('contactModal')) {
        console.log('✅ Contact modal template loaded');
        return;
      }

      attempts++;
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    console.warn('⚠️ Contact modal template not loaded after waiting');
  }

  setupModalElements() {
    this.modal = document.getElementById('contactModal');
    this.form = document.getElementById('contactForm');

    if (!this.modal || !this.form) {
      console.warn('Contact modal elements not found');
      return;
    }
  }

  setupEventListeners() {
    if (!this.modal || !this.form) return;

    // Modal triggers
    const contactButtons = document.querySelectorAll('[data-tab="contact"], #contact-nav, .contact-link');
    contactButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        this.openModal();
      });
    });

    // Close modal
    const closeButton = document.getElementById('closeContactModal');
    const cancelButton = document.getElementById('cancelContact');

    if (closeButton) {
      closeButton.addEventListener('click', () => this.closeModal());
    }

    if (cancelButton) {
      cancelButton.addEventListener('click', () => this.closeModal());
    }

    // Close on overlay click
    this.modal.addEventListener('click', (e) => {
      if (e.target === this.modal) {
        this.closeModal();
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isModalOpen()) {
        this.closeModal();
      }
    });

    // Form submission
    this.form.addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleFormSubmission();
    });

    // Real-time validation
    this.setupRealTimeValidation();
  }

  setupRealTimeValidation() {
    const fields = [
      { id: 'contactName', validator: this.validateName },
      { id: 'contactEmail', validator: this.validateEmail },
      { id: 'contactSubject', validator: this.validateSubject },
      { id: 'contactMessage', validator: this.validateMessage }
    ];

    fields.forEach(field => {
      const element = document.getElementById(field.id);
      if (element) {
        element.addEventListener('blur', () => {
          this.validateField(field.id, field.validator);
        });

        element.addEventListener('input', () => {
          this.clearFieldError(field.id);
        });
      }
    });
  }

  openModal() {
    if (!this.modal) return;

    this.modal.style.display = 'flex';
    setTimeout(() => {
      this.modal.classList.add('active');
    }, 10);

    // Focus first input
    const firstInput = this.modal.querySelector('.form-input');
    if (firstInput) {
      setTimeout(() => firstInput.focus(), 300);
    }

    // Prevent body scroll
    document.body.style.overflow = 'hidden';
  }

  closeModal() {
    if (!this.modal) return;

    this.modal.classList.remove('active');
    setTimeout(() => {
      this.modal.style.display = 'none';
    }, 300);

    // Reset form and errors
    this.resetForm();

    // Restore body scroll
    document.body.style.overflow = '';
  }

  isModalOpen() {
    return this.modal && this.modal.classList.contains('active');
  }

  resetForm() {
    if (!this.form) return;

    this.form.reset();
    this.clearAllErrors();
    this.hideSuccessMessage();
    this.setSubmitButtonState(false);
  }

  async handleFormSubmission() {
    if (this.isSubmitting) return;

    // Validate all fields
    const isValid = this.validateAllFields();
    if (!isValid) {
      return;
    }

    // Set loading state
    this.isSubmitting = true;
    this.setSubmitButtonState(true);
    this.hideAllMessages();

    try {
      const formData = this.getFormData();
      const success = await this.submitContactForm(formData);

      if (success) {
        this.showSuccessMessage();
        setTimeout(() => {
          this.closeModal();
        }, 2000);
      } else {
        this.showErrorMessage('خطا در ارسال پیام. لطفا دوباره تلاش کنید.');
      }
    } catch (error) {
      console.error('Contact form submission error:', error);
      this.showErrorMessage('خطا در ارسال پیام. لطفا دوباره تلاش کنید یا مستقیما به ایمیل zanadeveloper@gmail.com پیام دهید.');
    } finally {
      this.isSubmitting = false;
      this.setSubmitButtonState(false);
    }
  }

  getFormData() {
    return {
      name: document.getElementById('contactName')?.value?.trim() || '',
      email: document.getElementById('contactEmail')?.value?.trim() || '',
      subject: document.getElementById('contactSubject')?.value || '',
      message: document.getElementById('contactMessage')?.value?.trim() || ''
    };
  }

  async submitContactForm(formData) {
    // Since there's no backend, create a mailto link and open it
    const subjectMap = {
      bug: 'گزارش باگ',
      feature: 'درخواست قابلیت جدید',
      feedback: 'بازخورد عمومی',
      support: 'درخواست پشتیبانی',
      other: 'سایر'
    };

    const subjectText = subjectMap[formData.subject] || formData.subject;
    const emailSubject = encodeURIComponent(`Prizo Extension - ${subjectText}`);
    const emailBody = encodeURIComponent(
      `سلام،\n\nنام: ${formData.name}\nایمیل: ${formData.email}\nموضوع: ${subjectText}\n\nپیام:\n${formData.message}\n\n---\nارسال شده از افزونه Prizo`
    );

    const mailtoUrl = `mailto:zanadeveloper@gmail.com?subject=${emailSubject}&body=${emailBody}`;

    // Small delay to simulate processing
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Open mail client
    window.open(mailtoUrl);

    return true;
  }

  validateAllFields() {
    const validations = [
      this.validateField('contactName', this.validateName),
      this.validateField('contactEmail', this.validateEmail),
      this.validateField('contactSubject', this.validateSubject),
      this.validateField('contactMessage', this.validateMessage)
    ];

    return validations.every(result => result);
  }

  validateField(fieldId, validator) {
    const element = document.getElementById(fieldId);
    if (!element) return false;

    const value = element.value.trim();
    const result = validator.call(this, value);

    if (result.isValid) {
      this.clearFieldError(fieldId);
      return true;
    } else {
      this.showFieldError(fieldId, result.message);
      return false;
    }
  }

  validateName(value) {
    if (!value) {
      return { isValid: false, message: 'نام الزامی است.' };
    }
    if (value.length < 2) {
      return { isValid: false, message: 'نام باید حداقل ۲ کاراکتر باشد.' };
    }
    if (value.length > 50) {
      return { isValid: false, message: 'نام نباید بیش از ۵۰ کاراکتر باشد.' };
    }
    return { isValid: true };
  }

  validateEmail(value) {
    if (!value) {
      return { isValid: false, message: 'ایمیل الزامی است.' };
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
      return { isValid: false, message: 'لطفا ایمیل معتبر وارد کنید.' };
    }

    return { isValid: true };
  }

  validateSubject(value) {
    if (!value) {
      return { isValid: false, message: 'انتخاب موضوع الزامی است.' };
    }
    return { isValid: true };
  }

  validateMessage(value) {
    if (!value) {
      return { isValid: false, message: 'پیام الزامی است.' };
    }
    if (value.length < 10) {
      return { isValid: false, message: 'پیام باید حداقل ۱۰ کاراکتر باشد.' };
    }
    if (value.length > 1000) {
      return { isValid: false, message: 'پیام نباید بیش از ۱۰۰۰ کاراکتر باشد.' };
    }
    return { isValid: true };
  }

  showFieldError(fieldId, message) {
    const errorElement = document.getElementById(fieldId.replace('contact', '').toLowerCase() + 'Error');
    if (errorElement) {
      errorElement.textContent = message;
      errorElement.style.display = 'block';
    }

    const field = document.getElementById(fieldId);
    if (field) {
      field.classList.add('error');
    }
  }

  clearFieldError(fieldId) {
    const errorElement = document.getElementById(fieldId.replace('contact', '').toLowerCase() + 'Error');
    if (errorElement) {
      errorElement.style.display = 'none';
    }

    const field = document.getElementById(fieldId);
    if (field) {
      field.classList.remove('error');
    }
  }

  clearAllErrors() {
    const errorElements = this.modal?.querySelectorAll('.form-error');
    errorElements?.forEach(element => {
      element.style.display = 'none';
    });

    const fields = this.modal?.querySelectorAll('.form-input, .form-textarea, .form-select');
    fields?.forEach(field => {
      field.classList.remove('error');
    });
  }

  showSuccessMessage() {
    const successElement = document.getElementById('contactSuccess');
    if (successElement) {
      successElement.style.display = 'block';
    }
  }

  hideSuccessMessage() {
    const successElement = document.getElementById('contactSuccess');
    if (successElement) {
      successElement.style.display = 'none';
    }
  }

  showErrorMessage(message) {
    const errorElement = document.getElementById('contactError');
    if (errorElement) {
      errorElement.textContent = message;
      errorElement.style.display = 'block';
    }
  }

  hideErrorMessage() {
    const errorElement = document.getElementById('contactError');
    if (errorElement) {
      errorElement.style.display = 'none';
    }
  }

  hideAllMessages() {
    this.hideSuccessMessage();
    this.hideErrorMessage();
  }

  setSubmitButtonState(loading) {
    const submitButton = document.getElementById('submitContact');
    const buttonText = submitButton?.querySelector('.btn-text');
    const loadingSpinner = submitButton?.querySelector('.form-loading');

    if (!submitButton) return;

    if (loading) {
      submitButton.disabled = true;
      if (buttonText) buttonText.textContent = 'در حال ارسال...';
      if (loadingSpinner) loadingSpinner.style.display = 'inline-block';
    } else {
      submitButton.disabled = false;
      if (buttonText) buttonText.textContent = 'ارسال پیام';
      if (loadingSpinner) loadingSpinner.style.display = 'none';
    }
  }
}

// Initialize contact manager when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new ContactManager();
  });
} else {
  new ContactManager();
}

// Export for use in other scripts if needed
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ContactManager;
}