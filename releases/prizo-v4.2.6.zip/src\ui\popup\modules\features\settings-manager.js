/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Settings Manager - Handles all extension settings and configuration
 */

class SettingsManager extends BaseModule {
  constructor(eventBus, domManager) {
    super('SettingsManager', eventBus, domManager);

    // Settings state
    this.settings = {
      persistentMode: true,
      sortFeatureEnabled: true,
      cartFeatureEnabled: true,
      globalDelay: 1000,
      networkStabilityCheck: true
    };

    // Storage keys
    this.storageKeys = [
      'persistentMode',
      'sortFeatureEnabled',
      'cartFeatureEnabled',
      'globalDelay',
      'networkStabilityCheck'
    ];
  }

  async initializeElements() {
    this.elements = this.domManager.getElements({
      // Persistent mode elements
      persistentModeCheckbox: '#persistentMode',
      toggleSwitchContainer: '#toggleSwitchContainer',

      // Sort feature elements
      sortFeatureSection: '#sortFeatureSection',
      sortFeatureCheckbox: '#sortFeatureMode',
      sortToggleSwitchContainer: '#sortToggleSwitchContainer',

      // Cart feature elements
      cartFeatureSection: '#cartFeatureSection',
      cartFeatureCheckbox: '#cartFeatureMode',
      cartToggleSwitchContainer: '#cartToggleSwitchContainer',


      // Delay settings elements
      globalDelayRange: '#globalDelayRange',
      globalDelayValue: '#globalDelayValue',
      networkStabilityCheckbox: '#networkStabilityCheck',
      networkStabilityToggleContainer: '#networkStabilityToggleContainer'
    });

    const validation = this.domManager.validateElements(this.elements, []);
    if (!validation.valid) {
      this.warn('Some settings elements are missing:', validation.missing);
    }
  }

  async setupEventListeners() {
    // Listen for external settings requests
    this.on('settings:load', () => this.loadAllSettings());
    this.on('settings:save', (data) => this.handleSettingsSaveRequest(data));
    this.on('settings:reset', () => this.resetAllSettings());
    this.on('settings:export', () => this.exportSettings());
    this.on('settings:import', (data) => this.importSettings(data));

    // Listen for button manager events
    this.on('settings:persistent-mode-changed', (data) => this.handlePersistentModeChange(data));
    this.on('settings:sort-feature-changed', (data) => this.handleSortFeatureChange(data));
    this.on('settings:cart-feature-changed', (data) => this.handleCartFeatureChange(data));
    this.on('settings:network-stability-changed', (data) => this.handleNetworkStabilityChange(data));
    this.on('settings:global-delay-changed', (data) => this.handleGlobalDelayChange(data));

    // Setup storage listener for synchronization with fullscreen settings
    this.setupStorageListener();
  }

  async loadInitialData() {
    await this.loadAllSettings();
    this.updateAllToggleSwitches();
  }

  // Event handlers for button manager events
  async handlePersistentModeChange(data) {
    this.settings.persistentMode = data.enabled;
    await this.saveSetting('persistentMode', data.enabled);
    this.emit('extension:setting-changed', { name: 'persistentMode', value: data.enabled });
  }

  async handleSortFeatureChange(data) {
    this.settings.sortFeatureEnabled = data.enabled;
    await this.saveSetting('sortFeatureEnabled', data.enabled);
    this.emit('extension:setting-changed', { name: 'sortFeatureEnabled', value: data.enabled });
  }

  async handleCartFeatureChange(data) {
    this.settings.cartFeatureEnabled = data.enabled;
    await this.saveSetting('cartFeatureEnabled', data.enabled);
    this.emit('extension:setting-changed', { name: 'cartFeatureEnabled', value: data.enabled });
  }


  async handleNetworkStabilityChange(data) {
    this.settings.networkStabilityCheck = data.enabled;
    await this.saveSetting('networkStabilityCheck', data.enabled);
  }

  async handleGlobalDelayChange(data) {
    this.settings.globalDelay = data.delay;
    await this.saveSetting('globalDelay', data.delay);
  }

  // Settings loading and saving
  async loadAllSettings() {
    try {
      const result = await chrome.storage.local.get(this.storageKeys);

      // Update settings with loaded values or defaults
      this.settings.persistentMode = result.persistentMode !== undefined ? result.persistentMode : true;
      this.settings.sortFeatureEnabled = result.sortFeatureEnabled !== undefined ? result.sortFeatureEnabled : true;
      this.settings.cartFeatureEnabled = result.cartFeatureEnabled !== undefined ? result.cartFeatureEnabled : true;
      this.settings.globalDelay = result.globalDelay || 1000;
      this.settings.networkStabilityCheck = result.networkStabilityCheck !== undefined ? result.networkStabilityCheck : true;

      this.log('Settings loaded:', this.settings);

      // Update UI elements
      this.updateSettingsUI();

      this.emit('settings:loaded', { settings: this.settings });
    } catch (error) {
      this.error('Error loading settings:', error);
      this.useDefaultSettings();
      this.showError('خطا در بارگذاری تنظیمات، از مقادیر پیش‌فرض استفاده شد');
    }
  }

  async loadDelaySettings() {
    try {
      const result = await chrome.storage.local.get(['globalDelay', 'networkStabilityCheck']);
      this.settings.globalDelay = result.globalDelay || 1000;
      this.settings.networkStabilityCheck = result.networkStabilityCheck !== undefined ? result.networkStabilityCheck : true;

      this.log('Delay settings loaded:', {
        globalDelay: this.settings.globalDelay,
        networkStabilityCheck: this.settings.networkStabilityCheck
      });

      this.updateDelaySettingsUI();
    } catch (error) {
      this.error('Error loading delay settings:', error);
      this.settings.globalDelay = 1000;
      this.settings.networkStabilityCheck = false;
    }
  }

  async saveSettings(settingsToSave = null) {
    try {
      const dataToSave = settingsToSave || this.settings;
      await chrome.storage.local.set(dataToSave);

      this.log('Settings saved:', dataToSave);
      this.emit('settings:saved', { settings: dataToSave });

      return true;
    } catch (error) {
      this.error('Error saving settings:', error);
      this.showError('خطا در ذخیره تنظیمات');
      return false;
    }
  }

  async saveSetting(key, value) {
    try {
      this.settings[key] = value;
      await chrome.storage.local.set({ [key]: value });

      this.log(`Setting saved: ${key} = ${value}`);
      this.emit('settings:setting-changed', { key, value });

      return true;
    } catch (error) {
      this.error(`Error saving setting ${key}:`, error);
      return false;
    }
  }

  // UI update methods
  updateSettingsUI() {
    this.updateCheckboxStates();
    this.updateDelaySettingsUI();
    this.updateAllToggleSwitches();
  }

  updateCheckboxStates() {
    const {
      persistentModeCheckbox, sortFeatureCheckbox,
      cartFeatureCheckbox, networkStabilityCheckbox
    } = this.elements;

    if (persistentModeCheckbox) {
      persistentModeCheckbox.checked = this.settings.persistentMode;
    }
    if (sortFeatureCheckbox) {
      sortFeatureCheckbox.checked = this.settings.sortFeatureEnabled;
    }
    if (cartFeatureCheckbox) {
      cartFeatureCheckbox.checked = this.settings.cartFeatureEnabled;
    }
    if (networkStabilityCheckbox) {
      networkStabilityCheckbox.checked = this.settings.networkStabilityCheck;
    }
  }

  updateDelaySettingsUI() {
    const { globalDelayRange, globalDelayValue } = this.elements;

    if (globalDelayRange && globalDelayValue) {
      globalDelayRange.value = this.settings.globalDelay;
      this.domManager.setText(globalDelayValue, this.settings.globalDelay.toString());
    }
  }

  updateAllToggleSwitches() {
    this.updateToggleSwitch();
    this.updateSortToggleSwitch();
    this.updateCartToggleSwitch();
    this.updateNetworkStabilityToggleSwitch();
  }

  updateToggleSwitch() {
    const { toggleSwitchContainer } = this.elements;
    if (toggleSwitchContainer) {
      this.domManager.toggleClass(toggleSwitchContainer, 'active', this.settings.persistentMode);
    }
  }

  updateSortToggleSwitch() {
    const { sortToggleSwitchContainer } = this.elements;
    if (sortToggleSwitchContainer) {
      this.domManager.toggleClass(sortToggleSwitchContainer, 'active', this.settings.sortFeatureEnabled);
    }
  }

  updateCartToggleSwitch() {
    const { cartToggleSwitchContainer } = this.elements;
    if (cartToggleSwitchContainer) {
      this.domManager.toggleClass(cartToggleSwitchContainer, 'active', this.settings.cartFeatureEnabled);
    }
  }


  updateNetworkStabilityToggleSwitch() {
    const { networkStabilityToggleContainer } = this.elements;
    if (networkStabilityToggleContainer) {
      this.domManager.toggleClass(networkStabilityToggleContainer, 'active', this.settings.networkStabilityCheck);
    }
  }

  // Feature toggle handlers
  async togglePersistentMode() {
    const { persistentModeCheckbox } = this.elements;
    if (!persistentModeCheckbox) return;

    persistentModeCheckbox.checked = !persistentModeCheckbox.checked;
    this.settings.persistentMode = persistentModeCheckbox.checked;

    await this.saveSetting('persistentMode', this.settings.persistentMode);
    this.updateToggleSwitch();

    this.emit('settings:persistent-mode-changed', {
      enabled: this.settings.persistentMode
    });

    this.log(`Persistent mode ${this.settings.persistentMode ? 'enabled' : 'disabled'}`);
  }

  async toggleSortFeature() {
    const { sortFeatureCheckbox } = this.elements;
    if (!sortFeatureCheckbox) return;

    sortFeatureCheckbox.checked = !sortFeatureCheckbox.checked;
    this.settings.sortFeatureEnabled = sortFeatureCheckbox.checked;

    await this.saveSetting('sortFeatureEnabled', this.settings.sortFeatureEnabled);
    this.updateSortToggleSwitch();

    this.emit('settings:sort-feature-changed', {
      enabled: this.settings.sortFeatureEnabled
    });

    this.log(`Sort feature ${this.settings.sortFeatureEnabled ? 'enabled' : 'disabled'}`);
  }

  async toggleCartFeature() {
    const { cartFeatureCheckbox } = this.elements;
    if (!cartFeatureCheckbox) return;

    cartFeatureCheckbox.checked = !cartFeatureCheckbox.checked;
    this.settings.cartFeatureEnabled = cartFeatureCheckbox.checked;

    await this.saveSetting('cartFeatureEnabled', this.settings.cartFeatureEnabled);
    this.updateCartToggleSwitch();

    this.emit('settings:cart-feature-changed', {
      enabled: this.settings.cartFeatureEnabled
    });

    this.log(`Cart feature ${this.settings.cartFeatureEnabled ? 'enabled' : 'disabled'}`);
  }


  async toggleNetworkStability() {
    const { networkStabilityCheckbox } = this.elements;
    if (!networkStabilityCheckbox) return;

    networkStabilityCheckbox.checked = !networkStabilityCheckbox.checked;
    this.settings.networkStabilityCheck = networkStabilityCheckbox.checked;

    await this.saveSetting('networkStabilityCheck', this.settings.networkStabilityCheck);
    this.updateNetworkStabilityToggleSwitch();

    this.emit('settings:network-stability-changed', {
      enabled: this.settings.networkStabilityCheck
    });

    this.log(`Network stability check ${this.settings.networkStabilityCheck ? 'enabled' : 'disabled'}`);
  }

  // Delay change handler
  async handleDelayChange(value) {
    if (typeof value !== 'number' || value < 500 || value > 5000) {
      this.warn(`Invalid delay value: ${value}`);
      return;
    }

    this.settings.globalDelay = value;
    await this.saveSetting('globalDelay', value);

    this.emit('settings:delay-changed', { delay: value });
    this.log(`Global delay changed to: ${value}ms`);
  }

  // External event handlers
  handleSettingsSaveRequest(data) {
    if (data.settings) {
      this.saveSettings(data.settings);
    } else {
      this.saveSettings();
    }
  }

  async resetAllSettings() {
    try {
      this.useDefaultSettings();
      await this.saveSettings();
      this.updateSettingsUI();

      this.showSuccess('تمام تنظیمات به مقادیر پیش‌فرض بازگردانده شدند');
      this.emit('settings:reset');
      this.log('All settings reset to defaults');
    } catch (error) {
      this.error('Error resetting settings:', error);
      this.showError('خطا در بازنشانی تنظیمات');
    }
  }

  useDefaultSettings() {
    this.settings = {
      persistentMode: true,
      sortFeatureEnabled: true,
      cartFeatureEnabled: true,
      comparisonFeatureEnabled: true,
      globalDelay: 1000,
      networkStabilityCheck: true
    };
  }

  // Import/Export functionality
  exportSettings() {
    try {
      const settingsJSON = JSON.stringify(this.settings, null, 2);
      const blob = new Blob([settingsJSON], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = this.domManager.createElement('a', {
        attributes: {
          href: url,
          download: 'prizo-settings.json'
        }
      });

      a.click();
      URL.revokeObjectURL(url);

      this.showSuccess('تنظیمات با موفقیت صادر شد');
      this.emit('settings:exported');
    } catch (error) {
      this.error('Error exporting settings:', error);
      this.showError('خطا در صادرات تنظیمات');
    }
  }

  async importSettings(data) {
    try {
      let settingsData;

      if (data.file) {
        // Import from file
        const text = await data.file.text();
        settingsData = JSON.parse(text);
      } else if (data.settings) {
        // Import from object
        settingsData = data.settings;
      } else {
        throw new Error('No settings data provided');
      }

      // Validate settings data
      const validatedSettings = this.validateImportedSettings(settingsData);

      // Merge with current settings
      this.settings = { ...this.settings, ...validatedSettings };

      await this.saveSettings();
      this.updateSettingsUI();

      this.showSuccess('تنظیمات با موفقیت وارد شدند');
      this.emit('settings:imported', { settings: validatedSettings });
    } catch (error) {
      this.error('Error importing settings:', error);
      this.showError('خطا در وارد کردن تنظیمات: ' + error.message);
    }
  }

  validateImportedSettings(settingsData) {
    const validatedSettings = {};

    // Validate each setting
    if (typeof settingsData.persistentMode === 'boolean') {
      validatedSettings.persistentMode = settingsData.persistentMode;
    }
    if (typeof settingsData.sortFeatureEnabled === 'boolean') {
      validatedSettings.sortFeatureEnabled = settingsData.sortFeatureEnabled;
    }
    if (typeof settingsData.cartFeatureEnabled === 'boolean') {
      validatedSettings.cartFeatureEnabled = settingsData.cartFeatureEnabled;
    }
    if (typeof settingsData.comparisonFeatureEnabled === 'boolean') {
      validatedSettings.comparisonFeatureEnabled = settingsData.comparisonFeatureEnabled;
    }
    if (typeof settingsData.networkStabilityCheck === 'boolean') {
      validatedSettings.networkStabilityCheck = settingsData.networkStabilityCheck;
    }
    if (typeof settingsData.globalDelay === 'number' &&
        settingsData.globalDelay >= 500 &&
        settingsData.globalDelay <= 5000) {
      validatedSettings.globalDelay = settingsData.globalDelay;
    }

    return validatedSettings;
  }

  // Public API methods
  getSetting(key) {
    return this.settings[key];
  }

  getAllSettings() {
    return { ...this.settings };
  }

  async setSetting(key, value) {
    if (this.storageKeys.includes(key)) {
      return await this.saveSetting(key, value);
    }
    this.warn(`Unknown setting key: ${key}`);
    return false;
  }

  async updateSetting(key, value) {
    return await this.setSetting(key, value);
  }

  isFeatureEnabled(featureName) {
    switch (featureName) {
      case 'persistent':
        return this.settings.persistentMode;
      case 'sort':
        return this.settings.sortFeatureEnabled;
      case 'cart':
        return this.settings.cartFeatureEnabled;
      case 'comparison':
        return this.settings.comparisonFeatureEnabled;
      case 'networkStability':
        return this.settings.networkStabilityCheck;
      default:
        return false;
    }
  }

  getGlobalDelay() {
    return this.settings.globalDelay;
  }

  // Settings validation
  validateSettings(settings = this.settings) {
    const errors = [];

    if (typeof settings.persistentMode !== 'boolean') {
      errors.push('persistentMode must be boolean');
    }
    if (typeof settings.sortFeatureEnabled !== 'boolean') {
      errors.push('sortFeatureEnabled must be boolean');
    }
    if (typeof settings.cartFeatureEnabled !== 'boolean') {
      errors.push('cartFeatureEnabled must be boolean');
    }
    if (typeof settings.comparisonFeatureEnabled !== 'boolean') {
      errors.push('comparisonFeatureEnabled must be boolean');
    }
    if (typeof settings.networkStabilityCheck !== 'boolean') {
      errors.push('networkStabilityCheck must be boolean');
    }
    if (typeof settings.globalDelay !== 'number' ||
        settings.globalDelay < 500 ||
        settings.globalDelay > 5000) {
      errors.push('globalDelay must be a number between 500 and 5000');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  // Debug utilities
  logCurrentSettings() {
    this.log('Current Settings:', this.settings);
    this.log('Settings Validation:', this.validateSettings());
  }

  // Setup storage listener for synchronization
  setupStorageListener() {
    if (chrome.storage && chrome.storage.onChanged) {
      this.storageChangeListener = (changes, namespace) => {
        if (namespace === 'local') {
          // Handle settings changes from fullscreen
          const settingsKeys = [
            'persistentMode',
            'sortFeatureEnabled',
            'cartFeatureEnabled',
            'networkStabilityCheck',
            'globalDelay',
            'comparisonFeatureEnabled'
          ];

          const changedSettings = {};
          let hasSettingsChanges = false;

          settingsKeys.forEach(key => {
            if (changes[key]) {
              this.log(`Setting ${key} synchronized from fullscreen:`, changes[key]);
              this.settings[key] = changes[key].newValue;
              changedSettings[key] = changes[key].newValue;
              hasSettingsChanges = true;
            }
          });

          if (hasSettingsChanges) {
            this.log('Settings synchronized from fullscreen:', changedSettings);
            // Update the popup settings UI
            this.updateSettingsUI();
            // Emit event to notify other components
            this.emit('settings:synchronized', { settings: changedSettings });
          }
        }
      };

      chrome.storage.onChanged.addListener(this.storageChangeListener);
      this.log('Storage change listener registered for settings synchronization');
    }
  }

  // Cleanup
  async cleanup() {
    // Remove storage listener
    if (this.storageChangeListener && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.removeListener(this.storageChangeListener);
      this.log('Storage change listener removed');
    }
    // Event listeners are managed by DOMManager
  }
}

// Make available globally
window.SettingsManager = SettingsManager;