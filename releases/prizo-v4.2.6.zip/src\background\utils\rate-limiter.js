/**
 * Rate Limiter Utility
 * Controls API request rate limiting
 */

class RateLimiter {
  constructor() {
    this.tokens = 10; // Start with 10 tokens
    this.maxTokens = 10;
    this.refillRate = 2; // tokens per second
    this.lastRefill = Date.now();

    // Start refilling tokens
    setInterval(() => this.refillTokens(), 1000);
  }

  refillTokens() {
    const now = Date.now();
    const timePassed = (now - this.lastRefill) / 1000;
    const tokensToAdd = Math.floor(timePassed * this.refillRate);

    if (tokensToAdd > 0) {
      this.tokens = Math.min(this.maxTokens, this.tokens + tokensToAdd);
      this.lastRefill = now;
    }
  }

  async consume(tokens = 1) {
    await this.refillTokens();

    if (this.tokens >= tokens) {
      this.tokens -= tokens;
      return true;
    }

    return false;
  }

  async waitForSlot() {
    this.refillTokens();

    if (this.tokens > 0) {
      this.tokens--;
      return;
    }

    // Wait for next token
    const waitTime = 1000 / this.refillRate;
    await new Promise(resolve => setTimeout(resolve, waitTime));
    return this.waitForSlot();
  }
}

export { RateLimiter };