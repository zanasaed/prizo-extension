/**
 * Core utilities and browser compatibility layer
 * Loaded first to provide foundation for other modules
 */

// Browser Compatibility Layer - Use centralized BrowserCompatUtils
class BrowserCompat {
  static init() {
    if (typeof window.BrowserCompatUtils !== 'undefined') {
      const browserInfo = window.BrowserCompatUtils.getBrowserInfo();
      this.isChrome = browserInfo.isChrome;
      this.isFirefox = browserInfo.isFirefox;
      this.isWebKit = !this.isChrome && !this.isFirefox;
      
      if (this.isFirefox && typeof chrome === 'undefined') {
        window.chrome = browser;
      }
    } else {
      this.fallbackInit();
    }
  }

  static fallbackInit() {
    this.isChrome = typeof chrome !== 'undefined' && chrome.runtime;
    this.isFirefox = typeof browser !== 'undefined' && browser.runtime;
    this.isWebKit = !this.isChrome && !this.isFirefox && typeof window.webkit !== 'undefined';
    
    if (this.isFirefox && typeof chrome === 'undefined') {
      window.chrome = browser;
    }
  }

  static getBrowserName() {
    if (this.isChrome) return 'Chrome/Chromium';
    if (this.isFirefox) return 'Firefox';
    if (this.isWebKit) return 'WebKit';
    return 'Unknown';
  }

  static createFallbackAPI() {
    return {
      runtime: {
        sendMessage: () => Promise.reject(new Error('Extension API not available')),
        onMessage: { addListener: () => {} }
      },
      storage: {
        local: {
          get: () => Promise.resolve({}),
          set: () => Promise.resolve(),
          remove: () => Promise.resolve()
        }
      },
      tabs: {
        sendMessage: () => Promise.reject(new Error('Extension API not available')),
        query: () => Promise.resolve([])
      }
    };
  }

  static polyfillAbortController() {
    window.AbortController = class {
      constructor() {
        this.signal = {
          aborted: false,
          addEventListener: () => {},
          removeEventListener: () => {}
        };
      }
      abort() {
        this.signal.aborted = true;
      }
    };
  }

  static supportsExtensionAPI() {
    try {
      // Check if we have the basic chrome runtime API
      if (typeof chrome === 'undefined' || !chrome.runtime) {
        return false;
      }
      
      // Additional checks for Manifest V3 compatibility
      const hasRuntime = chrome.runtime && typeof chrome.runtime.sendMessage === 'function';
      const hasValidContext = chrome.runtime.id !== undefined;
      
      // For content scripts, chrome.runtime.id might be available even if messaging fails
      // So we also check if we can access the runtime without throwing
      return hasRuntime && hasValidContext;
    } catch (error) {
      console.debug('Extension API check failed:', error);
      return false;
    }
  }

  static async safeStorageGet(keys, defaults = {}) {
    try {
      if (!this.supportsExtensionAPI()) return defaults;
      const result = await chrome.storage.local.get(keys);
      return { ...defaults, ...result };
    } catch (error) {
      console.warn('Storage API unavailable, using defaults:', error);
      return defaults;
    }
  }

  static async safeStorageSet(data) {
    try {
      if (!this.supportsExtensionAPI()) return false;
      await chrome.storage.local.set(data);
      return true;
    } catch (error) {
      console.warn('Storage API unavailable:', error);
      return false;
    }
  }

  static async safeSendMessage(message) {
    try {
      if (!this.supportsExtensionAPI()) {
        throw new Error('Extension messaging not supported');
      }
      
      // Add timeout to prevent hanging
      const timeout = message.timeout || 30000;
      const messagePromise = chrome.runtime.sendMessage(message);
      
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Message timeout')), timeout);
      });
      
      return await Promise.race([messagePromise, timeoutPromise]);
    } catch (error) {
      console.warn('Messaging API unavailable:', error);
      
      // Handle specific Chrome extension errors
      if (error.message) {
        if (error.message.includes('Extension context invalidated')) {
          throw new Error('Messaging API unavailable: Extension context invalidated');
        }
        if (error.message.includes('Could not establish connection')) {
          throw new Error('Messaging API unavailable: Could not establish connection to background script');
        }
        if (error.message.includes('A listener indicated an asynchronous response by returning true')) {
          throw new Error('Messaging API unavailable: Background script listener timeout');
        }
        if (error.message.includes('Message timeout')) {
          throw new Error('Messaging API unavailable: Message timeout');
        }
      }
      
      throw new Error(`Messaging API unavailable: ${error.message || 'Unknown error'}`);
    }
  }

  static isCompatible() {
    const required = [
      this.supportsExtensionAPI(),
      typeof Promise !== 'undefined',
      typeof fetch !== 'undefined' || typeof XMLHttpRequest !== 'undefined'
    ];

    return required.every(Boolean);
  }

  static addMessageListener(action, handler) {
    if (!this.supportsExtensionAPI()) {
      console.debug('Cannot add message listener - Extension API not supported');
      return; // Silently skip, this is normal for content scripts
    }

    try {
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === action) {
          let hasResponded = false;
          const safeSendResponse = (response) => {
            if (!hasResponded) {
              hasResponded = true;
              sendResponse(response);
            }
          };

          try {
            const result = handler(request, sender);
            if (result && typeof result.then === 'function') {
              // Handle async responses
              result
                .then(safeSendResponse)
                .catch(error => {
                  console.error(`Error in message handler for ${action}:`, error);
                  safeSendResponse({ error: error.message });
                });
              return true; // Indicate async response
            } else if (result !== undefined) {
              safeSendResponse(result);
              return false; // Sync response sent
            } else {
              console.warn(`Handler for ${action} returned undefined - no response sent`);
              safeSendResponse({ error: 'Handler returned no response' });
              return false;
            }
          } catch (error) {
            console.error(`Error in message handler for ${action}:`, error);
            safeSendResponse({ error: error.message });
            return false;
          }
        }
        return false; // Let other listeners handle the message
      });
      // console.log(`📡 Message listener added for action: ${action}`);
    } catch (error) {
      console.error(`Failed to add message listener for ${action}:`, error);
    }
  }
}

// Enhanced scroll handler with proper throttling
class OptimizedEventHandler {
  constructor() {
    this.throttleMap = new Map();
    this.activeTimeouts = new Set();
    this.activeIntervals = new Set();
  }

  throttle(func, delay, key) {
    if (this.throttleMap.has(key)) {
      return; // Already throttled
    }

    this.throttleMap.set(key, true);

    const timeoutId = setTimeout(() => {
      this.throttleMap.delete(key);
      this.activeTimeouts.delete(timeoutId);
      func();
    }, delay);

    this.activeTimeouts.add(timeoutId);
  }

  debounce(func, delay, key) {
    if (this.throttleMap.has(key)) {
      clearTimeout(this.throttleMap.get(key));
    }

    const timeoutId = setTimeout(() => {
      this.throttleMap.delete(key);
      this.activeTimeouts.delete(timeoutId);
      func();
    }, delay);

    this.throttleMap.set(key, timeoutId);
    this.activeTimeouts.add(timeoutId);
  }

  setManagedInterval(func, delay) {
    const intervalId = setInterval(func, delay);
    this.activeIntervals.add(intervalId);
    return intervalId;
  }

  cleanup() {
    // Clear all throttled functions
    this.throttleMap.forEach((timeoutId, key) => {
      if (typeof timeoutId === 'number') {
        clearTimeout(timeoutId);
      }
    });
    this.throttleMap.clear();

    // Clear all active timeouts
    this.activeTimeouts.forEach(timeoutId => clearTimeout(timeoutId));
    this.activeTimeouts.clear();

    // Clear all active intervals
    this.activeIntervals.forEach(intervalId => clearInterval(intervalId));
    this.activeIntervals.clear();
  }
}

// Enhanced DOM readiness and initialization
class ExtensionInitializer {
  static async waitForDOM() {
    return new Promise((resolve) => {
      if (document.readyState === 'complete') {
        resolve();
        return;
      }

      if (document.readyState === 'interactive') {
        // DOM is loaded but resources might still be loading
        setTimeout(resolve, 100);
        return;
      }

      // DOM is still loading
      document.addEventListener('DOMContentLoaded', resolve, { once: true });
    });
  }

  static async waitWithGlobalDelay() {
    try {
      // Get configurable delay (default: 1000ms for prod, 2000ms for slow networks)
      const baseDelay = await this.getConfiguredDelay();
      
      console.log(`⏳ Global delay: ${baseDelay}ms`);
      await new Promise(resolve => setTimeout(resolve, baseDelay));
      
      // Optional: Network stability check
      if (await this.shouldWaitForNetworkStability()) {
        console.log('🌐 Waiting for network stability...');
        await this.waitForNetworkStability();
      }
    } catch (error) {
      console.warn('⚠️ Global delay failed, using fallback 1000ms:', error);
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  static async getConfiguredDelay() {
    try {
      const result = await BrowserCompat.safeStorageGet(['globalDelay'], { globalDelay: 1000 });
      let delay = result.globalDelay;
      
      // Environment-aware: longer delay for slow connections
      if (typeof navigator !== 'undefined' && navigator.connection) {
        const connection = navigator.connection;
        if (connection.effectiveType === 'slow-2g' || connection.effectiveType === '2g') {
          delay = Math.max(delay, 2000);
          console.log('🐌 Slow network detected, using extended delay');
        }
      }
      
      return Math.min(Math.max(delay, 500), 5000); // Clamp between 500ms-5000ms
    } catch (error) {
      console.warn('Using default delay due to storage error:', error);
      return 1000; // Safe default
    }
  }

  static async shouldWaitForNetworkStability() {
    try {
      const result = await BrowserCompat.safeStorageGet(['networkStabilityCheck'], { networkStabilityCheck: false });
      return result.networkStabilityCheck;
    } catch (error) {
      return false; // Default to disabled if storage fails
    }
  }

  static async waitForNetworkStability() {
    // Simple network stability check - wait for no pending requests
    const maxWait = 3000; // Max 3 seconds
    const checkInterval = 100;
    let waited = 0;
    
    while (waited < maxWait) {
      // Check if there are active network requests
      const hasActiveRequests = performance.getEntriesByType('navigation')
        .some(entry => entry.loadEventEnd === 0);
      
      if (!hasActiveRequests) {
        console.log(`✅ Network stability achieved after ${waited}ms`);
        return;
      }
      
      await new Promise(resolve => setTimeout(resolve, checkInterval));
      waited += checkInterval;
    }
    
    console.log('⚠️ Network stability timeout, proceeding anyway');
  }

  static async waitForDigikalaElements() {
    // Wait for typical Digikala page elements to be available
    const maxAttempts = 20;
    const interval = 250;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      // Check for common Digikala elements that indicate page is ready
      const indicators = [
        document.querySelector('header'),
        document.querySelector('main'),
        document.querySelector('[data-testid="product-list"]'),
        document.querySelector('[data-testid="cart-item"]'),
        document.querySelector('div[class*="ProductList"]'),
        document.querySelector('div[class*="HeaderSort"]'),
        document.querySelector('div[class*="product-list"]')
      ];

      // If any indicator exists, page structure is likely ready
      if (indicators.some(el => el !== null)) {
        // console.log(`✅ Digikala page structure ready after ${attempt} attempts`);
        return;
      }

      if (attempt < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, interval));
      }
    }

    console.log('⚠️ Digikala page structure not fully detected, proceeding anyway');
  }

  static async initialize() {
    try {
      console.log('🚀 Starting extension initialization...');

      // Wait for DOM to be ready
      await this.waitForDOM();
      console.log('✅ DOM is ready');

      // Apply global delay for stability
      await this.waitWithGlobalDelay();
      console.log('✅ Global delay completed');

      // Wait for Digikala-specific elements
      await this.waitForDigikalaElements();
      console.log('✅ Digikala elements detected');

      // Load modules dynamically based on page type (check if available)
      if (typeof ModuleLoader !== 'undefined') {
        const moduleLoader = new ModuleLoader();
        await moduleLoader.loadForCurrentPage();
      } else {
        console.warn('ModuleLoader not available, skipping module loading');
      }

      console.log('✅ Extension initialized successfully');

    } catch (error) {
      console.error('❌ Extension initialization failed:', error);

      // Use enhanced error handling if available
      if (window.EnhancedErrorHandler) {
        const errorHandler = new window.EnhancedErrorHandler();
        await errorHandler.handleError(error, 'EXTENSION_INITIALIZATION', {
          rethrow: false,
          retryCallback: async () => {
            console.log('🔄 Retrying extension initialization...');
            await new Promise(resolve => setTimeout(resolve, 2000));
            return this.initialize();
          }
        });
      } else {
        // Fallback retry
        setTimeout(() => {
          console.log('🔄 Retrying extension initialization...');
          this.initialize();
        }, 2000);
      }
    }
  }
}

// Module loader for lazy loading
class ModuleLoader {
  constructor() {
    this.loadedModules = new Set();
    this.moduleCache = new Map();
  }

  detectPageType() {
    const pathname = window.location.pathname;

    if (pathname === '/' || pathname === '/main/') {
      return 'homepage';
    } else if (pathname.includes('/checkout/cart/')) {
      return 'cart';
    } else if (pathname.includes('/profile/lists/') || pathname.includes('/profile/wishlist/')) {
      return 'wishlist';
    } else if (pathname.includes('/product/dkp-') || pathname.includes('/fresh/product/dkp-')) {
      return 'product';
    } else if (pathname.includes('/seller/')) {
      return 'seller';
    } else if (pathname.includes('/search') || pathname.includes('/fresh/search') || pathname.includes('/category') || 
               pathname.includes('/incredible-offers') || pathname.includes('/tags')) {
      return 'listing';
    }
    
    return 'unknown';
  }

  async loadForCurrentPage() {
    const pageType = this.detectPageType();
    console.log(`📄 Detected page type: ${pageType}`);

    // Always load core modules
    await this.loadModule('storage');
    await this.loadModule('security');
    await this.loadModule('first-time-welcome');

    // Load page-specific modules
    switch (pageType) {
      case 'seller':
      case 'listing':
      case 'wishlist':
      case 'product':
      case 'cart':
        // Main price updater handles all these page types
        await this.loadModule('digikala-price-updater');
        break;
      case 'homepage':
        await this.loadModule('homepage-banner');
        break;
      default:
        console.log('🔄 Loading minimal modules for unknown page type');
        break;
    }

    // Initialize main extension
    await this.initializeExtension(pageType);
  }

  async loadModule(moduleName) {
    if (this.loadedModules.has(moduleName)) {
      return this.moduleCache.get(moduleName);
    }

    try {
      // console.log(`📦 Loading module: ${moduleName}`);
      
      // Module availability check with proper guards
      let moduleClass = null;
      let moduleFound = false;
      
      switch (moduleName) {
        case 'storage':
          if (typeof StorageManager !== 'undefined') {
            moduleClass = StorageManager;
            moduleFound = true;
          }
          break;
        case 'security':
          if (typeof URLSafetyManager !== 'undefined') {
            moduleClass = URLSafetyManager;
            moduleFound = true;
          }
          break;
        case 'digikala-price-updater':
          if (typeof DigikalaSellerPriceUpdater !== 'undefined') {
            moduleClass = DigikalaSellerPriceUpdater;
            moduleFound = true;
          }
          break;
        case 'homepage-banner':
          if (typeof HomepageBanner !== 'undefined') {
            moduleClass = HomepageBanner;
            moduleFound = true;
          }
          break;
        case 'first-time-welcome':
          if (typeof FirstTimeWelcome !== 'undefined') {
            moduleClass = FirstTimeWelcome;
            moduleFound = true;
          }
          break;
        default:
          console.warn(`Unknown module requested: ${moduleName}`);
          return null;
      }

      if (!moduleFound || !moduleClass) {
        console.warn(`Module class not found: ${moduleName} - skipping gracefully`);
        // Mark as "loaded" but with null to prevent repeated attempts
        this.loadedModules.add(moduleName);
        this.moduleCache.set(moduleName, null);
        return null;
      }

      // Additional safety check for class constructor
      if (typeof moduleClass !== 'function') {
        console.warn(`Module ${moduleName} is not a valid class constructor`);
        this.loadedModules.add(moduleName);
        this.moduleCache.set(moduleName, null);
        return null;
      }

      this.loadedModules.add(moduleName);
      this.moduleCache.set(moduleName, moduleClass);
      // console.log(`✅ Module loaded successfully: ${moduleName}`);
      
      return moduleClass;
    } catch (error) {
      console.error(`❌ Failed to load module ${moduleName}:`, error);
      // Mark as attempted to prevent retry loops
      this.loadedModules.add(moduleName);
      this.moduleCache.set(moduleName, null);
      return null;
    }
  }

  async initializeExtension(pageType) {
    console.log(`🎯 Initializing extension for ${pageType} page`);
    
    // Only initialize the main updater for supported pages
    if (['seller', 'listing', 'wishlist', 'product', 'cart'].includes(pageType)) {
      if (typeof DigikalaSellerPriceUpdater !== 'undefined') {
        const updater = new DigikalaSellerPriceUpdater();
        window.digikalaExtension = updater;
        return updater;
      } else {
        console.warn('DigikalaSellerPriceUpdater not available');
        return null;
      }
    }
    
    // For homepage and other pages, no main updater needed
    console.log(`✅ Extension initialized for ${pageType} page`);
    return null;
  }
}

// Note: Message listeners are handled by background script, not content script

// Initialize browser compatibility
BrowserCompat.init();

// Export for use in other parts
window.ExtensionCore = {
  BrowserCompat,
  OptimizedEventHandler,
  ExtensionInitializer,
  ModuleLoader
};