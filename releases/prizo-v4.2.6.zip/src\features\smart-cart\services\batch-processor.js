/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-18
 * Batch Processor - Handles batch API requests for Smart Cart optimization
 */
class BatchProcessor {
  constructor(apiService, eventBus) {
    this.apiService = apiService;
    this.eventBus = eventBus;

    // Batch configuration
    this.batchConfig = {
      maxBatchSize: 5,
      batchTimeout: 1000, // 1 second
      maxWaitTime: 3000, // 3 seconds max wait
      concurrency: 2 // Max 2 batches processing simultaneously
    };

    // Batch queue and processing
    this.pendingRequests = [];
    this.batchTimer = null;
    this.processingBatches = 0;
    this.requestId = 0;

    // Request deduplication
    this.activeRequests = new Map();
    this.requestPromises = new Map();

    // Statistics
    this.stats = {
      totalRequests: 0,
      batchedRequests: 0,
      duplicatesPrevented: 0,
      averageBatchSize: 0,
      totalBatches: 0
    };
  }

  async processProductRequest(productId, options = {}) {
    this.stats.totalRequests++;

    const {
      variantId = null,
      includeVariant = false,
      priority = 'normal',
      timeout = 8000,
      immediate = false
    } = options;

    const requestKey = this.generateRequestKey(productId, variantId, includeVariant);

    // Check for duplicate requests
    if (this.requestPromises.has(requestKey)) {
      this.stats.duplicatesPrevented++;
      console.log(`🔄 Reusing existing request for ${productKey}`);
      return await this.requestPromises.get(requestKey);
    }

    // Create request promise
    const requestPromise = new Promise((resolve, reject) => {
      const requestInfo = {
        id: ++this.requestId,
        productId,
        variantId,
        includeVariant,
        priority,
        timeout,
        timestamp: Date.now(),
        resolve,
        reject,
        key: requestKey
      };

      if (immediate || priority === 'critical') {
        // Process immediately for critical requests
        this.processImmediateRequest(requestInfo);
      } else {
        // Add to batch queue
        this.addToBatchQueue(requestInfo);
      }
    });

    this.requestPromises.set(requestKey, requestPromise);

    try {
      const result = await requestPromise;
      return result;
    } finally {
      this.requestPromises.delete(requestKey);
    }
  }

  async processMultipleProducts(productRequests, options = {}) {
    const { priority = 'normal', immediate = false } = options;

    console.log(`🔄 Processing ${productRequests.length} products in batch mode`);

    if (immediate || productRequests.length <= this.batchConfig.maxBatchSize) {
      // Process as single batch
      return await this.processBatchDirect(productRequests, options);
    } else {
      // Split into multiple batches
      return await this.processLargeBatch(productRequests, options);
    }
  }

  async processBatchDirect(requests, options = {}) {
    const { priority = 'normal' } = options;

    // Deduplicate requests
    const uniqueRequests = this.deduplicateRequests(requests);

    console.log(`📦 Processing batch of ${uniqueRequests.length} unique products`);

    this.stats.batchedRequests += uniqueRequests.length;
    this.stats.totalBatches++;

    const results = {};

    try {
      // Process batch with API service
      const apiResults = await this.apiService.fetchMultipleProducts(uniqueRequests, {
        priority,
        freshData: false
      });

      // Transform results to match expected format
      for (const [productId, result] of Object.entries(apiResults)) {
        results[productId] = result;
      }

      // Update average batch size
      this.updateBatchStats(uniqueRequests.length);

      console.log(`✅ Batch completed: ${Object.keys(results).length} products processed`);

      return results;
    } catch (error) {
      console.error('❌ Batch processing failed:', error);

      // Return error results for all requests
      for (const request of uniqueRequests) {
        results[request.productId] = {
          success: false,
          error: error.message,
          fromCache: false
        };
      }

      return results;
    }
  }

  async processLargeBatch(requests, options = {}) {
    const chunks = this.chunkArray(requests, this.batchConfig.maxBatchSize);
    const allResults = {};

    console.log(`📦 Processing large batch: ${requests.length} products in ${chunks.length} chunks`);

    // Process chunks with concurrency control
    for (let i = 0; i < chunks.length; i += this.batchConfig.concurrency) {
      const concurrentChunks = chunks.slice(i, i + this.batchConfig.concurrency);

      const chunkPromises = concurrentChunks.map(chunk =>
        this.processBatchDirect(chunk, options)
      );

      const chunkResults = await Promise.allSettled(chunkPromises);

      // Merge results from concurrent chunks
      chunkResults.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          Object.assign(allResults, result.value);
        } else {
          console.error(`❌ Chunk ${i + index} failed:`, result.reason);
          // Add error results for failed chunk
          const failedChunk = concurrentChunks[index];
          failedChunk.forEach(request => {
            allResults[request.productId] = {
              success: false,
              error: result.reason.message,
              fromCache: false
            };
          });
        }
      });

      // Add delay between concurrent batch sets
      if (i + this.batchConfig.concurrency < chunks.length) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }

    console.log(`✅ Large batch completed: ${Object.keys(allResults).length} products processed`);
    return allResults;
  }

  addToBatchQueue(requestInfo) {
    this.pendingRequests.push(requestInfo);

    // Start batch timer if not already running
    if (!this.batchTimer) {
      this.batchTimer = setTimeout(() => {
        this.processPendingBatch();
      }, this.batchConfig.batchTimeout);
    }

    // Process immediately if batch is full
    if (this.pendingRequests.length >= this.batchConfig.maxBatchSize) {
      this.processPendingBatch();
    }
  }

  async processPendingBatch() {
    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
      this.batchTimer = null;
    }

    if (this.pendingRequests.length === 0) {
      return;
    }

    // Check concurrency limit
    if (this.processingBatches >= this.batchConfig.concurrency) {
      // Restart timer to try again later
      this.batchTimer = setTimeout(() => {
        this.processPendingBatch();
      }, this.batchConfig.batchTimeout);
      return;
    }

    const requestsToProcess = this.pendingRequests.splice(0, this.batchConfig.maxBatchSize);
    this.processingBatches++;

    console.log(`📦 Processing pending batch: ${requestsToProcess.length} requests`);

    try {
      const productRequests = requestsToProcess.map(req => ({\n        productId: req.productId,\n        variantId: req.variantId,\n        includeVariant: req.includeVariant\n      }));\n\n      const results = await this.processBatchDirect(productRequests, {\n        priority: this.getHighestPriority(requestsToProcess)\n      });\n\n      // Resolve individual request promises\n      requestsToProcess.forEach(request => {\n        const result = results[request.productId];\n        if (result) {\n          request.resolve(result);\n        } else {\n          request.reject(new Error(`No result for product ${request.productId}`));\n        }\n      });\n\n    } catch (error) {\n      console.error('❌ Pending batch processing failed:', error);\n\n      // Reject all requests in the batch\n      requestsToProcess.forEach(request => {\n        request.reject(error);\n      });\n    } finally {\n      this.processingBatches--;\n\n      // Process remaining requests if any\n      if (this.pendingRequests.length > 0) {\n        setTimeout(() => {\n          this.processPendingBatch();\n        }, 100);\n      }\n    }\n  }\n\n  async processImmediateRequest(requestInfo) {\n    console.log(`⚡ Processing immediate request for product ${requestInfo.productId}`);\n\n    try {\n      const result = await this.apiService.fetchProductData(requestInfo.productId, {\n        variantId: requestInfo.variantId,\n        includeVariant: requestInfo.includeVariant,\n        priority: 'high',\n        timeout: requestInfo.timeout\n      });\n\n      requestInfo.resolve(result);\n    } catch (error) {\n      requestInfo.reject(error);\n    }\n  }\n\n  // Utility methods\n  generateRequestKey(productId, variantId, includeVariant) {\n    return `${productId}_${includeVariant ? `variant_${variantId}` : 'default'}`;\n  }\n\n  deduplicateRequests(requests) {\n    const seen = new Set();\n    const unique = [];\n\n    for (const request of requests) {\n      const key = this.generateRequestKey(\n        request.productId,\n        request.variantId,\n        request.includeVariant\n      );\n\n      if (!seen.has(key)) {\n        seen.add(key);\n        unique.push(request);\n      }\n    }\n\n    return unique;\n  }\n\n  chunkArray(array, chunkSize) {\n    const chunks = [];\n    for (let i = 0; i < array.length; i += chunkSize) {\n      chunks.push(array.slice(i, i + chunkSize));\n    }\n    return chunks;\n  }\n\n  getHighestPriority(requests) {\n    const priorities = ['critical', 'high', 'normal', 'low'];\n    for (const priority of priorities) {\n      if (requests.some(req => req.priority === priority)) {\n        return priority;\n      }\n    }\n    return 'normal';\n  }\n\n  updateBatchStats(batchSize) {\n    const totalProcessed = this.stats.averageBatchSize * (this.stats.totalBatches - 1) + batchSize;\n    this.stats.averageBatchSize = totalProcessed / this.stats.totalBatches;\n  }\n\n  // Configuration methods\n  updateConfig(newConfig) {\n    this.batchConfig = { ...this.batchConfig, ...newConfig };\n    console.log('🔧 Batch processor configuration updated:', this.batchConfig);\n  }\n\n  // Statistics and monitoring\n  getStats() {\n    return {\n      ...this.stats,\n      pendingRequests: this.pendingRequests.length,\n      processingBatches: this.processingBatches,\n      activeRequests: this.requestPromises.size,\n      batchEfficiency: this.stats.totalRequests > 0\n        ? ((this.stats.batchedRequests / this.stats.totalRequests) * 100).toFixed(2) + '%'\n        : '0%'\n    };\n  }\n\n  // Force process pending requests\n  async flushPendingRequests() {\n    if (this.pendingRequests.length > 0) {\n      console.log(`🚀 Flushing ${this.pendingRequests.length} pending requests`);\n      await this.processPendingBatch();\n    }\n  }\n\n  // Clear all pending requests\n  clearPendingRequests() {\n    const count = this.pendingRequests.length;\n    \n    // Reject all pending requests\n    this.pendingRequests.forEach(request => {\n      request.reject(new Error('Batch processor cleared'));\n    });\n\n    this.pendingRequests = [];\n    this.requestPromises.clear();\n\n    if (this.batchTimer) {\n      clearTimeout(this.batchTimer);\n      this.batchTimer = null;\n    }\n\n    console.log(`🧹 Cleared ${count} pending requests`);\n  }\n\n  destroy() {\n    this.clearPendingRequests();\n    console.log('🧹 Batch Processor destroyed');\n  }\n}\n\nwindow.BatchProcessor = BatchProcessor;