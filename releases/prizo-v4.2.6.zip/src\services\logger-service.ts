/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-28
 * LoggerService - Centralized logging service with timestamp and level indicators
 */

/**
 * Interface for metadata that can be passed to logging methods
 */
export interface LogMetadata {
  productId?: number | string;
  error?: Error | unknown;
  details?: any;
  [key: string]: any;
}

/**
 * Enum for log levels
 */
enum LogLevel {
  INFO = 'INFO',
  WARN = 'WARN',
  ERROR = 'ERROR'
}

/**
 * Centralized logging service with structured logging capabilities
 */
export class LoggerService {
  private readonly logLevels = LogLevel;

  /**
   * Formats a timestamp for logging
   * @returns Formatted timestamp string
   */
  private formatTimestamp(): string {
    const now = new Date();
    return now.toISOString().replace('T', ' ').substring(0, 19);
  }

  /**
   * Formats a log message with timestamp and level
   * @param level - Log level (INFO, WARN, ERROR)
   * @param message - Log message
   * @param metadata - Optional metadata object
   * @returns Formatted log message
   */
  private formatLogMessage(level: LogLevel, message: string, metadata?: LogMetadata): string {
    const timestamp = this.formatTimestamp();
    let formattedMessage = `[${timestamp}] [${level}] ${message}`;
    
    if (metadata) {
      if (metadata.productId) {
        formattedMessage += ` | Product: ${metadata.productId}`;
      }
      if (metadata.error) {
        const errorMessage = metadata.error instanceof Error 
          ? metadata.error.message 
          : String(metadata.error);
        formattedMessage += ` | Error: ${errorMessage}`;
      }
      if (metadata.details) {
        formattedMessage += ` | Details: ${JSON.stringify(metadata.details)}`;
      }
    }
    
    return formattedMessage;
  }

  /**
   * Logs an info message
   * @param message - Message to log
   * @param meta - Optional metadata (productId, details, etc.)
   */
  public info(message: string, meta?: LogMetadata): void {
    const formattedMessage = this.formatLogMessage(this.logLevels.INFO, message, meta);
    console.log(formattedMessage);
  }

  /**
   * Logs a warning message
   * @param message - Message to log
   * @param meta - Optional metadata (productId, details, etc.)
   */
  public warn(message: string, meta?: LogMetadata): void {
    const formattedMessage = this.formatLogMessage(this.logLevels.WARN, message, meta);
    console.warn(formattedMessage);
  }

  /**
   * Logs an error message
   * @param message - Message to log
   * @param meta - Optional metadata (productId, error, details, etc.)
   */
  public error(message: string, meta?: LogMetadata): void {
    const formattedMessage = this.formatLogMessage(this.logLevels.ERROR, message, meta);
    console.error(formattedMessage);
  }
}

// Default export for backward compatibility
export default LoggerService;

// Also make available globally for browser environment compatibility
declare global {
  interface Window {
    LoggerService: typeof LoggerService;
  }
}

if (typeof window !== 'undefined') {
  window.LoggerService = LoggerService;
}