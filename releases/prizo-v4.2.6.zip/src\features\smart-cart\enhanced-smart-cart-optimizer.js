/**
 * @Author: Enhanced Smart Cart System
 * @Date: 2025-01-19
 * Enhanced Smart Cart Optimizer Integration - Integrates API data fetching with basket optimization
 */

class EnhancedSmartCartOptimizer {
  constructor(smartCartManager, apiService, cacheService) {
    this.smartCartManager = smartCartManager;
    this.apiService = apiService;
    this.cacheService = cacheService;

    // Optimization components
    this.basketOptimizer = null;
    this.isInitialized = false;

    // Optimization settings
    this.settings = {
      enableAPIRefresh: true,
      enableOptimization: true,
      autoCalculateOnChange: true,
      maxOptimizationTime: 5000, // 5 seconds max
      preferredSellers: [],
      optimizationMode: 'COST' // COST, SELLERS, or MIXED
    };

    // Calculation states
    this.isCalculating = false;
    this.lastCalculationTime = null;
    this.currentCalculationPromise = null;

    // Event bus for notifications
    this.eventBus = smartCartManager?.eventBus || null;

    console.log('🚀 Enhanced Smart Cart Optimizer initialized');
  }

  /**
   * Add event listener - proxy to eventBus
   */
  on(event, callback) {
    if (this.eventBus && typeof this.eventBus.on === 'function') {
      return this.eventBus.on(event, callback);
    }
    console.warn(`⚠️ Cannot add listener for event '${event}': eventBus not available`);
  }

  /**
   * Remove event listener - proxy to eventBus
   */
  off(event, callback) {
    if (this.eventBus && typeof this.eventBus.off === 'function') {
      return this.eventBus.off(event, callback);
    }
    console.warn(`⚠️ Cannot remove listener for event '${event}': eventBus not available`);
  }

  /**
   * Initialize the optimizer with required dependencies
   */
  async initialize() {
    try {
      if (this.isInitialized) {
        return true;
      }

      // Load basket optimizer components
      await this.loadOptimizerComponents();

      // Initialize basket optimizer
      if (window.BasketOptimizer) {
        this.basketOptimizer = new window.BasketOptimizer();
      } else {
        console.warn('⚠️ BasketOptimizer not available, optimization disabled');
        this.settings.enableOptimization = false;
      }

      this.isInitialized = true;
      console.log('✅ Enhanced Smart Cart Optimizer initialized successfully');

      // Setup event listeners for automatic recalculation
      this.setupEventListeners();

      return true;
    } catch (error) {
      console.error('❌ Failed to initialize Enhanced Smart Cart Optimizer:', error);
      return false;
    }
  }

  /**
   * Load optimizer components
   */
  async loadOptimizerComponents() {
    const requiredComponents = [
      'BasketOptimizer',
      'BasketValidator',
      'CostCalculator'
    ];

    for (const component of requiredComponents) {
      if (!window[component]) {
        console.warn(`⚠️ ${component} not found, some features may be disabled`);
      }
    }
  }

  /**
   * Setup event listeners for automatic recalculation
   */
  setupEventListeners() {
    if (!this.eventBus) return;

    // Listen for cart changes
    this.eventBus.on('smart-cart:item-added', () => this.triggerOptimization('item_added'));
    this.eventBus.on('smart-cart:item-removed', () => this.triggerOptimization('item_removed'));
    this.eventBus.on('smart-cart:quantity-updated', () => this.triggerOptimization('quantity_updated'));
    this.eventBus.on('smart-cart:seller-changed', () => this.triggerOptimization('seller_changed'));
    this.eventBus.on('smart-cart:variation-changed', () => this.triggerOptimization('variation_changed'));
    this.eventBus.on('smart-cart:cart-opened', () => this.triggerOptimization('cart_opened'));

    console.log('📡 Event listeners set up for automatic optimization');
  }

  /**
   * Trigger optimization with debouncing
   */
  async triggerOptimization(reason = 'manual', delay = 500) {
    if (!this.settings.autoCalculateOnChange && reason !== 'manual') {
      return;
    }

    // Skip optimization if no cart items available
    const cartItems = this.getCartItems();
    if (cartItems.length === 0 && reason !== 'manual') {
      console.log(`ℹ️ Skipping optimization - no cart items available (reason: ${reason})`);
      return this.createEmptyCartResult();
    }

    console.log(`🔄 Optimization triggered: ${reason}`);

    // Debounce optimization calls
    if (this.currentCalculationPromise) {
      console.log('⏳ Optimization already in progress, waiting...');
      return this.currentCalculationPromise;
    }

    // Add delay for user interaction debouncing
    if (delay > 0) {
      await new Promise(resolve => setTimeout(resolve, delay));
    }

    return this.optimizeCurrentCart();
  }

  /**
   * Main optimization function that fetches fresh data and calculates optimal cart
   */
  async optimizeCurrentCart(options = {}) {
    if (this.isCalculating) {
      console.log('⏳ Optimization already in progress');
      return this.currentCalculationPromise;
    }

    this.isCalculating = true;
    this.currentCalculationPromise = this._performOptimization(options);

    try {
      const result = await this.currentCalculationPromise;
      return result;
    } finally {
      this.isCalculating = false;
      this.currentCalculationPromise = null;
      this.lastCalculationTime = Date.now();
    }
  }

  /**
   * Perform the actual optimization process
   */
  async _performOptimization(options = {}) {
    try {
      console.log('🧮 Starting Smart Cart optimization...');

      // Emit optimization started event
      this.eventBus?.emit('optimization-started', { timestamp: Date.now() });

      // Step 1: Get current cart items
      const cartItems = this.getCartItems();

      if (!Array.isArray(cartItems) || cartItems.length === 0) {
        console.log('📋 No cart items found or invalid cart data');
        return this.createEmptyCartResult();
      }

      // Validate cart items structure
      const validCartItems = this.validateAndCleanCartItems(cartItems);
      if (validCartItems.length === 0) {
        console.warn('⚠️ No valid cart items after validation');
        return this.createEmptyCartResult();
      }

      console.log(`📋 Optimizing ${validCartItems.length} cart items (${cartItems.length - validCartItems.length} invalid items filtered out)`);

      // Step 2: Fetch fresh product data from API
      const freshProductData = await this.fetchFreshProductData(validCartItems);

      // Step 3: Extract seller and pricing information using dual-layer approach
      const sellerData = this.extractSellerData(freshProductData, validCartItems);

      // Step 4: Run basket optimization if enabled (uses filtered algorithm layer)
      let optimizationResult = null;
      if (this.settings.enableOptimization && this.basketOptimizer) {
        optimizationResult = await this.runBasketOptimization(validCartItems, sellerData, options);
      }

      // Step 5: Calculate current cart totals
      const currentCartTotals = this.calculateCurrentCartTotals(validCartItems, freshProductData);

      // Step 6: Create comprehensive result (includes both UI and algorithm layers)
      const result = this.createOptimizationResult({
        cartItems: validCartItems,
        freshProductData,
        sellerData,
        optimizationResult,
        currentCartTotals,
        options
      });

      console.log('✅ Smart Cart optimization completed:', result.summary);

      // Emit optimization completed event
      this.eventBus?.emit('optimization-completed', {
        result,
        timestamp: Date.now(),
        duration: Date.now() - (this.lastCalculationTime || Date.now())
      });

      return result;

    } catch (error) {
      console.error('❌ Smart Cart optimization failed:', error);

      const errorResult = {
        success: false,
        error: error.message,
        timestamp: Date.now(),
        cartItems: this.getCartItems(),
        summary: {
          totalItems: this.getCartItems().length,
          totalValue: 0,
          optimizationSavings: 0,
          recommendationsCount: 0
        }
      };

      // Emit optimization error event
      this.eventBus?.emit('optimization-error', { error: error.message, result: errorResult });

      return errorResult;
    }
  }

  /**
   * Get current cart items from Smart Cart Manager
   */
  getCartItems() {
    console.log('🔍 Enhanced Smart Cart Optimizer - getCartItems called');
    if (!this.smartCartManager) {
      console.log('⚠️ No smartCartManager available');
      return [];
    }

    try {
      console.log('📋 smartCartManager available:', !!this.smartCartManager);
      console.log('📋 smartCartManager.cart:', this.smartCartManager.cart);
      console.log('📋 smartCartManager.getCartItems function:', typeof this.smartCartManager.getCartItems);

      const result = this.smartCartManager.cart || this.smartCartManager.getCartItems?.() || [];

      console.log('📋 Enhanced Smart Cart Optimizer - Raw cart data received:');
      console.log('  Items count:', result.length);
      console.log('  Detailed items:', result.map((item, index) => ({
        index,
        id: item.id,
        productId: item.pId || item.productId,
        variantId: item.vId || item.variantId,
        title: item._c?.t || item.productTitle || 'Unknown',
        price: item.price || 0,
        quantity: item.qty || item.quantity || 1,
        hasApiData: !!(item.price && item.productTitle),
        cacheStatus: item._c ? {
          title: item._c.t,
          lastFetched: item._c.lf,
          needsRefresh: item._c.nr
        } : 'No cache',
        sellers: item.sellers ? item.sellers.length : 0
      })));

      return result;
    } catch (error) {
      console.error('❌ Error getting cart items:', error);
      return [];
    }
  }

  /**
   * Fetch fresh product data from Digikala API
   */
  async fetchFreshProductData(cartItems) {
    if (!this.apiService || !this.settings.enableAPIRefresh) {
      console.log('⚠️ API service not available or disabled, using cached data');
      return this.getFallbackProductData(cartItems);
    }

    try {
      console.log('🌐 Fetching fresh product data from API...');

      const productRequests = cartItems.map(item => ({
        productId: item.pId || item.productId,
        variantId: item.vId || item.variantId,
        includeVariant: !!(item.vId || item.variantId),
        includeSellers: true,
        includePricing: true
      }));

      const results = await this.apiService.fetchMultipleProducts(productRequests, {
        priority: 'high',
        freshData: true,
        timeout: 8000
      });

      console.log(`✅ Fetched data for ${Object.keys(results).length} products`);
      return results;

    } catch (error) {
      console.error('❌ Error fetching fresh product data:', error);
      return this.getFallbackProductData(cartItems);
    }
  }

  /**
   * Get fallback product data when API is unavailable
   */
  getFallbackProductData(cartItems) {
    const fallbackData = {};

    cartItems.forEach(item => {
      const productId = item.pId || item.productId;
      const variantId = item.vId || item.variantId;
      const price = item.price || item._c?.price || 0;
      const title = item.productTitle || item._c?.t || 'نام محصول نامشخص';

      fallbackData[productId] = {
        success: true,
        data: {
          id: productId,
          title: title,
          price: {
            selling_price: price
          },
          default_variant: variantId ? {
            id: variantId,
            price: {
              selling_price: price
            }
          } : null,
          sellers: [
            {
              id: 'digikala',
              name: 'دیجی‌کالا',
              price: price,
              inventory: 10,
              shipsDirectly: false,
              rating: 4.5
            }
          ]
        },
        source: 'fallback',
        timestamp: Date.now()
      };
    });

    return fallbackData;
  }

  /**
   * Extract complete variant and seller data using dual-layer approach
   * UI Layer: Complete options for all variants and sellers
   * Algorithm Layer: Filtered based on user constraints
   */
  extractSellerData(freshProductData, cartItems) {
    const sellers = {};
    const productOptions = {}; // UI Layer - complete variant/seller data
    const productSellers = {}; // Algorithm Layer - filtered data for optimization

    // Validate inputs
    if (!freshProductData || typeof freshProductData !== 'object') {
      console.warn('⚠️ Invalid freshProductData, using fallback seller data');
      return this.generateFallbackSellerData(cartItems);
    }

    if (!Array.isArray(cartItems) || cartItems.length === 0) {
      console.warn('⚠️ Invalid or empty cartItems');
      return {
        sellers: { 'digikala': { shippingCost: 0 } },
        productOptions: {},
        productSellers: {},
        marketplaceShipping: { cost: 0, freeThreshold: 150000 }
      };
    }

    // Default sellers
    sellers['digikala'] = { shippingCost: 0, name: 'دیجی‌کالا', rating: 4.5 };
    sellers['fresh'] = { shippingCost: 0, name: 'دیجی‌کالا فرش', rating: 4.7 };

    cartItems.forEach(item => {
      const productId = item.pId || item.productId;
      const userSelectedVariant = item.vId || item.variantId;
      const userSelectedSeller = item.selectedSeller;

      if (!productId) {
        console.warn('⚠️ Cart item missing product ID:', item);
        return;
      }

      const productData = freshProductData[productId];

      // Handle real Digikala API response structure
      if (productData?.success && productData.data) {
        let apiProductData = null;

        console.log(`🔍 DEBUG - Raw productData for ${productId}:`, {
          hasSuccess: !!productData.success,
          hasData: !!productData.data,
          dataKeys: Object.keys(productData.data || {}),
          hasZoneTop: !!productData.data.zone_top,
          hasZoneTopProducts: !!(productData.data.zone_top?.products),
          zoneTopProductsLength: productData.data.zone_top?.products?.length || 0,
          hasDirectId: !!productData.data.id,
          hasDefaultVariant: !!productData.data.default_variant
        });

        // Check if this is the real API format with zone_top.products[]
        if (productData.data.zone_top?.products && Array.isArray(productData.data.zone_top.products)) {
          apiProductData = productData.data.zone_top.products.find(p => p.id == productId);
          console.log(`🔍 Found product in zone_top.products for ID ${productId}:`, !!apiProductData);
          if (apiProductData) {
            console.log(`🔍 DEBUG - API product data structure:`, {
              id: apiProductData.id,
              hasVariants: !!(apiProductData.variants),
              variantsLength: apiProductData.variants?.length || 0,
              hasDefaultVariant: !!apiProductData.default_variant,
              hasPrice: !!apiProductData.price,
              hasSellers: !!apiProductData.sellers
            });
          }
        }
        // Legacy format (direct product data)
        else if (productData.data.id || productData.data.default_variant) {
          apiProductData = productData.data;
          console.log(`🔍 DEBUG - Using legacy format for ${productId}`);
        }

        if (apiProductData) {
          // UI Layer: Extract ALL variants and sellers
          const completeOptions = this.extractCompleteVariantSellerOptions(apiProductData);
          productOptions[productId] = completeOptions;

          console.log(`🔍 DEBUG - Complete options extracted for ${productId}:`, {
            totalVariants: Object.keys(completeOptions).length,
            variantDetails: Object.entries(completeOptions).map(([vId, vData]) => ({
              variantId: vId,
              sellersCount: Object.keys(vData.sellers).length,
              sellerIds: Object.keys(vData.sellers)
            }))
          });

          // Algorithm Layer: Filter based on user constraints
          const filteredOptions = this.filterOptionsForOptimization(
            completeOptions,
            userSelectedVariant,
            userSelectedSeller,
            item
          );

          // Convert filtered options to the format expected by optimizer
          productSellers[productId] = this.convertToOptimizerFormat(filteredOptions, sellers);

          console.log(`✅ Dual-layer data for product ${productId}:`, {
            totalVariants: Object.keys(completeOptions).length,
            filteredOptions: productSellers[productId].length,
            userConstraints: { variant: userSelectedVariant, seller: userSelectedSeller }
          });
        } else {
          console.warn(`⚠️ No product data found for ${productId} - productData structure:`, productData);
          this.createFallbackSellerForProduct(productId, item, productSellers, productOptions, sellers);
        }
      } else {
        console.warn(`⚠️ Invalid or unsuccessful product data for ${productId}:`, productData);
        this.createFallbackSellerForProduct(productId, item, productSellers, productOptions, sellers);
      }
    });

    console.log(`🏪 Dual-layer extraction complete:`, {
      products: Object.keys(productOptions).length,
      totalSellers: Object.keys(sellers).length,
      uiOptions: Object.keys(productOptions).length,
      algorithmOptions: Object.keys(productSellers).length
    });

    console.log('🔍 DEBUG - productOptions structure:', productOptions);
    console.log('🔍 DEBUG - productSellers structure:', productSellers);
    console.log('🔍 DEBUG - freshProductData available:', !!freshProductData);
    console.log('🔍 DEBUG - freshProductData keys:', Object.keys(freshProductData || {}));

    return {
      sellers,
      productOptions, // UI Layer - complete variant/seller data
      productSellers, // Algorithm Layer - filtered data for optimization
      marketplaceShipping: 8000
    };
  }

  /**
   * Extract complete variant and seller options for UI layer
   */
  extractCompleteVariantSellerOptions(apiProductData) {
    const variantOptions = {};

    console.log(`🔍 DEBUG - extractCompleteVariantSellerOptions called with:`, {
      hasVariants: !!(apiProductData.variants),
      variantsLength: apiProductData.variants?.length || 0,
      hasDefaultVariant: !!apiProductData.default_variant,
      apiProductDataKeys: Object.keys(apiProductData || {})
    });

    // Handle variants array if available
    if (apiProductData.variants && Array.isArray(apiProductData.variants)) {
      console.log(`🔍 DEBUG - Processing ${apiProductData.variants.length} variants from API`);
      apiProductData.variants.forEach((variant, index) => {
        console.log(`🔍 DEBUG - Variant ${index + 1}:`, {
          hasId: !!variant.id,
          hasSeller: !!variant.seller,
          hasPrice: !!variant.price,
          hasSellingPrice: !!variant.price?.selling_price,
          variantKeys: Object.keys(variant || {})
        });

        if (variant.id && variant.seller && variant.price?.selling_price) {
          const variantId = variant.id.toString();
          const sellerId = variant.seller.id.toString();

          if (!variantOptions[variantId]) {
            variantOptions[variantId] = {
              variantInfo: {
                id: variantId,
                color: variant.color,
                size: variant.size,
                warranty: variant.warranty,
                displayName: variant.selector_type?.display_name
              },
              sellers: {}
            };
          }

          variantOptions[variantId].sellers[sellerId] = {
            sellerId: sellerId,
            name: variant.seller.title || variant.seller.name || `فروشنده ${sellerId}`,
            price: variant.price.selling_price,
            inventory: variant.price.marketable_stock || 5,
            shipsDirectly: !variant.properties?.in_digikala_warehouse || false,
            rating: variant.seller.rating?.total_rate ? (variant.seller.rating.total_rate / 20) : variant.seller.stars || 4.0,
            shippingCost: variant.properties?.is_ship_by_seller ? 15000 : 0
          };

          console.log(`✅ DEBUG - Added variant ${variantId} with seller ${sellerId}`);
        } else {
          console.log(`❌ DEBUG - Skipped variant ${index + 1} - missing required fields`);
        }
      });
    } else {
      console.log(`⚠️ DEBUG - No variants array found or invalid variants`);
    }

    // Handle default variant
    if (apiProductData.default_variant && apiProductData.default_variant.seller) {
      const defaultVariant = apiProductData.default_variant;
      const variantId = defaultVariant.id ? defaultVariant.id.toString() : 'default';
      const sellerId = defaultVariant.seller.id.toString();

      if (!variantOptions[variantId]) {
        variantOptions[variantId] = {
          variantInfo: {
            id: variantId,
            color: defaultVariant.color,
            size: defaultVariant.size,
            warranty: defaultVariant.warranty,
            displayName: defaultVariant.selector_type?.display_name || 'پیش‌فرض'
          },
          sellers: {}
        };
      }

      variantOptions[variantId].sellers[sellerId] = {
        sellerId: sellerId,
        name: defaultVariant.seller.title || defaultVariant.seller.name || `فروشنده ${sellerId}`,
        price: defaultVariant.price?.selling_price || 0,
        inventory: defaultVariant.price?.marketable_stock || 5,
        shipsDirectly: !defaultVariant.properties?.in_digikala_warehouse || false,
        rating: defaultVariant.seller.rating?.total_rate ? (defaultVariant.seller.rating.total_rate / 20) : defaultVariant.seller.stars || 4.0,
        shippingCost: defaultVariant.properties?.is_ship_by_seller ? 15000 : 0
      };
    }

    return variantOptions;
  }

  /**
   * Filter variant/seller options based on user constraints for optimization algorithm
   */
  filterOptionsForOptimization(completeOptions, userSelectedVariant, userSelectedSeller, cartItem) {
    const filteredOptions = [];

    console.log(`🔍 DEBUG - filterOptionsForOptimization called:`, {
      productId: cartItem.pId || cartItem.productId,
      userSelectedVariant,
      userSelectedSeller,
      completeOptionsKeys: Object.keys(completeOptions),
      completeOptionsEmpty: Object.keys(completeOptions).length === 0
    });

    // If user selected a specific variant and seller -> only include that option
    if (userSelectedVariant && userSelectedSeller && userSelectedSeller !== 'all') {
      console.log(`🎯 DEBUG - Specific variant AND seller selected`);
      const variantData = completeOptions[userSelectedVariant];
      if (variantData && variantData.sellers[userSelectedSeller]) {
        filteredOptions.push({
          variantId: userSelectedVariant,
          ...variantData.sellers[userSelectedSeller]
        });
        console.log(`✅ DEBUG - Added specific variant+seller option`);
      } else {
        console.log(`❌ DEBUG - Specific variant+seller not found in completeOptions`);
      }
    }
    // If user selected a specific variant -> include all sellers for that variant
    else if (userSelectedVariant && completeOptions[userSelectedVariant]) {
      console.log(`🎯 DEBUG - Specific variant selected, all sellers`);
      const variantData = completeOptions[userSelectedVariant];
      Object.values(variantData.sellers).forEach(seller => {
        filteredOptions.push({
          variantId: userSelectedVariant,
          ...seller
        });
      });
      console.log(`✅ DEBUG - Added ${Object.keys(variantData.sellers).length} sellers for variant`);
    }
    // If user selected a specific seller -> include that seller across all variants
    else if (userSelectedSeller && userSelectedSeller !== 'all') {
      console.log(`🎯 DEBUG - Specific seller selected across all variants`);
      Object.entries(completeOptions).forEach(([variantId, variantData]) => {
        if (variantData.sellers[userSelectedSeller]) {
          filteredOptions.push({
            variantId: variantId,
            ...variantData.sellers[userSelectedSeller]
          });
        }
      });
      console.log(`✅ DEBUG - Added seller ${userSelectedSeller} across variants`);
    }
    // No constraints -> include all options for optimization
    else {
      console.log(`🎯 DEBUG - NO CONSTRAINTS - should include ALL options`);
      console.log(`🔍 DEBUG - Condition analysis:`, {
        userSelectedVariant: !!userSelectedVariant,
        userSelectedSeller: userSelectedSeller,
        isSellerAll: userSelectedSeller === 'all',
        shouldIncludeAllOptions: !userSelectedVariant && (!userSelectedSeller || userSelectedSeller === 'all')
      });
      console.log(`🔍 DEBUG - completeOptions structure:`, completeOptions);

      let totalOptionsAdded = 0;
      Object.entries(completeOptions).forEach(([variantId, variantData]) => {
        console.log(`🔍 DEBUG - Processing variant ${variantId} with ${Object.keys(variantData.sellers).length} sellers`);
        Object.values(variantData.sellers).forEach(seller => {
          filteredOptions.push({
            variantId: variantId,
            ...seller
          });
          totalOptionsAdded++;
        });
      });
      console.log(`✅ DEBUG - Added ${totalOptionsAdded} total options (all variants & sellers)`);
    }

    console.log(`🔍 DEBUG - Before fallback check: filteredOptions.length = ${filteredOptions.length}`);

    // Fallback if no options found
    if (filteredOptions.length === 0) {
      console.log(`⚠️ DEBUG - NO OPTIONS FOUND! Applying fallback to Digikala`);
      console.log(`🔍 DEBUG - Fallback context:`, {
        userSelectedVariant,
        userSelectedSeller,
        completeOptionsEmpty: Object.keys(completeOptions).length === 0,
        cartItemPrice: cartItem.price,
        cartItemCachedPrice: cartItem._c?.price
      });

      const fallbackPrice = cartItem.price || cartItem._c?.price || 0;
      filteredOptions.push({
        variantId: userSelectedVariant || 'default',
        sellerId: userSelectedSeller === 'all' ? 'digikala' : (userSelectedSeller || 'digikala'),
        name: 'دیجی‌کالا',
        price: fallbackPrice,
        inventory: 5,
        shipsDirectly: false,
        rating: 4.5,
        shippingCost: 0
      });
      console.log(`✅ DEBUG - Fallback option created`);
    }

    console.log(`📊 DEBUG - Final filteredOptions:`, filteredOptions.map(opt => ({
      variantId: opt.variantId,
      sellerId: opt.sellerId,
      price: opt.price
    })));

    return filteredOptions;
  }

  /**
   * Convert filtered options to format expected by basket optimizer
   */
  convertToOptimizerFormat(filteredOptions, globalSellers) {
    return filteredOptions.map(option => {
      // Ensure seller exists in global sellers list
      if (!globalSellers[option.sellerId]) {
        globalSellers[option.sellerId] = {
          shippingCost: option.shippingCost || 0,
          name: option.name || `فروشنده ${option.sellerId}`,
          rating: option.rating || 4.0
        };
      }

      return {
        sellerId: option.sellerId,
        price: option.price,
        inventory: option.inventory,
        shipsDirectly: option.shipsDirectly,
        rating: option.rating,
        variantId: option.variantId // Include variant information for tracking
      };
    });
  }

  /**
   * Create fallback seller data for a product when API data is missing/invalid
   */
  createFallbackSellerForProduct(productId, item, productSellers, productOptions, sellers) {
    const fallbackPrice = item.price || item._cached?.price || item._c?.price || 0;
    const userSelectedSeller = item.selectedSeller;
    const fallbackVariantId = item.vId || item.variantId || 'default';

    console.log(`🔄 DEBUG - Creating fallback seller for product ${productId}:`, {
      fallbackPrice,
      userSelectedSeller,
      fallbackVariantId,
      itemPrice: item.price,
      itemCachedPrice: item._c?.price,
      shouldCreateAllSellers: !userSelectedSeller || userSelectedSeller === 'all'
    });

    // Define fallback sellers - create multiple if "all" is selected
    const fallbackSellers = [];

    if (!userSelectedSeller || userSelectedSeller === 'all') {
      // User wants all sellers - create multiple seller options
      console.log(`🔄 DEBUG - Creating multiple fallback sellers for 'all sellers' selection`);
      fallbackSellers.push(
        {
          sellerId: 'digikala',
          name: 'دیجی‌کالا',
          price: fallbackPrice,
          inventory: 10,
          shipsDirectly: false,
          rating: 4.5,
          shippingCost: 0
        },
        {
          sellerId: 'fresh',
          name: 'دیجی‌کالا فرش',
          price: Math.floor(fallbackPrice * 0.95), // Slightly lower price
          inventory: 5,
          shipsDirectly: false,
          rating: 4.7,
          shippingCost: 0
        },
        {
          sellerId: 'seller_1',
          name: 'فروشنده محبوب',
          price: Math.floor(fallbackPrice * 0.92), // Better price
          inventory: 3,
          shipsDirectly: true,
          rating: 4.2,
          shippingCost: 15000
        }
      );
    } else {
      // User selected a specific seller
      console.log(`🔄 DEBUG - Creating single fallback seller for specific selection: ${userSelectedSeller}`);
      fallbackSellers.push({
        sellerId: userSelectedSeller,
        name: userSelectedSeller === 'digikala' ? 'دیجی‌کالا' : userSelectedSeller === 'fresh' ? 'دیجی‌کالا فرش' : `فروشنده ${userSelectedSeller}`,
        price: fallbackPrice,
        inventory: 5,
        shipsDirectly: userSelectedSeller !== 'digikala' && userSelectedSeller !== 'fresh',
        rating: userSelectedSeller === 'fresh' ? 4.7 : 4.5,
        shippingCost: userSelectedSeller !== 'digikala' && userSelectedSeller !== 'fresh' ? 15000 : 0
      });
    }

    // Create UI layer data (productOptions)
    const sellersData = {};
    fallbackSellers.forEach(seller => {
      sellersData[seller.sellerId] = seller;
    });

    productOptions[productId] = {
      [fallbackVariantId]: {
        variantInfo: {
          id: fallbackVariantId,
          displayName: 'پیش‌فرض'
        },
        sellers: sellersData
      }
    };

    // Create algorithm layer data (productSellers)
    productSellers[productId] = fallbackSellers.map(seller => ({
      sellerId: seller.sellerId,
      price: seller.price,
      inventory: seller.inventory,
      shipsDirectly: seller.shipsDirectly,
      rating: seller.rating,
      variantId: fallbackVariantId
    }));

    // Ensure all fallback sellers exist in global sellers
    fallbackSellers.forEach(seller => {
      if (!sellers[seller.sellerId]) {
        sellers[seller.sellerId] = {
          shippingCost: seller.shippingCost,
          name: seller.name,
          rating: seller.rating
        };
      }
    });

    console.log(`✅ DEBUG - Fallback sellers created for ${productId}: ${fallbackSellers.length} sellers (both UI and algorithm layers)`);
  }

  /**
   * Generate fallback seller data when API data is unavailable
   */
  generateFallbackSellerData(cartItems) {
    const sellers = {
      'digikala': { shippingCost: 0, name: 'دیجی‌کالا', rating: 4.5 }
    };
    const productOptions = {};
    const productSellers = {};

    if (Array.isArray(cartItems)) {
      cartItems.forEach(item => {
        const productId = item.pId || item.productId;
        if (productId) {
          const price = item.price || item._c?.price || 0;
          const variantId = item.vId || item.variantId || 'default';

          // UI Layer - complete options
          productOptions[productId] = {
            [variantId]: {
              variantInfo: {
                id: variantId,
                displayName: 'پیش‌فرض'
              },
              sellers: {
                'digikala': {
                  sellerId: 'digikala',
                  name: 'دیجی‌کالا',
                  price: price,
                  inventory: 5,
                  shipsDirectly: false,
                  rating: 4.5,
                  shippingCost: 0
                }
              }
            }
          };

          // Algorithm Layer - filtered options
          productSellers[productId] = [
            {
              sellerId: 'digikala',
              price: price,
              inventory: 5,
              shipsDirectly: false,
              rating: 4.5,
              variantId: variantId
            }
          ];
        }
      });
    }

    return {
      sellers,
      productOptions,
      productSellers,
      marketplaceShipping: 8000
    };
  }

  /**
   * Validate and clean cart items to ensure they have required fields
   */
  validateAndCleanCartItems(cartItems) {
    if (!Array.isArray(cartItems)) {
      console.warn('⚠️ Cart items is not an array:', typeof cartItems);
      return [];
    }

    const validItems = cartItems.filter(item => {
      if (!item || typeof item !== 'object') {
        console.warn('⚠️ Invalid cart item (not an object):', item);
        return false;
      }

      const productId = item.pId || item.productId;
      if (!productId) {
        console.warn('⚠️ Cart item missing product ID:', item);
        return false;
      }

      const quantity = item.qty || item.quantity;
      if (!quantity || quantity <= 0) {
        console.warn('⚠️ Cart item has invalid quantity:', item);
        return false;
      }

      return true;
    });

    console.log(`✅ Validated ${validItems.length}/${cartItems.length} cart items`);
    return validItems;
  }

  /**
   * Run basket optimization if available
   */
  async runBasketOptimization(cartItems, sellerData, options) {
    if (!this.basketOptimizer) {
      console.log('⚠️ Basket optimizer not available');
      return null;
    }

    try {
      console.log('🔍 ALGORITHM INPUT - Basket optimization detailed data:');
      console.log('  Cart Items Input:');
      cartItems.forEach((item, index) => {
        console.log(`    Item ${index + 1}:`, {
          productId: item.pId || item.productId,
          title: item._c?.t || item.productTitle || 'Unknown',
          quantity: item.qty || item.quantity || 1,
          price: item.price || 0,
          variantId: item.vId || item.variantId,
          selectedSeller: item.selectedSeller
        });
      });

      console.log('  Seller Data Structure:');
      console.log('    Global Sellers:', Object.keys(sellerData.sellers || {}).map(sellerId => ({
        sellerId,
        name: sellerData.sellers[sellerId].name,
        shippingCost: sellerData.sellers[sellerId].shippingCost
      })));

      console.log('    Product Sellers (Algorithm Layer):');
      Object.entries(sellerData.productSellers || {}).forEach(([productId, sellers]) => {
        console.log(`      Product ${productId}:`, sellers.map(seller => ({
          sellerId: seller.sellerId,
          price: seller.price,
          inventory: seller.inventory,
          variantId: seller.variantId
        })));
      });

      console.log('    UI Options (Complete Layer):');
      Object.entries(sellerData.productOptions || {}).forEach(([productId, variants]) => {
        console.log(`      Product ${productId} variants:`, Object.keys(variants).length);
        Object.entries(variants).forEach(([variantId, variantData]) => {
          console.log(`        Variant ${variantId}: ${Object.keys(variantData.sellers).length} sellers`);
        });
      });

      const basketData = this.convertCartToBasketData(cartItems, sellerData, options);

      console.log('🔄 ALGORITHM INPUT - Converted basket data for optimization:');
      console.log('  Products for optimization:', basketData.products.length);
      basketData.products.forEach((product, index) => {
        console.log(`    Product ${index + 1}:`, {
          id: product.id,
          quantity: product.quantity,
          availableSellers: product.sellers.length,
          preferredSeller: product.preferredSeller,
          preferredVariant: product.preferredVariant,
          userConstraints: product.userConstraints,
          sellerOptions: product.sellers.map(s => ({
            sellerId: s.sellerId,
            price: s.price,
            variantId: s.variantId
          }))
        });
      });
      console.log('  Global settings:', {
        optimizationMode: basketData.optimizationMode,
        maxSellers: basketData.maxSellers,
        marketplaceShipping: basketData.marketplaceShipping
      });

      console.log('🧮 Running basket optimization algorithm...');
      const result = await this.basketOptimizer.optimizeBasket(basketData);

      console.log('📊 ALGORITHM OUTPUT - Detailed optimization result:');
      console.log('  Success:', result.success);
      console.log('  Total Cost:', result.totalCost);
      console.log('  Product Cost:', result.totalProductCost);
      console.log('  Shipping Cost:', result.totalShippingCost);
      console.log('  Savings:', result.totalSavings || 0);
      console.log('  Sellers Used:', result.sellersUsed);

      if (result.assignments && result.assignments.length > 0) {
        console.log('  Product Assignments:');
        result.assignments.forEach((assignment, index) => {
          console.log(`    Assignment ${index + 1}:`, {
            productId: assignment.productId,
            sellerId: assignment.sellerId,
            variantId: assignment.variantId,
            quantity: assignment.quantity,
            unitPrice: assignment.unitPrice,
            totalPrice: assignment.totalPrice
          });
        });
      } else {
        console.log('  No assignments found in result');
      }

      if (result.error) {
        console.log('  Error:', result.error);
      }

      return result;

    } catch (error) {
      console.error('❌ Basket optimization error:', error);
      console.error('❌ Error stack:', error.stack);
      return {
        success: false,
        error: error.message,
        assignments: [],
        totalProductCost: 0,
        totalShippingCost: 0,
        totalCost: 0,
        sellersUsed: []
      };
    }
  }

  /**
   * Convert cart items to basket optimization format using dual-layer approach
   * Uses the algorithm layer (filtered data) for optimization
   */
  convertCartToBasketData(cartItems, sellerData, options) {
    const products = cartItems.map(item => {
      const productId = item.pId || item.productId;
      const quantity = item.qty || item.quantity || 1;
      const userSelectedVariant = item.vId || item.variantId;
      const userSelectedSeller = item.selectedSeller;

      if (!productId) {
        console.error('❌ Cart item missing product ID:', item);
        return null;
      }

      // Use algorithm layer data (already filtered based on user constraints)
      const algorithmLayerSellers = sellerData.productSellers[productId] || [];

      if (algorithmLayerSellers.length === 0) {
        console.warn(`⚠️ No algorithm layer sellers found for product ${productId}`);
        return null;
      }

      // Validate preferred seller against filtered options
      let preferredSeller = undefined;
      if (userSelectedSeller && userSelectedSeller !== 'all') {
        const sellerExists = algorithmLayerSellers.some(seller => seller.sellerId === userSelectedSeller);
        if (sellerExists) {
          preferredSeller = userSelectedSeller;
        } else {
          console.warn(`⚠️ Preferred seller '${userSelectedSeller}' not available in filtered options for product ${productId}`);
        }
      }

      // Validate preferred variant against filtered options
      let preferredVariant = undefined;
      if (userSelectedVariant) {
        const variantExists = algorithmLayerSellers.some(seller => seller.variantId === userSelectedVariant);
        if (variantExists) {
          preferredVariant = userSelectedVariant;
        } else {
          console.warn(`⚠️ Preferred variant '${userSelectedVariant}' not available in filtered options for product ${productId}`);
        }
      }

      console.log(`📊 Product ${productId} optimization data:`, {
        algorithmLayerOptions: algorithmLayerSellers.length,
        userConstraints: { variant: userSelectedVariant, seller: userSelectedSeller },
        validatedConstraints: { variant: preferredVariant, seller: preferredSeller }
      });

      return {
        id: productId,
        quantity: quantity,
        sellers: algorithmLayerSellers, // Algorithm layer - respects user constraints
        preferredSeller: preferredSeller,
        preferredVariant: preferredVariant,
        userConstraints: {
          selectedVariant: userSelectedVariant,
          selectedSeller: userSelectedSeller
        }
      };
    }).filter(Boolean); // Remove null entries

    return {
      products,
      sellers: sellerData.sellers,
      marketplaceShipping: sellerData.marketplaceShipping,
      optimizationMode: options.mode || this.settings.optimizationMode,
      maxSellers: options.maxSellers || 5,
      preferredSellers: options.preferredSellers || this.settings.preferredSellers
    };
  }

  /**
   * Calculate current cart totals
   */
  calculateCurrentCartTotals(cartItems, freshProductData) {
    let totalItems = 0;
    let totalValue = 0;
    let totalOriginalValue = 0;

    cartItems.forEach(item => {
      const quantity = item.qty || item.quantity || 1;
      totalItems += quantity;

      const currentPrice = this.getCurrentItemPrice(item, freshProductData);
      totalValue += currentPrice * quantity;

      const originalPrice = item.originalPrice || currentPrice;
      totalOriginalValue += originalPrice * quantity;
    });

    return {
      totalItems,
      totalValue,
      totalOriginalValue,
      totalSavings: totalOriginalValue - totalValue,
      averageItemPrice: totalItems > 0 ? totalValue / totalItems : 0
    };
  }

  /**
   * Get current price for an item from fresh data
   * Fixed to handle real Digikala API structure: data.zone_top.products[]
   */
  getCurrentItemPrice(item, freshProductData) {
    const productId = item.pId || item.productId;
    const productData = freshProductData[productId];

    if (productData?.success && productData.data) {
      let apiProductData = null;

      // Check if this is the real API format with zone_top.products[]
      if (productData.data.zone_top?.products && Array.isArray(productData.data.zone_top.products)) {
        // Find the matching product in the zone_top.products array
        apiProductData = productData.data.zone_top.products.find(p => p.id == productId);
      }
      // Legacy format (direct product data)
      else if (productData.data.id || productData.data.default_variant) {
        apiProductData = productData.data;
      }

      // Extract price from the correct structure
      if (apiProductData?.default_variant?.price?.selling_price) {
        return apiProductData.default_variant.price.selling_price;
      }

      // Fallback to direct price if available
      if (apiProductData?.price?.selling_price) {
        return apiProductData.price.selling_price;
      }
    }

    // Fallback to stored price or 0
    return item.price || item._cached?.price || item._c?.price || 0;
  }

  /**
   * Create comprehensive optimization result
   */
  createOptimizationResult({ cartItems, freshProductData, sellerData, optimizationResult, currentCartTotals, options }) {
    const result = {
      success: true,
      timestamp: Date.now(),
      cartItems: cartItems.length,

      // Current cart information
      currentCart: {
        items: cartItems,
        totals: currentCartTotals,
        sellers: this.getCurrentCartSellers(cartItems)
      },

      // Fresh product data and dual-layer seller information
      productData: freshProductData,
      sellerData,

      // UI Layer - complete variant/seller options for user interface
      uiOptions: sellerData.productOptions || {},

      // Optimization results (based on algorithm layer)
      optimization: optimizationResult ? {
        success: optimizationResult.success,
        totalCost: optimizationResult.totalCost,
        totalSavings: optimizationResult.totalSavings || 0,
        sellersUsed: optimizationResult.sellersUsed || [],
        assignments: optimizationResult.assignments || [],
        recommendations: this.generateRecommendations(optimizationResult, currentCartTotals)
      } : null,

      // Summary for UI display
      summary: {
        totalItems: currentCartTotals.totalItems,
        totalValue: currentCartTotals.totalValue,
        originalValue: currentCartTotals.totalOriginalValue,
        currentSavings: currentCartTotals.totalSavings,
        optimizationSavings: optimizationResult?.totalSavings || 0,
        bestSellers: this.getBestSellers(sellerData, optimizationResult),
        recommendationsCount: optimizationResult ? (optimizationResult.assignments?.length || 0) : 0,
        calculationTime: Date.now() - (this.lastCalculationTime || Date.now())
      }
    };

    console.log('📋 FINAL RESULT - Comprehensive optimization result created:');
    console.log('  Success:', result.success);
    console.log('  Cart Items Count:', result.cartItems);
    console.log('  Current Cart Totals:', {
      totalItems: result.currentCart.totals.totalItems,
      totalValue: result.currentCart.totals.totalValue,
      totalSavings: result.currentCart.totals.totalSavings
    });
    console.log('  Current Cart Sellers:', result.currentCart.sellers);

    if (result.optimization) {
      console.log('  Optimization Results:', {
        success: result.optimization.success,
        totalCost: result.optimization.totalCost,
        totalSavings: result.optimization.totalSavings,
        sellersUsed: result.optimization.sellersUsed,
        assignmentsCount: result.optimization.assignments.length
      });

      if (result.optimization.assignments.length > 0) {
        console.log('  Optimization Assignments:');
        result.optimization.assignments.forEach((assignment, index) => {
          console.log(`    ${index + 1}. Product ${assignment.productId}: ${assignment.sellerId} - ${assignment.unitPrice} x ${assignment.quantity} = ${assignment.totalPrice}`);
        });
      }
    } else {
      console.log('  No optimization results available');
    }

    console.log('  UI Options Available:', Object.keys(result.uiOptions).length, 'products');
    Object.entries(result.uiOptions).forEach(([productId, variants]) => {
      const variantCount = Object.keys(variants).length;
      const totalSellers = Object.values(variants).reduce((sum, variant) => sum + Object.keys(variant.sellers).length, 0);
      console.log(`    Product ${productId}: ${variantCount} variants, ${totalSellers} total seller options`);
    });

    console.log('  Summary for UI:', {
      totalItems: result.summary.totalItems,
      totalValue: result.summary.totalValue,
      optimizationSavings: result.summary.optimizationSavings,
      bestSellers: result.summary.bestSellers,
      calculationTime: result.summary.calculationTime + 'ms'
    });

    return result;
  }

  /**
   * Get current sellers used in cart
   */
  getCurrentCartSellers(cartItems) {
    const sellers = new Set();
    cartItems.forEach(item => {
      if (item.selectedSeller && item.selectedSeller !== 'all') {
        sellers.add(item.selectedSeller);
      } else {
        sellers.add('digikala'); // Default
      }
    });
    return Array.from(sellers);
  }

  /**
   * Generate recommendations based on optimization result
   */
  generateRecommendations(optimizationResult, currentCartTotals) {
    const recommendations = [];

    if (!optimizationResult || !optimizationResult.success) {
      return recommendations;
    }

    // Savings recommendation
    if (optimizationResult.totalSavings > 0) {
      recommendations.push({
        type: 'savings',
        title: 'صرفه‌جویی در هزینه',
        description: `با انتخاب فروشندگان بهینه، ${this.formatPrice(optimizationResult.totalSavings)} صرفه‌جویی کنید`,
        action: 'apply_optimization',
        priority: 'high'
      });
    }

    // Seller recommendations
    if (optimizationResult.sellersUsed && optimizationResult.sellersUsed.length > 1) {
      recommendations.push({
        type: 'sellers',
        title: 'ترکیب فروشندگان',
        description: `استفاده از ${optimizationResult.sellersUsed.length} فروشنده برای بهترین قیمت`,
        action: 'view_seller_breakdown',
        priority: 'medium'
      });
    }

    return recommendations;
  }

  /**
   * Get best sellers from optimization
   */
  getBestSellers(sellerData, optimizationResult) {
    if (!optimizationResult || !optimizationResult.sellersUsed) {
      return ['digikala'];
    }

    return optimizationResult.sellersUsed.slice(0, 3); // Top 3 sellers
  }

  /**
   * Create empty cart result
   */
  createEmptyCartResult() {
    return {
      success: true,
      timestamp: Date.now(),
      cartItems: 0,
      currentCart: { items: [], totals: { totalItems: 0, totalValue: 0 } },
      optimization: null,
      summary: {
        totalItems: 0,
        totalValue: 0,
        optimizationSavings: 0,
        recommendationsCount: 0
      },
      message: 'سبد هوشمند خالی است'
    };
  }

  /**
   * Format price for display
   */
  formatPrice(price) {
    if (!price || price === 0) return '0 تومان';
    const formatted = price.toLocaleString('fa-IR');
    return `${formatted} تومان`;
  }

  /**
   * Get optimization settings
   */
  getSettings() {
    return { ...this.settings };
  }

  /**
   * Update optimization settings
   */
  updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    console.log('⚙️ Optimization settings updated:', newSettings);
  }

  /**
   * Get optimization statistics
   */
  getStats() {
    return {
      isInitialized: this.isInitialized,
      isCalculating: this.isCalculating,
      lastCalculationTime: this.lastCalculationTime,
      currentCartItems: this.getCartItems().length,
      optimizationEnabled: this.settings.enableOptimization,
      apiEnabled: this.settings.enableAPIRefresh
    };
  }
}

// Make it available globally
if (typeof window !== 'undefined') {
  window.EnhancedSmartCartOptimizer = EnhancedSmartCartOptimizer;
}