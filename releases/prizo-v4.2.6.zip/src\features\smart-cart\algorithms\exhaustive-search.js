/**
 * @Author: Smart Cart System
 * @Date: 2025-01-18
 * Exhaustive Search Optimizer - For small instances (≤8-12 products)
 * Guarantees optimal solution by evaluating all valid combinations
 */

class ExhaustiveSearchOptimizer {
  constructor(costCalculator) {
    this.costCalculator = costCalculator;
    this.maxCombinations = 1000000; // Safety limit
  }

  /**
   * Find optimal solution using exhaustive search
   * @param {Object} data - Normalized basket data
   * @returns {Object} Optimal solution
   */
  async optimize(data) {
    console.log(`🔍 Starting exhaustive search for ${data.products.length} products`);

    const startTime = Date.now();
    let bestSolution = null;
    let evaluatedCombinations = 0;

    try {
      // Generate all valid combinations
      const combinations = this.generateValidCombinations(data);
      console.log(`📊 Generated ${combinations.length} valid combinations to evaluate`);

      if (combinations.length > this.maxCombinations) {
        console.warn(`⚠️ Too many combinations (${combinations.length}), falling back to sampling`);
        return this.optimizeWithSampling(data, combinations);
      }

      // Evaluate each combination
      for (const combination of combinations) {
        evaluatedCombinations++;
        const solution = this.evaluateCombination(combination, data);

        if (this.isBetterSolution(solution, bestSolution, data.optimizationMode)) {
          bestSolution = solution;
        }

        // Yield control occasionally for better browser performance
        if (evaluatedCombinations % 1000 === 0) {
          await this.yieldControl();
        }
      }

      const duration = Date.now() - startTime;
      console.log(`✅ Exhaustive search completed in ${duration}ms, evaluated ${evaluatedCombinations} combinations`);

      return bestSolution;

    } catch (error) {
      console.error('❌ Exhaustive search failed:', error);
      throw error;
    }
  }

  /**
   * Generate all valid seller combinations for products
   */
  generateValidCombinations(data) {
    const combinations = [];

    // Build arrays of valid sellers for each product
    const productSellerOptions = data.products.map(product => {
      if (product.preferredSeller) {
        // If preferred seller exists, only use that
        const preferredSeller = product.sellers.find(s => s.sellerId === product.preferredSeller);
        return preferredSeller ? [preferredSeller] : [];
      }
      return product.sellers;
    });

    // Generate cartesian product of all combinations
    this.generateCartesianProduct(productSellerOptions, [], 0, combinations, data);

    return combinations;
  }

  /**
   * Recursively generate cartesian product of seller combinations
   */
  generateCartesianProduct(productSellerOptions, currentCombination, productIndex, combinations, data) {
    if (productIndex >= productSellerOptions.length) {
      // Complete combination - validate constraints
      if (this.isValidCombination(currentCombination, data)) {
        combinations.push([...currentCombination]);
      }
      return;
    }

    // Try each seller option for current product
    for (const seller of productSellerOptions[productIndex]) {
      currentCombination[productIndex] = {
        productId: data.products[productIndex].id,
        sellerId: seller.sellerId,
        price: seller.price,
        shipsDirectly: seller.shipsDirectly
      };

      this.generateCartesianProduct(
        productSellerOptions,
        currentCombination,
        productIndex + 1,
        combinations,
        data
      );
    }
  }

  /**
   * Check if a combination satisfies all constraints
   */
  isValidCombination(combination, data) {
    const sellersUsed = new Set(combination.map(assignment => assignment.sellerId));

    // Check max sellers constraint
    if (data.optimizationMode === 'MAX_SELLERS' && sellersUsed.size > data.maxSellers) {
      return false;
    }

    return true;
  }

  /**
   * Evaluate a specific combination and return solution
   */
  evaluateCombination(combination, data) {
    const assignments = combination.map(assignment => ({
      productId: assignment.productId,
      sellerId: assignment.sellerId,
      price: assignment.price
    }));

    const costs = this.costCalculator.calculateTotalCost(assignments, data);
    const sellersUsed = [...new Set(assignments.map(a => a.sellerId))];

    return {
      assignments,
      totalProductCost: costs.productCost,
      totalShippingCost: costs.shippingCost,
      totalCost: costs.totalCost,
      sellersUsed,
      shippingBreakdown: costs.shippingBreakdown
    };
  }

  /**
   * Compare two solutions based on optimization mode
   */
  isBetterSolution(newSolution, currentBest, optimizationMode) {
    if (!currentBest) return true;
    if (!newSolution) return false;

    switch (optimizationMode) {
      case 'COST':
        return newSolution.totalCost < currentBest.totalCost;

      case 'SELLERS_FIRST':
        // First minimize sellers, then cost
        if (newSolution.sellersUsed.length !== currentBest.sellersUsed.length) {
          return newSolution.sellersUsed.length < currentBest.sellersUsed.length;
        }
        return newSolution.totalCost < currentBest.totalCost;

      case 'MAX_SELLERS':
        // Within seller limit, minimize cost
        return newSolution.totalCost < currentBest.totalCost;

      default:
        return newSolution.totalCost < currentBest.totalCost;
    }
  }

  /**
   * Optimize with sampling when there are too many combinations
   */
  async optimizeWithSampling(data, allCombinations) {
    console.log(`🎲 Using sampling strategy for large problem space`);

    const sampleSize = Math.min(this.maxCombinations, allCombinations.length);
    const sampledCombinations = this.sampleCombinations(allCombinations, sampleSize);

    let bestSolution = null;

    for (const combination of sampledCombinations) {
      const solution = this.evaluateCombination(combination, data);

      if (this.isBetterSolution(solution, bestSolution, data.optimizationMode)) {
        bestSolution = solution;
      }
    }

    console.log(`✅ Sampling completed with ${sampledCombinations.length} evaluations`);
    return bestSolution;
  }

  /**
   * Sample combinations using various strategies
   */
  sampleCombinations(combinations, sampleSize) {
    if (combinations.length <= sampleSize) {
      return combinations;
    }

    const sampled = [];
    const step = Math.floor(combinations.length / sampleSize);

    // Systematic sampling
    for (let i = 0; i < combinations.length && sampled.length < sampleSize; i += step) {
      sampled.push(combinations[i]);
    }

    // Add some random samples to avoid bias
    const randomSampleSize = Math.min(100, sampleSize - sampled.length);
    for (let i = 0; i < randomSampleSize; i++) {
      const randomIndex = Math.floor(Math.random() * combinations.length);
      sampled.push(combinations[randomIndex]);
    }

    return sampled;
  }

  /**
   * Yield control to prevent browser freezing
   */
  async yieldControl() {
    return new Promise(resolve => setTimeout(resolve, 0));
  }
}

// Browser extension compatibility
if (typeof window !== 'undefined') {
  window.ExhaustiveSearchOptimizer = ExhaustiveSearchOptimizer;
}