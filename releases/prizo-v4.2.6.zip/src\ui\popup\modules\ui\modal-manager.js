/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Modal Manager - Generic modal management system
 */

class ModalManager extends BaseModule {
  constructor(eventBus, domManager) {
    super('ModalManager', eventBus, domManager);

    this.activeModals = new Map();
    this.modalStack = [];
    this.keyboardHandler = null;
  }

  async initializeElements() {
    // This is a generic manager, elements are registered dynamically
    this.elements = {};
  }

  async setupEventListeners() {
    // Listen for modal events
    this.on('modal:show', (data) => this.showModal(data));
    this.on('modal:hide', (data) => this.hideModal(data));
    this.on('modal:hide-all', () => this.hideAllModals());
    this.on('modal:register', (data) => this.registerModal(data));
    this.on('modal:unregister', (data) => this.unregisterModal(data));

    // Listen for specific UI events
    this.on('ui:show-comparison-help', (data) => this.showComparisonHelp(data));
    this.on('ui:show-welcome-guide', (data) => this.showWelcomeGuide(data));
    this.on('ui:show-confirm-dialog', (data) => this.showConfirmDialog(data));

    // Setup global keyboard handler
    this.setupKeyboardHandler();
  }

  async loadInitialData() {
    // Auto-register common modals
    this.registerCommonModals();
  }

  registerCommonModals() {
    const commonModals = [
      'watchlistModal',
      'editWatchlistModal',
      'comparisonHelpModal'
    ];

    commonModals.forEach(modalId => {
      const element = this.domManager.getElementById(modalId);
      if (element) {
        this.registerModal({
          id: modalId,
          element: element,
          options: {
            closeOnEscape: true,
            closeOnOverlayClick: true
          }
        });
      }
    });
  }

  // Modal registration and management
  registerModal(data) {
    const { id, element, options = {} } = data;

    if (!id || !element) {
      this.warn('Cannot register modal: missing id or element');
      return false;
    }

    const modalConfig = {
      id,
      element,
      options: {
        closeOnEscape: true,
        closeOnOverlayClick: true,
        preventBodyScroll: true,
        focusOnShow: true,
        restoreFocusOnHide: true,
        ...options
      },
      isOpen: false,
      previousActiveElement: null
    };

    this.activeModals.set(id, modalConfig);

    // Setup modal-specific event handlers
    this.setupModalEventHandlers(modalConfig);

    this.log(`Modal registered: ${id}`);
    this.emit('modal:registered', { id, config: modalConfig });

    return true;
  }

  unregisterModal(data) {
    const { id } = data;
    const modalConfig = this.activeModals.get(id);

    if (modalConfig) {
      // Hide if currently open
      if (modalConfig.isOpen) {
        this.hideModal({ id });
      }

      // Clean up event handlers
      this.cleanupModalEventHandlers(modalConfig);

      this.activeModals.delete(id);

      this.log(`Modal unregistered: ${id}`);
      this.emit('modal:unregistered', { id });

      return true;
    }

    return false;
  }

  setupModalEventHandlers(modalConfig) {
    const { element, options } = modalConfig;

    // Close on overlay click
    if (options.closeOnOverlayClick) {
      this.domManager.addEventListener(element, 'click', (e) => {
        if (e.target === element) {
          this.hideModal({ id: modalConfig.id });
        }
      });
    }

    // Close button handling
    const closeButtons = element.querySelectorAll('.modal-close, [data-modal-close]');
    closeButtons.forEach(button => {
      this.domManager.addEventListener(button, 'click', () => {
        this.hideModal({ id: modalConfig.id });
      });
    });

    // Trap focus within modal
    if (options.focusOnShow) {
      this.domManager.addEventListener(element, 'keydown', (e) => {
        this.handleModalKeydown(e, modalConfig);
      });
    }
  }

  cleanupModalEventHandlers(modalConfig) {
    // Event listeners will be cleaned up by DOMManager automatically
  }

  setupKeyboardHandler() {
    this.keyboardHandler = (e) => {
      if (e.key === 'Escape' && this.modalStack.length > 0) {
        const topModal = this.modalStack[this.modalStack.length - 1];
        const modalConfig = this.activeModals.get(topModal);

        if (modalConfig && modalConfig.options.closeOnEscape) {
          e.preventDefault();
          this.hideModal({ id: topModal });
        }
      }
    };

    document.addEventListener('keydown', this.keyboardHandler);
  }

  handleModalKeydown(e, modalConfig) {
    if (e.key === 'Tab') {
      this.trapFocus(e, modalConfig.element);
    }
  }

  trapFocus(e, modalElement) {
    const focusableElements = modalElement.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );

    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];

    if (e.shiftKey) {
      // Shift + Tab
      if (document.activeElement === firstElement) {
        e.preventDefault();
        lastElement.focus();
      }
    } else {
      // Tab
      if (document.activeElement === lastElement) {
        e.preventDefault();
        firstElement.focus();
      }
    }
  }

  // Modal show/hide methods
  showModal(data) {
    const { id, options = {} } = data;
    const modalConfig = this.activeModals.get(id);

    if (!modalConfig) {
      this.warn(`Modal not found: ${id}`);
      return false;
    }

    if (modalConfig.isOpen) {
      this.warn(`Modal already open: ${id}`);
      return false;
    }

    // Store current focus
    if (modalConfig.options.restoreFocusOnHide) {
      modalConfig.previousActiveElement = document.activeElement;
    }

    // Prevent body scroll if needed
    if (modalConfig.options.preventBodyScroll) {
      document.body.classList.add('modal-open');
    }

    // Show the modal
    this.domManager.show(modalConfig.element, 'flex');
    modalConfig.isOpen = true;

    // Add to modal stack
    this.modalStack.push(id);

    // Focus management
    if (modalConfig.options.focusOnShow) {
      setTimeout(() => {
        const firstFocusable = modalConfig.element.querySelector(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (firstFocusable) {
          firstFocusable.focus();
        }
      }, 100);
    }

    this.log(`Modal shown: ${id}`);
    this.emit('modal:shown', { id, modalConfig });

    // Execute custom show callback
    if (options.onShow && typeof options.onShow === 'function') {
      options.onShow(modalConfig);
    }

    return true;
  }

  hideModal(data) {
    const { id } = data;
    const modalConfig = this.activeModals.get(id);

    if (!modalConfig) {
      this.warn(`Modal not found: ${id}`);
      return false;
    }

    if (!modalConfig.isOpen) {
      this.warn(`Modal not open: ${id}`);
      return false;
    }

    // Hide the modal
    this.domManager.hide(modalConfig.element);
    modalConfig.isOpen = false;

    // Remove from modal stack
    const stackIndex = this.modalStack.indexOf(id);
    if (stackIndex !== -1) {
      this.modalStack.splice(stackIndex, 1);
    }

    // Restore body scroll if no other modals are open
    if (this.modalStack.length === 0) {
      document.body.classList.remove('modal-open');
    }

    // Restore focus
    if (modalConfig.options.restoreFocusOnHide && modalConfig.previousActiveElement) {
      modalConfig.previousActiveElement.focus();
      modalConfig.previousActiveElement = null;
    }

    this.log(`Modal hidden: ${id}`);
    this.emit('modal:hidden', { id, modalConfig });

    return true;
  }

  hideAllModals() {
    // Hide all open modals in reverse order (LIFO)
    const openModals = [...this.modalStack].reverse();

    openModals.forEach(id => {
      this.hideModal({ id });
    });

    this.emit('modal:all-hidden', { count: openModals.length });
    return openModals.length;
  }

  // Modal state queries
  isModalOpen(id) {
    const modalConfig = this.activeModals.get(id);
    return modalConfig ? modalConfig.isOpen : false;
  }

  getOpenModals() {
    return [...this.modalStack];
  }

  getModalCount() {
    return this.activeModals.size;
  }

  getOpenModalCount() {
    return this.modalStack.length;
  }

  hasOpenModals() {
    return this.modalStack.length > 0;
  }

  getTopModal() {
    return this.modalStack.length > 0 ? this.modalStack[this.modalStack.length - 1] : null;
  }

  // Dynamic modal creation
  createModal(config) {
    const { id, title, content, className = '', options = {} } = config;

    // Create modal HTML
    const modalHTML = `
      <div class="modal-overlay" id="${id}">
        <div class="modal-container ${className}">
          <div class="modal-header">
            <h3 class="modal-title">${title}</h3>
            <button class="modal-close" aria-label="بستن">×</button>
          </div>
          <div class="modal-body">
            ${content}
          </div>
          ${options.footer ? `<div class="modal-footer">${options.footer}</div>` : ''}
        </div>
      </div>
    `;

    // Create DOM element
    const modalElement = this.domManager.createElement('div');
    modalElement.innerHTML = modalHTML;
    const modal = modalElement.firstElementChild;

    // Add to document
    document.body.appendChild(modal);

    // Register the modal
    this.registerModal({
      id,
      element: modal,
      options: {
        ...options,
        dynamic: true
      }
    });

    this.log(`Dynamic modal created: ${id}`);
    return modal;
  }

  destroyModal(id) {
    const modalConfig = this.activeModals.get(id);

    if (modalConfig) {
      // Hide if open
      if (modalConfig.isOpen) {
        this.hideModal({ id });
      }

      // Remove from DOM if dynamic
      if (modalConfig.options.dynamic && modalConfig.element.parentNode) {
        modalConfig.element.parentNode.removeChild(modalConfig.element);
      }

      // Unregister
      this.unregisterModal({ id });

      this.log(`Modal destroyed: ${id}`);
      return true;
    }

    return false;
  }

  // Utility methods
  toggleModal(data) {
    const { id } = data;

    if (this.isModalOpen(id)) {
      return this.hideModal({ id });
    } else {
      return this.showModal({ id });
    }
  }

  // Alert and confirm modals
  async showAlert(message, options = {}) {
    const id = `alert_${Date.now()}`;

    const modal = this.createModal({
      id,
      title: options.title || 'توجه',
      content: `<p>${message}</p>`,
      className: 'alert-modal',
      options: {
        footer: '<button class="btn btn-primary modal-close">تأیید</button>',
        closeOnEscape: true,
        closeOnOverlayClick: false,
        ...options
      }
    });

    this.showModal({ id });

    return new Promise((resolve) => {
      const handleClose = () => {
        this.destroyModal(id);
        resolve(true);
      };

      this.once('modal:hidden', (data) => {
        if (data.id === id) {
          handleClose();
        }
      });
    });
  }

  async showConfirm(message, options = {}) {
    const id = `confirm_${Date.now()}`;
    const cancelText = options.cancelText || 'انصراف';
    const confirmText = options.confirmText || 'تأیید';

    const modal = this.createModal({
      id,
      title: options.title || 'تأیید',
      content: `<p>${message}</p>`,
      className: 'confirm-modal',
      options: {
        footer: `
          <button class="btn btn-secondary" data-action="cancel">${cancelText}</button>
          <button class="btn btn-primary" data-action="confirm">${confirmText}</button>
        `,
        closeOnEscape: true,
        closeOnOverlayClick: false,
        ...options
      }
    });

    // Add action handlers
    const confirmBtn = modal.querySelector('[data-action="confirm"]');
    const cancelBtn = modal.querySelector('[data-action="cancel"]');

    if (!confirmBtn || !cancelBtn) {
      console.error('Confirmation dialog buttons not found!', { confirmBtn, cancelBtn, modal });
      this.destroyModal(id);
      return Promise.resolve(false);
    }

    this.showModal({ id });

    return new Promise((resolve) => {
      let resolved = false;

      const cleanup = () => {
        this.destroyModal(id);
      };

      const safeResolve = (value, source = 'unknown') => {
        console.log(`safeResolve called with: ${value} from ${source}, already resolved: ${resolved}`);
        if (!resolved) {
          resolved = true;
          console.log(`Resolving Promise with: ${value}`);
          resolve(value);
        } else {
          console.log(`Promise already resolved, ignoring resolve(${value}) from ${source}`);
        }
      };

      this.domManager.addEventListener(confirmBtn, 'click', () => {
        console.log('Confirm button clicked');
        safeResolve(true, 'confirm-button');
        cleanup();
      });

      this.domManager.addEventListener(cancelBtn, 'click', () => {
        console.log('Cancel button clicked');
        safeResolve(false, 'cancel-button');
        cleanup();
      });

      // Handle escape key or manual modal close as cancel
      this.once('modal:hidden', (data) => {
        if (data.id === id) {
          console.log('modal:hidden event triggered for id:', data.id);
          safeResolve(false, 'modal-hidden-escape');
        }
      });
    });
  }

  // Specific UI event handlers
  showComparisonHelp() {
    this.showModal({ id: 'comparisonHelpModal' });
  }

  showWelcomeGuide() {
    // Send message to content script to show the proper welcome guide
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'showWelcomeGuide' }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('Error showing welcome guide:', chrome.runtime.lastError);
            // Fallback to alert if content script is not available
            this.showAlert(
              'لطفاً در صفحه دیجی‌کالا باشید تا راهنما نمایش داده شود.',
              {
                title: '⚠️ توجه',
                className: 'welcome-modal'
              }
            );
          } else if (response && !response.success) {
            console.error('Welcome guide error:', response.error);
            this.showAlert(
              'خطا در نمایش راهنما. لطفاً صفحه را رفرش کنید و دوباره تلاش کنید.',
              {
                title: '⚠️ خطا',
                className: 'welcome-modal'
              }
            );
          }
        });
      }
    });
  }

  showConfirmDialog(data) {
    const { title, message, confirmText, cancelText, onConfirm, onCancel } = data;

    console.log('showConfirmDialog called with:', { title, message, confirmText, cancelText, hasOnConfirm: !!onConfirm, hasOnCancel: !!onCancel });

    this.showConfirm(message, {
      title: title,
      confirmText: confirmText || 'تأیید',
      cancelText: cancelText || 'انصراف'
    }).then(confirmed => {
      console.log('Confirmation result:', confirmed);
      if (confirmed && onConfirm) {
        console.log('Calling onConfirm callback');
        onConfirm();
      } else if (!confirmed && onCancel) {
        console.log('Calling onCancel callback');
        onCancel();
      }
    }).catch(error => {
      console.error('Error in confirmation dialog:', error);
      if (onCancel) {
        onCancel();
      }
    });
  }

  // Debug utilities
  logModalStats() {
    this.log('Modal Statistics:', {
      totalModals: this.activeModals.size,
      openModals: this.modalStack.length,
      modalStack: this.modalStack,
      registeredModals: Array.from(this.activeModals.keys())
    });
  }

  // Cleanup
  async cleanup() {
    // Hide all modals
    this.hideAllModals();

    // Remove keyboard handler
    if (this.keyboardHandler) {
      document.removeEventListener('keydown', this.keyboardHandler);
      this.keyboardHandler = null;
    }

    // Destroy dynamic modals
    for (const [id, config] of this.activeModals) {
      if (config.options.dynamic) {
        this.destroyModal(id);
      }
    }

    // Clear collections
    this.activeModals.clear();
    this.modalStack = [];

    // Remove body class
    document.body.classList.remove('modal-open');
  }
}

// Make available globally
window.ModalManager = ModalManager;