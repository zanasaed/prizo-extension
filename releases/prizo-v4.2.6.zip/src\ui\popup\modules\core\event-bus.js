/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Event Bus - Central communication hub for popup modules
 */

class EventBus {
  constructor() {
    this.events = new Map();
    this.eventHistory = [];
    this.maxHistorySize = 100;
    this.debugMode = false;
  }

  // Enable debug mode to log all events
  setDebugMode(enabled) {
    this.debugMode = enabled;
  }

  // Register an event listener
  on(event, callback, options = {}) {
    if (typeof callback !== 'function') {
      throw new Error('Callback must be a function');
    }

    if (!this.events.has(event)) {
      this.events.set(event, []);
    }

    const listener = {
      callback,
      once: options.once || false,
      priority: options.priority || 0,
      id: this.generateListenerId()
    };

    const listeners = this.events.get(event);
    listeners.push(listener);

    // Sort by priority (higher priority first)
    listeners.sort((a, b) => b.priority - a.priority);

    if (this.debugMode) {
      console.log(`📡 EventBus: Registered listener for '${event}'`, { listener: listener.id, priority: listener.priority });
    }

    // Return unsubscribe function
    return () => this.off(event, listener.id);
  }

  // Register a one-time event listener
  once(event, callback, options = {}) {
    return this.on(event, callback, { ...options, once: true });
  }

  // Remove event listener(s)
  off(event, callbackOrId = null) {
    if (!this.events.has(event)) {
      return false;
    }

    const listeners = this.events.get(event);

    if (callbackOrId === null) {
      // Remove all listeners for this event
      this.events.delete(event);
      if (this.debugMode) {
        console.log(`📡 EventBus: Removed all listeners for '${event}'`);
      }
      return true;
    }

    const initialLength = listeners.length;
    const isId = typeof callbackOrId === 'string';

    const newListeners = listeners.filter(listener => {
      if (isId) {
        return listener.id !== callbackOrId;
      } else {
        return listener.callback !== callbackOrId;
      }
    });

    if (newListeners.length < initialLength) {
      this.events.set(event, newListeners);
      if (this.debugMode) {
        console.log(`📡 EventBus: Removed listener for '${event}'`);
      }
      return true;
    }

    return false;
  }

  // Emit an event
  emit(event, data = {}) {
    const timestamp = Date.now();
    const eventData = {
      event,
      data,
      timestamp,
      id: this.generateEventId()
    };

    // Add to history
    this.addToHistory(eventData);

    if (this.debugMode) {
      console.log(`📡 EventBus: Emitting '${event}'`, data);
    }

    if (!this.events.has(event)) {
      if (this.debugMode) {
        console.log(`📡 EventBus: No listeners for '${event}'`);
      }
      return { handled: false, listenerCount: 0 };
    }

    const listeners = [...this.events.get(event)]; // Copy to avoid issues if listeners are modified during iteration
    let handledCount = 0;
    const results = [];

    for (const listener of listeners) {
      try {
        const result = listener.callback(data, eventData);
        results.push(result);
        handledCount++;

        // Remove one-time listeners
        if (listener.once) {
          this.off(event, listener.id);
        }
      } catch (error) {
        console.error(`📡 EventBus: Error in listener for '${event}':`, error);

        // Emit error event
        if (event !== 'eventbus:error') { // Prevent infinite loops
          this.emit('eventbus:error', {
            originalEvent: event,
            originalData: data,
            error: error.message,
            listenerError: true
          });
        }
      }
    }

    const result = {
      handled: handledCount > 0,
      listenerCount: handledCount,
      results
    };

    if (this.debugMode) {
      console.log(`📡 EventBus: Event '${event}' handled by ${handledCount} listeners`);
    }

    return result;
  }

  // Emit an event and wait for all async listeners to complete
  async emitAsync(event, data = {}) {
    const timestamp = Date.now();
    const eventData = {
      event,
      data,
      timestamp,
      id: this.generateEventId()
    };

    this.addToHistory(eventData);

    if (this.debugMode) {
      console.log(`📡 EventBus: Emitting async '${event}'`, data);
    }

    if (!this.events.has(event)) {
      return { handled: false, listenerCount: 0 };
    }

    const listeners = [...this.events.get(event)];
    const promises = [];

    for (const listener of listeners) {
      try {
        const result = listener.callback(data, eventData);

        // Handle both sync and async results
        if (result && typeof result.then === 'function') {
          promises.push(result);
        } else {
          promises.push(Promise.resolve(result));
        }

        // Remove one-time listeners
        if (listener.once) {
          this.off(event, listener.id);
        }
      } catch (error) {
        console.error(`📡 EventBus: Error in async listener for '${event}':`, error);
        promises.push(Promise.reject(error));
      }
    }

    try {
      const results = await Promise.allSettled(promises);
      const successfulResults = results.filter(r => r.status === 'fulfilled').map(r => r.value);
      const failedResults = results.filter(r => r.status === 'rejected');

      if (failedResults.length > 0 && event !== 'eventbus:error') {
        this.emit('eventbus:error', {
          originalEvent: event,
          originalData: data,
          failedResults: failedResults.map(r => r.reason)
        });
      }

      return {
        handled: results.length > 0,
        listenerCount: results.length,
        results: successfulResults,
        failures: failedResults.length
      };
    } catch (error) {
      console.error(`📡 EventBus: Unexpected error in emitAsync for '${event}':`, error);
      return { handled: false, listenerCount: 0, error: error.message };
    }
  }

  // Get event history
  getEventHistory(limit = 50) {
    return this.eventHistory.slice(-limit);
  }

  // Clear event history
  clearHistory() {
    this.eventHistory = [];
  }

  // Get all registered events
  getRegisteredEvents() {
    return Array.from(this.events.keys());
  }

  // Get listener count for an event
  getListenerCount(event) {
    return this.events.has(event) ? this.events.get(event).length : 0;
  }

  // Remove all listeners
  removeAllListeners() {
    this.events.clear();
    if (this.debugMode) {
      console.log('📡 EventBus: Removed all listeners');
    }
  }

  // Private methods
  generateListenerId() {
    return `listener_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  generateEventId() {
    return `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  addToHistory(eventData) {
    this.eventHistory.push(eventData);

    // Keep history size manageable
    if (this.eventHistory.length > this.maxHistorySize) {
      this.eventHistory = this.eventHistory.slice(-this.maxHistorySize);
    }
  }

  // Debug utilities
  logStats() {
    console.log('📡 EventBus Statistics:');
    console.log(`- Registered events: ${this.events.size}`);
    console.log(`- Total listeners: ${Array.from(this.events.values()).reduce((sum, listeners) => sum + listeners.length, 0)}`);
    console.log(`- Event history: ${this.eventHistory.length} events`);

    if (this.events.size > 0) {
      console.log('- Events and listener counts:');
      for (const [event, listeners] of this.events) {
        console.log(`  - ${event}: ${listeners.length} listeners`);
      }
    }
  }
}

// Create global instance
window.EventBus = EventBus;