/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-25
 * Global Sorting Service - Adds "Highest Discount" option to any page with sorting sections
 */
class GlobalSortingService {
  constructor(services) {
    this.services = services;
    this.isEnabled = true;
    this.currentURL = '';
    this.sortContainer = null;
    this.observer = null;
    this.checkInterval = null;
    this.urlChangeMonitorInterval = null;
  }

  async initialize() {
    try {
      console.log('🎯 Initializing Global Sorting Service');
      
      // Check if we should exclude this page
      if (this.isExcludedPage()) {
        console.log('❌ Page excluded from global sorting');
        return;
      }

      this.currentURL = window.location.href;
      
      // Start the global sorting feature
      this.startGlobalSorting();
      
      console.log('✅ Global Sorting Service initialized');
    } catch (error) {
      console.error('❌ Error initializing Global Sorting Service:', error);
    }
  }

  isExcludedPage() {
    const url = window.location.href;
    const pathname = window.location.pathname;
    
    // Specific exclusions - only pages that definitely shouldn't have sorting
    const exclusions = [
      '/profile/lists/', // User wishlist - explicitly requested exclusion
      '/checkout/',      // Checkout pages don't have product sorting
      '/product/dkp-',   // Single product pages don't need sorting
      '/fresh/product/dkp-', // Fresh single product pages
      '/profile/orders/', // Order pages don't have product sorting
    ];
    
    // Check URL-based exclusions
    for (const exclusion of exclusions) {
      if (url.includes(exclusion)) {
        console.log(`❌ Page excluded from global sorting: ${exclusion}`);
        return true;
      }
    }
    
    // Exclude only the exact homepage paths (they don't have sorting)
    if (pathname === '/' || pathname === '/main/' || pathname === '/fresh/' || pathname === '/fresh') {
      console.log('❌ Homepage detected - excluding from global sorting');
      return true;
    }
    
    return false;
  }

  startGlobalSorting() {
    console.log('🎯 Starting global sorting feature');
    
    // Try to add sort option immediately
    setTimeout(() => {
      this.addHighestDiscountSortOption();
    }, 1500);
    
    // Set up monitoring for dynamic content changes
    this.setupGlobalSortMonitoring();
  }

  shouldAddSortOption() {
    // Centralized validation logic
    
    // 1. Check if page is excluded
    if (this.isExcludedPage()) {
      console.log('❌ [Global] Page excluded from sorting injection');
      return false;
    }
    
    // 2. Double-check that we're on a page that should have sorting
    if (!this.isLikelySortingPage()) {
      console.log('❌ [Global] Page does not appear to be a sorting/listing page');
      return false;
    }
    
    // 3. Check if a valid sort container exists
    const sortContainer = this.findSortContainer();
    if (!sortContainer) {
      console.log('ℹ️ [Global] No valid sort container found - injection not needed');
      return false;
    }
    
    // 4. Check if option already exists
    const existingOption = this.findExistingDiscountOption(sortContainer);
    if (existingOption) {
      console.log('ℹ️ [Global] Highest discount option already exists');
      return false;
    }
    
    console.log('✅ [Global] All conditions met for sort option injection');
    return true;
  }

  isLikelySortingPage() {
    // First check: Look for the specific "مرتب سازی:" text on the page
    const pageText = document.body.textContent || document.body.innerText || '';
    if (pageText.includes('مرتب سازی:')) {
      console.log('✅ [Global] Found "مرتب سازی:" text - definitely a sorting page');
      return true;
    }
    
    // Second check: Look for the specific sort icon element
    const sortIcon = document.querySelector('div[data-cro-id="plp-sort-icon"]');
    if (sortIcon) {
      console.log('✅ [Global] Found plp-sort-icon element - definitely a sorting page');
      return true;
    }
    
    // Third check: URL-based indicators (as fallback)
    const url = window.location.href;
    const pathname = window.location.pathname;
    
    const sortingPageIndicators = [
      '/search/',
      '/fresh/search/',
      '/category/',
      '/fresh/category/',
      '/tags/',
      '/incredible-offers/',
      '/fresh-offers/',
      'product-list',
      'q=' // search query parameter
    ];
    
    const urlMatch = sortingPageIndicators.some(indicator => 
      url.includes(indicator) || pathname.includes(indicator)
    );
    
    if (urlMatch) {
      console.log('✅ [Global] URL indicates sorting page');
    }
    
    return urlMatch;
  }

  addHighestDiscountSortOption() {
    try {
      console.log('🎯 [Global] Checking if highest discount sort option should be added');
      
      // Use centralized validation
      if (!this.shouldAddSortOption()) {
        return;
      }
      
      // Find the validated sorting container
      const sortContainer = this.findSortContainer();
      if (!sortContainer) {
        console.log('❌ [Global] Sort container disappeared during validation');
        return;
      }

      // Get current sort value
      const currentSortValue = this.getCurrentSortValue();
      const isActive = currentSortValue === '26';

      // Create the new sort option
      const highestDiscountOption = this.createSortOption(isActive);
      
      // Insert the option at the beginning of the sort list
      sortContainer.insertBefore(highestDiscountOption, sortContainer.firstChild);

      console.log('✅ [Global] Highest discount sort option added', isActive ? '(active)' : '(inactive)');
      
      // Store reference for monitoring
      this.sortContainer = sortContainer;
      
      // Set up styling monitoring to update our option when other options are selected
      this.setupSortOptionStylingMonitor(sortContainer, highestDiscountOption);
      
    } catch (error) {
      console.error('❌ [Global] Error adding highest discount sort option:', error);
    }
  }

  findSortContainer() {
    // First priority: Look for sort container near "مرتب سازی:" text or sort icon
    const priorityContainer = this.findSortContainerNearIndicators();
    if (priorityContainer) {
      console.log('✅ [Global] Found sort container near sort indicators');
      return priorityContainer;
    }
    
    // Comprehensive list of selectors to find sort containers
    const sortSelectors = [
      // Digikala specific - main product pages
      '.styles_HeaderSort__SortList__OPEV3',
      '[class*="HeaderSort"][class*="SortList"]',
      
      // Wishlist and profile pages specific
      '[class*="sortAndStatsHeader"][class*="desktopSortOptions"]',
      '.sortAndStatsHeader_SortAndStatsHeader__desktopSortOptions__lFY3_',
      'div[class*="desktopSortOptions"]',
      
      // Generic sort selectors
      '[class*="sort-list"]',
      '[class*="sort-options"]',
      '[class*="sorting-options"]',
      '.sort-options',
      '.sorting-list',
      '.filter-sort-options',
      
      // More generic patterns
      'div[class*="sort"] div[class*="list"]',
      'div[class*="Sort"] div[class*="List"]',
      'ul[class*="sort"]',
      'div[role="list"][class*="sort"]',
      
      // Look for containers with sort-related children
      'div:has(span[data-sort-value])',
      'div:has([class*="sort"]:not([class*="resort"]))',
      'div:has(div[data-cro-id="plp-sort-option"])',
      
      // Fallback: any container with multiple clickable sort-like elements
      'div:has(> span.cursor-pointer:nth-child(2))',
      'div:has(> div.cursor-pointer:nth-child(2))'
    ];
    
    for (const selector of sortSelectors) {
      try {
        let container = null;
        
        // Handle selectors with :has() pseudo-class
        if (selector.includes(':has(')) {
          // For browsers that don't support :has(), use manual search
          container = this.findContainerManually(selector);
        } else {
          container = document.querySelector(selector);
        }
        
        if (container && this.isValidSortContainer(container)) {
          console.log(`✅ [Global] Sort container found with selector: ${selector}`);
          return container;
        }
      } catch (error) {
        // Continue to next selector if this one fails
        continue;
      }
    }
    
    // Fallback: search for containers with sort-like patterns
    return this.findSortContainerByPattern();
  }

  findSortContainerNearIndicators() {
    // Look for sort container near "مرتب سازی:" text
    const sortTextElements = this.findElementsWithText('مرتب سازی:');
    for (const element of sortTextElements) {
      const nearbyContainer = this.findNearbyContainer(element);
      if (nearbyContainer && this.isValidSortContainer(nearbyContainer)) {
        return nearbyContainer;
      }
    }
    
    // Look for sort container near the sort icon
    const sortIcon = document.querySelector('div[data-cro-id="plp-sort-icon"]');
    if (sortIcon) {
      const nearbyContainer = this.findNearbyContainer(sortIcon);
      if (nearbyContainer && this.isValidSortContainer(nearbyContainer)) {
        return nearbyContainer;
      }
    }
    
    return null;
  }

  findElementsWithText(text) {
    const elements = [];
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    
    let node;
    while (node = walker.nextNode()) {
      if (node.textContent.includes(text)) {
        elements.push(node.parentElement);
      }
    }
    
    return elements;
  }

  findNearbyContainer(element) {
    // Search in parent elements and siblings for sort container
    let current = element;
    
    // Check parent elements (up to 5 levels)
    for (let i = 0; i < 5 && current; i++) {
      current = current.parentElement;
      if (!current) break;
      
      // Look for containers with multiple clickable children nearby
      const containers = current.querySelectorAll('div');
      for (const container of containers) {
        const clickableChildren = Array.from(container.children).filter(child => 
          child.classList.contains('cursor-pointer') || 
          child.getAttribute('data-cro-id') === 'plp-sort-option'
        );
        
        if (clickableChildren.length >= 2) {
          return container;
        }
      }
    }
    
    return null;
  }

  findContainerManually(selector) {
    // Manual implementation for :has() selectors
    if (selector.includes('span[data-sort-value]')) {
      const spans = document.querySelectorAll('span[data-sort-value]');
      for (const span of spans) {
        const container = span.parentElement;
        if (container && container.children.length > 1) {
          return container;
        }
      }
    }
    
    if (selector.includes('div[data-cro-id="plp-sort-option"]')) {
      const sortDivs = document.querySelectorAll('div[data-cro-id="plp-sort-option"]');
      for (const div of sortDivs) {
        const container = div.parentElement;
        if (container && container.children.length > 1) {
          return container;
        }
      }
    }
    
    return null;
  }

  findSortContainerByPattern() {
    // Look for containers with multiple clickable elements that look like sort options
    const possibleContainers = document.querySelectorAll('div');
    
    for (const container of possibleContainers) {
      // Check if container has multiple spans OR divs with cursor-pointer
      const clickableSpans = container.querySelectorAll('span.cursor-pointer, span[class*="cursor-pointer"]');
      const clickableDivs = container.querySelectorAll('div.cursor-pointer, div[class*="cursor-pointer"], div[data-cro-id="plp-sort-option"]');
      
      const totalClickable = clickableSpans.length + clickableDivs.length;
      
      if (totalClickable >= 2) {
        // Check if any of the elements contain sort-related text
        const sortKeywords = ['قیمت', 'جدیدترین', 'پرفروش', 'محبوب', 'ارزان', 'گران', 'تخفیف', 'امتیاز'];
        const allClickable = [...clickableSpans, ...clickableDivs];
        const hasKeywords = allClickable.some(element => 
          sortKeywords.some(keyword => element.textContent.includes(keyword))
        );
        
        if (hasKeywords) {
          console.log('✅ [Global] Sort container found by pattern matching');
          return container;
        }
      }
    }
    
    return null;
  }

  isValidSortContainer(container) {
    if (!container || !container.children) return false;
    
    // Should have at least 2 children for a real sort list (not just one element)
    if (container.children.length < 2) return false;
    
    // Children should be clickable elements (span, div, button, etc.)
    const clickableChildren = Array.from(container.children).filter(child => 
      child.tagName === 'SPAN' || 
      child.tagName === 'DIV' ||
      child.tagName === 'BUTTON' || 
      child.tagName === 'A' ||
      child.classList.contains('cursor-pointer') ||
      child.getAttribute('role') === 'button' ||
      child.getAttribute('data-cro-id') === 'plp-sort-option'
    );
    
    // Must have at least 2 clickable children for a valid sort list
    if (clickableChildren.length < 2) return false;
    
    // Check if children contain sort-related text - need at least ONE to confirm it's sorting
    const commonSortKeywords = ['قیمت', 'جدید', 'محبوب', 'ارزان', 'گران', 'تخفیف'];
    const hasAnySortContent = clickableChildren.some(child => 
      commonSortKeywords.some(keyword => child.textContent.trim().includes(keyword))
    );
    
    // Only allow containers with proper sort content - no generic selector fallback
    // This prevents false positives on pages that aren't actually sorting pages
    return hasAnySortContent;
  }

  findExistingDiscountOption(container) {
    return Array.from(container.children).find(element =>
      element.textContent && element.textContent.trim() === 'بیشترین تخفیف'
    );
  }

  getCurrentSortValue() {
    try {
      // Try URLSafetyManager first
      if (this.services.urlSafety) {
        return this.services.urlSafety.getCurrentSortValue();
      }
      
      // Fallback: URL parameter extraction
      const urlParams = new URLSearchParams(window.location.search);
      const sortValue = urlParams.get('sort');
      console.log('🎯 [Global] Current sort value from URL:', sortValue);
      return sortValue;
    } catch (error) {
      console.error('❌ [Global] Error getting current sort value:', error);
      return null;
    }
  }

  createSortOption(isActive) {
    // Detect if we should create a div (wishlist style) or span (main pages style)
    const sortContainer = this.findSortContainer();
    const shouldCreateDiv = sortContainer && sortContainer.querySelector('div[data-cro-id="plp-sort-option"]');
    
    const highestDiscountOption = document.createElement(shouldCreateDiv ? 'div' : 'span');
    
    if (shouldCreateDiv) {
      // Wishlist page styling
      highestDiscountOption.className = isActive
        ? 'cursor-pointer whitespace-nowrap text-body2-strong text-primary-700 sortAndStatsHeader_SortAndStatsHeader__SortOption__0TLKu'
        : 'cursor-pointer whitespace-nowrap text-body-2 text-neutral-500 sortAndStatsHeader_SortAndStatsHeader__SortOption__0TLKu';
      
      highestDiscountOption.setAttribute('data-cro-id', 'plp-sort-option');
    } else {
      // Main product pages styling
      highestDiscountOption.className = isActive
        ? 'cursor-pointer whitespace-nowrap text-body2-strong text-primary-700'
        : 'cursor-pointer whitespace-nowrap text-body-2 text-neutral-500';
        
      highestDiscountOption.setAttribute('data-cro-id', 'plp-sort');
    }
      
    // Set common attributes
    highestDiscountOption.setAttribute('data-sort-value', '26');
    highestDiscountOption.textContent = 'بیشترین تخفیف';

    // Add click handler
    highestDiscountOption.addEventListener('click', () => {
      this.handleSortOptionClick('26', highestDiscountOption);
    });

    return highestDiscountOption;
  }

  handleSortOptionClick(sortValue, clickedElement) {
    try {
      console.log(`🎯 [Global] Sort option clicked: ${sortValue}`);

      // Use URLSafetyManager if available
      if (this.services.urlSafety) {
        // Validate sort value first
        const validatedValue = this.services.urlSafety.validateSortValue(sortValue);
        if (validatedValue === null) {
          console.error('❌ [Global] Invalid sort value provided:', sortValue);
          return;
        }

        // Use safe navigation
        const success = this.services.urlSafety.navigateToSortURL(window.location.href, validatedValue);
        if (!success) {
          console.error('❌ [Global] Failed to navigate to sort URL');
        }
      } else {
        // Fallback: direct URL manipulation
        const url = new URL(window.location.href);
        url.searchParams.set('sort', sortValue);
        window.location.href = url.toString();
      }
    } catch (error) {
      console.error('❌ [Global] Error handling sort option click:', error);
    }
  }

  setupSortOptionStylingMonitor(sortContainer, highestDiscountOption) {
    try {
      console.log('🎯 [Global] Setting up sort option styling monitor');
      
      // Monitor clicks on other sort options to update our option's styling
      const otherSortOptions = Array.from(sortContainer.children).filter(child => 
        child !== highestDiscountOption && 
        (child.classList.contains('cursor-pointer') || child.getAttribute('data-cro-id'))
      );
      
      otherSortOptions.forEach(option => {
        option.addEventListener('click', () => {
          setTimeout(() => {
            this.updateHighestDiscountStyling(highestDiscountOption);
          }, 100); // Small delay to let the page update
        });
      });
      
      // Also monitor URL changes to update styling
      let monitorURL = window.location.href;
      const urlMonitorInterval = setInterval(() => {
        if (window.location.href !== monitorURL) {
          monitorURL = window.location.href;
          setTimeout(() => {
            this.updateHighestDiscountStyling(highestDiscountOption);
          }, 500);
        }
      }, 1000);
      
      // Store interval for cleanup
      this.stylingMonitorInterval = urlMonitorInterval;
      
      // Monitor DOM changes that might affect styling
      const stylingObserver = new MutationObserver((mutations) => {
        let shouldUpdateStyling = false;
        
        for (const mutation of mutations) {
          if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
            // Check if any sort option's class changed (indicating selection change)
            const target = mutation.target;
            if (target !== highestDiscountOption && 
                sortContainer.contains(target) &&
                (target.classList.contains('cursor-pointer') || target.getAttribute('data-cro-id'))) {
              shouldUpdateStyling = true;
              break;
            }
          }
        }
        
        if (shouldUpdateStyling) {
          setTimeout(() => {
            this.updateHighestDiscountStyling(highestDiscountOption);
          }, 100);
        }
      });
      
      // Observe the sort container for class changes
      stylingObserver.observe(sortContainer, {
        attributes: true,
        attributeFilter: ['class'],
        subtree: true
      });
      
      // Store observer for cleanup
      this.stylingObserver = stylingObserver;
      
      console.log('✅ [Global] Sort option styling monitor setup complete');
      
    } catch (error) {
      console.error('❌ [Global] Error setting up sort option styling monitor:', error);
    }
  }

  updateHighestDiscountStyling(highestDiscountOption) {
    try {
      const currentSortValue = this.getCurrentSortValue();
      const isActive = currentSortValue === '26';
      
      console.log(`🎯 [Global] Updating highest discount styling - isActive: ${isActive}, currentSort: ${currentSortValue}`);
      
      // Detect if this is a wishlist-style div or main page span
      const isWishlistStyle = highestDiscountOption.tagName === 'DIV' && 
                              highestDiscountOption.getAttribute('data-cro-id') === 'plp-sort-option';
      
      if (isWishlistStyle) {
        // Wishlist page styling
        highestDiscountOption.className = isActive
          ? 'cursor-pointer whitespace-nowrap text-body2-strong text-primary-700 sortAndStatsHeader_SortAndStatsHeader__SortOption__0TLKu'
          : 'cursor-pointer whitespace-nowrap text-body-2 text-neutral-500 sortAndStatsHeader_SortAndStatsHeader__SortOption__0TLKu';
      } else {
        // Main product pages styling
        highestDiscountOption.className = isActive
          ? 'cursor-pointer whitespace-nowrap text-body2-strong text-primary-700'
          : 'cursor-pointer whitespace-nowrap text-body-2 text-neutral-500';
      }
      
      console.log(`✅ [Global] Updated highest discount styling to ${isActive ? 'active' : 'inactive'}`);
      
    } catch (error) {
      console.error('❌ [Global] Error updating highest discount styling:', error);
    }
  }

  setupGlobalSortMonitoring() {
    console.log('🎯 [Global] Setting up sort container monitoring');
    
    // Clean up existing monitoring
    this.teardownGlobalSortMonitoring();
    
    // Monitor URL changes
    this.urlChangeMonitorInterval = setInterval(() => {
      if (window.location.href !== this.currentURL) {
        console.log('🎯 [Global] URL changed, will re-add sort option');
        this.currentURL = window.location.href;
        
        // Re-add sort option after URL change
        setTimeout(() => {
          this.addHighestDiscountSortOption();
        }, 2000);
      }
    }, 1000);
    
    // Monitor DOM changes
    this.observer = new MutationObserver((mutations) => {
      let shouldCheckForSort = false;
      
      for (const mutation of mutations) {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          // Check if new nodes might contain sort containers
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // Check if this could be a sort container or contain one
              if (this.couldContainSortElements(node)) {
                shouldCheckForSort = true;
                break;
              }
            }
          }
        }
      }
      
      if (shouldCheckForSort) {
        console.log('🎯 [Global] DOM changes detected, checking for sort option');
        setTimeout(() => {
          this.addHighestDiscountSortOption();
        }, 500);
      }
    });
    
    // Observe the entire document for changes
    this.observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    // Periodic check as a fallback
    this.checkInterval = setInterval(() => {
      if (this.shouldAddSortOption()) {
        console.log('🎯 [Global] Periodic check: Sort option missing, re-adding');
        this.addHighestDiscountSortOption();
      }
    }, 5000); // Check every 5 seconds
    
    console.log('✅ [Global] Sort container monitoring started');
  }

  couldContainSortElements(element) {
    // Check if element or its children might contain sort-related content
    const sortIndicators = [
      'sort', 'Sort', 'HeaderSort', 'قیمت', 'تخفیف', 'جدید', 'محبوب'
    ];
    
    const elementText = element.textContent || '';
    const elementClass = typeof element.className === 'string' ? element.className : (element.className.toString ? element.className.toString() : '');
    
    return sortIndicators.some(indicator => 
      elementText.includes(indicator) || elementClass.includes(indicator)
    );
  }

  teardownGlobalSortMonitoring() {
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
      console.log('🎯 [Global] DOM observer disconnected');
    }
    
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
      console.log('🎯 [Global] Check interval cleared');
    }
    
    if (this.urlChangeMonitorInterval) {
      clearInterval(this.urlChangeMonitorInterval);
      this.urlChangeMonitorInterval = null;
      console.log('🎯 [Global] URL change monitor cleared');
    }
    
    if (this.stylingMonitorInterval) {
      clearInterval(this.stylingMonitorInterval);
      this.stylingMonitorInterval = null;
      console.log('🎯 [Global] Styling monitor interval cleared');
    }
    
    if (this.stylingObserver) {
      this.stylingObserver.disconnect();
      this.stylingObserver = null;
      console.log('🎯 [Global] Styling observer disconnected');
    }
  }

  cleanup() {
    console.log('🎯 [Global] Cleaning up Global Sorting Service');
    this.teardownGlobalSortMonitoring();
  }
}

window.GlobalSortingService = GlobalSortingService;