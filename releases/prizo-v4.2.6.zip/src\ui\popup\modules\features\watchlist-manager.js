/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Watchlist Manager - Handles all watchlist CRUD operations and UI
 */

class WatchlistManager extends BaseModule {
  constructor(eventBus, domManager) {
    super('WatchlistManager', eventBus, domManager);

    this.watchlistCache = [];
    this.currentEditingEntry = null;
    this.watchlistClickHandler = null;
    this.watchlistKeydownHandler = null;
  }

  async initializeElements() {
    this.elements = this.domManager.getElements({
      // Main watchlist elements
      showWatchlistBtn: '#showWatchlistBtn',
      refreshWatchlistBtn: '#refreshWatchlistBtn',
      watchlistSummary: '#watchlistSummary',
      totalItemsCount: '#totalItemsCount',
      activeItemsCount: '#activeItemsCount',
      lastUpdateText: '#lastUpdateText',

      // Modal elements
      watchlistModal: '#watchlistModal',
      closeWatchlistModal: '#closeWatchlistModal',
      clearAllWatchlistBtn: '#clearAllWatchlistBtn',
      watchlistLoading: '#watchlistLoading',
      watchlistEmpty: '#watchlistEmpty',
      watchlistItems: '#watchlistItems',

      // Edit modal elements
      editWatchlistModal: '#editWatchlistModal',
      closeEditModal: '#closeEditModal',
      editProductTitle: '#editProductTitle',
      editPriceThreshold: '#editPriceThreshold',
      editDiscountThreshold: '#editDiscountThreshold',
      editNotifyLowest30Days: '#editNotifyLowest30Days',
      editCheckInterval: '#editCheckInterval',
      saveEditBtn: '#saveEditBtn',
      cancelEditBtn: '#cancelEditBtn'
    });

    const validation = this.domManager.validateElements(this.elements, [
      'showWatchlistBtn', 'watchlistModal', 'watchlistItems'
    ]);

    if (!validation.valid) {
      this.warn('Some required watchlist elements are missing:', validation.missing);
    }
  }

  async setupEventListeners() {
    // External events
    this.on('tab:switched', (data) => this.handleTabSwitch(data));
    this.on('watchlist:refresh', () => this.refreshWatchlist());
    this.on('watchlist:clear', () => this.handleClearAllWatchlist());
    this.on('storage:cleared', () => this.handleStorageCleared());

    // UI event listeners
    this.setupWatchlistEventListeners();
  }

  async loadInitialData() {
    await this.loadWatchlistSummary();
  }

  setupWatchlistEventListeners() {
    const {
      showWatchlistBtn, refreshWatchlistBtn, watchlistModal,
      closeWatchlistModal, clearAllWatchlistBtn, editWatchlistModal,
      closeEditModal, saveEditBtn, cancelEditBtn
    } = this.elements;

    // Show watchlist button
    if (showWatchlistBtn) {
      this.domManager.addEventListener(showWatchlistBtn, 'click', () => this.showWatchlistModal());
    }

    // Refresh watchlist button
    if (refreshWatchlistBtn) {
      this.domManager.addEventListener(refreshWatchlistBtn, 'click', () => this.refreshWatchlist());
    }

    // Close watchlist modal
    if (closeWatchlistModal) {
      this.domManager.addEventListener(closeWatchlistModal, 'click', () => this.hideWatchlistModal());
    }

    // Clear all watchlist button
    if (clearAllWatchlistBtn) {
      this.domManager.addEventListener(clearAllWatchlistBtn, 'click', () => this.handleClearAllWatchlist());
    }

    // Close edit modal
    if (closeEditModal) {
      this.domManager.addEventListener(closeEditModal, 'click', () => this.hideEditModal());
    }

    // Save edit button
    if (saveEditBtn) {
      this.domManager.addEventListener(saveEditBtn, 'click', () => this.saveWatchlistItemEdit());
    }

    // Cancel edit button
    if (cancelEditBtn) {
      this.domManager.addEventListener(cancelEditBtn, 'click', () => this.hideEditModal());
    }

    // Modal backdrop clicks
    if (watchlistModal) {
      this.domManager.addEventListener(watchlistModal, 'click', (e) => {
        if (e.target === watchlistModal) {
          this.hideWatchlistModal();
        }
      });
    }

    if (editWatchlistModal) {
      this.domManager.addEventListener(editWatchlistModal, 'click', (e) => {
        if (e.target === editWatchlistModal) {
          this.hideEditModal();
        }
      });
    }

    // Setup event delegation for watchlist items
    this.setupWatchlistEventDelegation();

    // Setup tooltip accessibility
    this.setupTooltipAccessibility();
  }

  setupWatchlistEventDelegation() {
    const { watchlistItems } = this.elements;

    if (!watchlistItems) return;

    // Remove existing listeners if any
    if (this.watchlistClickHandler) {
      watchlistItems.removeEventListener('click', this.watchlistClickHandler);
      watchlistItems.removeEventListener('keydown', this.watchlistKeydownHandler);
    }

    // Create enhanced handlers
    const handleWatchlistClick = async (e) => {
      const button = e.target.closest('.action-btn');
      if (!button) return;

      e.preventDefault();
      e.stopPropagation();

      try {
        if (button.classList.contains('watchlist-refresh-btn')) {
          await this.handleRefreshProduct(button.dataset.productId);
        } else if (button.classList.contains('watchlist-edit-btn')) {
          await this.editWatchlistItem(button.dataset.itemId);
        } else if (button.classList.contains('watchlist-toggle-btn')) {
          await this.toggleWatchlistItem(button.dataset.itemId);
        } else if (button.classList.contains('watchlist-remove-btn')) {
          await this.removeWatchlistItem(button.dataset.itemId);
        } else if (button.classList.contains('watchlist-view-btn')) {
          await this.viewProduct(button.dataset.productUrl);
        }
      } catch (error) {
        this.error('Error handling watchlist action:', error);
        this.showError('خطا در انجام عملیات: ' + error.message);
      }
    };

    const handleWatchlistKeydown = (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handleWatchlistClick(e);
      }
    };

    // Add event listeners
    watchlistItems.addEventListener('click', handleWatchlistClick);
    watchlistItems.addEventListener('keydown', handleWatchlistKeydown);

    // Store handlers for cleanup
    this.watchlistClickHandler = handleWatchlistClick;
    this.watchlistKeydownHandler = handleWatchlistKeydown;

    watchlistItems.hasEventListener = true;
    this.log('Enhanced watchlist event delegation set up successfully');
  }

  setupTooltipAccessibility() {
    // Handle tooltip visibility for keyboard navigation
    document.addEventListener('focusin', (e) => {
      if (e.target.matches('.action-btn[title]')) {
        e.target.setAttribute('data-tooltip-visible', 'true');
      }
    });

    document.addEventListener('focusout', (e) => {
      if (e.target.matches('.action-btn[title]')) {
        e.target.removeAttribute('data-tooltip-visible');
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const focusedBtn = document.querySelector('.action-btn:focus[data-tooltip-visible]');
        if (focusedBtn) {
          focusedBtn.removeAttribute('data-tooltip-visible');
        }
      }
    });
  }

  // Event handlers
  handleTabSwitch(data) {
    if (data.tabIndex === 0) { // Watchlist tab
      this.loadWatchlistSummary();
    }
  }

  handleStorageCleared() {
    this.watchlistCache = [];
    this.loadWatchlistSummary();

    // Clear watchlist display if visible
    const { watchlistItems } = this.elements;
    if (watchlistItems) {
      watchlistItems.innerHTML = '<p style="text-align: center; color: #666; padding: 20px;">لیست نظارت قیمت خالی است</p>';
    }
  }

  // Core watchlist operations
  async loadWatchlistSummary() {
    try {
      const result = await this.getStorage('digikala_extension_watchlist', []);
      this.watchlistCache = result;

      const activeCount = result.filter(item => item.isActive).length;
      const totalCount = result.length;

      // Update show button
      const { showWatchlistBtn } = this.elements;
      if (showWatchlistBtn) {
        showWatchlistBtn.innerHTML = `<span>👁️</span> مشاهده لیست (${activeCount})`;
      }

      // Update summary display
      this.updateWatchlistSummary(totalCount, activeCount, result);

      this.emit('watchlist:summary-loaded', { totalCount, activeCount });
    } catch (error) {
      this.error('Error loading watchlist summary:', error);
      this.showError('خطا در بارگذاری خلاصه لیست نظارت');
    }
  }

  updateWatchlistSummary(totalCount, activeCount, watchlist) {
    const { watchlistSummary, totalItemsCount, activeItemsCount, lastUpdateText } = this.elements;

    if (!watchlistSummary) return;

    if (totalCount > 0) {
      // Calculate last check time
      const lastCheck = Math.max(...watchlist.map(item => item.lastCheckedAt || 0));
      let lastCheckText = 'هرگز';

      if (lastCheck > 0) {
        const lastCheckDate = new Date(lastCheck);
        const now = new Date();
        const diffInHours = (now - lastCheckDate) / (1000 * 60 * 60);

        if (diffInHours < 1) {
          const minutes = Math.round(diffInHours * 60);
          lastCheckText = `${minutes} دقیقه پیش`;
        } else if (diffInHours < 24) {
          lastCheckText = `${Math.round(diffInHours)} ساعت پیش`;
        } else {
          const days = Math.round(diffInHours / 24);
          lastCheckText = `${days} روز پیش`;
        }
      }

      // Update individual elements
      if (totalItemsCount) {
        this.domManager.setText(totalItemsCount, totalCount.toLocaleString('fa-IR'));
      }
      if (activeItemsCount) {
        this.domManager.setText(activeItemsCount, activeCount.toLocaleString('fa-IR'));
      }
      if (lastUpdateText) {
        this.domManager.setText(lastUpdateText, lastCheckText);
      }

      this.domManager.show(watchlistSummary);
    } else {
      this.domManager.hide(watchlistSummary);
    }
  }

  async showWatchlistModal() {
    const { watchlistModal } = this.elements;
    if (!watchlistModal) return;

    this.domManager.show(watchlistModal, 'flex');
    await this.loadWatchlistItems();

    this.emit('watchlist:modal-opened');
  }

  hideWatchlistModal() {
    const { watchlistModal } = this.elements;
    if (watchlistModal) {
      this.domManager.hide(watchlistModal);
    }

    this.emit('watchlist:modal-closed');
  }

  showEditModal() {
    const { editWatchlistModal } = this.elements;
    if (editWatchlistModal) {
      this.domManager.show(editWatchlistModal, 'flex');
    }
  }

  hideEditModal() {
    const { editWatchlistModal } = this.elements;
    if (editWatchlistModal) {
      this.domManager.hide(editWatchlistModal);
    }
    this.currentEditingEntry = null;
  }

  async loadWatchlistItems() {
    const { watchlistLoading, watchlistEmpty, watchlistItems } = this.elements;

    try {
      this.log('Loading watchlist items...');

      // Show loading state
      if (watchlistLoading) this.domManager.show(watchlistLoading, 'flex');
      if (watchlistEmpty) this.domManager.hide(watchlistEmpty);
      if (watchlistItems) this.domManager.hide(watchlistItems);

      // Load watchlist from storage
      const watchlist = await this.getStorage('digikala_extension_watchlist', []);
      this.watchlistCache = watchlist;

      this.log(`Loaded ${watchlist.length} watchlist items from storage`);

      // Hide loading state
      if (watchlistLoading) this.domManager.hide(watchlistLoading);

      if (watchlist.length === 0) {
        // Show empty state
        this.log('Showing empty state - no watchlist items');
        if (watchlistEmpty) this.domManager.show(watchlistEmpty, 'flex');
      } else {
        // Show watchlist items
        this.log('Rendering watchlist items');
        if (watchlistItems) {
          this.domManager.show(watchlistItems);
          this.renderWatchlistItems(watchlist);

          // Re-setup event delegation after rendering new content
          setTimeout(() => {
            this.setupWatchlistEventDelegation();
          }, 0);
        }
      }

      this.emit('watchlist:items-loaded', { count: watchlist.length });
    } catch (error) {
      this.error('Error loading watchlist items:', error);
      if (watchlistLoading) this.domManager.hide(watchlistLoading);
      this.showError('خطا در بارگذاری لیست نظارت: ' + error.message);
    }
  }

  renderWatchlistItems(watchlist) {
    const { watchlistItems } = this.elements;
    if (!watchlistItems) return;

    const itemsHTML = watchlist.map(item => this.generateWatchlistItemHTML(item)).join('');
    this.domManager.setHTML(watchlistItems, itemsHTML);

    // Add error handling for product images
    this.setupProductImageErrorHandling();
  }

  generateWatchlistItemHTML(item) {
    const conditions = this.formatConditions(item.conditions, item.checkInterval);
    const lastChecked = item.lastCheckedAt ?
      new Date(item.lastCheckedAt).toLocaleDateString('fa-IR', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }) : 'هرگز';

    const lastKnownPrice = item.lastKnownPrice ?
      `${Math.round(item.lastKnownPrice / 10).toLocaleString('fa-IR')} تومان` : 'نامشخص';

    return `
      <div class="watchlist-item ${item.isActive ? '' : 'disabled'}">
        <div class="watchlist-header">
          <div class="watchlist-product-info">
            <h4 class="watchlist-title">${item.productTitle}</h4>
            <div class="watchlist-conditions">${conditions}</div>
          </div>
          <div class="watchlist-product-image">
            ${item.productImage ? `
              <img src="${this.resizeDigikalaImage(item.productImage, 100, 100)}" alt="${item.productTitle}" class="product-image" />
              <div class="image-fallback" style="display: none;">
                <span>📦</span>
              </div>
            ` : `
              <div class="image-fallback">
                <span>📦</span>
              </div>
            `}
          </div>
        </div>

        <div class="watchlist-status">
          <div class="status-indicator ${item.isActive ? '' : 'inactive'}"></div>
          <div class="status-info">
            <div class="status-line">آخرین بررسی: ${lastChecked}</div>
            <div class="status-line price-info">آخرین قیمت: ${lastKnownPrice}</div>
          </div>
        </div>

        <div class="watchlist-actions">
          ${this.generateWatchlistActionsHTML(item)}
        </div>
      </div>
    `;
  }

  generateWatchlistActionsHTML(item) {
    return `
      <button class="action-btn watchlist-refresh-btn"
              data-product-id="${item.productId}"
              title="بررسی مجدد"
              aria-label="بررسی مجدد قیمت محصول ${item.productTitle}"
              tabindex="0"
              role="button">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21.5 2v6h-6"></path>
          <path d="M21.34 15.57a10 10 0 1 1-.57-8.38l-4.86 4.86"></path>
        </svg>
      </button>
      <button class="action-btn watchlist-edit-btn"
              data-item-id="${item.id}"
              title="ویرایش شرایط نظارت"
              aria-label="ویرایش شرایط نظارت برای ${item.productTitle}"
              tabindex="0"
              role="button">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
        </svg>
      </button>
      <button class="action-btn toggle watchlist-toggle-btn ${item.isActive ? '' : 'disabled'}"
              data-item-id="${item.id}"
              data-active="${item.isActive}"
              title="${item.isActive ? 'متوقف کردن نظارت' : 'فعال کردن نظارت'}"
              aria-label="${item.isActive ? 'متوقف کردن' : 'فعال کردن'} نظارت قیمت برای ${item.productTitle}"
              tabindex="0"
              role="button">
        ${item.isActive ?
          `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="6" y="4" width="4" height="16"></rect>
            <rect x="14" y="4" width="4" height="16"></rect>
          </svg>` :
          `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polygon points="5,3 19,12 5,21 5,3"></polygon>
          </svg>`
        }
      </button>
      <button class="action-btn danger watchlist-remove-btn"
              data-item-id="${item.id}"
              title="حذف از لیست نظارت"
              aria-label="حذف ${item.productTitle} از لیست نظارت"
              tabindex="0"
              role="button">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="3,6 5,6 21,6"></polyline>
          <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"></path>
          <line x1="10" y1="11" x2="10" y2="17"></line>
          <line x1="14" y1="11" x2="14" y2="17"></line>
        </svg>
      </button>
      ${item.productUrl ? `
      <button class="action-btn watchlist-view-btn"
              data-product-url="${item.productUrl}"
              title="نمایش محصول"
              aria-label="نمایش محصول ${item.productTitle} در دیجی‌کالا"
              tabindex="0"
              role="button">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
          <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
        </svg>
      </button>
      ` : ''}
    `;
  }

  setupProductImageErrorHandling() {
    const { watchlistItems } = this.elements;
    if (!watchlistItems) return;

    const productImages = watchlistItems.querySelectorAll('.product-image');
    productImages.forEach(img => {
      this.domManager.addEventListener(img, 'error', () => {
        img.style.display = 'none';
        const fallback = img.nextElementSibling;
        if (fallback && fallback.classList.contains('image-fallback')) {
          fallback.style.display = 'flex';
        }
      });
    });
  }

  formatConditions(conditions, checkInterval) {
    const tags = [];

    if (conditions.priceThreshold) {
      const price = Math.round(conditions.priceThreshold / 10).toLocaleString('fa-IR');
      tags.push(`<span class="condition-tag price">قیمت ≤ ${price} تومان</span>`);
    }

    if (conditions.minDiscountPercent) {
      tags.push(`<span class="condition-tag discount">تخفیف ≥ ${conditions.minDiscountPercent}%</span>`);
    }

    if (conditions.notifyOnLowest30Days) {
      tags.push(`<span class="condition-tag monthly">نزدیک به کمترین قیمت ۳۰ روز</span>`);
    }

    if (checkInterval && checkInterval !== 3600000) {
      const minutes = checkInterval / (1000 * 60);
      if (minutes < 60) {
        tags.push(`<span class="condition-tag interval">بررسی هر ${minutes} دقیقه</span>`);
      } else {
        const hours = Math.round(minutes / 60);
        tags.push(`<span class="condition-tag interval">بررسی هر ${hours} ساعت</span>`);
      }
    }

    return tags.join(' ');
  }

  resizeDigikalaImage(imageUrl, width, height) {
    if (!imageUrl) return '';

    // Handle images with existing resize parameters
    if (imageUrl.includes('h_') && imageUrl.includes('w_')) {
      const resizedUrl = imageUrl.replace(
        /h_\d+,w_\d+/g,
        `h_${height},w_${width}`
      );
      return resizedUrl;
    }

    // If it doesn't have size parameters but is a Digikala image, add them
    if (imageUrl.includes('dkstatics-public.digikala.com')) {
      const separator = imageUrl.includes('?') ? '&' : '?';
      return `${imageUrl}${separator}x-oss-process=image/resize,m_lfit,h_${height},w_${width}/quality,q_90`;
    }

    // Return original URL if not a Digikala image
    return imageUrl;
  }

  // Action handlers
  async handleRefreshProduct(productId) {
    if (!productId) return;

    this.showLoading(true);
    try {
      // Send message directly to background script instead of through tab
      const response = await chrome.runtime.sendMessage({
        action: 'refreshWatchlistItem',
        productId: productId
      });

      if (response && response.success) {
        this.showSuccess('بررسی مجدد محصول انجام شد ✅');
        await this.loadWatchlistItems();
        await this.loadWatchlistSummary();
      } else if (response?.error === 'throttled') {
        const retryAfter = response.retryAfter || 60;
        this.showError(`لطفاً ${retryAfter} ثانیه صبر کنید و دوباره تلاش کنید`);
      } else {
        throw new Error(response?.error || 'Failed to refresh product');
      }
    } catch (error) {
      this.error('Error refreshing product:', error);
      this.showError('خطا در بررسی مجدد محصول');
    } finally {
      this.showLoading(false);
    }
  }

  async editWatchlistItem(itemId) {
    const item = this.watchlistCache.find(item => item.id === itemId);
    if (!item) {
      this.showError('محصول مورد نظر یافت نشد');
      return;
    }

    this.currentEditingEntry = item;

    // Populate edit form
    const {
      editProductTitle, editPriceThreshold, editDiscountThreshold,
      editNotifyLowest30Days, editCheckInterval
    } = this.elements;

    if (editProductTitle) {
      this.domManager.setText(editProductTitle, item.productTitle);
    }
    if (editPriceThreshold) {
      editPriceThreshold.value = item.conditions.priceThreshold ?
        Math.round(item.conditions.priceThreshold / 10) : '';
    }
    if (editDiscountThreshold) {
      editDiscountThreshold.value = item.conditions.minDiscountPercent || '';
    }
    if (editNotifyLowest30Days) {
      editNotifyLowest30Days.checked = item.conditions.notifyOnLowest30Days || false;
    }
    if (editCheckInterval) {
      editCheckInterval.value = item.checkInterval || 14400000; // 4 hours default
    }

    this.showEditModal();
    this.emit('watchlist:item-edit-started', { itemId, item });
  }

  async saveWatchlistItemEdit() {
    if (!this.currentEditingEntry) {
      this.showError('هیچ محصولی در حال ویرایش نیست');
      return;
    }

    try {
      const {
        editPriceThreshold, editDiscountThreshold,
        editNotifyLowest30Days, editCheckInterval
      } = this.elements;

      // Get form values
      const priceThreshold = editPriceThreshold?.value ?
        parseFloat(editPriceThreshold.value) * 10 : null; // Convert to rials
      const discountThreshold = editDiscountThreshold?.value ?
        parseFloat(editDiscountThreshold.value) : null;
      const notifyLowest30Days = editNotifyLowest30Days?.checked || false;
      const checkInterval = parseInt(editCheckInterval?.value) || 14400000; // 4 hours default

      // Validation - at least one condition must be set
      if (!priceThreshold && !discountThreshold && !notifyLowest30Days) {
        this.showError('لطفاً حداقل یک شرط برای نظارت تعیین کنید');
        return;
      }

      // Update the watchlist
      const watchlist = await this.getStorage('digikala_extension_watchlist', []);
      const itemIndex = watchlist.findIndex(item => item.id === this.currentEditingEntry.id);

      if (itemIndex === -1) {
        this.showError('محصول در لیست نظارت یافت نشد');
        return;
      }

      // Update the item
      watchlist[itemIndex].conditions = {
        priceThreshold,
        minDiscountPercent: discountThreshold,
        notifyOnLowest30Days: notifyLowest30Days
      };
      watchlist[itemIndex].checkInterval = checkInterval;

      // Save to storage
      await this.setStorage('digikala_extension_watchlist', watchlist);

      this.showSuccess('تنظیمات نظارت به‌روزرسانی شد');
      this.hideEditModal();

      // Refresh the display
      await this.loadWatchlistItems();
      await this.loadWatchlistSummary();

      this.emit('watchlist:item-edited', {
        itemId: this.currentEditingEntry.id,
        updatedItem: watchlist[itemIndex]
      });

    } catch (error) {
      this.error('Error saving watchlist item edit:', error);
      this.showError('خطا در ذخیره تغییرات');
    }
  }

  async toggleWatchlistItem(itemId) {
    try {
      const watchlist = await this.getStorage('digikala_extension_watchlist', []);
      const itemIndex = watchlist.findIndex(item => item.id === itemId);

      if (itemIndex === -1) {
        throw new Error('Item not found');
      }

      const item = watchlist[itemIndex];
      item.isActive = !item.isActive;

      await this.setStorage('digikala_extension_watchlist', watchlist);

      this.showSuccess(`نظارت محصول ${item.isActive ? 'فعال' : 'غیرفعال'} شد`);

      await this.loadWatchlistItems();
      await this.loadWatchlistSummary();

      this.emit('watchlist:item-toggled', { itemId, isActive: item.isActive });
    } catch (error) {
      this.error('Error toggling watchlist item:', error);
      this.showError('خطا در تغییر وضعیت نظارت');
    }
  }

  async removeWatchlistItem(itemId) {
    // Find the item to get its title for the confirmation message
    const item = this.watchlistCache.find(item => item.id === itemId);
    const productTitle = item ? item.productTitle : 'این محصول';

    // Show custom confirmation dialog through modal manager
    const confirmed = await new Promise((resolve) => {
      this.emit('ui:show-confirm-dialog', {
        title: 'حذف از لیست نظارت',
        message: `آیا مطمئن هستید که می‌خواهید "${productTitle}" را از لیست نظارت حذف کنید؟`,
        confirmText: 'حذف',
        cancelText: 'انصراف',
        onConfirm: () => resolve(true),
        onCancel: () => resolve(false)
      });
    });

    if (!confirmed) {
      return;
    }

    try {
      const watchlist = await this.getStorage('digikala_extension_watchlist', []);
      const filteredWatchlist = watchlist.filter(item => item.id !== itemId);

      await this.setStorage('digikala_extension_watchlist', filteredWatchlist);

      this.showSuccess('محصول از لیست نظارت حذف شد');

      await this.loadWatchlistItems();
      await this.loadWatchlistSummary();

      this.emit('watchlist:item-removed', { itemId });
    } catch (error) {
      this.error('Error removing watchlist item:', error);
      this.showError('خطا در حذف محصول از لیست نظارت');
    }
  }

  async viewProduct(productUrl) {
    if (!productUrl) return;

    try {
      await chrome.tabs.create({
        url: productUrl,
        active: false
      });
      this.emit('watchlist:product-viewed', { url: productUrl });
    } catch (error) {
      this.error('Error opening product URL:', error);
      this.showError('خطا در باز کردن صفحه محصول');
    }
  }

  async refreshWatchlist() {
    this.showLoading(true);
    try {
      // Get all watchlist items to refresh their prices
      const watchlist = await this.getStorage('digikala_extension_watchlist', []);

      if (watchlist.length === 0) {
        this.showSuccess('هیچ محصولی در لیست نظارت نیست');
        return;
      }

      let successCount = 0;
      let totalCount = watchlist.length;

      // Refresh each product's price data
      for (const item of watchlist) {
        if (item.productId) {
          try {
            const response = await chrome.runtime.sendMessage({
              action: 'refreshWatchlistItem',
              productId: item.productId
            });

            if (response && response.success) {
              successCount++;
            }
          } catch (error) {
            this.warn(`Failed to refresh product ${item.productId}:`, error);
          }
        }
      }

      // Reload UI data after refreshing prices
      await this.loadWatchlistSummary();
      if (this.domManager.getStyle(this.elements.watchlistModal, 'display') === 'flex') {
        await this.loadWatchlistItems();
      }

      if (successCount === totalCount) {
        this.showSuccess(`تمام ${totalCount} محصول به‌روزرسانی شد ✅`);
      } else if (successCount > 0) {
        this.showSuccess(`${successCount} از ${totalCount} محصول به‌روزرسانی شد ⚠️`);
      } else {
        this.showError('خطا در به‌روزرسانی محصولات');
      }

      this.emit('watchlist:refreshed');
    } catch (error) {
      this.error('Error refreshing watchlist:', error);
      this.showError('خطا در به‌روزرسانی لیست نظارت');
    } finally {
      this.showLoading(false);
    }
  }

  async handleClearAllWatchlist() {
    // Show confirmation dialog through modal manager
    const confirmed = await new Promise((resolve) => {
      this.emit('ui:show-confirm-dialog', {
        title: 'پاک کردن لیست نظارت',
        message: 'آیا مطمئن هستید که می‌خواهید تمام محصولات را از لیست نظارت حذف کنید؟ این عمل قابل برگشت نیست.',
        confirmText: 'پاک کردن',
        cancelText: 'انصراف',
        onConfirm: () => resolve(true),
        onCancel: () => resolve(false)
      });
    });

    if (!confirmed) {
      return;
    }

    try {
      await this.setStorage('digikala_extension_watchlist', []);
      this.watchlistCache = [];

      this.showSuccess('تمام محصولات از لیست نظارت حذف شدند');

      await this.loadWatchlistItems();
      await this.loadWatchlistSummary();

      this.emit('watchlist:cleared');
    } catch (error) {
      this.error('Error clearing watchlist:', error);
      this.showError('خطا در پاک کردن لیست نظارت');
    }
  }

  // Cleanup
  async cleanup() {
    const { watchlistItems } = this.elements;

    if (watchlistItems && this.watchlistClickHandler) {
      watchlistItems.removeEventListener('click', this.watchlistClickHandler);
      watchlistItems.removeEventListener('keydown', this.watchlistKeydownHandler);
    }

    this.watchlistCache = [];
    this.currentEditingEntry = null;
    this.watchlistClickHandler = null;
    this.watchlistKeydownHandler = null;
  }

  // Public API
  getWatchlistCache() {
    return this.watchlistCache;
  }

  async getWatchlistCount() {
    const watchlist = await this.getStorage('digikala_extension_watchlist', []);
    return {
      total: watchlist.length,
      active: watchlist.filter(item => item.isActive).length
    };
  }
}

// Make available globally
window.WatchlistManager = WatchlistManager;