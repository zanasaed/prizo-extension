/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Product List Controller - Handles search pages, category pages, and product listings
 */
class ProductListController extends BaseController {
  constructor(services) {
    super(services, 'product-list');
    this.updateInterval = null;
    this.batchSize = 5;
    this.processDelay = 200;
  }

  async initialize() {
    console.log('🔄 Initializing product list controller');
    
    // Check if we're on a product listing page
    if (!this.isProductListPage()) {
      console.log('❌ Not a product list page, skipping initialization');
      return;
    }

    // Load settings
    const settings = this.getSettings();
    this.batchSize = settings.maxConcurrentRequests || 5;
    this.processDelay = settings.processDelay || 200;
    
    // Note: Sorting functionality is now handled by GlobalSortingService
  }

  isProductListPage() {
    const url = window.location.href;
    const path = window.location.pathname;
    
    // Exclude profile lists page specifically
    if (url.includes('/profile/lists/')) {
      console.log('❌ Profile lists page detected - excluding from product list processing');
      return false;
    }
    
    // Check for search pages, category pages, etc.
    const listPagePatterns = [
      /\/search\//,
      /\/category\//,
      /\/categories\//,
      /\/brand\//,
      /\/seller\//,
      /\/products\//,
      /\/tags\//,
      /\/offers\//,
      /\/bestselling\//,
      /\/most-popular\//,
      /\/discounted\//
    ];

    return listPagePatterns.some(pattern => pattern.test(url) || pattern.test(path)) ||
           document.querySelector('[data-testid="product-list"]') ||
           document.querySelector('.product-list') ||
           this.getProductElements().length > 1;
  }

  setupEventListeners() {
    // Listen for scroll events to process visible products
    this.scrollHandler = this.debounce(() => {
      if (this.isActive) {
        this.processVisibleElements();
      }
    }, 300);

    window.addEventListener('scroll', this.scrollHandler);

    // Listen for page changes (for SPA navigation)
    this.urlChangeHandler = () => {
      if (this.isActive) {
        setTimeout(() => this.processInitialElements(), 1000);
        
        // Sort option is now handled by GlobalSortingService
      }
    };

    window.addEventListener('popstate', this.urlChangeHandler);
    
    // Sort monitoring is now handled by GlobalSortingService
  }

  removeEventListeners() {
    if (this.scrollHandler) {
      window.removeEventListener('scroll', this.scrollHandler);
      this.scrollHandler = null;
    }

    if (this.urlChangeHandler) {
      window.removeEventListener('popstate', this.urlChangeHandler);
      this.urlChangeHandler = null;
    }

    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
    
    // Sort monitoring cleanup is now handled by GlobalSortingService
  }

  cleanup() {
    this.processingQueue.clear();
    
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }
  }

  async processInitialElements() {
    console.log('🔄 Processing initial product elements');
    
    // Get products using DOM manager (exactly like original)
    const productElements = this.services.domManager.getProductElements();
    console.log(`📦 Found ${productElements.length} product elements`);

    if (productElements.length === 0) {
      console.log('⚠️ No product elements found');
      return;
    }

    // Process products exactly like original (updateMonthlyPricesOnly method)
    await this.updateMonthlyPricesOnly(Array.from(productElements));
  }

  async updateMonthlyPricesOnly(products) {
    console.log(`🔄 Processing ${products.length} products for monthly prices only`);

    for (let i = 0; i < products.length; i++) {
      if (this.shouldStop) {
        console.log('⏹️ Processing stopped by user');
        throw new Error('STOPPED_BY_USER');
      }

      const productElement = products[i];
      console.log(`\n--- Processing product ${i + 1}/${products.length} for monthly price ---`);

      try {
        const productId = this.services.domManager.extractProductId(productElement);
        console.log('🆔 Product ID:', productId);

        if (!productId) {
          console.log('❌ No product ID found, skipping');
          continue;
        }

        if (this.processedElements.has(productId)) {
          console.log('⏭️ Product already processed, skipping');
          continue;
        }

        this.processedElements.add(productId);
        await this.updateSingleProductMonthlyPrice(productElement, productId);

        // Check for stop again after processing
        if (this.shouldStop) {
          throw new Error('STOPPED_BY_USER');
        }

        // Reasonable delay between requests (exactly like original)
        await new Promise(resolve => setTimeout(resolve, 800));

      } catch (error) {
        if (error.message === 'STOPPED_BY_USER') {
          throw error;
        }
        console.error('❌ Error updating product monthly price:', error);
        // Continue with next product instead of failing completely
      }
    }
  }

  async updateSingleProductMonthlyPrice(productElement, productId) {
    try {
      console.log(`🔄 Updating monthly price for product: ${productId}`);

      const productData = await this.services.dataManager.fetchProductDataForProductPage(productId);
      if (!productData) {
        console.log('❌ No product data received');
        return;
      }

      const monthlyLowPrice = await this.services.dataManager.extractMonthlyLowPrice(productData, productId);

      // Check if this product has seller-only shipping and extract shipping cost
      let sellerShippingInfo = null;
      if (productData.default_variant) {
        sellerShippingInfo = this.services.dataManager.extractSellerOnlyShippingCost(productData.default_variant);
      }

      // Add monthly price section with optional shipping info
      this.addMonthlyPriceSectionOnly(productElement, monthlyLowPrice, sellerShippingInfo);

      console.log('✅ Monthly price update completed', sellerShippingInfo ? 'with shipping info' : '');
    } catch (error) {
      console.error(`❌ Error updating monthly price for product ${productId}:`, error);
    }
  }

  addMonthlyPriceSectionOnly(productElement, monthlyLowPrice, sellerShippingInfo = null) {
    // Use the DOMManager's new system instead of the old monthly-price-section system
    if (this.services.domManager && this.services.domManager.addMonthlyPriceSectionOnly) {
      this.services.domManager.addMonthlyPriceSectionOnly(productElement, monthlyLowPrice, sellerShippingInfo);
    } else {
      console.log('⚠️ DOMManager not available for monthly price injection');
    }
  }

  async processNewElements() {
    if (!this.isActive) return;
    
    const newProductElements = this.getProductElements().filter(element => 
      !this.processedElements.has(element)
    );

    if (newProductElements.length > 0) {
      console.log(`📦 Found ${newProductElements.length} new product elements`);
      await this.processBatch(newProductElements);
    }
  }

  async processVisibleElements() {
    if (!this.isActive) return;
    
    const visibleElements = this.getProductElements().filter(element => 
      !this.processedElements.has(element) && this.isElementInViewport(element)
    );

    if (visibleElements.length > 0) {
      console.log(`👁️ Processing ${visibleElements.length} visible product elements`);
      await this.processBatch(visibleElements);
    }
  }

  async processBatch(elements) {
    // Process elements in smaller batches to avoid overwhelming the API
    for (let i = 0; i < elements.length; i += this.batchSize) {
      const batch = elements.slice(i, i + this.batchSize);
      
      const promises = batch.map(element => {
        const productId = this.extractProductId(element);
        if (productId) {
          return this.processElement(element, productId);
        }
        return Promise.resolve();
      });

      await Promise.allSettled(promises);
      
      // Add delay between batches to be respectful to the API
      if (i + this.batchSize < elements.length) {
        await new Promise(resolve => setTimeout(resolve, this.processDelay));
      }
    }
  }

  async handleElement(element, productId) {
    try {
      console.log(`🔄 Processing product ${productId}`);

      // Use the data manager (which uses background script messaging)
      const dataResult = await this.services.dataManager.fetchProductData(productId);
      
      if (!dataResult || !dataResult.success || !dataResult.data) {
        console.log(`⚠️ No data found for product ${productId}`);
        this.markElementAsUnavailable(element);
        return;
      }

      const productData = dataResult.data;

      // Extract monthly low price using data manager
      const monthlyLowPrice = await this.services.dataManager.extractMonthlyLowPrice(productData, productId);

      // Check if this product has seller shipping and extract shipping cost
      let sellerShippingInfo = null;
      if (productData.default_variant) {
        sellerShippingInfo = this.services.dataManager.extractSellerOnlyShippingCost(productData.default_variant);
      }

      // Update UI - show monthly price and shipping for listing pages
      if (monthlyLowPrice > 0) {
        this.addMonthlyPriceInfo(element, monthlyLowPrice, sellerShippingInfo);
      }

      this.markElementAsUpdated(element);
      console.log(`✅ Successfully processed product ${productId}`);

    } catch (error) {
      console.error(`❌ Error processing product ${productId}:`, error);
      this.markElementAsError(element);
      
      // Show user-friendly error for network issues
      if (error.message.includes('fetch') || error.message.includes('network')) {
        this.showNotification({
          type: 'warning',
          title: 'خطای شبکه',
          message: 'مشکل در دریافت اطلاعات قیمت. در حال تلاش مجدد...',
          autoHide: true,
          duration: 3000
        });
      }
    }
  }

  getProductElements() {
    // Use DOM manager to get product elements
    return this.services.domManager.getProductElements();
  }

  addSellerPriceInfo(element, discountResult, monthlyLowPrice) {
    if (this.services.domManager) {
      this.services.domManager.addSellerPriceSection(
        element, 
        discountResult.sellerPrice, 
        discountResult.discount, 
        monthlyLowPrice
      );
    }
  }

  addMonthlyPriceInfo(element, monthlyLowPrice, sellerShippingInfo = null) {
    // Use the DOM manager's addMonthlyPriceSectionOnly method
    this.services.domManager.addMonthlyPriceSectionOnly(element, monthlyLowPrice, sellerShippingInfo);
  }

  markElementAsUpdated(element) {
    this.services.domManager.addUpdatedIndicator(element);
  }

  markElementAsError(element) {
    this.services.domManager.markProductAsError(element);
  }

  markElementAsUnavailable(element) {
    this.services.domManager.markProductAsUnavailable(element);
  }

  isElementVisible(element) {
    return this.services.domManager.isElementVisible(element);
  }

  isElementInViewport(element) {
    const rect = element.getBoundingClientRect();
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    const windowWidth = window.innerWidth || document.documentElement.clientWidth;
    
    return rect.top < windowHeight + 200 && // 200px buffer
           rect.bottom > -200 &&
           rect.left < windowWidth &&
           rect.right > 0;
  }

  isElementRelevant(element) {
    // Check if element is a product card
    const selectors = [
      'article[data-product-id]',
      '[data-testid="product-card"]',
      '.c-product-box',
      '.product-list__item'
    ];

    return selectors.some(selector => 
      element.matches(selector) || element.querySelector(selector)
    );
  }

  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  async refreshAllProducts() {
    console.log('🔄 Refreshing all products');
    
    // Clear processed elements to force reprocessing
    this.processedElements = new Set();
    
    // Remove existing price elements
    if (this.services.domManager) {
      this.services.domManager.removeAllSellerElements();
    }
    
    // Reprocess all elements
    await this.processInitialElements();
    
    this.showNotification({
      type: 'success',
      title: 'بروزرسانی کامل',
      message: 'قیمت همه محصولات بروزرسانی شد',
      autoHide: true,
      duration: 3000
    });
  }

  async activate() {
    // Call parent activate method first
    await super.activate();
    
    // Sort feature is now handled globally by GlobalSortingService
  }

}

window.ProductListController = ProductListController;