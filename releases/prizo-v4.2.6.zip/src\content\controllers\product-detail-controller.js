/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Product Detail Controller - Handles individual product pages
 */
class ProductDetailController extends BaseController {
  constructor(services) {
    super(services, 'product-detail');
    this.currentProductId = null;
    this.priceUpdateInterval = null;
    this.watchlistModal = null;
    this.isInWatchlist = false;
    this.smartCartButton = null;
  }

  async initialize() {
    console.log('🔄 Initializing product detail controller');

    // Check if we're on a product detail page
    if (!this.isProductDetailPage()) {
      console.log('❌ Not a product detail page, skipping initialization');
      return;
    }

    // Extract current product ID
    this.currentProductId = this.extractProductIdFromURL();
    console.log(`📦 Current product ID: ${this.currentProductId}`);

    if (!this.currentProductId) {
      console.log('⚠️ Could not extract product ID from URL');
      return;
    }
  }

  isProductDetailPage() {
    const url = window.location.href;
    const path = window.location.pathname;

    // Check for product detail page patterns
    const detailPagePatterns = [
      /\/dp\//,
      /\/product\//,
      /\/dkp-\d+/
    ];

    return detailPagePatterns.some(pattern => pattern.test(url) || pattern.test(path)) ||
      document.querySelector('[data-testid="buy-box"]') ||
      document.querySelector('.product-buy-box') ||
      document.querySelector('[data-testid="price-final"]');
  }

  extractProductIdFromURL() {
    const url = window.location.href;
    const path = window.location.pathname;

    // Try different URL patterns
    const patterns = [
      /\/dp\/(\d+)\//,
      /\/product\/(\d+)\//,
      /\/dkp-(\d+)/,
      /product-id[=:](\d+)/,
      /\/(\d+)\//
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern) || path.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }

    return null;
  }

  setupEventListeners() {
    // Listen for URL changes (SPA navigation)
    this.urlChangeHandler = () => {
      setTimeout(() => {
        const newProductId = this.extractProductIdFromURL();
        if (newProductId && newProductId !== this.currentProductId) {
          this.currentProductId = newProductId;
          this.processInitialElements();
        }
      }, 1000);
    };

    window.addEventListener('popstate', this.urlChangeHandler);

    // Listen for page refresh/reload events
    this.pageShowHandler = (event) => {
      console.log('📄 Page show event detected', { persisted: event.persisted });
      if (event.persisted) {
        // Page was restored from back/forward cache - clear processed elements
        console.log('🔄 Clearing processed elements cache due to page restore');
        this.processedElements.clear();
      }
      // Always reprocess on page show to ensure elements are present
      setTimeout(() => {
        this.processInitialElements();
      }, 500);
    };

    window.addEventListener('pageshow', this.pageShowHandler);

    // Also listen for beforeunload to clear cache on refresh
    this.beforeUnloadHandler = () => {
      console.log('📄 Page unloading, clearing processed elements cache');
      this.processedElements.clear();
    };

    window.addEventListener('beforeunload', this.beforeUnloadHandler);

    // Listen for variant selection changes
    this.variantChangeHandler = () => {
      setTimeout(() => this.handleVariantChange(), 500);
    };

    document.addEventListener('click', this.variantChangeHandler);

    // Listen for requests to get current product info with updated price
    this.services.eventBus.on('product-detail:get-current-info', this.handleGetCurrentInfo.bind(this));
  }

  removeEventListeners() {
    if (this.urlChangeHandler) {
      window.removeEventListener('popstate', this.urlChangeHandler);
      this.urlChangeHandler = null;
    }

    if (this.pageShowHandler) {
      window.removeEventListener('pageshow', this.pageShowHandler);
      this.pageShowHandler = null;
    }

    if (this.beforeUnloadHandler) {
      window.removeEventListener('beforeunload', this.beforeUnloadHandler);
      this.beforeUnloadHandler = null;
    }

    if (this.variantChangeHandler) {
      document.removeEventListener('click', this.variantChangeHandler);
      this.variantChangeHandler = null;
    }

    if (this.priceUpdateInterval) {
      clearInterval(this.priceUpdateInterval);
      this.priceUpdateInterval = null;
    }

    // Remove event bus listeners
    this.services.eventBus.off('product-detail:get-current-info', this.handleGetCurrentInfo.bind(this));
  }

  cleanup() {
    // Remove any product-specific UI elements
    this.removeProductDetailElements();

    // Close watchlist modal if open
    this.closeWatchlistModal();

    // Cleanup Smart Cart button
    if (this.smartCartButton) {
      this.smartCartButton.cleanup();
      this.smartCartButton = null;
    }

    // Cleanup voucher section
    if (this.voucherSection) {
      this.voucherSection.cleanup();
      this.voucherSection = null;
    }
  }

  async processInitialElements() {
    console.log('🔄 Processing product detail page');

    try {
      // Extract product ID from URL (exactly like original)
      const productId = this.extractProductIdFromURL();
      if (!productId) {
        console.log('❌ Could not extract product ID from URL');
        return;
      }

      console.log('🆔 Product ID:', productId);
      this.currentProductId = productId;

      // Check if already processed to avoid duplication (exactly like original)
      if (this.processedElements.has(`product_${productId}`)) {
        console.log('ℹ️ Product already processed, checking for updates...');

        // Check if page structure has changed (e.g., due to navigation)
        const hasPrice = document.querySelector('[data-testid="price-final"]');
        const hasExistingSection = document.querySelector('.monthly-price-main-section');
        const hasShippingCost = document.querySelector('.seller-shipping-cost');

        if (hasPrice && (!hasExistingSection || !hasShippingCost)) {
          console.log('🔄 Page structure changed or shipping cost missing, reprocessing...');
          this.processedElements.delete(`product_${productId}`);
        } else {
          console.log('✅ All elements present, skipping reprocessing');
          return;
        }
      }

      // Wait for page to be ready before fetching data (exactly like original)
      const pageReady = await this.waitForProductPageElements();
      if (!pageReady) {
        console.log('⚠️ Product page elements not ready');
        return;
      }

      // Fetch product data (exactly like original)
      const productData = await this.services.dataManager.fetchProductDataForProductPage(productId);
      if (!productData) {
        console.log('❌ Failed to fetch product data, will retry later');

        // Schedule a retry after a delay (exactly like original)
        setTimeout(() => {
          if (!this.isStopped) {
            console.log('🔄 Retrying product detail page update...');
            this.processInitialElements();
          }
        }, 3000);
        return;
      }

      // Validate that we have essential product data (exactly like original)
      if (!this.services.dataManager.validateProductData(productData)) {
        console.log('⚠️ Product data incomplete, attempting partial update...');
      }

      // Mark as processed (exactly like original)
      this.processedElements.add(`product_${productId}`);

      // Update the product detail page display (exactly like original)
      await this.updateProductDetailDisplay(productData, productId);

      // Inject comparison links with a small delay to ensure DOM is ready
      setTimeout(async () => {
        await this.injectComparisonLinks();
      }, 500);

      console.log('✅ Product detail page update completed');
    } catch (error) {
      if (error.message === 'STOPPED_BY_USER') {
        throw error;
      }
      console.error('❌ Error updating product detail page:', error);
    }
  }

  async waitForProductPageElements(maxAttempts = 15, interval = 500) {
    console.log('⏳ Waiting for product page elements to load...');

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      // Multiple fallback selectors for price container (exactly like original)
      const priceSelectors = [
        '.flex.flex-row.items-center:has([data-testid="price-final"])',
        '[data-testid="buy-box"] [data-testid="price-final"]',
        '[data-testid="price-final"]',
        '.flex.justify-start.mr-auto.text-h3',
        '[data-testid="buy-box"]'
      ];

      let priceContainer = null;
      for (const selector of priceSelectors) {
        try {
          priceContainer = document.querySelector(selector);
          if (priceContainer) {
            console.log(`✅ Price container found with selector: ${selector}`);
            break;
          }
        } catch (e) {
          // Skip invalid selectors
          continue;
        }
      }

      // Multiple fallback selectors for variant container (exactly like original)
      const variantSelectors = [
        '.flex.lg\\:flex-wrap.overflow-x-auto.px-5.lg\\:px-0',
        '[data-testid="variant-selector"]',
        '.variant-selector',
        '.variants-container',
        '[class*="variant"]',
        '[class*="color-selector"]',
        '[class*="size-selector"]'
      ];

      let variantContainer = null;
      for (const selector of variantSelectors) {
        try {
          variantContainer = document.querySelector(selector);
          if (variantContainer) {
            console.log(`✅ Variant container found with selector: ${selector}`);
            break;
          }
        } catch (e) {
          // Skip invalid selectors
          continue;
        }
      }

      if (priceContainer) {
        console.log(`✅ Price container found after ${attempt} attempts`);

        // If we have price but not variants yet, wait a bit more for variants
        if (!variantContainer && attempt < maxAttempts - 5) {
          console.log('⏳ Price found, waiting for variant container...');
          await new Promise(resolve => setTimeout(resolve, interval * 2));
          continue;
        }

        if (variantContainer) {
          console.log(`✅ Variant container also found`);
        } else {
          console.log('ℹ️ No variant container found (product might not have variants)');
        }

        // Additional check for buy-box readiness
        const buyBoxContainer = document.querySelector('[data-testid="buy-box"]');
        if (buyBoxContainer) {
          console.log('✅ Buy-box container confirmed');
        }

        return true;
      }

      if (attempt < maxAttempts) {
        console.log(`⏳ Attempt ${attempt}/${maxAttempts}: Elements not ready, waiting...`);
        await new Promise(resolve => setTimeout(resolve, interval));
      }
    }

    console.log('⚠️ Some elements not found after maximum attempts');
    return false;
  }

  async updateProductDetailDisplay(productData, productId) {
    // Wait for page elements to be ready before updating (exactly like original)
    await this.waitForProductPageElements();

    // Add monthly price below main price (exactly like original)
    await this.addMonthlyPriceBelowMainPrice(productData, productId);

    // Add seller shipping cost to product page if it's seller-only shipping
    this.addSellerShippingCostToPage(productData);

    // Add watchlist button near the monthly price section
    await this.addWatchlistButton(productData, productId);

    // Add Smart Cart button near the watchlist button
    await this.addSmartCartButton(productData, productId);

    // Add seller vouchers section
    await this.addSellerVouchers(productId);

    // Add variant price comparison below variant selector (exactly like original)
    if (this.services.domManager && this.services.domManager.addVariantPriceComparison) {
      this.services.domManager.addVariantPriceComparison(productData, this.services.dataManager);
    }
  }

  /**
   * Add seller shipping cost to single product page if it's seller-only shipping
   * @param {Object} productData - Product data from API
   */
  addSellerShippingCostToPage(productData) {
    try {
      console.log('🔍 Checking for seller shipping cost...', {
        hasProductData: !!productData,
        hasDefaultVariant: !!(productData?.default_variant)
      });
      
      if (!productData || !productData.default_variant) {
        console.log('⚠️ Missing product data or default variant');
        return;
      }

      // Check if this product has seller-only shipping
      const sellerShippingInfo = this.services.dataManager.extractSellerOnlyShippingCost(productData.default_variant);
      
      if (sellerShippingInfo) {
        console.log('🚚 Product has seller-only shipping, adding cost to page', sellerShippingInfo);
        
        // Check if shipping cost is already present
        const existingCost = document.querySelector('.seller-shipping-cost');
        if (existingCost) {
          console.log('⚠️ Shipping cost already exists, removing existing before adding new');
          existingCost.remove();
        }
        
        // Add shipping cost to the product page using DOM manager
        this.services.domManager.addShippingCostToProductPage(sellerShippingInfo);
      } else {
        console.log('📦 Product does not have seller-only shipping');
      }
    } catch (error) {
      console.error('❌ Error adding seller shipping cost to page:', error);
    }
  }

  async addMonthlyPriceBelowMainPrice(productData, productId) {
    // Multiple strategies to find the main price element (exactly like original)
    let priceElement = null;
    let priceContainer = null;

    // Strategy 1: XPath approach - target parent element with 'flex items-center' class
    const xpaths = [
      "//div[@data-testid='buy-box']//div[@class='flex justify-start mr-auto text-h3']/ancestor::*[contains(@class,'flex items-center')][1]",
      "//div[@data-testid='buy-box']//span[@data-testid='price-final']/ancestor::*[contains(@class,'flex items-center')][1]",
      "//div[@data-testid='buy-box']//span[contains(@class,'price')]/ancestor::*[contains(@class,'flex items-center')][1]",
      "//div[@data-testid='buy-box']//div[contains(@class,'text-h3')]/ancestor::*[contains(@class,'flex items-center')][1]"
    ];

    for (const xpath of xpaths) {
      try {
        const result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        if (result.singleNodeValue) {
          priceElement = result.singleNodeValue;
          console.log(`✅ Found price element with XPath: ${xpath}`);
          break;
        }
      } catch (e) {
        console.log(`⚠️ XPath failed: ${xpath}`);
        continue;
      }
    }

    // Strategy 2: CSS selector approach (exactly like original)
    if (!priceElement) {
      const selectors = [
        '[data-testid="buy-box"] [data-testid="price-final"]',
        '[data-testid="buy-box"] .flex.justify-start.mr-auto.text-h3',
        '[data-testid="price-final"]',
        '[data-testid="buy-box"] span[class*="price"]',
        '[data-testid="buy-box"] div[class*="text-h3"]'
      ];

      for (const selector of selectors) {
        try {
          priceElement = document.querySelector(selector);
          if (priceElement) {
            console.log(`✅ Found price element with CSS: ${selector}`);
            break;
          }
        } catch (e) {
          continue;
        }
      }
    }

    if (!priceElement) {
      console.log('❌ Could not find main price element with any strategy');
      return;
    }

    // Find the parent container of the price element with multiple fallbacks (exactly like original)
    const containerSelectors = [
      '.flex.flex-row.items-center',
      '[data-testid="buy-box"]',
      '.price-container',
      '.product-price'
    ];

    for (const selector of containerSelectors) {
      priceContainer = priceElement.closest(selector);
      if (priceContainer) {
        console.log(`✅ Found price container: ${selector}`);
        break;
      }
    }

    // Fallback to parent element (exactly like original)
    if (!priceContainer) {
      priceContainer = priceElement.parentElement;
      console.log('✅ Using price element parent as container');
    }

    if (!priceContainer) {
      console.log('❌ Could not find main price container');
      return;
    }

    // Remove existing monthly price section if any (exactly like original)
    const existingSection = document.querySelector('.monthly-price-main-section');
    if (existingSection) {
      existingSection.remove();
    }

    // Extract monthly low price (exactly like original)
    const monthlyLowPrice = await this.services.dataManager.extractMonthlyLowPrice(productData, productId);

    // Create modern monthly price section
    let monthlySection;
    if (window.StyleService && this.services.styleService) {
      monthlySection = this.services.styleService.createPriceElement('monthlyPrice', {
        monthlyLowPrice,
        currentPrice: this.getCurrentPrice(),
        isMainSection: true
      });
    } else {
      // Fallback with modern styling
      monthlySection = document.createElement('div');
      monthlySection.className = 'monthly-price-main-section';

      if (monthlyLowPrice && monthlyLowPrice > 0) {
        const formattedPrice = Math.round(monthlyLowPrice / 10).toLocaleString('fa-IR');
        const currentPrice = this.getCurrentPrice();
        const difference = currentPrice && monthlyLowPrice ?
          Math.round(((currentPrice - monthlyLowPrice) / monthlyLowPrice) * 100) : 0;

        monthlySection.innerHTML = `
    <div style="display: flex; align-items: center; gap: 6px; margin: 4px 0; padding: 6px 8px; background-color: #fff9e6; border-radius: 6px; border-left: 3px solid #fbbf24;">
      <span style="font-size: 14px;">💰</span>
      <span style="font-size: 11px; font-weight: 600; color: #92400e;">کمترین قیمت ۳۰ روز:</span>
      <span style="font-size: 13px; font-weight: 700; color: #b45309;">${formattedPrice} تومان</span>
      ${difference > 0 ? `<span style="font-size: 10px; color: #059669; font-weight: 500;">(${difference}% کمتر)</span>` : ''}
    </div>
  `;
      } else {
        monthlySection.innerHTML = `
    <div style="display: flex; align-items: center; gap: 6px; margin: 4px 0; padding: 6px 8px; background-color: #fef2f2; border-radius: 6px; border-left: 3px solid #f87171;">
      <span style="font-size: 14px;">⚠️</span>
      <span style="font-size: 11px; font-weight: 600; color: #991b1b;">اطلاعات قیمت ماهانه موجود نیست</span>
    </div>
  `;
      }
    }

    // Insert after the price container (exactly like original)
    // try {
    //   priceContainer.parentNode.insertBefore(monthlySection, priceContainer.nextSibling);
    //   console.log('✅ Monthly price section added below main price');
    // } catch (error) {
    //   console.error('❌ Error inserting monthly price section:', error);
    // }
    try {
      priceElement.parentNode.insertBefore(monthlySection, priceElement.nextSibling);
      console.log('✅ Monthly price section added right after the price container');
    } catch (error) {
      console.error('❌ Error inserting monthly price section:', error);
    }
  }

  async addMonthlyPriceSection(productData) {
    try {
      console.log('📊 Adding monthly price section');

      // Extract monthly low price
      const monthlyLowPrice = await this.services.dataManager.extractMonthlyLowPrice(productData, this.currentProductId);

      if (monthlyLowPrice > 0) {
        // Find the main price element and add monthly price below it
        const priceSelectors = [
          '[data-testid="price-final"]',
          '[data-testid="buy-box"] span[class*="price"]',
          '.product-price'
        ];

        let priceElement = null;
        for (const selector of priceSelectors) {
          priceElement = document.querySelector(selector);
          if (priceElement) break;
        }

        if (priceElement) {
          // Remove existing monthly price section
          const existing = document.querySelector('.monthly-price-main-section');
          if (existing) existing.remove();

          // Create monthly price section
          const monthlySection = document.createElement('div');
          monthlySection.className = 'monthly-price-main-section';
          monthlySection.style.cssText = `
            margin-top: 12px;
            padding: 12px;
            background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
            border: 1px solid #ffeeba;
            border-radius: 8px;
            font-size: 14px;
            color: #856404;
          `;

          monthlySection.innerHTML = `
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 16px;">📊</span>
              <span style="font-weight: 600;">کمترین قیمت 30 روز گذشته: ${this.services.dataManager.formatPrice(monthlyLowPrice)}</span>
            </div>
          `;

          // Insert after the price element's parent
          const priceContainer = priceElement.closest('[data-testid="buy-box"]') || priceElement.parentElement;
          if (priceContainer && priceContainer.parentNode) {
            priceContainer.parentNode.insertBefore(monthlySection, priceContainer.nextSibling);
            console.log('✅ Monthly price section added to product detail page');
          }
        }
      }
    } catch (error) {
      console.error('❌ Error adding monthly price section:', error);
    }
  }

  async addVariantComparison(productData) {
    try {
      console.log('🏷️ Adding variant comparison');

      if (this.services.domManager && this.services.domManager.addVariantPriceComparison) {
        this.services.domManager.addVariantPriceComparison(
          productData,
          this.services.priceService
        );
      }
    } catch (error) {
      console.error('❌ Error adding variant comparison:', error);
    }
  }

  async addSellerPriceComparison(productData) {
    try {
      console.log('💰 Adding seller price comparison');

      const discountResult = await this.services.priceService.calculateSellerDiscount(
        productData,
        this.currentProductId
      );

      if (discountResult && discountResult.discount > 0) {
        this.addSellerPriceInfo(discountResult);
      }
    } catch (error) {
      console.error('❌ Error adding seller price comparison:', error);
    }
  }

  addSellerPriceInfo(discountResult) {
    // Find buy box or price container
    const containers = [
      document.querySelector('[data-testid="buy-box"]'),
      document.querySelector('.product-buy-box'),
      document.querySelector('.product-detail-container')
    ];

    const container = containers.find(c => c !== null);
    if (!container) {
      console.log('⚠️ Could not find suitable container for seller price info');
      return;
    }

    // Remove existing seller price info
    const existing = container.querySelector('.seller-price-detail-info');
    if (existing) {
      existing.remove();
    }

    // Create seller price info element
    const priceInfo = document.createElement('div');
    priceInfo.className = 'seller-price-detail-info';
    priceInfo.style.cssText = `
      margin-top: 16px;
      padding: 16px;
      background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
      border: 1px solid #c3e6cb;
      border-radius: 8px;
      display: flex;
      align-items: center;
      gap: 12px;
    `;

    priceInfo.innerHTML = `
      <div style="font-size: 24px;">💰</div>
      <div>
        <div style="font-size: 16px; font-weight: bold; color: #155724; margin-bottom: 4px;">
          ${discountResult.discount}% تخفیف نسبت به رقبا
        </div>
        <div style="font-size: 14px; color: #155724;">
          قیمت فروشنده: ${this.services.priceService.formatPrice(discountResult.sellerPrice)}
        </div>
        <div style="font-size: 12px; color: #6c757d; margin-top: 2px;">
          قیمت بازار: ${this.services.priceService.formatPrice(discountResult.marketPrice)}
        </div>
      </div>
    `;

    container.appendChild(priceInfo);
  }

  async handleVariantChange() {
    // Check if variant selection changed
    const variantElements = document.querySelectorAll('[data-testid="variant-selector"]');
    if (variantElements.length === 0) return;

    console.log('🔄 Variant change detected, updating prices');

    // Remove existing dynamic elements
    this.removeProductDetailElements();

    // Wait a bit for the page to update
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Reprocess the product
    await this.processInitialElements();
  }

  async handleGetCurrentInfo(callback) {
    try {
      // Get fresh product info with current price
      console.log('📋 Getting current product info for Smart Cart');

      const productInfo = {
        productId: this.currentProductId,
        productTitle: this.getProductTitle(),
        productUrl: window.location.href,
        productImage: await this.getProductImage(),
        currentPrice: this.getCurrentPrice(), // Use the enhanced price extraction
        extractedAt: Date.now()
      };

      console.log('✅ Extracted current product info:', {
        productId: productInfo.productId,
        productTitle: productInfo.productTitle,
        currentPrice: productInfo.currentPrice
      });

      if (typeof callback === 'function') {
        callback(productInfo);
      } else {
        console.warn('⚠️ Invalid callback provided for get-current-info');
      }
    } catch (error) {
      console.error('❌ Error getting current product info:', error);
      if (typeof callback === 'function') {
        callback(null);
      }
    }
  }

  removeProductDetailElements() {
    const selectors = [
      '.monthly-price-main-section',
      '.variant-price-comparison-section',
      '.seller-price-detail-info',
      '.watchlist-button-container',
      '.watchlist-modal-overlay',
      '.digikala-extension-comparison-links',
      '.smart-cart-button-container',
      '.digikala-extension-vouchers'
    ];

    selectors.forEach(selector => {
      const elements = document.querySelectorAll(selector);
      elements.forEach(element => element.remove());
    });
  }

  async refreshProductDetail() {
    console.log('🔄 Refreshing product detail');

    this.removeProductDetailElements();

    // Clear API cache for this product
    if (this.services.apiService) {
      this.services.apiService.clearCache(this.currentProductId);
    }

    await this.processInitialElements();

    this.showNotification({
      type: 'success',
      title: 'بروزرسانی کامل',
      message: 'اطلاعات محصول بروزرسانی شد',
      autoHide: true,
      duration: 3000
    });
  }

  async processNewElements() {
    // For product detail pages, we mainly react to variant changes
    // rather than new elements being added
    return;
  }

  isElementRelevant(element) {
    // Check if element is related to product details
    const selectors = [
      '[data-testid="buy-box"]',
      '[data-testid="variant-selector"]',
      '.product-buy-box',
      '.variant-selection'
    ];

    return selectors.some(selector =>
      element.matches(selector) || element.querySelector(selector)
    );
  }

  getCurrentPrice() {
    console.log('💰 Attempting to extract current price...');

    // Method 1: Try variation-aware price extraction first
    const variationPrice = this.getVariationAwarePrice();
    if (variationPrice) {
      console.log('✅ Got variation-aware price:', variationPrice);
      return variationPrice;
    }

    // Method 2: Standard price extraction
    const standardPrice = this.getStandardPrice();
    if (standardPrice) {
      console.log('✅ Got standard price:', standardPrice);
      return standardPrice;
    }

    console.warn('❌ Could not extract price from page');
    return null;
  }

  getVariationAwarePrice() {
    console.log('🔍 Attempting variation-aware price extraction...');

    // Look for currently selected variant elements that might contain price info
    const selectedVariants = document.querySelectorAll([
      '[data-testid="variant-selector"] .selected',
      '.variant-selector .selected',
      '.variant-option.selected',
      '.color-selector .selected',
      '.size-selector .selected',
      '[class*="variant"] [class*="selected"]',
      '[data-selected="true"]'
    ].join(', '));

    // Check if any selected variant has associated price data
    for (const variant of selectedVariants) {
      // Look for price data attributes on the variant
      if (variant.dataset.price) {
        const price = parseInt(variant.dataset.price);
        if (price > 0) {
          console.log('💰 Found variant price in data-price:', price);
          return price * 10; // Convert to Rials if needed
        }
      }

      // Look for price in variant text content
      const variantText = variant.textContent || variant.innerText;
      if (variantText && variantText.includes('تومان')) {
        const priceMatch = variantText.match(/[\d,]+/);
        if (priceMatch) {
          const price = parseInt(priceMatch[0].replace(/,/g, ''));
          if (price > 1000) {
            console.log('💰 Found variant price in text:', price);
            return price * 10;
          }
        }
      }

      // Check if there's a price element near this variant
      const nearbyPrice = this.findNearbyPrice(variant);
      if (nearbyPrice) {
        console.log('💰 Found nearby variant price:', nearbyPrice);
        return nearbyPrice;
      }
    }

    // Look for dynamic price updates that happen after variant selection
    const dynamicPrice = this.getDynamicPrice();
    if (dynamicPrice) {
      console.log('💰 Found dynamic price:', dynamicPrice);
      return dynamicPrice;
    }

    return null;
  }

  getStandardPrice() {
    console.log('🔍 Attempting enhanced standard price extraction...');

    // Enhanced selectors for current Digikala structure
    const priceSelectors = [
      // Main price selectors (most reliable)
      '[data-testid="price-final"]',
      '[data-testid="price-selling"]',
      '[data-testid="price-selling-variant"]',

      // Buy box selectors
      '[data-testid="buy-box"] [class*="text-h3"]',
      '[data-testid="buy-box"] [class*="price"]',
      '[data-testid="buy-box"] .text-h3',

      // Common price selectors
      '.c-price__value',
      '.price-final',
      '.selling-price',
      '.product-price',
      '.price-now',
      '.current-price',

      // Alternative selectors
      '.styles_current__',
      '[class*="styles_current"]',
      '[class*="price"][class*="current"]'
    ];

    for (const selector of priceSelectors) {
      const priceElement = document.querySelector(selector);
      if (priceElement) {
        const priceText = (priceElement.textContent || priceElement.innerText || '').trim();
        console.log(`💰 Found price element with selector "${selector}":`, priceText);

        if (priceText) {
          const extractedPrice = this.extractPriceFromText(priceText);
          if (extractedPrice) {
            console.log(`✅ Successfully extracted price: ${extractedPrice} rials`);
            return extractedPrice;
          }
        }
      }
    }

    // Enhanced fallback with better targeting
    console.log('💰 Trying enhanced fallback price extraction...');

    // Look in buy-box specifically
    const buyBox = document.querySelector('[data-testid="buy-box"]');
    if (buyBox) {
      const allTextNodes = this.getTextNodesWithNumbers(buyBox);
      for (const textNode of allTextNodes) {
        const text = textNode.textContent || textNode.innerText;
        if (text && text.includes('تومان') && !text.includes('ماهانه') && !text.includes('قسط')) {
          const extractedPrice = this.extractPriceFromText(text);
          if (extractedPrice && extractedPrice > 10000) { // Reasonable threshold
            console.log(`💰 Buy-box fallback found price: ${extractedPrice} rials`);
            return extractedPrice;
          }
        }
      }
    }

    console.warn('❌ Could not extract price using standard methods');
    return null;
  }

  extractPriceFromText(text) {
    // Clean and extract price from text
    if (!text) return null;

    // Remove common persian/arabic characters, keep numbers and commas
    const cleanText = text.replace(/[^\d,۰-۹]/g, '');

    // Convert persian numbers to english
    const persianToEnglish = cleanText.replace(/[۰-۹]/g, (w) => {
      const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
      return persian.indexOf(w).toString();
    });

    // Extract numbers (remove commas)
    const numberText = persianToEnglish.replace(/,/g, '');
    const price = parseInt(numberText);

    if (price && price > 0) {
      // Convert from Tomans to Rials (multiply by 10)
      // Digikala ALWAYS displays prices in Tomans on their website
      const finalPrice = price * 10;
      console.log(`💰 Extracted: ${price} Tomans -> ${finalPrice} Rials`);
      return finalPrice;
    }

    return null;
  }

  getTextNodesWithNumbers(element) {
    // Get all elements that contain numeric text
    const elements = [];
    const walker = document.createTreeWalker(
      element,
      NodeFilter.SHOW_ELEMENT,
      {
        acceptNode: function(node) {
          const text = node.textContent || node.innerText;
          return text && /\d/.test(text) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
        }
      }
    );

    let node;
    while (node = walker.nextNode()) {
      elements.push(node);
    }

    return elements;
  }

  findNearbyPrice(variantElement) {
    // Look for price elements near the selected variant
    const container = variantElement.closest('[class*="variant"], [class*="option"], [data-testid*="variant"]');
    if (container) {
      const priceInContainer = container.querySelector('[class*="price"], [data-testid*="price"]');
      if (priceInContainer) {
        const priceText = priceInContainer.textContent || priceInContainer.innerText;
        const priceMatch = priceText.match(/[\d,]+/);
        if (priceMatch) {
          const price = parseInt(priceMatch[0].replace(/,/g, ''));
          if (price > 1000) {
            return price * 10;
          }
        }
      }
    }
    return null;
  }

  getDynamicPrice() {
    // Look for price elements that might have been updated dynamically
    // after variant selection (common in modern SPAs)
    const dynamicPriceSelectors = [
      '[data-testid*="dynamic"], [class*="dynamic"]',
      '[data-updated="true"]',
      '[class*="updated"]'
    ];

    for (const selector of dynamicPriceSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const element of elements) {
        const text = element.textContent || element.innerText;
        if (text && text.includes('تومان')) {
          const priceMatch = text.match(/[\d,]+/);
          if (priceMatch) {
            const price = parseInt(priceMatch[0].replace(/,/g, ''));
            if (price > 1000) {
              return price * 10;
            }
          }
        }
      }
    }
    return null;
  }

  // Watchlist functionality methods
  async addWatchlistButton(productData, productId) {
    try {
      // Remove existing watchlist button
      const existingButton = document.querySelector('.watchlist-button-container');
      if (existingButton) {
        existingButton.remove();
      }

      // Find the monthly price section to add the button after it
      const monthlyPriceSection = document.querySelector('.monthly-price-main-section');
      if (!monthlyPriceSection) {
        console.log('⚠️ Monthly price section not found, cannot add watchlist button');
        return;
      }

      // Check if product is already in watchlist
      await this.checkWatchlistStatus(productId);

      // Create watchlist button container
      const buttonContainer = document.createElement('div');
      buttonContainer.className = 'watchlist-button-container';
      buttonContainer.style.cssText = `
        margin-top: 12px;
        display: flex;
        justify-content: center;
      `;

      // Create the watchlist button
      const button = document.createElement('button');
      button.className = 'extension-watchlist-button';
      this.updateButtonState(button);

      // Add click event listener
      button.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.handleWatchlistButtonClick(productData, productId);
      });

      buttonContainer.appendChild(button);

      // Insert after the monthly price section
      monthlyPriceSection.parentNode.insertBefore(buttonContainer, monthlyPriceSection.nextSibling);

      console.log('✅ Watchlist button added to product detail page');
    } catch (error) {
      console.error('❌ Error adding watchlist button:', error);
    }
  }

  updateButtonState(button) {
    if (this.isInWatchlist) {
      button.innerHTML = `
        <span style="margin-right: 6px;">👁️</span>
        تحت نظارت
      `;
      button.style.cssText = `
        background: white;
        color: #10b981;
        border: 2px solid #10b981;
        border-radius: 8px;
        padding: 16px 24px;
        font-size: 16px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.2s ease;
        width: 100%;
        min-height: 56px;
        display: flex;
        align-items: center;
        justify-content: center;
        direction: rtl;
        box-sizing: border-box;
      `;
    } else {
      button.innerHTML = `
        <span style="margin-right: 6px;">🎯</span>
        شکار قیمت
      `;
      button.style.cssText = `
        background: white;
        color: #ea580c;
        border: 2px solid #ea580c;
        border-radius: 8px;
        padding: 16px 24px;
        font-size: 16px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.2s ease;
        width: 100%;
        min-height: 56px;
        display: flex;
        align-items: center;
        justify-content: center;
        direction: rtl;
        box-sizing: border-box;
      `;
    }

    // Add hover effects
    button.addEventListener('mouseenter', () => {
      if (this.isInWatchlist) {
        button.style.background = '#10b981';
        button.style.color = 'white';
        button.style.transform = 'translateY(-1px)';
        button.style.boxShadow = '0 4px 8px rgba(16, 185, 129, 0.3)';
      } else {
        button.style.background = '#ea580c';
        button.style.color = 'white';
        button.style.transform = 'translateY(-1px)';
        button.style.boxShadow = '0 4px 8px rgba(234, 88, 12, 0.3)';
      }
    });

    button.addEventListener('mouseleave', () => {
      if (this.isInWatchlist) {
        button.style.background = 'white';
        button.style.color = '#10b981';
        button.style.transform = 'translateY(0)';
        button.style.boxShadow = 'none';
      } else {
        button.style.background = 'white';
        button.style.color = '#ea580c';
        button.style.transform = 'translateY(0)';
        button.style.boxShadow = 'none';
      }
    });
  }

  async checkWatchlistStatus(productId) {
    try {
      // Use the same storage key format as background script
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlistArray = result['digikala_extension_watchlist'] || [];
      this.isInWatchlist = watchlistArray.some(entry => entry.productId === productId && entry.isActive);
      console.log(`🔍 Checking watchlist status for product ${productId}:`, {
        watchlistCount: watchlistArray.length,
        isInWatchlist: this.isInWatchlist
      });
    } catch (error) {
      console.error('❌ Error checking watchlist status:', error);
      this.isInWatchlist = false;
    }
  }

  async handleWatchlistButtonClick(productData, productId) {
    if (this.isInWatchlist) {
      // Remove from watchlist
      await this.removeFromWatchlist(productId);
    } else {
      // Show modal to add to watchlist
      this.showWatchlistModal(productData, productId);
    }
  }

  showWatchlistModal(productData, productId) {
    // Remove existing modal
    this.closeWatchlistModal();

    // Create modal overlay
    const overlay = document.createElement('div');
    overlay.className = 'watchlist-modal-overlay';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(4px);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
      animation: fadeIn 0.2s ease;
    `;

    // Create modal container
    const modal = document.createElement('div');
    modal.className = 'watchlist-modal';
    modal.style.cssText = `
      background: white;
      border-radius: 12px;
      padding: 24px;
      max-width: 480px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
      animation: slideInUp 0.3s ease;
    `;

    // Add styles for animations
    const styleEl = document.createElement('style');
    styleEl.textContent = `
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      @keyframes slideInUp {
        from { 
          opacity: 0; 
          transform: translateY(30px) scale(0.95); 
        }
        to { 
          opacity: 1; 
          transform: translateY(0) scale(1); 
        }
      }
    `;
    document.head.appendChild(styleEl);

    // Get product title
    const productTitle = this.getProductTitle() || 'محصول انتخابی';

    modal.innerHTML = `
      <div style="margin-bottom: 20px;">
        <h3 style="margin: 0 0 8px 0; font-size: 18px; font-weight: 700; color: #1f2937;">
          افزودن به لیست نظارت قیمت
        </h3>
        <p style="margin: 0; font-size: 14px; color: #6b7280; line-height: 1.4;">
          ${productTitle}
        </p>
      </div>
      
      <div style="margin-bottom: 20px;">
        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">
          آستانه قیمت (تومان)
        </label>
        <input 
          type="number" 
          id="price-threshold" 
          placeholder="مثال: 500000"
          style="
            width: 100%;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.2s ease;
            direction: ltr;
            text-align: right;
          "
        />
        <p style="margin: 4px 0 0 0; font-size: 12px; color: #6b7280;">
          زمانی که قیمت به این مقدار یا کمتر رسید، اطلاع رسانی شود
        </p>
      </div>

      <div style="margin-bottom: 20px;">
        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">
          حداقل درصد تخفیف (%)
        </label>
        <input 
          type="number" 
          id="discount-threshold" 
          placeholder="مثال: 20"
          min="0" 
          max="100"
          style="
            width: 100%;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.2s ease;
            direction: ltr;
            text-align: right;
          "
        />
        <p style="margin: 4px 0 0 0; font-size: 12px; color: #6b7280;">
          زمانی که درصد تخفیف به این مقدار یا بیشتر رسید، اطلاع رسانی شود
        </p>
      </div>

      <div style="margin-bottom: 20px;">
        <label style="display: flex; align-items: center; cursor: pointer;">
          <input 
            type="checkbox" 
            id="notify-lowest-30days"
            style="margin-left: 8px; width: 16px; height: 16px;"
          />
          <span style="font-size: 14px; color: #374151;">
            اطلاع رسانی در صورت نزدیک شدن به کمترین قیمت ۳۰ روز گذشته
          </span>
        </label>
      </div>

      <div style="margin-bottom: 24px;">
        <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">
          فاصله زمانی بررسی قیمت
        </label>
        <select 
          id="check-interval"
          style="
            width: 100%;
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            background: white;
            transition: border-color 0.2s ease;
            direction: rtl;
          "
        >
          <option value="1800000">۳۰ دقیقه</option>
          <option value="3600000">۱ ساعت</option>
          <option value="7200000">۲ ساعت</option>
          <option value="14400000" selected>۴ ساعت (پیش‌فرض)</option>
          <option value="21600000">۶ ساعت</option>
          <option value="43200000">۱۲ ساعت</option>
          <option value="86400000">۲۴ ساعت</option>
        </select>
        <p style="margin: 4px 0 0 0; font-size: 12px; color: #6b7280;">
          تعیین کنید هر چند وقت یکبار قیمت این محصول بررسی شود
        </p>
      </div>

      <div style="display: flex; gap: 12px; justify-content: flex-end;">
        <button 
          id="cancel-watchlist" 
          style="
            padding: 12px 20px;
            background: #f3f4f6;
            color: #374151;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
          "
        >
          انصراف
        </button>
        <button 
          id="save-watchlist" 
          style="
            padding: 12px 20px;
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white;
            border: 1px solid #2563eb;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 4px rgba(59, 130, 246, 0.3);
          "
        >
          افزودن به لیست نظارت
        </button>
      </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);
    this.watchlistModal = overlay;

    // Add event listeners
    overlay.querySelector('#cancel-watchlist').addEventListener('click', () => {
      this.closeWatchlistModal();
    });

    overlay.querySelector('#save-watchlist').addEventListener('click', () => {
      this.saveWatchlistEntry(productData, productId);
    });

    // Close modal on overlay click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        this.closeWatchlistModal();
      }
    });

    // Close modal on ESC key
    const escHandler = (e) => {
      if (e.key === 'Escape') {
        this.closeWatchlistModal();
        document.removeEventListener('keydown', escHandler);
      }
    };
    document.addEventListener('keydown', escHandler);

    // Add input focus styles
    const inputs = modal.querySelectorAll('input[type="number"]');
    inputs.forEach(input => {
      input.addEventListener('focus', () => {
        input.style.borderColor = '#3b82f6';
        input.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.1)';
      });
      input.addEventListener('blur', () => {
        input.style.borderColor = '#e5e7eb';
        input.style.boxShadow = 'none';
      });
    });

    // Add select focus styling
    const selectElement = modal.querySelector('#check-interval');
    if (selectElement) {
      selectElement.addEventListener('focus', () => {
        selectElement.style.borderColor = '#3b82f6';
        selectElement.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.1)';
      });
      selectElement.addEventListener('blur', () => {
        selectElement.style.borderColor = '#e5e7eb';
        selectElement.style.boxShadow = 'none';
      });
    }

    // Focus first input
    setTimeout(() => {
      const firstInput = modal.querySelector('#price-threshold');
      if (firstInput) firstInput.focus();
    }, 100);
  }

  closeWatchlistModal() {
    if (this.watchlistModal) {
      this.watchlistModal.remove();
      this.watchlistModal = null;
    }
  }

  async saveWatchlistEntry(productData, productId) {
    try {
      console.log('💾 Starting to save watchlist entry for product:', productId);
      // Get form values
      const priceThresholdInput = document.querySelector('#price-threshold');
      const discountThresholdInput = document.querySelector('#discount-threshold');
      const notifyLowest30DaysInput = document.querySelector('#notify-lowest-30days');
      const checkIntervalInput = document.querySelector('#check-interval');

      // Validate inputs
      const priceThreshold = priceThresholdInput.value ?
        parseFloat(priceThresholdInput.value) * 10 : null; // Convert to Rials
      const discountThreshold = discountThresholdInput.value ?
        parseFloat(discountThresholdInput.value) : null;
      const notifyOnLowest30Days = notifyLowest30DaysInput.checked;
      const checkInterval = parseInt(checkIntervalInput.value) || (4 * 60 * 60 * 1000); // Default to 4 hours

      // Validation
      if (!priceThreshold && !discountThreshold && !notifyOnLowest30Days) {
        this.showValidationError('لطفاً حداقل یک شرط برای نظارت قیمت تعیین کنید');
        return;
      }

      if (priceThreshold && priceThreshold < 0) {
        this.showValidationError('آستانه قیمت نمی‌تواند منفی باشد');
        return;
      }

      if (discountThreshold && (discountThreshold < 0 || discountThreshold > 100)) {
        this.showValidationError('درصد تخفیف باید بین ۰ تا ۱۰۰ باشد');
        return;
      }

      // Validate check interval
      if (checkInterval < 1800000 || checkInterval > 86400000) {
        this.showValidationError('فاصله زمانی بررسی باید بین ۳۰ دقیقه تا ۲۴ ساعت باشد');
        return;
      }

      // Extract minimum price from API instead of DOM
      console.log('🔍 [WATCHLIST SAVE] Extracting minimum price from API for product:', productId);
      let minimumPrice = null;

      if (productData && this.services.dataManager) {
        const priceResult = await this.services.dataManager.extractCurrentLowestPrice(productData, productId);
        if (priceResult && priceResult.price) {
          minimumPrice = priceResult.price;
          console.log(`✅ [WATCHLIST SAVE] Got minimum price from API: ${minimumPrice} Rials (${Math.round(minimumPrice / 10).toLocaleString('fa-IR')} Tomans)`);
        } else {
          console.warn('⚠️ [WATCHLIST SAVE] Could not extract minimum price from API, falling back to DOM');
          minimumPrice = this.getCurrentPrice();
        }
      } else {
        console.warn('⚠️ [WATCHLIST SAVE] No product data available, falling back to DOM price extraction');
        minimumPrice = this.getCurrentPrice();
      }

      console.log(`💾 [WATCHLIST SAVE] Final price to save: ${minimumPrice} Rials`);

      // Create watchlist entry
      const watchlistEntry = {
        id: `${productId}_${Date.now()}`,
        productId: productId,
        productTitle: this.getProductTitle(),
        productImage: await this.getProductImage(),
        productUrl: window.location.href,
        conditions: {
          priceThreshold: priceThreshold,
          minDiscountPercent: discountThreshold,
          notifyOnLowest30Days: notifyOnLowest30Days
        },
        checkInterval: checkInterval, // Use user-selected interval
        currentPrice: minimumPrice, // Use minimum price from API, not DOM
        createdAt: Date.now(),
        isActive: true
      };

      // Get current watchlist using the same key as background script
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      let watchlist = result['digikala_extension_watchlist'] || [];
      console.log('📋 Current watchlist before adding:', watchlist);

      // Remove any existing entries for this product
      watchlist = watchlist.filter(entry => entry.productId !== productId);

      // Add new entry
      watchlist.push(watchlistEntry);

      // Save to storage using the same key as background script
      console.log('💾 Saving watchlist to storage:', watchlist);
      await chrome.storage.local.set({ 'digikala_extension_watchlist': watchlist });

      // Update UI state immediately after successful save
      this.isInWatchlist = true;
      const button = document.querySelector('.extension-watchlist-button');
      if (button) {
        this.updateButtonState(button);
      }

      // Close modal
      this.closeWatchlistModal();

      // Show success notification
      this.showNotification({
        type: 'success',
        title: 'موفق',
        message: 'محصول به لیست نظارت قیمت اضافه شد',
        autoHide: true,
        duration: 3000
      });

      console.log('✅ Product added to watchlist:', watchlistEntry);

      // Request notification permission if this is the first watchlist entry
      // This is done after UI update to avoid blocking on context invalidation
      if (watchlist.length === 1) {
        try {
          const response = await ExtensionCore.BrowserCompat.safeSendMessage({
            action: 'requestNotificationPermission'
          });

          if (response && response.success) {
            if (response.granted) {
              console.log('✅ Notification permission granted for watchlist');
            } else {
              console.log('📝 Notification permission not granted, watchlist will work without notifications');
            }
          }
        } catch (error) {
          console.warn('⚠️ Could not request notification permission:', error);
          // Don't throw - watchlist is already saved successfully
        }
      }
    } catch (error) {
      console.error('❌ Error saving watchlist entry:', error);
      this.showNotification({
        type: 'error',
        title: 'خطا',
        message: 'در ذخیره اطلاعات خطایی رخ داد',
        autoHide: true,
        duration: 3000
      });
    }
  }

  async removeFromWatchlist(productId) {
    try {
      // Get current watchlist using the same key as background script
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      let watchlist = result['digikala_extension_watchlist'] || [];
      console.log('📋 Current watchlist before removing:', watchlist);
      watchlist = watchlist.filter(entry => entry.productId !== productId);

      await chrome.storage.local.set({ 'digikala_extension_watchlist': watchlist });

      // Update UI state
      this.isInWatchlist = false;
      const button = document.querySelector('.extension-watchlist-button');
      if (button) {
        this.updateButtonState(button);
      }

      this.showNotification({
        type: 'success',
        title: 'حذف شد',
        message: 'محصول از لیست نظارت قیمت حذف شد',
        autoHide: true,
        duration: 3000
      });

      console.log('✅ Product removed from watchlist:', productId);
    } catch (error) {
      console.error('❌ Error removing from watchlist:', error);
      this.showNotification({
        type: 'error',
        title: 'خطا',
        message: 'در حذف از لیست نظارت خطایی رخ داد',
        autoHide: true,
        duration: 3000
      });
    }
  }

  showValidationError(message) {
    // Remove existing error
    const existingError = document.querySelector('.watchlist-validation-error');
    if (existingError) {
      existingError.remove();
    }

    // Create error element
    const errorElement = document.createElement('div');
    errorElement.className = 'watchlist-validation-error';
    errorElement.style.cssText = `
      background: #fef2f2;
      border: 1px solid #fecaca;
      color: #991b1b;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 12px;
      margin-bottom: 16px;
      animation: slideInDown 0.2s ease;
    `;
    errorElement.textContent = message;

    // Insert at the top of the modal content
    const modal = document.querySelector('.watchlist-modal');
    if (modal) {
      modal.insertBefore(errorElement, modal.firstChild);
    }

    // Remove error after 5 seconds
    setTimeout(() => {
      if (errorElement && errorElement.parentNode) {
        errorElement.remove();
      }
    }, 5000);
  }

  getProductTitle() {
    console.log('🏷️ Searching for product title...');
    
    // Try to get product title from various selectors
    const titleSelectors = [
      'h1[data-testid="pdp-product-title"]',
      'h1.c-product__title',
      '.product-title h1',
      '[data-testid="pdp-product-title"]',
      'h1'
    ];

    // Debug: log all available h1 elements
    const allH1s = document.querySelectorAll('h1');
    console.log(`📋 Found ${allH1s.length} h1 elements on page`);
    allH1s.forEach((h1, index) => {
      console.log(`H1 ${index + 1}: "${h1.textContent.trim().substring(0, 50)}..."`);
    });

    for (const selector of titleSelectors) {
      console.log(`🔍 Trying title selector: ${selector}`);
      const titleElement = document.querySelector(selector);
      if (titleElement && titleElement.textContent.trim()) {
        const title = titleElement.textContent.trim();
        console.log(`✅ Found product title: "${title.substring(0, 50)}..."`);
        return title;
      }
    }

    console.log('⚠️ No product title found, using fallback');
    return 'محصول انتخابی';
  }

  async getProductImage() {
    console.log('🖼️ Searching for product image...');
    
    // First, try to get image from API data
    try {
      const productId = this.getProductId();
      if (productId && this.services?.dataManager) {
        console.log('📡 Attempting to fetch image from API...');
        const productData = await this.services.dataManager.fetchProductData(productId);
        
        if (productData && productData.images && productData.images.main && productData.images.main.url && productData.images.main.url.length > 0) {
          // Try to find the best product image from API data
          const imageUrls = productData.images.main.url;
          
          for (const originalImageUrl of imageUrls) {
            if (originalImageUrl && !this.isBannerImage(originalImageUrl)) {
              console.log(`✅ Found valid image from API: ${originalImageUrl.substring(0, 100)}...`);
              
              // Resize image for watchlist display (change h_800,w_800 to h_100,w_100)
              const resizedImageUrl = this.resizeDigikalaImage(originalImageUrl, 100, 100);
              console.log(`🔧 Resized image URL: ${resizedImageUrl.substring(0, 100)}...`);
              
              return resizedImageUrl;
            }
          }
          
          console.log('⚠️ All API images were rejected as banners, falling back to DOM scraping');
        }
      }
    } catch (error) {
      console.log('⚠️ Failed to fetch image from API, falling back to DOM scraping:', error.message);
    }
    
    // Fallback to DOM scraping if API fails
    console.log('🔍 Falling back to DOM scraping for image...');
    
    // Try different selectors for product images in order of preference
    // More specific selectors first to avoid banners and other images
    const imageSelectors = [
      // Most specific product image selectors
      '[data-testid="pdp-product-image"] img',
      '[data-cy="pdp-product-image"] img',
      '.product-gallery-container img[src*="dkstatics-public"]',
      '.pdp-images img[src*="dkstatics-public"]',
      '.product-gallery img[src*="dkstatics-public"]',
      '.product-images img[src*="dkstatics-public"]',
      '.gallery-container img[src*="dkstatics-public"]',
      '.thumbnail-gallery img[src*="dkstatics-public"]',
      // Fallback selectors with additional filtering
      'img[alt*="product"][src*="dkstatics-public"]',
      'img[data-src*="dkstatics-public"]:not([src*="banner"]):not([src*="logo"])',
      'img[src*="dkstatics-public"]:not([src*="banner"]):not([src*="logo"]):not([src*="advertisement"])'
    ];

    // Debug: log available images
    const allImages = document.querySelectorAll('img[src]');
    console.log(`📋 Found ${allImages.length} images on page`);

    for (const selector of imageSelectors) {
      console.log(`🔍 Trying image selector: ${selector}`);
      const imageElement = document.querySelector(selector);
      if (imageElement && imageElement.src && 
          !imageElement.src.includes('placeholder') && 
          !imageElement.src.includes('loading') &&
          !this.isBannerImage(imageElement.src) &&
          imageElement.src.length > 50) {
        console.log(`✅ Found product image: ${imageElement.src.substring(0, 100)}...`);
        
        // Resize DOM-found images too
        const resizedImageUrl = this.resizeDigikalaImage(imageElement.src, 100, 100);
        return resizedImageUrl;
      }
    }

    console.log('⚠️ No product image found');
    return null;
  }

  /**
   * Check if an image URL is likely a banner or promotional image
   * @param {string} imageUrl - Image URL to check
   * @returns {boolean} - True if likely a banner image
   */
  isBannerImage(imageUrl) {
    if (!imageUrl || typeof imageUrl !== 'string') {
      return false;
    }
    
    // Common patterns in banner image URLs
    const bannerPatterns = [
      'banner', 'logo', 'advertisement', 'promo', 'campaign',
      'header', 'footer', 'sidebar', 'overlay', 'popup',
      'notification', 'alert', 'toast', 'modal'
    ];
    
    const lowercaseUrl = imageUrl.toLowerCase();
    
    // Check for banner patterns in URL
    for (const pattern of bannerPatterns) {
      if (lowercaseUrl.includes(pattern)) {
        console.log(`🚫 Rejecting banner image (contains '${pattern}'): ${imageUrl.substring(0, 100)}...`);
        return true;
      }
    }
    
    // Check image dimensions - banners are typically very wide or very tall
    // Look for dimension hints in URL parameters
    if (lowercaseUrl.includes('w_') && lowercaseUrl.includes('h_')) {
      const widthMatch = lowercaseUrl.match(/w_(\d+)/);
      const heightMatch = lowercaseUrl.match(/h_(\d+)/);
      
      if (widthMatch && heightMatch) {
        const width = parseInt(widthMatch[1]);
        const height = parseInt(heightMatch[1]);
        
        // Banner-like aspect ratios (very wide or very tall)
        const aspectRatio = width / height;
        if (aspectRatio > 4 || aspectRatio < 0.25) {
          console.log(`🚫 Rejecting banner image (aspect ratio ${aspectRatio.toFixed(2)}): ${imageUrl.substring(0, 100)}...`);
          return true;
        }
      }
    }
    
    return false;
  }

  /**
   * Resize Digikala image URL by modifying the URL parameters
   * @param {string} imageUrl - Original image URL
   * @param {number} width - Desired width
   * @param {number} height - Desired height
   * @returns {string} - Resized image URL
   */
  resizeDigikalaImage(imageUrl, width = 100, height = 100) {
    if (!imageUrl || typeof imageUrl !== 'string') {
      return imageUrl;
    }
    
    // Check if this is a Digikala image URL with size parameters
    if (imageUrl.includes('dkstatics-public.digikala.com') && imageUrl.includes('x-oss-process=image/resize')) {
      // Replace existing size parameters with new ones
      const resizedUrl = imageUrl.replace(
        /h_\d+,w_\d+/g,
        `h_${height},w_${width}`
      );
      return resizedUrl;
    }
    
    // If it doesn't have size parameters but is a Digikala image, add them
    if (imageUrl.includes('dkstatics-public.digikala.com')) {
      const separator = imageUrl.includes('?') ? '&' : '?';
      return `${imageUrl}${separator}x-oss-process=image/resize,m_lfit,h_${height},w_${width}/quality,q_90`;
    }
    
    // Return original URL if not a Digikala image
    return imageUrl;
  }

  // Voucher functionality methods
  async addSellerVouchers(productId) {
    try {
      console.log('🎟️ Adding seller vouchers section');

      // Check if voucher feature should be enabled (you can add a setting for this)
      // For now, we'll always try to show vouchers if available

      // Find the variant price comparison section (seller variant section) to add vouchers at the top
      let insertAfterElement = document.querySelector('.variant-price-comparison-section');

      // If variant section exists, we want to insert vouchers at the top of it
      // So we'll insert before the variant section (which means after its previous sibling)
      if (insertAfterElement && insertAfterElement.previousElementSibling) {
        insertAfterElement = insertAfterElement.previousElementSibling;
        console.log('✅ Found variant section, will insert vouchers at the top');
      } else {
        // Fallback strategy: look for other extension elements
        // Try Smart Cart button container first
        insertAfterElement = document.querySelector('.smart-cart-button-container');

        // Fallback to watchlist button if Smart Cart is not available
        if (!insertAfterElement) {
          insertAfterElement = document.querySelector('.watchlist-button-container');
        }

        // Fallback to monthly price section if neither button is available
        if (!insertAfterElement) {
          insertAfterElement = document.querySelector('.monthly-price-main-section');
        }
      }

      if (!insertAfterElement) {
        console.log('⚠️ Could not find insertion point for voucher section');
        return;
      }

      // Fetch voucher data using the API service
      if (!this.services.apiService) {
        console.log('⚠️ API service not available for vouchers');
        return;
      }

      console.log('📡 Fetching voucher data...');
      const voucherData = await this.services.apiService.fetchSellerVouchers(productId);

      if (!voucherData || !voucherData.data || voucherData.data.length === 0) {
        console.log('ℹ️ No vouchers available for this product');
        return;
      }

      // Initialize voucher section component
      if (!this.voucherSection) {
        this.voucherSection = new VoucherSection(this.services);
      }

      // Create and display voucher section
      const voucherElement = await this.voucherSection.createVoucherSection(voucherData, productId, insertAfterElement);

      if (voucherElement) {
        console.log('✅ Voucher section added to product detail page');
      }

    } catch (error) {
      console.error('❌ Error adding seller vouchers:', error);
    }
  }

  // Smart Cart functionality methods
  async addSmartCartButton(productData, productId) {
    try {
      // Check if Smart Cart feature is enabled through browser storage
      const smartCartSettings = await ExtensionCore.BrowserCompat.safeStorageGet(['smartCartEnabled'], { smartCartEnabled: false });
      if (!smartCartSettings.smartCartEnabled) {
        console.log('🚫 Smart Cart feature is disabled - not adding Smart Cart button');
        return;
      }

      // Remove existing Smart Cart button
      const existingButton = document.querySelector('.smart-cart-button-container');
      if (existingButton) {
        existingButton.remove();
      }

      // Find the watchlist button container to add Smart Cart button after it
      const watchlistContainer = document.querySelector('.watchlist-button-container');
      if (!watchlistContainer) {
        console.log('⚠️ Watchlist button container not found, cannot add Smart Cart button');
        return;
      }

      // Initialize Smart Cart Manager if not already done
      if (!this.services.smartCartManager) {
        console.log('⚠️ Smart Cart Manager not available in services:', Object.keys(this.services));
        return;
      }

      console.log('✅ Smart Cart Manager is available');

      // Create product info object
      const productTitle = this.getProductTitle();
      const currentPrice = this.getCurrentPrice();
      const productImage = await this.getProductImage();

      console.log('📦 Creating Smart Cart product info:', {
        productId,
        productTitle,
        currentPrice,
        hasImage: !!productImage,
        url: window.location.href
      });

      // Additional validation
      if (!currentPrice || currentPrice === 0) {
        console.warn('⚠️ Price extraction failed, currentPrice is:', currentPrice);
        console.log('🔍 Let me check what price elements are available on the page...');

        // Debug available price elements
        const allPriceElements = document.querySelectorAll('[data-testid*="price"], [class*="price"], [class*="cost"]');
        console.log('🔍 Available price-related elements:', Array.from(allPriceElements).map(el => ({
          selector: el.tagName + (el.className ? '.' + el.className.split(' ').join('.') : '') + (el.dataset.testid ? `[data-testid="${el.dataset.testid}"]` : ''),
          text: el.textContent?.trim()
        })));
      }

      const productInfo = {
        productId: productId,
        productTitle: productTitle,
        productUrl: window.location.href,
        productImage: productImage,
        currentPrice: currentPrice
      };

      // Validate product info
      if (!productInfo.productId || !productInfo.productTitle) {
        console.error('❌ Invalid product info for Smart Cart:', productInfo);
        return;
      }

      // Initialize Smart Cart Button if not already done
      if (!this.smartCartButton) {
        console.log('🔄 Creating new SmartCartButton instance');
        this.smartCartButton = new SmartCartButton(
          this.services.eventBus,
          this.services.smartCartManager
        );
      } else {
        console.log('♻️ Reusing existing SmartCartButton instance');
      }

      // Create the Smart Cart button
      const buttonContainer = await this.smartCartButton.create(productInfo, {
        size: 'medium',
        style: 'primary',
        position: 'after-watchlist',
        showVariantInfo: true
      });

      // Insert after the watchlist button
      if (buttonContainer && watchlistContainer.parentNode) {
        watchlistContainer.parentNode.insertBefore(buttonContainer, watchlistContainer.nextSibling);
        console.log('✅ Smart Cart button added to product detail page');
      } else if (!buttonContainer) {
        console.log('ℹ️ Smart Cart button creation returned null (feature likely disabled)');
      }

    } catch (error) {
      console.error('❌ Error adding Smart Cart button:', error);
    }
  }

  async injectComparisonLinks() {
    console.log('🔗 Starting comparison links injection process');

    try {
      // Remove existing comparison links to avoid duplicates
      const existingLinks = document.querySelector('.digikala-extension-comparison-links');
      if (existingLinks) {
        console.log('🗑️ Removing existing comparison links');
        existingLinks.remove();
      }

      // Check if comparison feature is enabled
      console.log('🔍 Checking if comparison feature is enabled...');
      const featureResult = await chrome.storage.local.get(['digikala_extension_comparison_feature_enabled']);
      const isFeatureEnabled = featureResult.digikala_extension_comparison_feature_enabled !== undefined 
        ? featureResult.digikala_extension_comparison_feature_enabled 
        : true; // Default to enabled

      if (!isFeatureEnabled) {
        console.log('ℹ️ Comparison feature is disabled by user');
        return;
      }

      console.log('✅ Comparison feature is enabled');

      // Get comparison sites from storage
      console.log('📦 Loading comparison sites from storage...');
      const result = await chrome.storage.local.get(['digikala_extension_comparison_sites']);
      const comparisonSites = result.digikala_extension_comparison_sites || this.getDefaultComparisonSites();

      console.log('📋 Comparison sites loaded:', comparisonSites);

      if (!comparisonSites || comparisonSites.length === 0) {
        console.log('ℹ️ No comparison sites configured');
        return;
      }

      // Extract product name
      console.log('🏷️ Extracting product name...');
      const productName = this.getProductTitle();
      if (!productName || productName === 'محصول انتخابی') {
        console.log('⚠️ Could not extract product name');
        return;
      }

      console.log(`🏷️ Product name extracted: "${productName}"`);

      // Find the product title container
      console.log('🎯 Looking for product title container...');
      const titleContainer = this.findProductTitleContainer();
      if (!titleContainer) {
        console.log('❌ Could not find product title container');
        return;
      }

      console.log('✅ Found title container:', {
        tagName: titleContainer.tagName,
        className: titleContainer.className,
        hasParent: !!titleContainer.parentNode
      });

      // Create comparison links container
      console.log('🏗️ Creating comparison links container...');
      const comparisonContainer = this.createComparisonLinksContainer(comparisonSites, productName);
      if (!comparisonContainer) {
        console.log('❌ Failed to create comparison container');
        return;
      }

      console.log('✅ Comparison container created successfully');

      // Insert after the title container
      console.log('📍 Inserting comparison links after title container...');
      if (titleContainer.parentNode) {
        titleContainer.parentNode.insertBefore(comparisonContainer, titleContainer.nextSibling);
        console.log(`✅ Successfully injected ${comparisonSites.length} comparison links for multiple sites`);
        
        // Verify injection
        setTimeout(() => {
          const injected = document.querySelector('.digikala-extension-comparison-links');
          if (injected) {
            console.log('✅ Injection verified - comparison links are in DOM');
            const linkCount = injected.querySelectorAll('a').length;
            console.log(`📊 Total comparison links displayed: ${linkCount}`);
          } else {
            console.log('❌ Injection failed - comparison links not found in DOM');
          }
        }, 100);
      } else {
        console.log('❌ Title container has no parent node');
      }
    } catch (error) {
      console.error('❌ Error injecting comparison links:', error);
      console.error('Stack trace:', error.stack);
    }
  }

  getDefaultComparisonSites() {
    return [
      {
        id: 'torob',
        name: 'Torob',
        url: 'https://torob.com/search/?query=PRODUCT_NAME',
        faviconUrl: 'https://torob.com/favicon.ico'
      },
      {
        id: 'digikalajet',
        name: 'DigiKala Jet',
        url: 'https://www.digikalajet.com/search/v2/result?q=PRODUCT_NAME',
        faviconUrl: 'https://www.digikalajet.com/favicon.ico'
      },
      {
        id: 'janebi',
        name: 'Janebi',
        url: 'https://janebi.com/search?q=PRODUCT_NAME',
        faviconUrl: 'https://janebi.com/favicon.ico'
      },
      {
        id: 'emalls',
        name: 'Emalls',
        url: 'https://www.emalls.ir/search?q=PRODUCT_NAME',
        faviconUrl: 'https://www.emalls.ir/favicon.ico'
      }
    ];
  }

  // Get favicon URL for a website
  getFaviconUrl(url) {
    try {
      const domain = new URL(url.replace('PRODUCT_NAME', 'test')).origin;
      return `${domain}/favicon.ico`;
    } catch (error) {
      return null;
    }
  }

  // Alternative favicon services
  getFaviconUrlAlternatives(url) {
    try {
      const domain = new URL(url.replace('PRODUCT_NAME', 'test')).hostname;
      return [
        `https://${domain}/favicon.ico`,
        `https://www.google.com/s2/favicons?domain=${domain}&sz=16`,
        `https://favicons.githubusercontent.com/${domain}`,
        `https://icon.horse/icon/${domain}`
      ];
    } catch (error) {
      return [];
    }
  }

  // Try loading favicon for icon container with multiple alternatives
  tryLoadFaviconForIcon(iconContainer, urls, index, site) {
    if (index >= urls.length) {
      // All attempts failed, use fallback
      iconContainer.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M10.59 13.41c.41.39.41 1.03 0 1.42-.39.39-1.03.39-1.42 0a5.003 5.003 0 0 1 0-7.07l3.54-3.54a5.003 5.003 0 0 1 7.07 0 5.003 5.003 0 0 1 0 7.07l-1.49 1.49c.01-.82-.12-1.64-.4-2.42l.47-.48a2.982 2.982 0 0 0 0-4.24 2.982 2.982 0 0 0-4.24 0l-3.53 3.53a2.982 2.982 0 0 0 0 4.24zm2.82-4.24c.39-.39 1.03-.39 1.42 0a5.003 5.003 0 0 1 0 7.07l-3.54 3.54a5.003 5.003 0 0 1-7.07 0 5.003 5.003 0 0 1 0-7.07l1.49-1.49c-.01.82.12 1.64.4 2.42l-.47.48a2.982 2.982 0 0 0 0 4.24 2.982 2.982 0 0 0 4.24 0l3.53-3.53a2.982 2.982 0 0 0 0-4.24.973.973 0 0 1 0-1.42z"/></svg>';
      iconContainer.style.fontSize = '12px';
      return;
    }

    const favicon = document.createElement('img');
    favicon.style.cssText = `
      width: 14px;
      height: 14px;
      object-fit: contain;
    `;
    favicon.alt = site.name;

    favicon.onload = () => {
      // Successfully loaded
      iconContainer.innerHTML = '';
      iconContainer.appendChild(favicon);
    };

    favicon.onerror = () => {
      // Try next URL
      this.tryLoadFaviconForIcon(iconContainer, urls, index + 1, site);
    };

    // Set timeout for each attempt
    setTimeout(() => {
      if (!favicon.complete) {
        favicon.src = ''; // Cancel loading
        this.tryLoadFaviconForIcon(iconContainer, urls, index + 1, site);
      }
    }, 3000);

    favicon.src = urls[index];
  }

  findProductTitleContainer() {
    console.log('🔍 Searching for product title container...');
    
    // Look for the container that holds the product title as mentioned in requirements
    const containerSelectors = [
      // Try different variations of the flex container
      '.flex.items-center.w-full.px-5.lg\\:px-0',
      '.flex.items-center.w-full[class*="px-5"]',
      '[class*="flex"][class*="items-center"][class*="w-full"][class*="px-"]',
      '.flex.items-center.w-full',
      // Direct h1 selectors
      'h1[data-testid="pdp-product-title"]',
      'h1[class*="text-"]',
      '.c-product__title',
      '.product-title-container'
    ];

    // First, let's log all potential containers for debugging
    console.log('📋 Available containers with h1 elements:');
    const allH1s = document.querySelectorAll('h1');
    allH1s.forEach((h1, index) => {
      console.log(`H1 ${index + 1}:`, {
        text: h1.textContent.trim().substring(0, 50) + '...',
        parent: h1.parentElement?.className || 'no-class',
        grandparent: h1.parentElement?.parentElement?.className || 'no-class'
      });
    });

    for (const selector of containerSelectors) {
      console.log(`🔍 Trying selector: ${selector}`);
      const container = document.querySelector(selector);
      if (container) {
        console.log(`✅ Found element with selector: ${selector}`);
        
        // Check if it contains an h1 element or is an h1
        const h1 = container.querySelector('h1') || (container.tagName === 'H1' ? container : null);
        if (h1) {
          console.log(`✅ Found product title container: ${selector}`);
          console.log('Container details:', {
            tagName: container.tagName,
            className: container.className,
            textContent: h1.textContent.trim().substring(0, 50) + '...'
          });
          return container.tagName === 'H1' ? container.parentNode : container;
        } else {
          console.log('⚠️ Container found but no h1 inside');
        }
      }
    }

    // Fallback: find the first h1 and use its parent
    const h1 = document.querySelector('h1');
    if (h1) {
      console.log('⚠️ Using fallback: first h1 parent container');
      console.log('Fallback h1 details:', {
        text: h1.textContent.trim().substring(0, 50) + '...',
        parentClass: h1.parentElement?.className || 'no-class'
      });
      return h1.parentElement;
    }

    console.log('❌ No product title container found');
    return null;
  }

  createComparisonLinksContainer(comparisonSites, productName) {
    try {
      const container = document.createElement('div');
      container.className = 'digikala-extension-comparison-links';
      container.style.cssText = `
        margin-top: 12px;
        margin-bottom: 8px;
        font-family: IRANSans, Tahoma, sans-serif;
      `;

      // Create header
      const header = document.createElement('div');
      header.style.cssText = `
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
        font-size: 12px;
        font-weight: 400;
        color: #81858b;
      `;
      header.innerHTML = `
        <span>مقایسه قیمت در سایت‌های دیگر:</span>
      `;

      // Create links container
      const linksContainer = document.createElement('div');
      linksContainer.style.cssText = `
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        align-items: center;
        justify-content: flex-start;
      `;

      // Create individual comparison links
      comparisonSites.forEach(site => {
        const link = this.createComparisonLink(site, productName);
        if (link) {
          linksContainer.appendChild(link);
        }
      });

      if (linksContainer.children.length === 0) {
        return null;
      }

      container.appendChild(header);
      container.appendChild(linksContainer);

      return container;
    } catch (error) {
      console.error('Error creating comparison links container:', error);
      return null;
    }
  }

  createComparisonLink(site, productName) {
    try {
      // Encode product name for URL
      const encodedProductName = encodeURIComponent(productName);
      // Replace all occurrences of PRODUCT_NAME (global replacement)
      const searchUrl = site.url.replace(/PRODUCT_NAME/g, encodedProductName);

      const link = document.createElement('a');
      link.href = searchUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      
      // Style to match Digikala's subtle button elements as shown in comparison
      link.className = 'inline-flex items-center cursor-pointer';
      link.style.cssText = `
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 4px 8px;
        background: #f8f8f8;
        border: 1px solid #e8e8e8;
        border-radius: 4px;
        text-decoration: none;
        color: #888888;
        font-size: 12px;
        font-weight: 400;
        transition: all 0.2s ease;
        cursor: pointer;
        white-space: nowrap;
        box-sizing: border-box;
      `;

      // Add hover effects
      link.addEventListener('mouseenter', () => {
        link.style.background = '#f0f0f0';
        link.style.borderColor = '#d8d8d8';
      });

      link.addEventListener('mouseleave', () => {
        link.style.background = '#f8f8f8';
        link.style.borderColor = '#e8e8e8';
      });

      // Create favicon or fallback icon
      const iconContainer = document.createElement('span');
      iconContainer.style.cssText = `
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 14px;
        height: 14px;
        flex-shrink: 0;
      `;

      if (site.faviconUrl) {
        // Try loading the saved favicon URL first
        this.tryLoadFaviconForIcon(iconContainer, [site.faviconUrl], 0, site);
      } else {
        // Try alternative favicon sources
        const faviconUrls = this.getFaviconUrlAlternatives(site.url);
        if (faviconUrls.length > 0) {
          this.tryLoadFaviconForIcon(iconContainer, faviconUrls, 0, site);
        } else {
          iconContainer.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M10.59 13.41c.41.39.41 1.03 0 1.42-.39.39-1.03.39-1.42 0a5.003 5.003 0 0 1 0-7.07l3.54-3.54a5.003 5.003 0 0 1 7.07 0 5.003 5.003 0 0 1 0 7.07l-1.49 1.49c.01-.82-.12-1.64-.4-2.42l.47-.48a2.982 2.982 0 0 0 0-4.24 2.982 2.982 0 0 0-4.24 0l-3.53 3.53a2.982 2.982 0 0 0 0 4.24zm2.82-4.24c.39-.39 1.03-.39 1.42 0a5.003 5.003 0 0 1 0 7.07l-3.54 3.54a5.003 5.003 0 0 1-7.07 0 5.003 5.003 0 0 1 0-7.07l1.49-1.49c-.01.82.12 1.64.4 2.42l-.47.48a2.982 2.982 0 0 0 0 4.24 2.982 2.982 0 0 0 4.24 0l3.53-3.53a2.982 2.982 0 0 0 0-4.24.973.973 0 0 1 0-1.42z"/></svg>';
          iconContainer.style.fontSize = '12px';
        }
      }

      const text = document.createElement('span');
      text.textContent = site.name;
      text.style.cssText = `
        line-height: 1.2;
      `;

      link.appendChild(iconContainer);
      link.appendChild(text);

      return link;
    } catch (error) {
      console.error('Error creating comparison link:', error);
      return null;
    }
  }

  // Debug method for manual testing
  async testComparisonLinksInjection() {
    console.log('🧪 Manual test: Injecting comparison links');
    await this.injectComparisonLinks();
  }

  // Debug method for price extraction testing
  debugPriceExtraction() {
    console.log('🧪 Manual price extraction debugging...');

    // Test the current method
    const extractedPrice = this.getCurrentPrice();
    console.log('Current method result:', extractedPrice);

    // Manual inspection of price elements
    console.log('🔍 Manual inspection of potential price elements:');

    const selectors = [
      '[data-testid="price-final"]',
      '[data-testid="price-selling"]',
      '[data-testid="price-discount"]',
      '.c-price__value',
      '.price-final',
      '.selling-price',
      '.product-price'
    ];

    selectors.forEach(selector => {
      const elements = document.querySelectorAll(selector);
      elements.forEach((el, index) => {
        console.log(`${selector}[${index}]:`, el.textContent?.trim(), el);
      });
    });

    // Find all elements containing "تومان"
    console.log('🔍 All elements containing "تومان":');
    const allElements = document.querySelectorAll('*');
    const tomanElements = Array.from(allElements).filter(el =>
      el.textContent && el.textContent.includes('تومان') &&
      el.children.length === 0 // Only leaf elements
    );

    tomanElements.forEach(el => {
      console.log('Toman element:', el.textContent?.trim(), el);
    });

    return {
      extractedPrice,
      availableSelectors: selectors.map(s => ({ selector: s, elements: document.querySelectorAll(s).length })),
      tomanElements: tomanElements.map(el => el.textContent?.trim())
    };
  }
}

window.ProductDetailController = ProductDetailController;

// Make debug method available globally for testing
if (typeof window !== 'undefined') {
  window.debugPriceExtraction = function() {
    const controller = window.productDetailController;
    if (controller) {
      return controller.debugPriceExtraction();
    } else {
      console.error('ProductDetailController not found');
      console.log('Available controllers:', Object.keys(window).filter(k => k.includes('Controller')));
    }
  };
}