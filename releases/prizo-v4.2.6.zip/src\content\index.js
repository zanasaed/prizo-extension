/**
 * Content Script Entry Point
 * Main entry point for all content script functionality
 */

// Use the proper ExtensionInitializer from core
(async () => {
  try {
    console.log('🚀 Prizo Extension - Content Script Initializing with startup delay...');
    
    // Use the proper ExtensionInitializer that handles startup delays
    if (typeof window.ExtensionCore !== 'undefined' && window.ExtensionCore.ExtensionInitializer) {
      await window.ExtensionCore.ExtensionInitializer.initialize();
      console.log('✅ Prizo Extension - Content Script Initialized Successfully with startup delay');
    } else {
      console.warn('⚠️ ExtensionInitializer not available, falling back to basic initialization');
      // Fallback to direct main.js initialization if available
      if (typeof initializeExtension === 'function') {
        initializeExtension();
      } else {
        console.error('❌ No initialization method available');
      }
    }
  } catch (error) {
    console.error('❌ Prizo Extension - Failed to initialize:', error);
  }
})();