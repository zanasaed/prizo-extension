/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-18
 * Smart Cart Button - UI component for adding products to Smart Cart
 */
class SmartCartButton {
  constructor(eventBus, smartCartManager) {
    this.eventBus = eventBus;
    this.smartCartManager = smartCartManager;
    this.button = null;
    this.productInfo = null;
    this.currentVariant = null;

    // Bind event handlers once to avoid issues with event listener removal
    this.boundHandleItemAdded = this.handleItemAdded.bind(this);
    this.boundHandleItemRemoved = this.handleItemRemoved.bind(this);
  }

  async create(productInfo, options = {}) {
    // Check if Smart Cart feature is enabled first
    try {
      const smartCartSettings = await ExtensionCore.BrowserCompat.safeStorageGet(['smartCartEnabled'], { smartCartEnabled: false });
      if (!smartCartSettings.smartCartEnabled) {
        console.log('🚫 Smart Cart feature is disabled - not creating Smart Cart button');
        return null;
      }
    } catch (error) {
      console.warn('⚠️ Could not check Smart Cart feature status, assuming disabled:', error);
      return null;
    }

    // Validate productInfo first
    if (!productInfo) {
      console.error('❌ SmartCartButton.create: productInfo is required');
      return null;
    }

    if (!productInfo.productId || !productInfo.productTitle) {
      console.error('❌ SmartCartButton.create: productInfo must have productId and productTitle');
      console.log('Received productInfo:', productInfo);
      return null;
    }

    const {
      size = 'medium',
      style = 'primary',
      position = 'after-price',
      showVariantInfo = true
    } = options;

    // Remove existing button if any (but don't clear productInfo yet)
    if (this.button?.parentElement) {
      this.button.parentElement.remove();
    }
    this.partialCleanup();

    // Now set the new productInfo and detect variant
    this.productInfo = productInfo;
    this.currentVariant = this.detectCurrentVariant();

    // Create button container
    const container = this.createButtonContainer(size, position);

    // Create button element
    this.button = this.createButtonElement(size, style);

    // Add variant info if enabled and variant exists
    if (showVariantInfo && this.currentVariant) {
      const variantInfo = this.createVariantInfo();
      container.appendChild(variantInfo);
    }

    container.appendChild(this.button);

    // Setup event listeners
    this.setupEventListeners();

    // Update button state
    this.updateButtonState();

    return container;
  }

  createButtonContainer(size, position) {
    const container = document.createElement('div');
    container.className = 'smart-cart-button-container';
    container.setAttribute('data-position', position);

    const sizeStyles = {
      small: 'margin: 8px 0;',
      medium: 'margin: 12px 0;',
      large: 'margin: 16px 0;'
    };

    container.style.cssText = `
      ${sizeStyles[size]}
      display: flex;
      flex-direction: column;
      gap: 8px;
      font-family: IRANSans, Tahoma, sans-serif;
    `;

    return container;
  }

  createButtonElement(size, style) {
    const button = document.createElement('button');
    button.className = 'smart-cart-button';
    button.type = 'button';

    const sizeStyles = {
      small: {
        padding: '8px 16px',
        fontSize: '13px',
        minHeight: '36px'
      },
      medium: {
        padding: '12px 20px',
        fontSize: '14px',
        minHeight: '44px'
      },
      large: {
        padding: '16px 24px',
        fontSize: '16px',
        minHeight: '52px'
      }
    };

    const styleVariants = {
      primary: {
        background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)',
        color: 'white',
        border: '1px solid #dc2626',
        hoverBg: '#dc2626'
      },
      secondary: {
        background: 'white',
        color: '#ef4444',
        border: '2px solid #ef4444',
        hoverBg: '#ef4444'
      },
      success: {
        background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
        color: 'white',
        border: '1px solid #059669',
        hoverBg: '#059669'
      }
    };

    const currentSize = sizeStyles[size];
    const currentStyle = styleVariants[style];

    button.style.cssText = `
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      width: 100%;
      padding: ${currentSize.padding};
      font-size: ${currentSize.fontSize};
      min-height: ${currentSize.minHeight};
      font-weight: 600;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s ease;
      direction: rtl;
      background: ${currentStyle.background};
      color: ${currentStyle.color};
      border: ${currentStyle.border};
      box-sizing: border-box;
      font-family: inherit;
    `;

    // Add hover effects
    button.addEventListener('mouseenter', () => {
      if (!button.disabled) {
        button.style.background = currentStyle.hoverBg;
        button.style.transform = 'translateY(-1px)';
        button.style.boxShadow = `0 4px 8px rgba(239, 68, 68, 0.3)`;
      }
    });

    button.addEventListener('mouseleave', () => {
      if (!button.disabled) {
        button.style.background = currentStyle.background;
        button.style.transform = 'translateY(0)';
        button.style.boxShadow = 'none';
      }
    });

    return button;
  }

  createVariantInfo() {
    const variantInfo = document.createElement('div');
    variantInfo.className = 'smart-cart-variant-info';

    variantInfo.style.cssText = `
      padding: 8px 12px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      font-size: 12px;
      color: #64748b;
      line-height: 1.4;
    `;

    const variantText = this.getVariantDisplayText();
    variantInfo.innerHTML = `
      <div style="display: flex; align-items: center; gap: 6px;">
        <span style="font-size: 14px;">🏷️</span>
        <span>تنوع انتخابی: ${variantText}</span>
      </div>
    `;

    return variantInfo;
  }

  detectCurrentVariant() {
    // Detect currently selected variant from page with enhanced Digikala selectors
    console.log('🔍 Detecting current variant...');

    // Enhanced selectors for Digikala's actual DOM structure
    const selectedVariantSelectors = [
      // Main variant selectors
      '[data-testid="variant-selector"] .selected',
      '[data-testid="variant-selector"] [class*="selected"]',
      '.variant-selector .selected',
      '.variant-option.selected',

      // Color selectors
      '[data-testid="color-selector"] .selected',
      '[data-testid="color-selector"] [class*="selected"]',
      '.color-selector .selected',
      '.color-option.selected',
      '.color-variant.selected',

      // Size selectors
      '[data-testid="size-selector"] .selected',
      '[data-testid="size-selector"] [class*="selected"]',
      '.size-selector .selected',
      '.size-option.selected',
      '.size-variant.selected',

      // Generic Digikala selectors
      '[data-testid*="variant"] [class*="selected"]',
      '[data-testid*="option"] [class*="selected"]',
      '.styles_selected__[class*="selected"]',
      '[class*="variant"][class*="selected"]'
    ];

    const selectedVariantElements = document.querySelectorAll(selectedVariantSelectors.join(', '));
    console.log(`🎯 Found ${selectedVariantElements.length} selected variant elements`);

    if (selectedVariantElements.length === 0) {
      // Try alternative detection methods
      const alternativeVariants = this.detectVariantsByContent();
      if (alternativeVariants) {
        console.log('✅ Found variant using alternative detection');
        return alternativeVariants;
      }
      console.log('❌ No variants detected');
      return null;
    }

    const variant = {
      id: null,
      color: null,
      size: null,
      warranty: null,
      themes: []
    };

    // Extract variant information from selected elements
    selectedVariantElements.forEach((element, index) => {
      console.log(`🔎 Processing variant element ${index + 1}:`, element);

      const variantType = this.detectVariantType(element);
      const variantValue = this.extractVariantValue(element, variantType);

      console.log(`📋 Detected: type=${variantType}, value=`, variantValue);

      if (variantValue) {
        switch (variantType) {
          case 'color':
            variant.color = variantValue;
            break;
          case 'size':
            variant.size = variantValue;
            break;
          case 'warranty':
            variant.warranty = variantValue;
            break;
          default:
            variant.themes.push(variantValue);
            break;
        }
      }
    });

    // Enhanced variant ID detection
    variant.id = this.generateVariantId(variant);

    const hasVariantData = Object.values(variant).some(v =>
      v !== null && (Array.isArray(v) ? v.length > 0 : true)
    );

    if (hasVariantData) {
      console.log('✅ Successfully detected variant:', variant);
      return variant;
    }

    console.log('❌ No valid variant data found');
    return null;
  }

  detectVariantsByContent() {
    // Alternative detection by looking for typical Digikala variant patterns
    const variantContainers = document.querySelectorAll([
      '[data-testid*="variant"]',
      '[class*="variant"]',
      '[class*="selector"]'
    ].join(', '));

    for (const container of variantContainers) {
      // Look for active/selected indicators
      const activeElement = container.querySelector([
        '[class*="active"]',
        '[class*="checked"]',
        '[aria-selected="true"]',
        '[data-selected="true"]'
      ].join(', '));

      if (activeElement) {
        const variantType = this.detectVariantType(container);
        const variantValue = this.extractVariantValue(activeElement, variantType);

        if (variantValue) {
          return {
            id: `alt_variant_${variantType}_${variantValue.title || ''}`.replace(/\s+/g, '_'),
            [variantType]: variantValue,
            color: variantType === 'color' ? variantValue : null,
            size: variantType === 'size' ? variantValue : null,
            warranty: variantType === 'warranty' ? variantValue : null,
            themes: variantType === 'theme' ? [variantValue] : []
          };
        }
      }
    }

    return null;
  }

  generateVariantId(variant) {
    console.log('🆔 VARIANT ID GENERATION - Input variant data:', variant);

    // Try multiple strategies to get/generate variant ID

    // 1. Look for data attributes
    const variantIdElement = document.querySelector([
      '[data-variant-id]',
      '[data-product-variant-id]',
      '[data-selected-variant]'
    ].join(', '));

    if (variantIdElement) {
      const id = variantIdElement.dataset.variantId ||
                  variantIdElement.dataset.productVariantId ||
                  variantIdElement.dataset.selectedVariant;
      if (id) {
        console.log('🆔 VARIANT ID GENERATION - Found DOM attribute ID:', id);
        return id;
      }
    }

    // 2. Generate clean, short variant ID from properties
    const variantParts = [];

    // Extract clean, key properties only
    if (variant.color?.title || variant.color?.name) {
      const colorName = (variant.color.title || variant.color.name).trim();
      // Take only the first part if it contains complex descriptions
      const cleanColor = colorName.split(/[:\-_،]/)[0].trim();
      if (cleanColor.length > 0 && cleanColor.length < 20) {
        variantParts.push(cleanColor);
      }
    }

    if (variant.size?.title || variant.size?.name) {
      const sizeName = (variant.size.title || variant.size.name).trim();
      const cleanSize = sizeName.split(/[:\-_،]/)[0].trim();
      if (cleanSize.length > 0 && cleanSize.length < 20) {
        variantParts.push(cleanSize);
      }
    }

    if (variant.warranty?.title || variant.warranty?.name) {
      const warrantyName = (variant.warranty.title || variant.warranty.name).trim();
      // Extract warranty period/type only
      const warrantyMatch = warrantyName.match(/(\d+)\s*(سال|ماه|روز)/);
      if (warrantyMatch) {
        variantParts.push(`${warrantyMatch[1]}${warrantyMatch[2]}`);
      } else {
        const cleanWarranty = warrantyName.split(/[:\-_،]/)[0].trim();
        if (cleanWarranty.length > 0 && cleanWarranty.length < 15) {
          variantParts.push(cleanWarranty);
        }
      }
    }

    // Add themes but clean them first
    if (variant.themes && Array.isArray(variant.themes)) {
      variant.themes.forEach(theme => {
        const themeName = (theme.title || theme.name || '').trim();
        const cleanTheme = themeName.split(/[:\-_،]/)[0].trim();
        if (cleanTheme.length > 0 && cleanTheme.length < 15) {
          variantParts.push(cleanTheme);
        }
      });
    }

    if (variantParts.length > 0) {
      // Create a clean, deterministic ID
      const cleanId = variantParts
        .join('_')
        .replace(/\s+/g, '_')
        .replace(/[^\w\u0600-\u06FF_]/g, '') // Keep only word chars, Persian chars, and underscores
        .substring(0, 50); // Limit length to 50 characters

      const finalId = `variant_${cleanId}`;
      console.log('🆔 VARIANT ID GENERATION - Generated clean ID from parts:', {
        inputParts: variantParts,
        cleanId: cleanId,
        finalId: finalId
      });
      return finalId;
    }

    // 3. Fallback to a simple hash if no clean properties found
    const variantStr = JSON.stringify({
      color: variant.color?.title || variant.color?.name,
      size: variant.size?.title || variant.size?.name,
      warranty: variant.warranty?.title || variant.warranty?.name
    });

    // Simple hash function for consistent IDs
    let hash = 0;
    for (let i = 0; i < variantStr.length; i++) {
      const char = variantStr.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }

    const hashId = `variant_${Math.abs(hash).toString(36)}`;
    console.log('🆔 VARIANT ID GENERATION - Generated hash ID as fallback:', {
      inputData: variantStr,
      hash: hash,
      finalId: hashId
    });
    return hashId;
  }

  detectVariantType(element) {
    const classList = element.classList.toString().toLowerCase();
    const dataAttributes = Array.from(element.attributes)
      .map(attr => attr.name.toLowerCase())
      .join(' ');

    if (classList.includes('color') || dataAttributes.includes('color')) {
      return 'color';
    }
    if (classList.includes('size') || dataAttributes.includes('size')) {
      return 'size';
    }
    if (classList.includes('warranty') || dataAttributes.includes('warranty')) {
      return 'warranty';
    }

    return 'theme';
  }

  extractVariantValue(element, type) {
    // Enhanced extraction for Digikala's variant elements
    console.log(`🔎 Extracting variant value for type: ${type}`, element);

    // Try multiple extraction strategies
    let title = this.extractVariantTitle(element);
    if (!title) {
      console.log('⚠️ No title found for variant element');
      return null;
    }

    console.log(`📋 Extracted title: "${title}"`);

    const value = { title, name: title };

    // Extract additional properties based on type
    switch (type) {
      case 'color':
        value.hex = this.extractColorHex(element);
        value.code = element.dataset.colorCode || element.dataset.color;
        break;

      case 'size':
        value.code = element.dataset.sizeCode ||
                     element.dataset.size ||
                     element.dataset.value;
        break;

      case 'warranty':
        const months = element.dataset.warrantyMonths ||
                       element.dataset.months ||
                       this.extractWarrantyMonths(title);
        if (months) {
          value.months = parseInt(months);
        }
        break;

      default:
        // For themes or other variant types
        value.code = element.dataset.code ||
                     element.dataset.value ||
                     element.id;
        break;
    }

    console.log(`✅ Final variant value:`, value);
    return value;
  }

  extractVariantTitle(element) {
    // FIXED: Extract clean variant titles, avoid seller/price contamination
    const titleSources = [
      // Prioritize clean data attributes first
      () => element.getAttribute('title'),
      () => element.getAttribute('aria-label'),
      () => element.dataset.title,
      () => element.dataset.name,
      () => element.dataset.value,
      () => element.dataset.label,

      // Look for specific variant-related elements
      () => element.querySelector('[title]')?.getAttribute('title'),
      () => element.querySelector('.variant-name, .option-name, .color-name, .size-name')?.textContent?.trim(),
      () => element.querySelector('.title, .name, .text')?.textContent?.trim(),

      // Fallback to text content but clean it
      () => this.extractCleanTextContent(element),
      () => element.closest('[title]')?.getAttribute('title')
    ];

    for (const source of titleSources) {
      try {
        const title = source();
        if (title && title.length > 0) {
          // Clean the extracted title to remove seller/price information
          const cleanTitle = this.cleanVariantTitle(title);
          if (cleanTitle && cleanTitle.length > 0) {
            return cleanTitle;
          }
        }
      } catch (e) {
        continue;
      }
    }

    return null;
  }

  extractCleanTextContent(element) {
    // Extract text content but avoid contamination from nested elements
    const text = element.textContent?.trim() || '';

    // If the text is too long, it probably contains unwanted info
    if (text.length > 100) {
      // Try to get text from direct text nodes only
      const directText = Array.from(element.childNodes)
        .filter(node => node.nodeType === Node.TEXT_NODE)
        .map(node => node.textContent.trim())
        .join(' ')
        .trim();

      return directText.length > 0 && directText.length <= 50 ? directText : null;
    }

    return text;
  }

  cleanVariantTitle(title) {
    if (!title || typeof title !== 'string') {
      return null;
    }

    console.log('🧹 VARIANT TITLE CLEANING - Input title:', `"${title}"`);

    // Remove common seller/price indicators from Persian text
    const cleanedTitle = title
      // Remove seller information
      .replace(/فروشنده[:\s]*[^،\n]*/gi, '')
      .replace(/فروشگاه[:\s]*[^،\n]*/gi, '')

      // Remove price information
      .replace(/قیمت[:\s]*[^،\n]*/gi, '')
      .replace(/هزینه[:\s]*[^،\n]*/gi, '')
      .replace(/\d+[٬,]\d+.*?تومان/gi, '')
      .replace(/\d+.*?ریال/gi, '')

      // Remove shipping information
      .replace(/ارسال[:\s]*[^،\n]*/gi, '')
      .replace(/حمل[:\s]*[^،\n]*/gi, '')

      // Remove stock/quantity information
      .replace(/حداکثر.*?سفارش[:\s]*[^،\n]*/gi, '')
      .replace(/موجودی[:\s]*[^،\n]*/gi, '')

      // Remove emojis and special characters that indicate selling info
      .replace(/[🏆📦💰🚚⭐]/g, '')

      // Clean up separators and whitespace
      .replace(/[:\-_▶►]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    // If what's left is too short or too long, it's probably not a good variant name
    if (cleanedTitle.length < 2 || cleanedTitle.length > 30) {
      console.log('🧹 VARIANT TITLE CLEANING - Rejected (length):', `"${cleanedTitle}" (length: ${cleanedTitle.length})`);
      return null;
    }

    // Check if it still contains price/seller indicators
    if (cleanedTitle.match(/\d+[٬,]\d+|فروش|قیمت|هزینه|ارسال/)) {
      console.log('🧹 VARIANT TITLE CLEANING - Rejected (still contains selling info):', `"${cleanedTitle}"`);
      return null;
    }

    console.log('🧹 VARIANT TITLE CLEANING - Success:', `"${title}" → "${cleanedTitle}"`);
    return cleanedTitle;
  }

  extractColorHex(element) {
    // Extract color hex from various sources
    const colorSources = [
      () => element.style.backgroundColor,
      () => element.style.background,
      () => element.dataset.colorCode,
      () => element.dataset.hex,
      () => element.querySelector('[style*="background"]')?.style.backgroundColor,
      () => element.querySelector('[style*="background"]')?.style.background,
      () => getComputedStyle(element).backgroundColor
    ];

    for (const source of colorSources) {
      try {
        const color = source();
        if (color && color !== 'rgba(0, 0, 0, 0)' && color !== 'transparent') {
          return color;
        }
      } catch (e) {
        continue;
      }
    }

    return null;
  }

  extractWarrantyMonths(title) {
    // Extract warranty months from title text
    const monthsMatch = title.match(/(\d+)\s*(ماه|month)/i);
    return monthsMatch ? parseInt(monthsMatch[1]) : null;
  }

  getVariantDisplayText() {
    if (!this.currentVariant) {
      return 'پیش‌فرض';
    }

    const parts = [];

    if (this.currentVariant.color) {
      parts.push(`رنگ: ${this.currentVariant.color.title}`);
    }

    if (this.currentVariant.size) {
      parts.push(`سایز: ${this.currentVariant.size.title}`);
    }

    if (this.currentVariant.warranty) {
      parts.push(`گارانتی: ${this.currentVariant.warranty.title}`);
    }

    if (this.currentVariant.themes && this.currentVariant.themes.length > 0) {
      this.currentVariant.themes.forEach(theme => {
        parts.push(theme.title);
      });
    }

    return parts.length > 0 ? parts.join(', ') : 'پیش‌فرض';
  }

  async getUpdatedProductInfo() {
    try {
      // Request fresh product info with current price from ProductDetailController
      return new Promise((resolve) => {
        this.eventBus.emit('product-detail:get-current-info', (productInfo) => {
          if (productInfo && productInfo.currentPrice) {
            console.log('✅ Got updated product info from ProductDetailController:', {
              productId: productInfo.productId,
              currentPrice: productInfo.currentPrice,
              hasVariant: !!this.currentVariant
            });
            resolve(productInfo);
          } else {
            console.warn('⚠️ No updated product info from controller, using existing');
            resolve(this.productInfo);
          }
        });

        // Fallback timeout in case no response
        setTimeout(() => {
          console.warn('⚠️ Timeout getting updated product info, using existing');
          resolve(this.productInfo);
        }, 2000);
      });
    } catch (error) {
      console.error('❌ Error getting updated product info:', error);
      return this.productInfo;
    }
  }

  setupEventListeners() {
    if (!this.button) return;

    this.button.addEventListener('click', this.handleClick.bind(this));

    // Listen for variant changes
    this.variantChangeHandler = this.handleVariantChange.bind(this);
    document.addEventListener('click', this.variantChangeHandler);

    // Listen for Smart Cart events
    this.eventBus.on('smart-cart:item-added', this.boundHandleItemAdded);
    this.eventBus.on('smart-cart:item-removed', this.boundHandleItemRemoved);
  }

  async handleClick(event) {
    event.preventDefault();
    event.stopPropagation();

    if (!this.productInfo) {
      console.error('❌ No product information available');
      console.log('Debug info:', {
        hasButton: !!this.button,
        hasSmartCartManager: !!this.smartCartManager,
        currentUrl: window.location.href
      });
      return;
    }

    console.log('🛒 Smart Cart button clicked with product info:', {
      productId: this.productInfo.productId,
      productTitle: this.productInfo.productTitle,
      hasVariant: !!this.currentVariant
    });

    // Update current variant before adding
    this.currentVariant = this.detectCurrentVariant();

    // Get current price that corresponds to selected variation
    const updatedProductInfo = await this.getUpdatedProductInfo();
    console.log('💰 Updated product info with current price:', {
      oldPrice: this.productInfo.currentPrice,
      newPrice: updatedProductInfo.currentPrice,
      hasVariant: !!this.currentVariant
    });

    // Show loading state
    this.setLoadingState(true);

    try {
      // Check if item already exists in cart
      const existingItem = this.smartCartManager.getProductFromCart(
        this.productInfo.productId,
        this.currentVariant?.id
      );

      if (existingItem) {
        // Item already in cart - UPDATE QUANTITY instead of removing
        console.log('📈 Updating quantity for existing item in Smart Cart:', existingItem.id);

        // Increase quantity by 1
        const newQuantity = (existingItem.qty || existingItem.quantity || 1) + 1;
        await this.smartCartManager.updateItemQuantity(existingItem.id, newQuantity);

        this.showSuccessAnimation();
        this.updateButtonState();

        // Emit event for other components
        this.eventBus.emit('smart-cart:button-clicked', {
          productId: this.productInfo.productId,
          variantId: this.currentVariant?.id,
          action: 'quantity_updated',
          cartItem: existingItem,
          newQuantity
        });
      } else {
        // Item not in cart - ADD it
        console.log('➕ Adding item to Smart Cart');

        const cartItem = await this.smartCartManager.addItem(
          updatedProductInfo,
          this.currentVariant
        );

        this.showSuccessAnimation();
        this.updateButtonState();

        // Emit event for other components
        this.eventBus.emit('smart-cart:button-clicked', {
          productId: this.productInfo.productId,
          variantId: this.currentVariant?.id,
          action: 'added',
          cartItem
        });
      }
    } catch (error) {
      console.error('❌ Error adding to Smart Cart:', error);
      this.showErrorState(error.message);
    } finally {
      this.setLoadingState(false);
    }
  }

  handleVariantChange(event) {
    // Check if click was on a variant selector
    const target = event.target;
    const isVariantSelector = target.closest([
      '[data-testid="variant-selector"]',
      '.variant-selector',
      '.variant-option',
      '.color-selector',
      '.size-selector'
    ].join(', '));

    if (isVariantSelector) {
      // Update variant info after a short delay
      setTimeout(() => {
        this.currentVariant = this.detectCurrentVariant();
        this.updateVariantDisplay();
        this.updateButtonState();
      }, 500);
    }
  }

  handleItemAdded(data) {
    const itemProductId = data.item?.pId || data.item?.productId;
    const itemVariantId = data.item?.vId || data.item?.variantId;

    if (itemProductId === this.productInfo?.productId &&
        itemVariantId === this.currentVariant?.id) {
      this.updateButtonState();
    }
  }

  handleItemRemoved(data) {
    // Check if removed item affects this button
    this.updateButtonState();
  }

  updateVariantDisplay() {
    const variantInfo = this.button?.parentElement.querySelector('.smart-cart-variant-info');
    if (variantInfo) {
      const variantText = this.getVariantDisplayText();
      variantInfo.innerHTML = `
        <div style="display: flex; align-items: center; gap: 6px;">
          <span style="font-size: 14px;">🏷️</span>
          <span>تنوع انتخابی: ${variantText}</span>
        </div>
      `;
    }
  }

  updateButtonState() {
    if (!this.button || !this.productInfo) return;

    const isInCart = this.smartCartManager.isProductInCart(
      this.productInfo.productId,
      this.currentVariant?.id
    );

    if (isInCart) {
      const existingItem = this.smartCartManager.getProductFromCart(
        this.productInfo.productId,
        this.currentVariant?.id
      );
      const quantity = existingItem ? (existingItem.qty || existingItem.quantity || 1) : 1;

      this.button.innerHTML = `
        <span style="font-size: 16px;">📈</span>
        <span>افزایش تعداد (${quantity})</span>
      `;
      this.button.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
      this.button.style.borderColor = '#059669';
      this.button.setAttribute('title', `موجود در سبد هوشمند: ${quantity} عدد - کلیک برای افزایش`);
    } else {
      this.button.innerHTML = `
        <span style="font-size: 16px;">🛒</span>
        <span>افزودن به سبد هوشمند</span>
      `;
      this.button.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
      this.button.style.borderColor = '#dc2626';
      this.button.setAttribute('title', 'کلیک کنید تا به سبد هوشمند اضافه شود');
    }
  }

  setLoadingState(loading) {
    if (!this.button) return;

    if (loading) {
      this.button.disabled = true;
      this.button.innerHTML = `
        <span style="display: inline-block; animation: spin 1s linear infinite;">⏳</span>
        <span>در حال افزودن...</span>
      `;

      // Add spinner animation
      if (!document.querySelector('#smart-cart-spinner-style')) {
        const style = document.createElement('style');
        style.id = 'smart-cart-spinner-style';
        style.textContent = `
          @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
        `;
        document.head.appendChild(style);
      }
    } else {
      this.button.disabled = false;
      this.updateButtonState();
    }
  }

  showSuccessAnimation() {
    if (!this.button) return;

    // Show temporary "added" state
    this.button.innerHTML = `
      <span style="font-size: 16px;">✅</span>
      <span>اضافه شد</span>
    `;
    this.button.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';

    setTimeout(() => {
      // After animation, update button state to reflect new status
      this.updateButtonState();
    }, 1000);
  }

  showRemovedAnimation() {
    if (!this.button) return;

    // Brief removal animation with orange/yellow color
    const originalBg = this.button.style.background;
    this.button.style.background = 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';

    // Show temporary "removed" state
    this.button.innerHTML = `
      <span style="font-size: 16px;">✅</span>
      <span>حذف شد</span>
    `;

    setTimeout(() => {
      // After animation, update button state to reflect new status
      this.updateButtonState();
    }, 1000);
  }

  showAddedState() {
    this.updateButtonState();
  }

  showErrorState(message) {
    if (!this.button) return;

    const originalContent = this.button.innerHTML;
    this.button.innerHTML = `
      <span style="font-size: 16px;">❌</span>
      <span>خطا در افزودن</span>
    `;
    this.button.style.background = '#ef4444';

    setTimeout(() => {
      this.button.innerHTML = originalContent;
      this.updateButtonState();
    }, 2000);
  }

  remove() {
    if (this.button?.parentElement) {
      this.button.parentElement.remove();
    }
    this.cleanup();
  }

  partialCleanup() {
    // Only clean up event listeners and button reference, keep productInfo
    if (this.variantChangeHandler) {
      document.removeEventListener('click', this.variantChangeHandler);
      this.variantChangeHandler = null;
    }

    this.eventBus.off('smart-cart:item-added', this.boundHandleItemAdded);
    this.eventBus.off('smart-cart:item-removed', this.boundHandleItemRemoved);

    this.button = null;
  }

  cleanup() {
    // Full cleanup including productInfo
    this.partialCleanup();
    this.productInfo = null;
    this.currentVariant = null;
  }

  // Debug and test methods for toggle behavior
  testToggleBehavior() {
    console.log('🧪 Testing Smart Cart Button toggle behavior');
    console.log('Current state:', {
      productId: this.productInfo?.productId,
      variantId: this.currentVariant?.id,
      isInCart: this.smartCartManager.isProductInCart(
        this.productInfo?.productId,
        this.currentVariant?.id
      ),
      buttonText: this.button?.textContent,
      cartItemsCount: this.smartCartManager.getCartItems()?.length || 0
    });

    return {
      productInfo: this.productInfo,
      currentVariant: this.currentVariant,
      isInCart: this.smartCartManager.isProductInCart(
        this.productInfo?.productId,
        this.currentVariant?.id
      ),
      cartItems: this.smartCartManager.getCartItems()
    };
  }

  // Force button state update for testing
  forceUpdateState() {
    console.log('🔄 Forcing button state update');
    this.updateButtonState();
  }
}

window.SmartCartButton = SmartCartButton;