/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-19
 * Centralized Smart Cart State Manager - Single Source of Truth
 * Manages all cart state, business logic, and synchronization between UI contexts
 */

class SmartCartStateManager {
  constructor(backgroundService) {
    this.backgroundService = backgroundService;
    this.storageKey = 'digikala_extension_smart_cart_items';
    this.cart = [];
    this.subscribers = new Map(); // UI contexts that listen to state changes
    this.initialized = false;

    // Configuration
    this.config = {
      maxQuantity: 10,
      minQuantity: 1,
      refreshInterval: 5 * 60 * 1000, // 5 minutes
      maxAge: 10 * 60 * 1000, // 10 minutes
      batchSize: 5
    };

    // Loading states for individual items
    this.loadingStates = new Map();
    this.lastRefreshTime = null;

    console.log('🏗️ Smart Cart State Manager initialized');
  }

  /**
   * Initialize the cart state manager
   */
  async initialize() {
    if (this.initialized) return;

    try {
      await this.loadCartFromStorage();
      this.setupStorageListener();
      this.initialized = true;
      console.log('✅ Smart Cart State Manager ready');

      // Notify all subscribers that state is initialized
      this.broadcastStateUpdate({
        type: 'CART_INITIALIZED',
        items: this.cart,
        itemCount: this.cart.length
      });
    } catch (error) {
      console.error('❌ Failed to initialize Smart Cart State Manager:', error);
    }
  }

  /**
   * Load cart data from storage
   */
  async loadCartFromStorage() {
    try {
      const result = await chrome.storage.local.get([this.storageKey]);
      this.cart = Array.isArray(result[this.storageKey]) ? result[this.storageKey] : [];
      console.log(`📦 Loaded ${this.cart.length} items from storage`);
    } catch (error) {
      console.error('❌ Failed to load cart from storage:', error);
      this.cart = [];
    }
  }

  /**
   * Save cart data to storage and broadcast changes
   */
  async saveCartToStorage() {
    try {
      await chrome.storage.local.set({ [this.storageKey]: this.cart });
      console.log(`💾 Saved ${this.cart.length} items to storage`);

      // Broadcast state update to all subscribers
      this.broadcastStateUpdate({
        type: 'CART_UPDATED',
        items: this.cart,
        itemCount: this.cart.length
      });
    } catch (error) {
      console.error('❌ Failed to save cart to storage:', error);
      throw error;
    }
  }

  /**
   * Subscribe a UI context to state changes
   */
  subscribe(contextId, callback) {
    this.subscribers.set(contextId, callback);
    console.log(`📡 Subscribed context: ${contextId}`);

    // Send initial state to new subscriber
    callback({
      type: 'INITIAL_STATE',
      items: this.cart,
      itemCount: this.cart.length
    });
  }

  /**
   * Unsubscribe a UI context from state changes
   */
  unsubscribe(contextId) {
    this.subscribers.delete(contextId);
    console.log(`📡 Unsubscribed context: ${contextId}`);
  }

  /**
   * Broadcast state updates to all subscribers
   */
  broadcastStateUpdate(update) {
    console.log(`📢 Broadcasting update: ${update.type} to ${this.subscribers.size} subscribers`);

    for (const [contextId, callback] of this.subscribers) {
      try {
        callback(update);
      } catch (error) {
        console.error(`❌ Error notifying subscriber ${contextId}:`, error);
      }
    }
  }

  /**
   * Add item to cart with variant and seller support
   */
  async addItem(productInfo, selectedVariant = null, selectedSeller = null) {
    if (!productInfo || !productInfo.productId) {
      throw new Error('Product information is required');
    }

    const cartItem = this.createCartItem(productInfo, selectedVariant, selectedSeller);

    // Check if item with same product/variant/seller already exists
    const existingIndex = this.findExistingItemIndex(cartItem);

    if (existingIndex !== -1) {
      // Update quantity of existing item
      const oldQuantity = this.cart[existingIndex].quantity;
      this.cart[existingIndex].quantity = Math.min(
        this.cart[existingIndex].quantity + cartItem.quantity,
        this.config.maxQuantity
      );
      this.cart[existingIndex].updatedAt = Date.now();

      console.log(`📈 Updated quantity: ${oldQuantity} → ${this.cart[existingIndex].quantity}`);
    } else {
      // Add new item
      this.cart.push(cartItem);
      console.log(`➕ Added new item: ${cartItem.productId}`);
    }

    await this.saveCartToStorage();

    // Fetch API data for display
    this.fetchItemDataInBackground(cartItem);

    this.broadcastStateUpdate({
      type: 'ITEM_ADDED',
      item: cartItem,
      isUpdate: existingIndex !== -1,
      items: this.cart,
      itemCount: this.cart.length
    });

    return cartItem;
  }

  /**
   * Remove item from cart
   */
  async removeItem(itemId) {
    const initialLength = this.cart.length;
    const removedItem = this.cart.find(item => item.id === itemId);

    this.cart = this.cart.filter(item => item.id !== itemId);

    if (this.cart.length < initialLength) {
      await this.saveCartToStorage();

      this.broadcastStateUpdate({
        type: 'ITEM_REMOVED',
        itemId,
        removedItem,
        items: this.cart,
        itemCount: this.cart.length
      });

      console.log(`🗑️ Removed item: ${itemId}`);
      return true;
    }

    return false;
  }

  /**
   * Update item quantity (removes if quantity becomes 0)
   */
  async updateQuantity(itemId, newQuantity) {
    const item = this.cart.find(item => item.id === itemId);
    if (!item) {
      throw new Error(`Item with ID ${itemId} not found`);
    }

    const oldQuantity = item.quantity;

    // Remove item if quantity is 0 or negative
    if (newQuantity <= 0) {
      return await this.removeItem(itemId);
    }

    // Enforce quantity limits
    newQuantity = Math.min(Math.max(newQuantity, this.config.minQuantity), this.config.maxQuantity);

    item.quantity = newQuantity;
    item.updatedAt = Date.now();

    await this.saveCartToStorage();

    this.broadcastStateUpdate({
      type: 'QUANTITY_UPDATED',
      itemId,
      oldQuantity,
      newQuantity,
      item,
      items: this.cart,
      itemCount: this.cart.length
    });

    console.log(`🔄 Updated quantity for ${itemId}: ${oldQuantity} → ${newQuantity}`);
    return item;
  }

  /**
   * Change item variant
   */
  async changeVariant(itemId, variantId, variantDetails = null) {
    const item = this.cart.find(item => item.id === itemId);
    if (!item) {
      throw new Error(`Item with ID ${itemId} not found`);
    }

    const oldVariant = item.variantId;

    if (variantId === 'all_best_price') {
      // Enable "Best Price" mode
      item.variantId = null;
      item.selectedVariant = null;
      item.bestPriceMode = true;

      // Trigger optimization
      this.optimizeItemForBestPrice(item);
    } else {
      // Specific variant selected
      item.variantId = variantId;
      item.selectedVariant = variantDetails;
      item.bestPriceMode = false;
    }

    item.updatedAt = Date.now();
    await this.saveCartToStorage();

    // Refresh item data from API
    this.fetchItemDataInBackground(item);

    this.broadcastStateUpdate({
      type: 'VARIANT_CHANGED',
      itemId,
      oldVariant,
      newVariant: variantId,
      item,
      items: this.cart,
      itemCount: this.cart.length
    });

    console.log(`🔄 Changed variant for ${itemId}: ${oldVariant} → ${variantId}`);
    return item;
  }

  /**
   * Change item seller
   */
  async changeSeller(itemId, sellerId, sellerDetails = null) {
    const item = this.cart.find(item => item.id === itemId);
    if (!item) {
      throw new Error(`Item with ID ${itemId} not found`);
    }

    const oldSeller = item.selectedSellerId;

    item.selectedSellerId = sellerId;
    if (sellerDetails) {
      item.selectedSeller = sellerDetails;
      // Update price if seller has price info
      if (sellerDetails.price) {
        item.price = sellerDetails.price;
      }
    }

    item.updatedAt = Date.now();
    await this.saveCartToStorage();

    this.broadcastStateUpdate({
      type: 'SELLER_CHANGED',
      itemId,
      oldSeller,
      newSeller: sellerId,
      item,
      items: this.cart,
      itemCount: this.cart.length
    });

    console.log(`🔄 Changed seller for ${itemId}: ${oldSeller} → ${sellerId}`);
    return item;
  }

  /**
   * Clear entire cart
   */
  async clearCart() {
    const itemCount = this.cart.length;
    this.cart = [];

    await this.saveCartToStorage();

    this.broadcastStateUpdate({
      type: 'CART_CLEARED',
      removedCount: itemCount,
      items: this.cart,
      itemCount: 0
    });

    console.log(`🧹 Cleared cart (${itemCount} items removed)`);
  }

  /**
   * Get current cart state
   */
  getCartState() {
    return {
      items: [...this.cart],
      summary: this.getCartSummary(),
      lastRefreshTime: this.lastRefreshTime,
      loadingItems: Array.from(this.loadingStates.keys())
    };
  }

  /**
   * Get cart summary statistics
   */
  getCartSummary() {
    const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalValue = this.cart.reduce((sum, item) => {
      const itemPrice = parseFloat(item.price || 0);
      const itemQuantity = parseInt(item.quantity) || 0;
      return sum + (itemPrice * itemQuantity);
    }, 0);
    const uniqueProducts = new Set(this.cart.map(item => item.productId)).size;

    return {
      totalItems,
      totalValue,
      uniqueProducts,
      itemCount: this.cart.length
    };
  }

  /**
   * Create a new cart item with proper structure
   */
  createCartItem(productInfo, selectedVariant, selectedSeller) {
    const now = Date.now();
    const variantId = selectedVariant?.id || null;
    const sellerId = selectedSeller?.id || 'digikala';

    return {
      // Core identifiers
      id: `cart_${productInfo.productId}_${variantId || 'default'}_${sellerId}_${now}`,
      productId: productInfo.productId,
      variantId,
      selectedSellerId: sellerId,

      // User-controlled data
      quantity: 1,

      // Product information (will be refreshed from API)
      title: productInfo.productTitle || 'در حال بارگذاری...',
      thumbnail: productInfo.productImage || null,
      price: productInfo.price || 0,
      maxQuantity: productInfo.maxQuantity || this.config.maxQuantity,

      // Selected variant/seller details
      selectedVariant,
      selectedSeller,

      // Sellers array (populated from API)
      sellers: selectedSeller ? [selectedSeller] : [],

      // Best price optimization
      bestPriceMode: false,

      // Metadata
      addedAt: now,
      updatedAt: now,
      source: 'smart_cart_button',

      // API data status
      _apiStatus: {
        lastFetched: null,
        needsRefresh: true,
        source: null,
        error: null
      }
    };
  }

  /**
   * Find existing item index for deduplication
   */
  findExistingItemIndex(cartItem) {
    return this.cart.findIndex(item =>
      item.productId === cartItem.productId &&
      item.variantId === cartItem.variantId &&
      item.selectedSellerId === cartItem.selectedSellerId
    );
  }

  /**
   * Fetch item data in background without blocking UI
   */
  async fetchItemDataInBackground(item) {
    if (!this.backgroundService?.requestManager) {
      console.warn('⚠️ Background service not available for API requests');
      return;
    }

    try {
      this.setItemLoading(item.id, true);

      const result = await this.backgroundService.requestManager.fetchWithDeduplication(
        item.productId,
        'product'
      );

      if (result.success) {
        this.mergeApiDataWithItem(item, result.data, result.source);
        await this.saveCartToStorage();

        this.broadcastStateUpdate({
          type: 'ITEM_API_UPDATED',
          itemId: item.id,
          item,
          source: result.source,
          items: this.cart,
          itemCount: this.cart.length
        });

        console.log(`✅ Updated API data for item: ${item.id}`);
      } else {
        console.warn(`⚠️ Failed to fetch API data for item: ${item.id}`, result.error);
        item._apiStatus.error = result.error;
      }
    } catch (error) {
      console.error(`❌ Error fetching API data for item: ${item.id}`, error);
      item._apiStatus.error = error.message;
    } finally {
      this.setItemLoading(item.id, false);
    }
  }

  /**
   * Merge API data with cart item
   */
  mergeApiDataWithItem(item, apiData, source) {
    const now = Date.now();

    // Extract key information from API response
    const title = apiData.title_fa || apiData.title || item.title;
    const thumbnail = this.extractImageFromApiData(apiData);
    const price = this.extractPriceFromApiData(apiData);
    const sellers = this.extractSellersFromApiData(apiData);
    const variants = this.extractVariantsFromApiData(apiData);
    const availability = this.extractAvailabilityFromApiData(apiData);

    // Update item with fresh data
    Object.assign(item, {
      title,
      thumbnail: thumbnail || item.thumbnail,
      price: price || item.price,
      sellers: sellers.length ? sellers : item.sellers,
      variants: variants || item.variants,
      availability,
      _apiStatus: {
        lastFetched: now,
        needsRefresh: false,
        source,
        error: null
      }
    });

    // Handle best price optimization
    if (item.bestPriceMode && sellers.length > 0) {
      this.optimizeItemForBestPrice(item);
    }

    console.log(`📊 Merged API data for ${item.productId}: price=${price}, sellers=${sellers.length}`);
  }

  /**
   * Extract image URL from API data
   */
  extractImageFromApiData(apiData) {
    return apiData.images?.main?.url?.[0] ||
           apiData.images?.list?.[0]?.url?.[0] ||
           apiData.image ||
           null;
  }

  /**
   * Extract price from API data
   */
  extractPriceFromApiData(apiData) {
    return apiData.default_variant?.price?.selling_price ||
           apiData.price?.selling_price ||
           apiData.variants?.[0]?.price?.selling_price ||
           null;
  }

  /**
   * Extract sellers from API data
   */
  extractSellersFromApiData(apiData) {
    const sellers = [];

    // Add default seller
    if (apiData.default_variant?.seller) {
      const seller = apiData.default_variant.seller;
      sellers.push({
        id: seller.id || 'digikala',
        name: seller.title || 'دیجی‌کالا',
        price: apiData.default_variant.price?.selling_price || 0,
        stock: apiData.default_variant.price?.marketable_stock || 0,
        shippingCost: 0,
        rating: seller.rating?.total_rate || 100
      });
    }

    // Add sellers from other variants
    if (apiData.variants && Array.isArray(apiData.variants)) {
      for (const variant of apiData.variants) {
        if (variant.seller && !sellers.find(s => s.id === variant.seller.id)) {
          sellers.push({
            id: variant.seller.id,
            name: variant.seller.title,
            price: variant.price?.selling_price || 0,
            stock: variant.price?.marketable_stock || 0,
            shippingCost: 0,
            rating: variant.seller.rating?.total_rate || 100
          });
        }
      }
    }

    return sellers;
  }

  /**
   * Extract variants from API data
   */
  extractVariantsFromApiData(apiData) {
    if (!apiData.variants || !Array.isArray(apiData.variants)) {
      return [];
    }

    return apiData.variants.map(variant => ({
      id: variant.id,
      title: this.formatVariantTitle(variant),
      price: variant.price?.selling_price || 0,
      stock: variant.price?.marketable_stock || 0,
      details: this.extractVariantDetails(variant)
    }));
  }

  /**
   * Extract availability info from API data
   */
  extractAvailabilityFromApiData(apiData) {
    const defaultVariant = apiData.default_variant;

    return {
      isAvailable: apiData.status === 'marketable' && defaultVariant?.price?.marketable_stock > 0,
      stockCount: defaultVariant?.price?.marketable_stock || 0,
      maxCartCount: defaultVariant?.price?.order_limit || this.config.maxQuantity
    };
  }

  /**
   * Format variant title from variant data
   */
  formatVariantTitle(variant) {
    const parts = [];

    if (variant.color) {
      parts.push(variant.color.title || variant.color.name);
    }
    if (variant.size) {
      parts.push(variant.size.title || variant.size.name);
    }
    if (variant.warranty) {
      parts.push(variant.warranty.title_fa || variant.warranty.title);
    }

    return parts.length > 0 ? parts.join(' - ') : `گزینه ${variant.id}`;
  }

  /**
   * Extract variant details
   */
  extractVariantDetails(variant) {
    const details = {};

    if (variant.color) {
      details.color = {
        title: variant.color.title || variant.color.name,
        code: variant.color.code,
        hex: variant.color.hex
      };
    }

    if (variant.size) {
      details.size = {
        title: variant.size.title || variant.size.name,
        code: variant.size.code
      };
    }

    if (variant.warranty) {
      details.warranty = {
        title: variant.warranty.title_fa || variant.warranty.title,
        months: variant.warranty.months
      };
    }

    return details;
  }

  /**
   * Optimize item for best price across all sellers and variants
   */
  optimizeItemForBestPrice(item) {
    if (!item.sellers || item.sellers.length === 0) {
      console.log(`⚠️ No sellers available for optimization: ${item.id}`);
      return;
    }

    // Find seller with lowest price
    const bestSeller = item.sellers.reduce((best, current) => {
      if (!best || (current.price > 0 && current.price < best.price && current.stock > 0)) {
        return current;
      }
      return best;
    });

    if (bestSeller && bestSeller.id !== item.selectedSellerId) {
      console.log(`🎯 Optimizing ${item.id}: switching to seller ${bestSeller.name} (${bestSeller.price})`);

      item.selectedSellerId = bestSeller.id;
      item.selectedSeller = bestSeller;
      item.price = bestSeller.price;
      item.updatedAt = Date.now();

      this.broadcastStateUpdate({
        type: 'ITEM_OPTIMIZED',
        itemId: item.id,
        optimizedSeller: bestSeller,
        item,
        items: this.cart,
        itemCount: this.cart.length
      });
    }
  }

  /**
   * Set loading state for an item
   */
  setItemLoading(itemId, isLoading) {
    if (isLoading) {
      this.loadingStates.set(itemId, true);
    } else {
      this.loadingStates.delete(itemId);
    }

    this.broadcastStateUpdate({
      type: 'LOADING_STATE_CHANGED',
      itemId,
      isLoading,
      loadingItems: Array.from(this.loadingStates.keys())
    });
  }

  /**
   * Refresh all cart items with fresh API data
   */
  async refreshAllItems() {
    if (this.cart.length === 0) {
      console.log('📋 No items to refresh');
      return;
    }

    console.log(`🔄 Refreshing ${this.cart.length} cart items with fresh API data`);
    this.lastRefreshTime = Date.now();

    const refreshPromises = this.cart.map(item => this.fetchItemDataInBackground(item));
    await Promise.allSettled(refreshPromises);

    this.broadcastStateUpdate({
      type: 'REFRESH_COMPLETED',
      timestamp: this.lastRefreshTime,
      items: this.cart,
      itemCount: this.cart.length
    });

    console.log('✅ Cart refresh completed');
  }

  /**
   * Setup storage listener for external changes
   */
  setupStorageListener() {
    if (chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, namespace) => {
        if (namespace === 'local' && changes[this.storageKey]) {
          const newItems = changes[this.storageKey].newValue || [];

          // Update internal state
          this.cart = newItems;

          // Broadcast the change
          this.broadcastStateUpdate({
            type: 'STORAGE_SYNC',
            items: this.cart,
            itemCount: this.cart.length
          });

          console.log(`🔄 Synced cart from storage: ${this.cart.length} items`);
        }
      });
    }
  }

  /**
   * Clean up resources
   */
  cleanup() {
    this.subscribers.clear();
    this.loadingStates.clear();
    console.log('🧹 Smart Cart State Manager cleaned up');
  }
}

// Export for use in background service
window.SmartCartStateManager = SmartCartStateManager;