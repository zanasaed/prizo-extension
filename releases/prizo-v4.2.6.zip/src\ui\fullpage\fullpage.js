/**
 * Prizo Full-Page UI Controller
 * Consolidated version with all functionality included
 * Manages sidebar navigation, watchlist functionality, and data operations
 */

class PrizoFullPageUI {
  constructor() {
    this.initialized = false;
    this.service = null;
    this.sidebarOpen = false;

    // Data management
    this.currentFilter = 'all';
    this.currentSearchQuery = '';
    this.watchlistItems = [];
    this.smartCartItems = [];
    this.comparisonSites = [];
    this.currentEditingSite = null;
    this.currentEditingItem = null;

    // Enhanced Smart Cart Optimizer
    this.smartCartOptimizer = null;
    this.optimizationResults = null;
    this.isOptimizing = false;

    // Bulk actions state
    this.bulkSelectionMode = false;
    this.selectedItems = new Set();

    // Hook system
    this.hooks = {};

    // Bind methods to preserve context
    this.handleFilterClick = this.handleFilterClick.bind(this);
    this.handleFAQClick = this.handleFAQClick.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handleSidebarToggle = this.handleSidebarToggle.bind(this);
    this.handleNavClick = this.handleNavClick.bind(this);

    this.init();
  }

  /**
   * Initialize the full-page UI
   */
  async init() {
    try {
      // Initialize the service first
      this.service = new FullPageService();
      await this.service.init();

      // Check Smart Cart feature flag and conditionally hide Smart Cart tab
      await this.checkSmartCartFeature();

      this.setupEventListeners();
      this.setupAccessibility();
      this.setupSidebarNavigation();

      // Load initial data
      await this.loadWatchlistData();
      await this.loadSmartCartData();
      await this.updateStats();

      // Initialize Smart Cart Optimizer only if enabled
      await this.initializeSmartCartOptimizer();

      // Setup storage listener for real-time updates
      this.setupStorageListener();

      this.initialized = true;
      this.trigger('ready');

      console.log('Prizo Full-Page UI initialized successfully');
    } catch (error) {
      console.error('Failed to initialize Prizo Full-Page UI:', error);
    }
  }

  /**
   * Check Smart Cart feature flag and conditionally hide Smart Cart tab
   */
  async checkSmartCartFeature() {
    try {
      // Check if Smart Cart feature is enabled
      const result = await chrome.storage.sync.get(['smartCartEnabled']);
      const smartCartEnabled = result.smartCartEnabled || false;

      if (!smartCartEnabled) {
        console.log('🚫 Smart Cart feature disabled - hiding Smart Cart tab in fullpage');

        // Hide Smart Cart navigation tab
        const smartCartNav = document.getElementById('smart-cart-nav');
        if (smartCartNav) {
          smartCartNav.style.display = 'none';
        }

        // Hide Smart Cart content panel
        const smartCartPanel = document.getElementById('smart-cart-panel');
        if (smartCartPanel) {
          smartCartPanel.style.display = 'none';
        }

        // If Smart Cart was the active tab, switch to watchlist
        const activeNav = document.querySelector('.nav-link.active');
        if (activeNav && activeNav.getAttribute('data-tab') === 'smart-cart') {
          // Remove active from Smart Cart tab
          activeNav.classList.remove('active');

          // Make watchlist tab active
          const watchlistNav = document.querySelector('[data-tab="watchlist"]');
          const watchlistPanel = document.getElementById('watchlist-panel');

          if (watchlistNav) {
            watchlistNav.classList.add('active');
          }

          if (watchlistPanel) {
            watchlistPanel.classList.add('active');
          }

          // Remove active from Smart Cart panel
          if (smartCartPanel) {
            smartCartPanel.classList.remove('active');
          }
        }
      } else {
        console.log('✅ Smart Cart feature enabled - keeping Smart Cart tab visible');
      }
    } catch (error) {
      console.warn('⚠️ Error checking Smart Cart feature status in fullpage:', error);
      // On error, assume disabled and hide Smart Cart tab
      const smartCartNav = document.getElementById('smart-cart-nav');
      const smartCartPanel = document.getElementById('smart-cart-panel');

      if (smartCartNav) smartCartNav.style.display = 'none';
      if (smartCartPanel) smartCartPanel.style.display = 'none';
    }
  }

  /**
   * Set up event listeners
   */
  setupEventListeners() {
    // Sidebar navigation
    this.setupSidebarNavigation();

    // Filter dropdown toggle
    const filterToggle = document.getElementById('filterToggle');
    const filterMenu = document.getElementById('filterMenu');
    if (filterToggle && filterMenu) {
      filterToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        filterMenu.classList.toggle('show');
      });

      // Close filter menu when clicking outside
      document.addEventListener('click', () => {
        filterMenu.classList.remove('show');
      });

      // Filter options
      const filterOptions = document.querySelectorAll('.filter-option');
      filterOptions.forEach(option => {
        option.addEventListener('click', this.handleFilterClick);
      });
    }

    // FAQ items
    const faqItems = document.querySelectorAll('.faq-question');
    faqItems.forEach(item => {
      item.addEventListener('click', this.handleFAQClick);
    });

    // Search functionality
    const searchInput = document.getElementById('search-watchlist');
    if (searchInput) {
      searchInput.addEventListener('input', this.debounce(this.handleSearch, 300));
    }

    // Header action buttons
    const fullscreenToggle = document.getElementById('fullscreenToggle');
    if (fullscreenToggle) {
      fullscreenToggle.addEventListener('click', this.toggleFullscreen.bind(this));
    }

    // Refresh All Watchlist functionality
    const refreshAllWatchlistBtn = document.getElementById('refresh-all-watchlist');
    if (refreshAllWatchlistBtn) {
      refreshAllWatchlistBtn.addEventListener('click', () => this.handleRefreshAllWatchlist());
    }

    // Bulk actions functionality
    const bulkActionsBtn = document.getElementById('bulk-actions');
    if (bulkActionsBtn) {
      bulkActionsBtn.addEventListener('click', () => this.toggleBulkSelectionMode());
    }

    // Bulk actions panel buttons
    const bulkDeleteBtn = document.getElementById('bulk-delete');
    if (bulkDeleteBtn) {
      bulkDeleteBtn.addEventListener('click', () => this.bulkDeleteItems());
    }

    const bulkChangeIntervalBtn = document.getElementById('bulk-change-interval');
    if (bulkChangeIntervalBtn) {
      bulkChangeIntervalBtn.addEventListener('click', () => this.bulkChangeInterval());
    }

    const bulkSelectAllBtn = document.getElementById('bulk-select-all');
    if (bulkSelectAllBtn) {
      bulkSelectAllBtn.addEventListener('click', () => {
        if (this.selectedItems.size === 0) {
          this.selectAllItems();
        } else {
          this.deselectAllItems();
        }
      });
    }

    // Optimize Cart functionality
    const optimizeCartBtn = document.getElementById('optimize-cart-btn');
    if (optimizeCartBtn) {
      optimizeCartBtn.addEventListener('click', () => this.handleOptimizeCartClick());
    }

    // Add Product functionality
    this.setupAddProductModal();

    // Edit Watchlist Item functionality
    this.setupEditWatchlistModal();

    // Setup image error handling
    this.setupImageErrorHandling();

    // Extension status updates
    this.updateExtensionStatus();
    setInterval(() => this.updateExtensionStatus(), 30000);

    // Setup settings functionality
    this.setupSettingsEventListeners();
  }

  /**
   * Setup sidebar navigation
   */
  setupSidebarNavigation() {
    // Mobile menu toggle
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    const sidebarToggle = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');

    if (mobileToggle) {
      mobileToggle.addEventListener('click', this.handleSidebarToggle);
    }

    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', this.handleSidebarToggle);
    }

    if (overlay) {
      overlay.addEventListener('click', this.closeSidebar.bind(this));
    }

    // Navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      link.addEventListener('click', this.handleNavClick);
    });

    // Close sidebar on escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.sidebarOpen) {
        this.closeSidebar();
      }
    });
  }

  /**
   * Handle sidebar toggle
   */
  handleSidebarToggle(e) {
    e.preventDefault();
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');

    if (this.sidebarOpen) {
      this.closeSidebar();
    } else {
      this.sidebarOpen = true;
      if (sidebar) sidebar.classList.add('show');
      if (overlay) overlay.classList.add('show');

      // Focus first nav link for accessibility
      const firstNavLink = document.querySelector('.nav-link');
      if (firstNavLink) firstNavLink.focus();
    }
  }

  /**
   * Close sidebar
   */
  closeSidebar() {
    this.sidebarOpen = false;
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');

    if (sidebar) sidebar.classList.remove('show');
    if (overlay) overlay.classList.remove('show');
  }

  /**
   * Handle navigation clicks
   */
  handleNavClick(e) {
    e.preventDefault();
    const link = e.currentTarget;
    const targetTab = link.getAttribute('data-tab');

    if (targetTab) {
      this.switchTab(targetTab);

      // Close sidebar on mobile after navigation
      if (window.innerWidth <= 1024) {
        this.closeSidebar();
      }
    }
  }

  /**
   * Switch to a specific tab
   */
  switchTab(tabId) {
    // Update navigation active state
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.remove('active');
    });

    const activeLink = document.querySelector(`[data-tab="${tabId}"]`);
    if (activeLink) {
      activeLink.classList.add('active');
    }

    // Update content panels
    document.querySelectorAll('.content-panel').forEach(panel => {
      panel.classList.remove('active');
    });

    const activePanel = document.getElementById(`${tabId}-panel`);
    if (activePanel) {
      activePanel.classList.add('active');
    }

    // Load tab-specific data
    this.loadTabData(tabId);

    // Update page title
    const pageTitleElement = document.querySelector('.page-title');
    if (pageTitleElement && activeLink) {
      const navText = activeLink.querySelector('.nav-text');
      if (navText) {
        pageTitleElement.textContent = navText.textContent;
      }
    }

    this.trigger('tabChanged', { tabId, activeLink, activePanel });
  }

  /**
   * Load tab-specific data
   */
  async loadTabData(tabId) {
    try {
      switch (tabId) {
        case 'watchlist':
          await this.loadWatchlistData();
          break;
        case 'smart-cart':
          console.log('🔄 Loading Smart Cart data for tab switch...');
          await this.loadSmartCartData();
          // Force refresh from storage to ensure we have the latest data
          const result = await chrome.storage.local.get(['digikala_extension_smart_cart_items']);
          const freshItems = result.digikala_extension_smart_cart_items || [];
          if (JSON.stringify(freshItems) !== JSON.stringify(this.smartCartItems)) {
            console.log('🔄 Found different data in storage, updating...');
            this.smartCartItems = freshItems;
            this.renderSmartCartData(this.smartCartItems);
            this.updateSmartCartSummary(this.smartCartItems);
          }
          break;
        case 'history':
          await this.loadHistoryData();
          break;
        case 'settings':
          console.log('⚙️ Loading settings data for tab switch...');
          await this.loadSettings();
          break;
        case 'help':
          // Help content is static
          break;
        case 'contact':
          // Contact content is static
          break;
      }
    } catch (error) {
      console.error(`Failed to load data for tab: ${tabId}`, error);
      this.trigger('dataLoadError', { tabId, error });
    }
  }

  /**
   * Load watchlist data
   */
  async loadWatchlistData() {
    try {
      // Show loading state
      this.showLoadingState('watchlist-items');

      // Get filtered data from service
      const data = await this.service.getFilteredWatchlistItems(this.currentFilter, this.currentSearchQuery);
      console.log(`📊 Loaded ${data.length} watchlist items with filter '${this.currentFilter}' and search '${this.currentSearchQuery}'`);
      this.watchlistItems = data;

      // Render the data
      this.renderWatchlistData(this.watchlistItems);

      // Update stats
      await this.updateStats();

      this.trigger('dataLoaded', {
        type: 'watchlist',
        items: this.watchlistItems,
        filter: this.currentFilter,
        search: this.currentSearchQuery
      });

    } catch (error) {
      console.error('Error loading watchlist data:', error);
      this.showErrorState('watchlist-items', error.message);
    }
  }

  /**
   * Load Smart Cart data
   */
  async loadSmartCartData() {
    try {
      // Check if Smart Cart feature is enabled
      const featureCheck = await chrome.storage.sync.get(['smartCartEnabled']);
      const smartCartEnabled = featureCheck.smartCartEnabled || false;

      if (!smartCartEnabled) {
        console.log('🚫 Smart Cart feature disabled - skipping Smart Cart data loading');
        this.smartCartItems = [];
        return;
      }

      console.log('🛒 Loading Smart Cart data with API-first approach...');
      this.showLoadingState('current-cart-items');

      // Get Smart Cart data from extension storage (using the correct prefixed key)
      const result = await chrome.storage.local.get(['digikala_extension_smart_cart_items']);
      const cartItems = result.digikala_extension_smart_cart_items || [];
      this.smartCartItems = cartItems;

      console.log(`📦 Loaded ${cartItems.length} Smart Cart items from storage`);

      // Update the display with current data (may show cached info temporarily)
      this.renderSmartCartData(cartItems);
      this.updateSmartCartSummary(cartItems);

      // Update sidebar badge
      this.updateSidebarBadges({ smartCart: cartItems.length });

      // Request fresh API data for all cart items
      if (cartItems.length > 0) {
        console.log('🌐 Requesting fresh API data for cart items...');
        await this.refreshCartItemsWithAPI(cartItems);
      }

      this.trigger('dataLoaded', {
        type: 'smart-cart',
        items: this.smartCartItems
      });

      // Log status for debugging
      if (this.smartCartItems.length === 0) {
        console.log('ℹ️ Smart Cart is empty - no items to display');
      } else {
        console.log(`✅ Successfully loaded ${this.smartCartItems.length} Smart Cart items for fullpage view`);
      }

    } catch (error) {
      console.error('Error loading Smart Cart data:', error);
      this.showErrorState('current-cart-items', error.message);
    }
  }

  /**
   * Refresh cart items with fresh API data
   */
  async refreshCartItemsWithAPI(cartItems) {
    if (!cartItems || cartItems.length === 0) {
      return;
    }

    try {
      console.log(`🔄 Refreshing ${cartItems.length} cart items with API data...`);

      // Group items that need API refresh
      const itemsNeedingRefresh = cartItems.filter(item => {
        if (!item._cached) return true;
        if (item._cached.needsRefresh) return true;
        if (!item._cached.lastFetched) return true;

        const age = Date.now() - item._cached.lastFetched;
        return age > (5 * 60 * 1000); // 5 minutes
      });

      if (itemsNeedingRefresh.length === 0) {
        console.log('✅ All cart items have fresh API data');
        return;
      }

      console.log(`🌐 ${itemsNeedingRefresh.length} items need API refresh`);

      // Show loading indicators for items being refreshed
      itemsNeedingRefresh.forEach(item => {
        this.showItemLoadingState(item.id);
      });

      // Process items in batches to avoid API rate limits
      const batchSize = 3;
      const batches = [];
      for (let i = 0; i < itemsNeedingRefresh.length; i += batchSize) {
        batches.push(itemsNeedingRefresh.slice(i, i + batchSize));
      }

      let refreshedCount = 0;
      for (const batch of batches) {
        const batchPromises = batch.map(item => this.fetchAPIDataForCartItem(item));
        const results = await Promise.allSettled(batchPromises);

        results.forEach((result, index) => {
          const item = batch[index];
          this.hideItemLoadingState(item.id);

          if (result.status === 'fulfilled' && result.value) {
            refreshedCount++;
            console.log(`✅ Refreshed API data for ${item.productId}`);
          } else {
            console.warn(`⚠️ Failed to refresh API data for ${item.productId}:`, result.reason);
          }
        });

        // Small delay between batches
        if (batches.indexOf(batch) < batches.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }

      // Update storage with refreshed data
      if (refreshedCount > 0) {
        await chrome.storage.local.set({ digikala_extension_smart_cart_items: this.smartCartItems });
        console.log(`💾 Saved ${refreshedCount} refreshed cart items to storage`);

        // Re-render with fresh data
        this.renderSmartCartData(this.smartCartItems);
        this.updateSmartCartSummary(this.smartCartItems);
      }

      console.log(`✅ API refresh completed: ${refreshedCount}/${itemsNeedingRefresh.length} items updated`);

    } catch (error) {
      console.error('❌ Error refreshing cart items with API:', error);
    }
  }

  /**
   * Fetch API data for a single cart item
   */
  async fetchAPIDataForCartItem(cartItem) {
    try {
      // Basic API endpoint for Digikala product
      const productId = cartItem.pId || cartItem.productId;
      if (!productId) {
        throw new Error('Missing product ID in cart item');
      }
      const apiUrl = `https://api.digikala.com/v2/product/${productId}/`;

      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();
      if (data && data.data && data.data.product) {
        // API returns {status: 200, data: {product: {...}}}
        this.mergeAPIDataWithCartItem(cartItem, data.data.product);
        return cartItem;
      } else {
        throw new Error('Invalid API response structure');
      }

    } catch (error) {
      console.warn(`⚠️ API fetch failed for ${cartItem.pId || cartItem.productId}:`, error);
      return null;
    }
  }

  /**
   * Merge API data with cart item
   * Fixed to handle real Digikala API structure: data.zone_top.products[]
   */
  mergeAPIDataWithCartItem(cartItem, apiData) {
    const now = Date.now();

    // Handle real Digikala API response structure
    let productData = apiData;

    // Check if this is the real API format with zone_top.products[]
    if (apiData.zone_top?.products && Array.isArray(apiData.zone_top.products)) {
      // Find the matching product by ID or use the first one as fallback
      const productId = cartItem.pId || cartItem.productId;
      productData = apiData.zone_top.products.find(p => p.id == productId) || apiData.zone_top.products[0];
      console.log(`🔍 Using product from zone_top.products for ID ${productId}:`, !!productData);
    }

    // Extract data from the correct structure
    const price = this.extractPriceFromAPIData(apiData);
    const title = productData?.title_fa || productData?.title || cartItem._cached?.productTitle;
    const image = this.extractImageFromAPIData(apiData);

    // Update cart item with API data
    if (price) cartItem.price = price;
    if (title) cartItem.productTitle = title;
    if (image) cartItem.productImage = image;

    // Update cached metadata
    cartItem._cached = {
      ...cartItem._cached,
      productTitle: title,
      productUrl: cartItem._cached?.productUrl || cartItem._c?.u || `https://www.digikala.com/product/dkp-${cartItem.pId || cartItem.productId}/`,
      lastFetched: now,
      needsRefresh: false,
      dataSource: 'api'
    };

    // Extract availability info from the correct API structure
    const defaultVariant = productData?.default_variant;
    cartItem.availability = {
      isAvailable: productData?.status === 'marketable' && defaultVariant?.price?.marketable_stock > 0,
      stockCount: defaultVariant?.price?.marketable_stock || 0,
      maxCartCount: defaultVariant?.price?.order_limit || 10
    };

    // Extract variations data from the correct API response structure
    // Based on real API: productData.default_variant.themes[] contains color/variant info
    if (productData?.default_variant?.themes && Array.isArray(productData.default_variant.themes)) {
      cartItem.variations = productData.default_variant.themes.map(theme => ({
        id: theme.value?.variant_id || theme.value?.id,
        color: theme.value ? {
          id: theme.value.id,
          title: theme.value.title,
          hex_code: theme.value.hex_code || theme.value.hexCode
        } : null,
        warranty: productData.default_variant.warranty,
        themes: [theme],
        price: productData.default_variant.price,
        seller: productData.default_variant.seller,
        properties: productData.default_variant.properties,
        type: theme.type,
        label: theme.label,
        isMain: theme.is_main
      }));
      console.log(`📊 Extracted ${cartItem.variations.length} theme variations for ${cartItem.pId || cartItem.productId}`);
    }
    // Fallback to legacy variants structure if available
    else if (apiData.variants && Array.isArray(apiData.variants)) {
      cartItem.variations = apiData.variants.map(variant => ({
        id: variant.id,
        color: variant.color,
        warranty: variant.warranty,
        themes: variant.themes,
        price: variant.price,
        seller: variant.seller,
        properties: variant.properties
      }));
      console.log(`📊 Extracted ${cartItem.variations.length} legacy variations for ${cartItem.pId || cartItem.productId}`);
    }

    // Store colors array for variation display - extract from themes
    if (productData?.default_variant?.themes) {
      cartItem.availableColors = productData.default_variant.themes
        .filter(theme => theme.type === 'colored' && theme.value)
        .map(theme => ({
          id: theme.value.id,
          title: theme.value.title,
          hex_code: theme.value.hex_code || theme.value.hexCode,
          code: theme.value.code
        }));
    }
    // Fallback to legacy colors structure
    else if (apiData.colors && Array.isArray(apiData.colors)) {
      cartItem.availableColors = apiData.colors;
    }

    // Extract sellers information from the correct API structure
    const sellers = [];

    // Add the default variant seller from the correct structure
    if (productData?.default_variant?.seller) {
      const defaultSeller = productData.default_variant.seller;
      sellers.push({
        id: defaultSeller.id || 'digikala',
        name: defaultSeller.title || 'دیجی‌کالا',
        price: price,
        inventory: defaultVariant?.price?.marketable_stock || 5,
        rating: defaultSeller.rating?.total_rate ? (defaultSeller.rating.total_rate / 20) : defaultSeller.stars || 4.0,
        shipsDirectly: !productData.default_variant.properties?.is_ship_by_seller
      });
    }

    // Add sellers from other variations (avoid duplicates)
    if (cartItem.variations) {
      cartItem.variations.forEach(variant => {
        if (variant.seller && variant.seller.id !== sellers[0]?.id) {
          const variantPrice = variant.price?.selling_price || price;
          sellers.push({
            id: variant.seller.id,
            name: variant.seller.title,
            price: variantPrice,
            inventory: variant.price?.marketable_stock || 5,
            rating: variant.seller.rating?.total_rate || 100,
            shipsDirectly: !variant.properties?.is_ship_by_seller
          });
        }
      });
    }

    cartItem.sellers = sellers;
    console.log(`🏪 Extracted ${sellers.length} sellers for ${cartItem.pId || cartItem.productId}`);

    console.log(`📊 Merged API data for ${cartItem.pId || cartItem.productId}: price=${price}, title="${title}"`);
  }

  /**
   * Extract price from API data
   * Fixed to handle real Digikala API structure: data.zone_top.products[]
   */
  extractPriceFromAPIData(apiData) {
    // Handle real Digikala API response structure
    let productData = apiData;

    // Check if this is the real API format with zone_top.products[]
    if (apiData.zone_top?.products && Array.isArray(apiData.zone_top.products)) {
      // For now, take the first product (this might need refinement based on use case)
      productData = apiData.zone_top.products[0];
      console.log('🔍 Using first product from zone_top.products for price extraction');
    }

    // Extract price from the correct structure
    if (productData?.default_variant?.price?.selling_price) {
      return productData.default_variant.price.selling_price;
    }

    // If no default variant, try direct price (fallback for different API endpoints)
    if (productData?.price?.selling_price) {
      return productData.price.selling_price;
    }

    // Try variant-specific prices if variants array exists
    if (productData?.variants && Array.isArray(productData.variants) && productData.variants.length > 0) {
      const firstVariant = productData.variants[0];
      if (firstVariant.price?.selling_price) {
        return firstVariant.price.selling_price;
      }
    }

    console.warn('⚠️ Could not extract price from product data:', Object.keys(apiData));
    return null;
  }

  /**
   * Extract image from API data
   * Fixed to handle real Digikala API structure: data.zone_top.products[]
   */
  extractImageFromAPIData(apiData) {
    // Handle real Digikala API response structure
    let productData = apiData;

    // Check if this is the real API format with zone_top.products[]
    if (apiData.zone_top?.products && Array.isArray(apiData.zone_top.products)) {
      // For now, take the first product (this might need refinement based on use case)
      productData = apiData.zone_top.products[0];
      console.log('🔍 Using first product from zone_top.products for image extraction');
    }

    // Extract image from the correct structure
    if (productData?.images?.main?.url?.[0]) {
      return productData.images.main.url[0];
    }

    // Try list images if main is not available
    if (productData?.images?.list && Array.isArray(productData.images.list) && productData.images.list.length > 0) {
      const firstImage = productData.images.list[0];
      if (firstImage.url?.[0]) {
        return firstImage.url[0];
      }
    }

    // Fallback to simple image field
    if (productData?.image) {
      return productData.image;
    }

    console.warn('⚠️ Could not extract image from product data:', Object.keys(apiData));
    return null;
  }

  /**
   * Show loading state for specific item
   */
  showItemLoadingState(itemId) {
    const itemElement = document.querySelector(`[data-item-id="${itemId}"]`);
    if (itemElement) {
      itemElement.classList.add('loading');
    }
  }

  /**
   * Hide loading state for specific item
   */
  hideItemLoadingState(itemId) {
    const itemElement = document.querySelector(`[data-item-id="${itemId}"]`);
    if (itemElement) {
      itemElement.classList.remove('loading');
    }
  }

  /**
   * Notify content script of Smart Cart updates (optional - won't fail if no content script)
   */
  async notifyContentScriptOptional(action, data) {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        await chrome.tabs.sendMessage(tabs[0].id, { action, ...data });
        console.log(`📡 Notified content script: ${action}`);
      }
    } catch (error) {
      // Silent fail - content script may not be available on non-Digikala tabs
      console.log(`📡 Content script notification skipped (${action}):`, error.message);
    }
  }

  /**
   * Render Smart Cart data
   */
  renderSmartCartData(cartItems) {
    console.log('🔄 UI DISPLAY - renderSmartCartData called with', cartItems.length, 'items');
    const container = document.getElementById('current-cart-items');
    console.log('🔍 current-cart-items container:', container);

    if (!container) {
      console.error('❌ Smart Cart container not found');
      return;
    }

    // Always clear existing content first (including static HTML)
    container.innerHTML = '';

    console.log('📋 UI DISPLAY - Detailed cart items being rendered:');
    cartItems.forEach((item, index) => {
      console.log(`  Item ${index + 1}:`, {
        id: item.id,
        productId: item.pId || item.productId,
        title: item._c?.t || item.productTitle || 'Unknown',
        price: item.price || 0,
        quantity: item.qty || item.quantity || 1,
        variantId: item.vId || item.variantId,
        selectedSeller: item.selectedSeller,
        hasApiData: !!(item.price && (item._c?.t || item.productTitle)),
        cacheStatus: item._c ? {
          title: item._c.t,
          lastFetched: item._c.lf ? new Date(item._c.lf).toLocaleTimeString() : 'Never',
          needsRefresh: item._c.nr
        } : 'No cache data',
        sellers: item.sellers ? `${item.sellers.length} sellers` : 'No sellers data',
        addedAt: item.at ? new Date(item.at).toLocaleString() : 'Unknown',
        updatedAt: item.ut ? new Date(item.ut).toLocaleString() : 'Unknown'
      });
    });

    if (cartItems.length === 0) {
      console.log('📭 No items, showing empty state');
      container.innerHTML = `
        <div class="empty-state" style="
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 40px 20px;
          text-align: center;
          background: #f8fafc;
          border: 2px dashed #d1d5db;
          border-radius: 8px;
          margin: 20px 0;
        ">
          <div class="empty-icon" style="font-size: 48px; margin-bottom: 16px;">🛒</div>
          <h3 style="color: #374151; font-size: 18px; margin-bottom: 8px;">سبد هوشمند خالی است</h3>
          <p style="color: #6b7280; font-size: 14px; max-width: 400px;">برای افزودن محصول به سبد هوشمند، در صفحه محصولات از دکمه "افزودن به سبد هوشمند" استفاده کنید.</p>
        </div>
      `;

      // Also hide the empty cart state element if it exists
      const emptyCartState = document.getElementById('empty-cart-state');
      if (emptyCartState) {
        emptyCartState.style.display = 'none';
      }

      return;
    }

    // Render cart items
    console.log('🎨 Rendering cart items...');
    const renderedHTML = cartItems.map(item => this.renderSmartCartItem(item)).join('');
    console.log('🎨 Generated HTML length:', renderedHTML.length);

    container.innerHTML = renderedHTML;
    console.log('✅ Smart Cart items rendered to fullpage container');

    // Hide the static empty cart state element if it exists
    const emptyCartState = document.getElementById('empty-cart-state');
    if (emptyCartState) {
      emptyCartState.style.display = 'none';
    }

    // Add event listeners for cart item actions
    this.setupSmartCartItemEventListeners();
  }

  /**
   * Render individual Smart Cart item with enhanced management features
   */
  renderSmartCartItem(item) {
    // Validate and sanitize item data
    if (!item || typeof item !== 'object') {
      console.error('❌ Invalid cart item for rendering:', item);
      return '';
    }

    // Ensure required fields have safe defaults
    item.quantity = item.quantity || item.qty || 1;
    item.id = item.id || Math.random().toString(36).substr(2, 9);
    item.productId = item.productId || item.pId || '';
    item.productTitle = item.productTitle || item._c?.t || 'محصول نامشخص';

    // Ensure productUrl is properly resolved from multiple possible sources
    item.productUrl = item.productUrl ||
      item._c?.u ||
      item._cached?.productUrl ||
      `https://www.digikala.com/product/${item.productId.startsWith('dkp-') ? item.productId : 'dkp-' + item.productId}/`;

    const displayPrice = this.getDisplayedPrice(item);
    const itemPrice = this.formatPrice(displayPrice);
    const totalPrice = this.formatPrice(displayPrice * item.quantity);
    const addedDate = (item.addedAt || item.at) ? new Date(item.addedAt || item.at).toLocaleDateString('fa-IR') : 'نامشخص';
    const variantText = this.getVariantDisplayText(item.variantDetails);

    // Update item.price to reflect the current displayed price for consistency
    item.price = displayPrice;

    // Generate seller options (placeholder for now - will be enhanced with real seller data)
    const sellerOptions = this.generateSellerOptions(item);

    // Generate variation options based on available variants
    const variationOptions = this.generateVariationOptions(item);

    return `
      <div class="cart-item enhanced-cart-item" data-product-id="${item.productId || ''}" data-item-id="${item.id || ''}">
        <div class="cart-item-content">
          <!-- Product Image and Basic Info -->
          <div class="cart-item-header">
            <div class="cart-item-image-container">
              ${item.productImage ?
        `<img src="${item.productImage}" alt="${item.productTitle}" class="cart-item-image">` :
        `<div class="cart-item-image-placeholder">📦</div>`
      }
            </div>
            <div class="cart-item-basic-info">
              <h4 class="cart-item-name">
                <a href="${item.productUrl}" target="_blank" rel="noopener noreferrer">
                  ${item.productTitle}
                </a>
              </h4>
              <div class="cart-item-metadata">
                <span class="unit-price">قیمت واحد: ${itemPrice}</span>
                <span class="added-date">افزودن: ${addedDate}</span>
              </div>
            </div>
          </div>

          <!-- Enhanced Management Controls -->
          <div class="cart-item-management">

            <!-- Quantity Control -->
            <div class="quantity-control-section">
              <label class="control-label">تعداد:</label>
              <div class="quantity-controls">
                <button class="quantity-btn quantity-decrease" data-item-id="${item.id || ''}" data-action="decrease" ${(item.quantity || 1) <= 1 ? 'disabled' : ''}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                  </svg>
                </button>
                <input type="number" class="quantity-input"
                       value="${item.quantity || 1}"
                       min="1"
                       max="20"
                       data-item-id="${item.id || ''}"
                       data-action="quantity-change">
                <button class="quantity-btn quantity-increase" data-item-id="${item.id || ''}" data-action="increase">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                  </svg>
                </button>
              </div>
            </div>

            <!-- Seller Selection -->
            <div class="seller-selection-section">
              <label class="control-label">فروشنده:</label>
              <select class="seller-select" data-item-id="${item.id || ''}" data-action="seller-change">
                ${sellerOptions}
              </select>
            </div>

            <!-- Variation Selection -->
            ${variationOptions ? `
              <div class="variation-selection-section">
                <label class="control-label">گزینه‌ها:</label>
                <div class="variation-controls">
                  ${variationOptions}
                </div>
              </div>
            ` : ''}

          </div>

          <!-- Price and Actions -->
          <div class="cart-item-footer">
            <div class="price-info">
              <div class="total-price">
                <span class="price-label">مجموع:</span>
                <span class="price-value" data-item-id="${item.id || ''}">${totalPrice}</span>
              </div>
              ${item.originalPrice && item.originalPrice !== item.price ?
        `<div class="discount-info">
                  <span class="original-price">${this.formatPrice(item.originalPrice * item.quantity)}</span>
                  <span class="discount-badge">تخفیف</span>
                </div>` : ''
      }
            </div>

            <div class="item-actions">
              <button class="btn-secondary refresh-item-btn" data-item-id="${item.id || ''}" data-action="refresh" title="بروزرسانی قیمت">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M3 3v5h5"></path>
                  <path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"></path>
                </svg>
              </button>
              <button class="btn-danger remove-cart-item" data-item-id="${item.id || ''}" data-action="remove" title="حذف از سبد">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="3,6 5,6 21,6"></polyline>
                  <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"></path>
                  <line x1="10" y1="11" x2="10" y2="17"></line>
                  <line x1="14" y1="11" x2="14" y2="17"></line>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Generate seller options for dropdown
   * Smart Cart is an optimization tool - seller dropdown is a filter, not a requirement
   */
  generateSellerOptions(item) {
    if (!item || typeof item !== 'object') {
      return '<option value="all">همه فروشندگان</option>';
    }

    const currentSeller = item.selectedSeller || 'all';
    const sellers = this.getAvailableSellersForVariant(item) || [];

    // ALWAYS include "All Sellers" as the default option - this is an optimization tool
    let options = `<option value="all" ${currentSeller === 'all' ? 'selected' : ''}>همه فروشندگان (بهینه‌سازی)</option>`;

    // Add real seller data if available
    if (sellers.length > 0) {
      sellers.forEach(seller => {
        const isSelected = currentSeller === seller.id ? 'selected' : '';
        const priceText = seller.price ? ` - ${this.formatPrice(seller.price)}` : '';
        const shippingIcon = seller.shipsDirectly ? ' 📦' : '';

        options += `<option value="${seller.id || 'unknown'}" ${isSelected}>${seller.name || 'نام ناشناس'}${priceText}${shippingIcon}</option>`;
      });
    } else {
      // Fallback to default sellers if no real data
      options += `
        <option value="digikala" ${currentSeller === 'digikala' ? 'selected' : ''}>دیجی‌کالا</option>
        <option value="fresh" ${currentSeller === 'fresh' ? 'selected' : ''}>دیجی‌کالا فرش</option>
        <option value="marketplace" ${currentSeller === 'marketplace' ? 'selected' : ''}>سایر فروشندگان</option>
      `;
    }

    return options;
  }

  /**
   * Get available sellers for the selected variant
   */
  getAvailableSellersForVariant(item) {
    const allSellers = item.sellers || [];

    // If no variant is selected or "all variants" is selected, return all sellers
    if (!item.variantId || item.variantId === 'all_best_price') {
      console.log(`📊 No specific variant selected for ${item.productTitle}, showing all ${allSellers.length} sellers`);
      return this.deduplicateSellers(allSellers);
    }

    // If we have variant-seller mapping data, filter sellers based on the selected variant
    if (item.variantSellerMap && item.variantSellerMap[item.variantId]) {
      const variantSellerIds = item.variantSellerMap[item.variantId];
      const filteredSellers = allSellers.filter(seller => variantSellerIds.includes(seller.id));
      console.log(`📊 Filtered sellers for variant ${item.variantId}: ${filteredSellers.length}/${allSellers.length} sellers`);
      return this.deduplicateSellers(filteredSellers);
    }

    // If we have variations data with seller information, extract sellers for the selected variant
    if (item.variations && item.variations.length > 0) {
      const selectedVariation = item.variations.find(v => v.id === item.variantId);
      if (selectedVariation && selectedVariation.sellers) {
        console.log(`📊 Found sellers in variation data for variant ${item.variantId}: ${selectedVariation.sellers.length} sellers`);
        return this.deduplicateSellers(selectedVariation.sellers);
      }
    }

    // Fallback: if the variant structure doesn't have seller mapping, return all sellers
    // This maintains backward compatibility
    console.log(`📊 No variant-seller mapping found for ${item.variantId}, returning all ${allSellers.length} sellers`);
    return this.deduplicateSellers(allSellers);
  }

  /**
   * Remove duplicate sellers based on seller ID
   */
  deduplicateSellers(sellers) {
    if (!sellers || sellers.length === 0) return [];

    const uniqueSellerMap = new Map();

    sellers.forEach(seller => {
      if (!uniqueSellerMap.has(seller.id)) {
        uniqueSellerMap.set(seller.id, seller);
      } else {
        // If duplicate found, keep the one with more complete data (e.g., has price)
        const existing = uniqueSellerMap.get(seller.id);
        if (seller.price && !existing.price) {
          uniqueSellerMap.set(seller.id, seller);
        }
      }
    });

    const uniqueSellers = Array.from(uniqueSellerMap.values());
    console.log(`🔄 Deduplicated sellers: ${sellers.length} → ${uniqueSellers.length}`);
    return uniqueSellers;
  }

  /**
   * Get the displayed price based on optimization tool logic:
   * Smart Cart is an optimization tool - price reflects best option within user's filters
   * 1. Default (no filters): Lowest price across all variants and sellers
   * 2. Variant filter: Lowest price for that variant across all sellers
   * 3. Variant + specific seller filter: Exact price for that combination
   */
  getDisplayedPrice(item) {
    const selectedVariant = item.variantId;
    const selectedSeller = item.selectedSeller;

    // Case 3: Specific variant + specific seller selected (most restrictive filter)
    if (selectedVariant && selectedVariant !== 'all_best_price' && selectedSeller && selectedSeller !== 'all') {
      const availableSellers = this.getAvailableSellersForVariant(item);
      const sellerData = availableSellers.find(seller => seller.id === selectedSeller);
      if (sellerData && sellerData.price) {
        console.log(`💰 Filtered price (variant + seller): ${this.formatPrice(sellerData.price)}`);
        return sellerData.price;
      }
    }

    // Case 2: Variant selected, but "All Sellers" chosen (variant filter only)
    if (selectedVariant && selectedVariant !== 'all_best_price' && (!selectedSeller || selectedSeller === 'all')) {
      const availableSellers = this.getAvailableSellersForVariant(item);
      if (availableSellers.length > 0) {
        const lowestPrice = Math.min(...availableSellers.map(seller => seller.price || Infinity).filter(p => p !== Infinity));
        if (lowestPrice !== Infinity) {
          console.log(`💰 Optimized price for variant ${selectedVariant}: ${this.formatPrice(lowestPrice)}`);
          return lowestPrice;
        }
      }

      // Check if we have variation price data
      if (item.variations && item.variations.length > 0) {
        const selectedVariation = item.variations.find(v => v.id === selectedVariant);
        if (selectedVariation && selectedVariation.price?.selling_price) {
          console.log(`💰 Variant price from API: ${this.formatPrice(selectedVariation.price.selling_price)}`);
          return selectedVariation.price.selling_price;
        }
      }
    }

    // Case 1: Default optimization (no filters applied) - Find absolute best price
    const allSellers = item.sellers || [];
    if (allSellers.length > 0) {
      const lowestPrice = Math.min(...allSellers.map(seller => seller.price || Infinity).filter(p => p !== Infinity));
      if (lowestPrice !== Infinity) {
        console.log(`💰 Fully optimized price (no filters): ${this.formatPrice(lowestPrice)}`);
        return lowestPrice;
      }
    }

    // Check all variations for the lowest price when no seller data
    if (item.variations && item.variations.length > 0) {
      const variationPrices = item.variations
        .map(v => v.price?.selling_price)
        .filter(p => p && p > 0);

      if (variationPrices.length > 0) {
        const lowestVariationPrice = Math.min(...variationPrices);
        console.log(`💰 Optimized variation price: ${this.formatPrice(lowestVariationPrice)}`);
        return lowestVariationPrice;
      }
    }

    // Fallback to item.price if available
    if (item.price && item.price > 0) {
      console.log(`💰 Fallback: Using item.price: ${this.formatPrice(item.price)}`);
      return item.price;
    }

    console.log('💰 No valid price found, returning 0');
    return 0;
  }

  /**
   * Reset seller to "All Sellers" when variant changes - this ensures optimization tool behavior
   */
  resetSellerToOptimizationMode(item) {
    const oldSeller = item.selectedSeller;
    item.selectedSeller = 'all';
    console.log(`🔄 Variant changed: Reset seller from "${oldSeller}" to "All Sellers" for optimization`);
  }

  /**
   * Reset seller selection if current seller is not available for the selected variant
   */
  resetSellerIfNotAvailable(item) {
    const currentSeller = item.selectedSeller;

    // If no seller is selected or "all" is selected, no need to reset
    if (!currentSeller || currentSeller === 'all') {
      return;
    }

    const availableSellers = this.getAvailableSellersForVariant(item);
    const isSellerAvailable = availableSellers.some(seller => seller.id === currentSeller);

    if (!isSellerAvailable) {
      console.log(`🔄 Seller "${currentSeller}" not available for variant "${item.variantId}", resetting to optimization mode`);

      // Always reset to "All Sellers" - this is an optimization tool, not a checkout system
      item.selectedSeller = 'all';
      console.log('🎯 Reset to "All Sellers" for optimization within the selected variant filter');
    }
  }

  /**
   * Remove duplicate variations based on variation ID
   */
  deduplicateVariations(variations) {
    if (!variations || variations.length === 0) return [];

    const uniqueVariationMap = new Map();

    variations.forEach(variation => {
      if (!uniqueVariationMap.has(variation.id)) {
        uniqueVariationMap.set(variation.id, variation);
      } else {
        // If duplicate found, keep the one with more complete data (e.g., has price)
        const existing = uniqueVariationMap.get(variation.id);
        if (variation.price?.selling_price && !existing.price?.selling_price) {
          uniqueVariationMap.set(variation.id, variation);
        }
      }
    });

    const uniqueVariations = Array.from(uniqueVariationMap.values());
    console.log(`🔄 Deduplicated variations: ${variations.length} → ${uniqueVariations.length}`);
    return uniqueVariations;
  }

  /**
   * Generate variation options for product
   */
  generateVariationOptions(item) {
    // Validate item
    if (!item || typeof item !== 'object') {
      return null;
    }

    console.log(`🔍 DEBUG - generateVariationOptions for item:`, {
      itemId: item.id,
      hasVariantData: !!item.variantData,
      hasVariations: !!item.variations,
      hasVariantDetails: !!item.variantDetails,
      currentVariantId: item.variantId || item.vId,
      rawVariationsLength: item.variations?.length || 0
    });

    // Get variant options from UI layer (optimization result) if available
    const productId = item.pId || item.productId;
    let uiVariants = null;

    if (productId && this.lastOptimizationResult?.uiOptions?.[productId]) {
      uiVariants = this.lastOptimizationResult.uiOptions[productId];
      console.log(`✅ DEBUG - Using UI layer variants for product ${productId}:`, Object.keys(uiVariants));
    }

    // Fallback to raw API data if UI layer not available
    if (!uiVariants) {
      const hasVariations = item.variantData || item.variations || item.variantDetails;
      if (!hasVariations) {
        console.log(`⚠️ DEBUG - No variation data available for item ${item.id}`);
        return null;
      }

      // Get available variations from API data and deduplicate by characteristics
      const rawVariations = item.variations || (item.variantData ? [item.variantData] : []);
      const variations = this.deduplicateVariationsByCharacteristics(rawVariations);

      // If we only have single variation data, don't show dropdown
      if (variations.length <= 1 && !item.variantDetails) {
        console.log(`⚠️ DEBUG - Only ${variations.length} unique variations found, not showing dropdown`);
        return null;
      }

      // Convert to UI variants format for consistent processing
      uiVariants = {};
      variations.forEach(variation => {
        uiVariants[variation.id] = {
          variantInfo: {
            id: variation.id,
            color: variation.color,
            size: variation.size,
            warranty: variation.warranty,
            displayName: this.formatVariationTitle(variation)
          },
          sellers: {} // Will be populated separately
        };
      });
    }

    // Check if we have enough variants to show dropdown
    const variantCount = Object.keys(uiVariants).length;
    if (variantCount <= 1) {
      console.log(`⚠️ DEBUG - Only ${variantCount} unique variants, not showing dropdown`);
      return null;
    }

    const currentVariationId = item.variantId || item.vId || item.variantData?.id;

    // Build comprehensive variation selector
    let variationHtml = `
      <div class="variation-group">
        <label class="variation-label">تنوع:</label>
        <select class="variation-select" data-item-id="${item.id || ''}" data-action="variation-change" data-variation="variation">
          <option value="all_best_price" ${!currentVariationId || item.optimizeForBestPrice ? 'selected' : ''}>
            همه تنوع‌ها (بهترین قیمت)
          </option>
    `;

    // Add actual variations (NO PRICE - variants should be unique by characteristics)
    Object.entries(uiVariants).forEach(([variantId, variantData]) => {
      const isSelected = currentVariationId === variantId;
      const title = variantData.variantInfo.displayName || this.formatVariationTitleFromInfo(variantData.variantInfo);

      variationHtml += `
        <option value="${variantId}" ${isSelected ? 'selected' : ''}>
          ${title}
        </option>
      `;
    });

    variationHtml += `
        </select>
      </div>
    `;

    console.log(`✅ DEBUG - Generated variation options with ${variantCount} unique variants (no price concatenation)`);
    return variationHtml;
  }

  /**
   * Deduplicate variations by their characteristics, not just ID
   */
  deduplicateVariationsByCharacteristics(variations) {
    if (!variations || variations.length === 0) return [];

    const uniqueVariationMap = new Map();

    variations.forEach(variation => {
      // Create a unique key based on variant characteristics, not ID
      const characteristicsKey = this.getVariantCharacteristicsKey(variation);

      if (!uniqueVariationMap.has(characteristicsKey)) {
        uniqueVariationMap.set(characteristicsKey, variation);
      } else {
        // If duplicate found by characteristics, keep the one with more complete data
        const existing = uniqueVariationMap.get(characteristicsKey);
        if (!existing.id && variation.id) {
          uniqueVariationMap.set(characteristicsKey, variation);
        }
      }
    });

    const uniqueVariations = Array.from(uniqueVariationMap.values());
    console.log(`🔄 Deduplicated variations by characteristics: ${variations.length} → ${uniqueVariations.length}`);
    return uniqueVariations;
  }

  /**
   * Get unique key for variant based on its characteristics
   */
  getVariantCharacteristicsKey(variation) {
    const parts = [];

    if (variation.color?.title || variation.color?.name) {
      parts.push(`color:${variation.color.title || variation.color.name}`);
    }

    if (variation.size?.title || variation.size?.name) {
      parts.push(`size:${variation.size.title || variation.size.name}`);
    }

    if (variation.warranty?.title_fa || variation.warranty?.title) {
      parts.push(`warranty:${variation.warranty.title_fa || variation.warranty.title}`);
    }

    if (variation.themes && variation.themes.length > 0) {
      const themeNames = variation.themes.map(theme => theme.title).join(',');
      parts.push(`themes:${themeNames}`);
    }

    // If no characteristics found, use ID or a default
    if (parts.length === 0) {
      return variation.id || 'default';
    }

    return parts.join('|');
  }

  /**
   * Format variation title from variant info structure
   */
  formatVariationTitleFromInfo(variantInfo) {
    const parts = [];

    if (variantInfo.color?.title || variantInfo.color?.name) {
      parts.push(variantInfo.color.title || variantInfo.color.name);
    }

    if (variantInfo.size?.title || variantInfo.size?.name) {
      parts.push(variantInfo.size.title || variantInfo.size.name);
    }

    if (variantInfo.warranty?.title_fa || variantInfo.warranty?.title) {
      parts.push(variantInfo.warranty.title_fa || variantInfo.warranty.title);
    }

    if (variantInfo.displayName && parts.length === 0) {
      return variantInfo.displayName;
    }

    return parts.length > 0 ? parts.join(' - ') : 'پیش‌فرض';
  }

  /**
   * Format variation title from API data
   */
  formatVariationTitle(variation) {
    const parts = [];

    if (variation.color) {
      parts.push(variation.color.title || variation.color.name);
    }

    if (variation.size) {
      parts.push(variation.size.title || variation.size.name);
    }

    if (variation.warranty) {
      parts.push(variation.warranty.title_fa || variation.warranty.title);
    }

    if (variation.themes && variation.themes.length > 0) {
      variation.themes.forEach(theme => {
        parts.push(theme.title);
      });
    }

    return parts.length > 0 ? parts.join(' - ') : `گزینه ${variation.id}`;
  }

  /**
   * Get variant display text
   */
  getVariantDisplayText(variantDetails) {
    if (!variantDetails) return null;

    const parts = [];
    if (variantDetails.color) parts.push(`رنگ: ${variantDetails.color.title}`);
    if (variantDetails.size) parts.push(`سایز: ${variantDetails.size.title}`);
    if (variantDetails.warranty) parts.push(`گارانتی: ${variantDetails.warranty.title}`);
    if (variantDetails.themes) {
      variantDetails.themes.forEach(theme => parts.push(theme.title));
    }

    return parts.length > 0 ? parts.join(' | ') : null;
  }

  /**
   * Update Smart Cart summary
   */
  updateSmartCartSummary(cartItems) {
    const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
    const totalValue = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    // Update summary elements
    const itemsCountEl = document.getElementById('cart-items-count');
    const totalValueEl = document.getElementById('cart-total-value');

    if (itemsCountEl) {
      itemsCountEl.textContent = `${totalItems} محصول`;
    }

    if (totalValueEl) {
      totalValueEl.textContent = this.formatPrice(totalValue);
    }
  }

  /**
   * Format price to Persian format
   */
  formatPrice(price) {
    if (!price || price === 0) return '0 تومان';

    // Convert from Rials to Tomans (divide by 10) for display
    const priceInTomans = Math.round(price / 10);
    const formatted = priceInTomans.toLocaleString('fa-IR');
    return `${formatted} تومان`;
  }

  /**
   * Setup event listeners for Smart Cart items with enhanced management features
   */
  setupSmartCartItemEventListeners() {
    const cartContainer = document.getElementById('current-cart-items');
    if (!cartContainer) return;

    // Use event delegation for better performance
    cartContainer.addEventListener('click', async (e) => {
      // Don't interfere with dropdown clicks
      if (e.target.tagName === 'SELECT' || e.target.tagName === 'OPTION') {
        return;
      }

      const target = e.target.closest('[data-action]');
      if (!target) return;

      e.preventDefault();
      const action = target.dataset.action;
      const itemId = target.dataset.itemId;

      if (!itemId) return;

      // Prevent multiple rapid clicks by disabling button during processing
      if (target.disabled) return;
      target.disabled = true;

      console.log(`🎯 Smart Cart action: ${action} for item: ${itemId}`);

      try {
        switch (action) {
          case 'decrease':
            await this.updateQuantity(itemId, -1);
            break;
          case 'increase':
            await this.updateQuantity(itemId, 1);
            break;
          case 'remove':
            await this.removeCartItem(itemId);
            break;
          case 'refresh':
            await this.refreshCartItem(itemId);
            break;
        }
      } catch (error) {
        console.error(`❌ Error handling ${action} action:`, error);
      } finally {
        // Re-enable button after processing
        target.disabled = false;
      }
    });

    // Handle all change events (quantity, seller, variation) in one listener
    cartContainer.addEventListener('change', async (e) => {
      const target = e.target;
      const itemId = target.dataset.itemId;

      if (!itemId) return;

      // Only prevent default for specific input types, not for dropdowns
      if (target.classList.contains('quantity-input')) {
        e.preventDefault();
      }

      // Disable the target element during processing to prevent multiple triggers
      target.disabled = true;

      try {
        if (target.classList.contains('quantity-input')) {
          const newQuantity = parseInt(target.value);
          if (newQuantity > 0) {
            await this.setQuantity(itemId, newQuantity);
          }
        } else if (target.classList.contains('seller-select')) {
          const selectedSeller = target.value;
          console.log(`📦 Seller dropdown changed: ${selectedSeller} for item ${itemId}`);
          await this.changeSeller(itemId, selectedSeller);
        } else if (target.classList.contains('variation-select')) {
          const variation = target.dataset.variation;
          const selectedValue = target.value;
          console.log(`🎨 Variant dropdown changed: ${selectedValue} for item ${itemId}`);
          if (variation) {
            await this.changeVariation(itemId, variation, selectedValue);
          }
        }
      } catch (error) {
        console.error('❌ Error handling change event:', error);
      } finally {
        // Re-enable the target element
        target.disabled = false;
      }
    });

    // Handle quantity input blur (for direct typing)
    cartContainer.addEventListener('blur', async (e) => {
      if (e.target.classList.contains('quantity-input')) {
        const itemId = e.target.dataset.itemId;
        const newQuantity = parseInt(e.target.value);

        if (itemId && newQuantity > 0) {
          await this.setQuantity(itemId, newQuantity);
        }
      }
    }, true);
  }

  /**
   * Remove item from Smart Cart
   */
  async removeCartItem(itemId) {
    try {
      // Find the item being removed for logging
      const removedItem = this.smartCartItems.find(item => item.id === itemId);

      // Remove from local array
      this.smartCartItems = this.smartCartItems.filter(item => item.id !== itemId);

      // Update storage with correct key
      await chrome.storage.local.set({ digikala_extension_smart_cart_items: this.smartCartItems });

      // Refresh display
      this.renderSmartCartData(this.smartCartItems);
      this.updateSmartCartSummary(this.smartCartItems);
      this.updateSidebarBadges({ smartCart: this.smartCartItems.length });

      // Notify content script if available (optional - won't fail on non-Digikala tabs)
      await this.notifyContentScriptOptional('smartCartUpdated', { items: this.smartCartItems });

      console.log(`✅ Removed item ${removedItem?.productTitle || itemId} from Smart Cart`);
      this.showNotification('محصول از سبد هوشمند حذف شد', 'success');

    } catch (error) {
      console.error('Error removing cart item:', error);
      this.showNotification('خطا در حذف محصول از سبد هوشمند', 'error');
    }
  }

  /**
   * Update quantity (relative change)
   */
  async updateQuantity(itemId, change) {
    try {
      const item = this.smartCartItems.find(item => item.id === itemId);
      if (!item) {
        console.error('❌ Item not found:', itemId);
        return;
      }

      const newQuantity = item.quantity + change;
      if (newQuantity <= 0) {
        await this.removeCartItem(itemId);
        return;
      }

      await this.setQuantity(itemId, newQuantity);
    } catch (error) {
      console.error('❌ Error updating quantity:', error);
    }
  }

  /**
   * Set absolute quantity
   */
  async setQuantity(itemId, newQuantity) {
    try {
      const item = this.smartCartItems.find(item => item.id === itemId);
      if (!item) {
        console.error('❌ Item not found:', itemId);
        return;
      }

      const oldQuantity = item.quantity;
      item.quantity = Math.max(1, Math.min(20, newQuantity)); // Clamp between 1-20
      item.updatedAt = Date.now();

      console.log(`📊 Quantity updated: ${oldQuantity} → ${item.quantity} for ${item.productTitle}`);

      // Save to storage
      await this.saveSmartCartData();

      // Update the specific item's display
      await this.updateItemDisplay(itemId);

      // Update summary
      this.updateSmartCartSummary(this.smartCartItems);

    } catch (error) {
      console.error('❌ Error setting quantity:', error);
    }
  }

  /**
   * Change seller selection
   */
  async changeSeller(itemId, selectedSeller) {
    try {
      const item = this.smartCartItems.find(item => item.id === itemId);
      if (!item) {
        console.error('❌ Item not found:', itemId);
        return;
      }

      const oldSeller = item.selectedSeller || 'all';
      item.selectedSeller = selectedSeller;
      item.updatedAt = Date.now();

      console.log(`🏪 Seller changed: ${oldSeller} → ${selectedSeller} for ${item.productTitle}`);

      // Update price using the new 3-step logic
      const newPrice = this.getDisplayedPrice(item);
      item.price = newPrice;
      console.log(`💰 Price updated to: ${this.formatPrice(newPrice)} for seller: ${selectedSeller}`);

      // Set optimization flags for backwards compatibility
      if (selectedSeller === 'all') {
        item.optimizeForBestSeller = true;
        console.log('🎯 Optimizing for best price across all sellers');
      } else {
        item.optimizeForBestSeller = false;
        console.log(`💰 Selecting specific seller: ${selectedSeller}`);
      }

      // Save to storage
      await this.saveSmartCartData();

      // Update the specific item's display
      await this.updateItemDisplay(itemId);

      // Show success notification
      this.showNotification(`فروشنده محصول به‌روزرسانی شد`, 'success');

    } catch (error) {
      console.error('❌ Error changing seller:', error);
    }
  }

  /**
   * Change variation selection
   */
  async changeVariation(itemId, variationType, selectedValue) {
    try {
      const item = this.smartCartItems.find(item => item.id === itemId);
      if (!item) {
        console.error('❌ Item not found:', itemId);
        return;
      }

      if (!item.variantDetails) {
        item.variantDetails = {};
      }

      // Handle the new unified variation selector vs legacy individual types
      if (variationType === 'variation' || !variationType) {
        // This is the new unified variation selector
        if (selectedValue === 'all_best_price') {
          console.log('🎯 Set to optimize for best price across all variations');
          item.variantId = null;
          item.variantDetails = null;
          item.optimizeForBestPrice = true;
        } else {
          // Specific variation selected
          item.variantId = selectedValue;
          item.optimizeForBestPrice = false;

          // Find the selected variation and update variant details
          if (item.variations && item.variations.length > 0) {
            const selectedVariation = item.variations.find(v => v.id === selectedValue);
            if (selectedVariation) {
              // Update variant details
              item.variantDetails = this.extractVariantDetails(selectedVariation);
            }
          }
        }

        console.log(`🎨 Variation changed to: ${selectedValue} for ${item.productTitle}`);

        // Reset seller to "All Sellers" when variant changes - optimization tool behavior
        this.resetSellerToOptimizationMode(item);

        // Update price using the new 3-step logic after variant and seller adjustments
        const newPrice = this.getDisplayedPrice(item);
        item.price = newPrice;
        console.log(`💰 Price updated to: ${this.formatPrice(newPrice)} for variant: ${selectedValue}`);
      } else {
        // Legacy individual variation type handling
        const oldValue = item.variantDetails[variationType]?.title || '';

        item.variantDetails[variationType] = {
          id: selectedValue,
          title: selectedValue
        };

        console.log(`🎨 ${variationType} changed: ${oldValue} → ${selectedValue} for ${item.productTitle}`);

        // Reset seller to "All Sellers" for legacy variation changes too
        this.resetSellerToOptimizationMode(item);

        // Update price using the new 3-step logic
        const newPrice = this.getDisplayedPrice(item);
        item.price = newPrice;
        console.log(`💰 Price updated to: ${this.formatPrice(newPrice)} for legacy variation change`);
      }

      item.updatedAt = Date.now();

      // Save to storage
      await this.saveSmartCartData();

      // Update the specific item's display
      await this.updateItemDisplay(itemId);

      // Show success notification
      this.showNotification(`تنوع محصول به‌روزرسانی شد`, 'success');

    } catch (error) {
      console.error('❌ Error changing variation:', error);
      this.showNotification('خطا در تغییر تنوع محصول', 'error');
    }
  }

  /**
   * Extract variant details from variation object
   */
  extractVariantDetails(variation) {
    const details = {};

    if (variation.color) {
      details.color = {
        id: variation.color.id,
        title: variation.color.title || variation.color.name
      };
    }

    if (variation.size) {
      details.size = {
        id: variation.size.id,
        title: variation.size.title || variation.size.name
      };
    }

    if (variation.warranty) {
      details.warranty = {
        id: variation.warranty.id,
        title: variation.warranty.title_fa || variation.warranty.title
      };
    }

    if (variation.themes && variation.themes.length > 0) {
      details.themes = variation.themes;
    }

    return details;
  }

  /**
   * Refresh a specific cart item's data
   */
  async refreshCartItem(itemId) {
    try {
      const item = this.smartCartItems.find(item => item.id === itemId);
      if (!item) {
        console.error('❌ Item not found:', itemId);
        return;
      }

      console.log(`🔄 Refreshing item data for: ${item.productTitle}`);

      // Show loading state for this item
      const itemElement = document.querySelector(`[data-item-id="${itemId}"]`);
      if (itemElement) {
        itemElement.classList.add('refreshing');
      }

      // TODO: Implement actual API call to refresh price and availability
      // For now, we'll simulate a successful refresh
      await new Promise(resolve => setTimeout(resolve, 1000));

      item.lastRefreshed = Date.now();

      // Remove loading state
      if (itemElement) {
        itemElement.classList.remove('refreshing');
      }

      // Save and update display
      await this.saveSmartCartData();
      await this.updateItemDisplay(itemId);

      console.log(`✅ Item refreshed: ${item.productTitle}`);

    } catch (error) {
      console.error('❌ Error refreshing cart item:', error);

      // Remove loading state on error
      const itemElement = document.querySelector(`[data-item-id="${itemId}"]`);
      if (itemElement) {
        itemElement.classList.remove('refreshing');
      }
    }
  }

  /**
   * Update display for a specific item
   */
  async updateItemDisplay(itemId) {
    const item = this.smartCartItems.find(item => item.id === itemId);
    if (!item) return;

    const itemElement = document.querySelector(`[data-item-id="${itemId}"]`);
    if (!itemElement) return;

    // Update quantity input
    const quantityInput = itemElement.querySelector('.quantity-input');
    if (quantityInput) {
      quantityInput.value = item.quantity;
    }

    // Update quantity buttons
    const decreaseBtn = itemElement.querySelector('.quantity-decrease');
    if (decreaseBtn) {
      decreaseBtn.disabled = item.quantity <= 1;
    }

    // Update price display using the new 3-step logic
    const priceElement = itemElement.querySelector('.price-value');
    if (priceElement) {
      const displayPrice = this.getDisplayedPrice(item);
      item.price = displayPrice; // Keep item.price in sync
      const totalPrice = this.formatPrice(displayPrice * item.quantity);
      priceElement.textContent = totalPrice;
    }

    // Update seller selection
    const sellerSelect = itemElement.querySelector('.seller-select');
    if (sellerSelect && item.selectedSeller) {
      sellerSelect.value = item.selectedSeller;
    }

    console.log(`🎨 Updated display for item: ${itemId}`);
  }

  /**
   * Save Smart Cart data to storage
   */
  async saveSmartCartData() {
    try {
      await chrome.storage.local.set({ digikala_extension_smart_cart_items: this.smartCartItems });
      console.log(`💾 Saved Smart Cart data: ${this.smartCartItems.length} items`);

      // Trigger optimization recalculation
      if (this.smartCartOptimizer) {
        this.smartCartOptimizer.triggerOptimization('data_saved');
      }
    } catch (error) {
      console.error('❌ Error saving Smart Cart data:', error);
      throw error;
    }
  }

  /**
   * Initialize Smart Cart Optimizer
   */
  async initializeSmartCartOptimizer() {
    try {
      // Check if Smart Cart feature is enabled
      const featureCheck = await chrome.storage.sync.get(['smartCartEnabled']);
      const smartCartEnabled = featureCheck.smartCartEnabled || false;

      if (!smartCartEnabled) {
        console.log('🚫 Smart Cart feature disabled - skipping Smart Cart Optimizer initialization');
        this.smartCartOptimizer = null;
        return false;
      }

      console.log('🚀 Initializing Smart Cart Optimizer...');

      // Check if Enhanced Smart Cart Optimizer is available
      if (!window.EnhancedSmartCartOptimizer) {
        console.warn('⚠️ Enhanced Smart Cart Optimizer not available');
        return false;
      }

      // Create a mock Smart Cart Manager interface for fullscreen
      // Ensure smartCartItems is initialized
      if (!this.smartCartItems) {
        this.smartCartItems = [];
      }

      const mockSmartCartManager = {
        cart: this.smartCartItems,
        getCartItems: () => {
          // Always return an array, even if smartCartItems is undefined
          return this.smartCartItems || [];
        },
        eventBus: {
          emit: (event, data) => {
            console.log(`📡 Smart Cart event: ${event}`, data);
            this.handleOptimizerEvent(event, data);
          },
          on: (event, handler) => {
            // Store event handlers for manual triggering
            if (!this.optimizerEventHandlers) {
              this.optimizerEventHandlers = {};
            }
            this.optimizerEventHandlers[event] = handler;
          }
        }
      };

      // Initialize optimizer with mock services
      this.smartCartOptimizer = new window.EnhancedSmartCartOptimizer(
        mockSmartCartManager,
        null, // API service not available in fullscreen
        null  // Cache service not available in fullscreen
      );

      // Initialize the optimizer
      const success = await this.smartCartOptimizer.initialize();

      if (success) {
        console.log('✅ Smart Cart Optimizer initialized successfully');

        // Setup optimization display
        this.setupOptimizationDisplay();

        // Trigger initial optimization if cart has items
        if (this.smartCartItems.length > 0) {
          this.triggerCartOptimization('initial_load');
        }

        return true;
      } else {
        console.warn('⚠️ Smart Cart Optimizer initialization failed');
        return false;
      }

    } catch (error) {
      console.error('❌ Error initializing Smart Cart Optimizer:', error);
      return false;
    }
  }

  /**
   * Handle optimizer events
   */
  handleOptimizerEvent(event, data) {
    switch (event) {
      case 'smart-cart:optimization-started':
        this.isOptimizing = true;
        this.showOptimizationLoading();
        break;

      case 'smart-cart:optimization-completed':
        this.isOptimizing = false;
        this.optimizationResults = data.result;
        this.displayOptimizationResults(data.result);
        break;

      case 'smart-cart:optimization-error':
        this.isOptimizing = false;
        this.hideOptimizationLoading();
        console.error('❌ Optimization error:', data.error);
        break;
    }
  }

  /**
   * Setup optimization display UI
   */
  setupOptimizationDisplay() {
    console.log('🎨 Setting up optimization display UI');

    // Find or create optimization results container
    let optimizationContainer = document.querySelector('.optimization-results-container');
    if (!optimizationContainer) {
      optimizationContainer = document.createElement('div');
      optimizationContainer.className = 'optimization-results-container';
      optimizationContainer.innerHTML = `
        <div class="optimization-section">
          <div class="optimization-header">
            <h3>🧮 Cart Optimization Results</h3>
            <div class="optimization-loading" style="display: none;">
              <div class="loading-spinner"></div>
              <span>Calculating optimal cart...</span>
            </div>
          </div>
          <div class="optimization-content">
            <div class="optimization-summary"></div>
            <div class="optimization-recommendations"></div>
            <div class="optimization-details"></div>
          </div>
        </div>
      `;

      // Insert after Smart Cart header
      const smartCartSection = document.querySelector('.smart-cart-section');
      if (smartCartSection) {
        smartCartSection.appendChild(optimizationContainer);
      } else {
        // Fallback: insert in main content
        const mainContent = document.querySelector('.main-content');
        if (mainContent) {
          mainContent.appendChild(optimizationContainer);
        }
      }
    }

    this.optimizationContainer = optimizationContainer;
    console.log('✅ Optimization display UI setup complete');
  }

  /**
   * Display optimization results
   */
  displayOptimizationResults(result) {
    console.log('📊 UI DISPLAY - Displaying optimization results:', result);

    console.log('📋 UI DISPLAY - Complete optimization result structure:');
    console.log('  Success:', result?.success);
    console.log('  Timestamp:', result?.timestamp ? new Date(result.timestamp).toLocaleString() : 'N/A');
    console.log('  Cart Items Count:', result?.cartItems);

    if (result?.currentCart) {
      console.log('  Current Cart Data:', {
        itemsCount: result.currentCart.items?.length || 0,
        totalItems: result.currentCart.totals?.totalItems || 0,
        totalValue: result.currentCart.totals?.totalValue || 0,
        totalSavings: result.currentCart.totals?.totalSavings || 0,
        sellers: result.currentCart.sellers || []
      });
    }

    if (result?.optimization) {
      console.log('  Optimization Results:', {
        success: result.optimization.success,
        totalCost: result.optimization.totalCost,
        totalSavings: result.optimization.totalSavings,
        sellersUsed: result.optimization.sellersUsed,
        assignmentsCount: result.optimization.assignments?.length || 0
      });

      if (result.optimization.assignments?.length > 0) {
        console.log('  Algorithm Assignments for UI:');
        result.optimization.assignments.forEach((assignment, index) => {
          console.log(`    ${index + 1}. Product ${assignment.productId}:`, {
            sellerId: assignment.sellerId,
            price: assignment.price, // Correct field from algorithm
            variantId: assignment.variantId || 'N/A',
            // Derived fields for compatibility
            unitPrice: assignment.price || 0,
            quantity: 1, // Default quantity
            totalPrice: assignment.price || 0
          });
        });
      }
    }

    if (result?.uiOptions) {
      console.log('  UI Options Available:', Object.keys(result.uiOptions).length, 'products');
      Object.entries(result.uiOptions).forEach(([productId, variants]) => {
        const variantCount = Object.keys(variants).length;
        const totalSellers = Object.values(variants).reduce((sum, variant) => sum + Object.keys(variant.sellers).length, 0);
        console.log(`    Product ${productId}: ${variantCount} variants, ${totalSellers} seller options for UI`);
      });
    }

    if (result?.summary) {
      console.log('  Summary for UI Display:', {
        totalItems: result.summary.totalItems,
        totalValue: result.summary.totalValue,
        optimizationSavings: result.summary.optimizationSavings,
        bestSellers: result.summary.bestSellers,
        calculationTime: result.summary.calculationTime
      });
    }

    if (!this.optimizationContainer) {
      console.warn('⚠️ Optimization container not found, setting up...');
      this.setupOptimizationDisplay();
    }

    this.hideOptimizationLoading();

    // Comprehensive result validation
    if (!result) {
      console.error('❌ No optimization result provided');
      this.displayOptimizationError('No optimization result received');
      return;
    }

    if (!result.success) {
      console.error('❌ Optimization failed:', result.error);
      this.displayOptimizationError(result?.error || 'Optimization failed');
      return;
    }

    // Validate result structure
    if (!this.validateOptimizationResult(result)) {
      console.error('❌ Invalid optimization result structure:', result);
      this.displayOptimizationError('Invalid optimization result structure');
      return;
    }

    const summaryContainer = this.optimizationContainer.querySelector('.optimization-summary');
    const recommendationsContainer = this.optimizationContainer.querySelector('.optimization-recommendations');
    const detailsContainer = this.optimizationContainer.querySelector('.optimization-details');

    // Display optimization summary with error handling
    if (summaryContainer) {
      try {
        summaryContainer.innerHTML = this.generateOptimizationSummary(result);
      } catch (error) {
        console.error('❌ Error generating optimization summary:', error);
        summaryContainer.innerHTML = '<div class="generation-error">Error displaying optimization summary</div>';
      }
    }

    // Display recommendations with error handling
    if (recommendationsContainer) {
      try {
        recommendationsContainer.innerHTML = this.generateOptimizationRecommendations(result);
      } catch (error) {
        console.error('❌ Error generating optimization recommendations:', error);
        recommendationsContainer.innerHTML = '<div class="generation-error">Error displaying recommendations</div>';
      }
    }

    // Display detailed breakdown with error handling
    if (detailsContainer) {
      try {
        detailsContainer.innerHTML = this.generateOptimizationDetails(result);
      } catch (error) {
        console.error('❌ Error generating optimization details:', error);
        detailsContainer.innerHTML = '<div class="generation-error">Error displaying optimization details</div>';
      }
    }

    // Show the optimization results
    this.optimizationContainer.style.display = 'block';
    console.log('✅ Optimization results displayed');
  }

  /**
   * Display multi-mode optimization results
   */
  displayMultiModeOptimizationResults(results) {
    console.log('📊 Displaying multi-mode optimization results:', results);

    // Update the three optimization sections
    this.updateLowestCostSection(results.COST);
    this.updateFewestShipmentsSection(results.SELLERS_FIRST);
    this.updateCustomShipmentsSection(results.MAX_SELLERS);

    // Also display the general optimization results for backwards compatibility
    if (results.COST && results.COST.success) {
      this.displayOptimizationResults(results.COST);
    }
  }

  /**
   * Update the "کمترین هزینه کل" section
   */
  updateLowestCostSection(result) {
    const costValueEl = document.getElementById('lowest-total-cost');
    const shipmentsValueEl = document.getElementById('lowest-shipments');
    const productsContainer = document.getElementById('lowest-cost-products');

    if (!result || !result.success) {
      if (costValueEl) costValueEl.textContent = 'خطا در محاسبه';
      if (shipmentsValueEl) shipmentsValueEl.textContent = 'خطا';
      if (productsContainer) {
        productsContainer.innerHTML = `
          <div class="empty-state">
            <p>خطا در محاسبه کمترین هزینه</p>
          </div>
        `;
      }
      return;
    }

    // Update cost display
    if (costValueEl && result.optimization) {
      costValueEl.textContent = this.formatPrice(result.optimization.totalCost);
    }

    // Update shipments count
    if (shipmentsValueEl && result.optimization) {
      const sellersCount = result.optimization.sellersUsed ? result.optimization.sellersUsed.length : 0;
      shipmentsValueEl.textContent = `${sellersCount} مرسوله`;
    }

    // Update products list
    if (productsContainer && result.optimization && result.optimization.assignments) {
      productsContainer.innerHTML = this.generateOptimizationProductsList(result.optimization.assignments, result.currentCart.items);
    }
  }

  /**
   * Update the "کمترین تعداد مرسوله" section
   */
  updateFewestShipmentsSection(result) {
    const costValueEl = document.getElementById('fewest-total-cost');
    const shipmentsValueEl = document.getElementById('fewest-shipments');
    const productsContainer = document.getElementById('fewest-shipments-products');

    if (!result || !result.success) {
      if (costValueEl) costValueEl.textContent = 'خطا در محاسبه';
      if (shipmentsValueEl) shipmentsValueEl.textContent = 'خطا';
      if (productsContainer) {
        productsContainer.innerHTML = `
          <div class="empty-state">
            <p>خطا در محاسبه کمترین مرسوله</p>
          </div>
        `;
      }
      return;
    }

    // Update cost display
    if (costValueEl && result.optimization) {
      costValueEl.textContent = this.formatPrice(result.optimization.totalCost);
    }

    // Update shipments count
    if (shipmentsValueEl && result.optimization) {
      const sellersCount = result.optimization.sellersUsed ? result.optimization.sellersUsed.length : 0;
      shipmentsValueEl.textContent = `${sellersCount} مرسوله`;
    }

    // Update products list
    if (productsContainer && result.optimization && result.optimization.assignments) {
      productsContainer.innerHTML = this.generateOptimizationProductsList(result.optimization.assignments, result.currentCart.items);
    }
  }

  /**
   * Update the "تعداد مرسوله دلخواه" section
   */
  updateCustomShipmentsSection(result) {
    const costValueEl = document.getElementById('custom-total-cost');
    const shipmentsValueEl = document.getElementById('custom-shipments');
    const productsContainer = document.getElementById('custom-shipments-products');

    if (!result || !result.success) {
      if (costValueEl) costValueEl.textContent = 'خطا در محاسبه';
      if (shipmentsValueEl) shipmentsValueEl.textContent = 'خطا';
      if (productsContainer) {
        productsContainer.innerHTML = `
          <div class="empty-state">
            <p>خطا در محاسبه تعداد مرسوله دلخواه</p>
          </div>
        `;
      }
      return;
    }

    // Update cost display
    if (costValueEl && result.optimization) {
      costValueEl.textContent = this.formatPrice(result.optimization.totalCost);
    }

    // Update shipments count
    if (shipmentsValueEl && result.optimization) {
      const sellersCount = result.optimization.sellersUsed ? result.optimization.sellersUsed.length : 0;
      shipmentsValueEl.textContent = `${sellersCount} مرسوله`;
    }

    // Update products list
    if (productsContainer && result.optimization && result.optimization.assignments) {
      productsContainer.innerHTML = this.generateOptimizationProductsList(result.optimization.assignments, result.currentCart.items);
    }
  }

  /**
   * Generate products list HTML for optimization results
   */
  generateOptimizationProductsList(assignments, cartItems) {
    if (!assignments || assignments.length === 0) {
      return `
        <div class="empty-state">
          <p>هیچ محصولی برای نمایش وجود ندارد</p>
        </div>
      `;
    }

    const assignmentMap = new Map();
    assignments.forEach(assignment => {
      assignmentMap.set(assignment.productId, assignment);
    });

    const productsHTML = cartItems.map(item => {
      const assignment = assignmentMap.get(item.pId || item.productId);
      if (!assignment) return '';

      const productTitle = item.productTitle || item._c?.t || 'محصول نامشخص';
      const sellerName = assignment.sellerName || assignment.sellerId || 'فروشنده نامشخص';
      const price = assignment.price || item.price || 0;
      const quantity = item.qty || item.quantity || 1;
      const totalPrice = price * quantity;

      return `
        <div class="product-item">
          <div class="product-info">
            <img
              src="${item.productImage || this.getPlaceholderImage()}"
              alt="${productTitle}"
              class="product-image"
              onerror="this.src=this.getPlaceholderImage()"
            >
            <div class="product-details">
              <h4>${productTitle}</h4>
              <p class="product-category">تعداد: ${quantity}</p>
            </div>
          </div>
          <div class="seller-selection">
            <div class="selected-seller">
              <div class="seller-info">
                <span class="seller-name">${sellerName}</span>
                <div class="seller-rating">
                  <span class="rating-value">${assignment.rating || '4.0'}</span>
                  <span class="rating-stars">⭐</span>
                </div>
              </div>
              <div class="seller-price">
                <span class="price-value">${this.formatPrice(totalPrice)}</span>
              </div>
            </div>
          </div>
        </div>
      `;
    }).filter(Boolean).join('');

    return productsHTML || `
      <div class="empty-state">
        <p>هیچ محصولی برای نمایش وجود ندارد</p>
      </div>
    `;
  }

  /**
   * Generate optimization summary HTML
   */
  generateOptimizationSummary(result) {
    const { optimization } = result;

    // Handle both currentCart and originalCart structures for backwards compatibility
    const cartData = result.currentCart || result.originalCart || {};
    const totalCost = cartData.totals?.totalValue || cartData.totalCost || 0;

    const savingsAmount = optimization?.totalSavings || 0;
    const savingsPercent = totalCost > 0 ?
      ((savingsAmount / totalCost) * 100).toFixed(1) : 0;

    return `
      <div class="optimization-summary-content">
        <div class="optimization-metric">
          <div class="metric-value">${this.formatPrice(savingsAmount)}</div>
          <div class="metric-label">Total Savings</div>
        </div>
        <div class="optimization-metric">
          <div class="metric-value">${savingsPercent}%</div>
          <div class="metric-label">Savings Percentage</div>
        </div>
        <div class="optimization-metric">
          <div class="metric-value">${optimization?.sellersUsed?.length || 0}</div>
          <div class="metric-label">Sellers Used</div>
        </div>
        <div class="optimization-metric">
          <div class="metric-value">${optimization?.strategy || 'unknown'}</div>
          <div class="metric-label">Algorithm</div>
        </div>
      </div>
    `;
  }

  /**
   * Generate optimization recommendations HTML
   */
  generateOptimizationRecommendations(result) {
    if (!result.recommendations || result.recommendations.length === 0) {
      return '<div class="no-recommendations">No specific recommendations available</div>';
    }

    const recommendationsHTML = result.recommendations.map(rec => `
      <div class="recommendation-item ${rec.type}">
        <div class="recommendation-header">
          <span class="recommendation-title">${rec.title}</span>
          <span class="recommendation-impact">${this.formatPrice(rec.impact)}</span>
        </div>
        <div class="recommendation-description">${rec.description}</div>
        ${rec.action ? `<button class="recommendation-action" data-action="${rec.action}">${rec.actionText}</button>` : ''}
      </div>
    `).join('');

    return `
      <div class="recommendations-header">
        <h4>💡 Optimization Recommendations</h4>
      </div>
      <div class="recommendations-list">
        ${recommendationsHTML}
      </div>
    `;
  }

  /**
   * Generate optimization details HTML
   */
  generateOptimizationDetails(result) {
    if (!result.optimization || !result.optimization.assignments) {
      return '<div class="no-details">No optimization details available</div>';
    }

    // Handle both currentCart and originalCart structures for backwards compatibility
    const cartItems = result.currentCart?.items || result.originalCart?.items || [];

    if (!Array.isArray(cartItems)) {
      console.warn('⚠️ Invalid cart items structure in optimization result');
      return '<div class="no-details">Cart data structure error</div>';
    }

    const assignmentsHTML = result.optimization.assignments.map(assignment => {
      const product = cartItems.find(item => item.productId === assignment.productId);
      return `
        <div class="assignment-item">
          <div class="assignment-product">
            ${product?.productTitle || assignment.productId}
          </div>
          <div class="assignment-seller">
            Seller: ${assignment.sellerId}
          </div>
          <div class="assignment-price">
            ${this.formatPrice(assignment.price)}
          </div>
        </div>
      `;
    }).join('');

    return `
      <div class="optimization-details-header">
        <h4>📋 Detailed Assignments</h4>
      </div>
      <div class="assignments-list">
        ${assignmentsHTML}
      </div>
      <div class="cost-breakdown">
        <div class="cost-item">
          <span>Product Cost:</span>
          <span>${this.formatPrice(result.optimization.totalProductCost)}</span>
        </div>
        <div class="cost-item">
          <span>Shipping Cost:</span>
          <span>${this.formatPrice(result.optimization.totalShippingCost)}</span>
        </div>
        <div class="cost-item total">
          <span>Total Cost:</span>
          <span>${this.formatPrice(result.optimization.totalCost)}</span>
        </div>
      </div>
    `;
  }

  /**
   * Validate optimization result structure
   */
  validateOptimizationResult(result) {
    try {
      // Check if result has basic required properties
      if (typeof result !== 'object' || result === null) {
        console.warn('❌ Result is not an object');
        return false;
      }

      // Check for cart data (either currentCart or originalCart)
      const hasCurrentCart = result.currentCart && typeof result.currentCart === 'object';
      const hasOriginalCart = result.originalCart && typeof result.originalCart === 'object';

      if (!hasCurrentCart && !hasOriginalCart) {
        console.warn('❌ Result missing both currentCart and originalCart');
        return false;
      }

      // Validate cart items structure
      const cartData = result.currentCart || result.originalCart;
      if (cartData.items && !Array.isArray(cartData.items)) {
        console.warn('❌ Cart items is not an array');
        return false;
      }

      // If optimization exists, validate its structure
      if (result.optimization) {
        if (typeof result.optimization !== 'object') {
          console.warn('❌ Optimization data is not an object');
          return false;
        }

        // Validate assignments if they exist
        if (result.optimization.assignments && !Array.isArray(result.optimization.assignments)) {
          console.warn('❌ Optimization assignments is not an array');
          return false;
        }
      }

      console.log('✅ Optimization result structure validation passed');
      return true;

    } catch (error) {
      console.error('❌ Error validating optimization result:', error);
      return false;
    }
  }

  /**
   * Display optimization error
   */
  displayOptimizationError(error) {
    if (!this.optimizationContainer) {
      return;
    }

    const summaryContainer = this.optimizationContainer.querySelector('.optimization-summary');
    if (summaryContainer) {
      summaryContainer.innerHTML = `
        <div class="optimization-error">
          <div class="error-icon">⚠️</div>
          <div class="error-message">
            <h4>Optimization Error</h4>
            <p>${error}</p>
          </div>
        </div>
      `;
    }

    // Clear other containers
    const recommendationsContainer = this.optimizationContainer.querySelector('.optimization-recommendations');
    const detailsContainer = this.optimizationContainer.querySelector('.optimization-details');

    if (recommendationsContainer) recommendationsContainer.innerHTML = '';
    if (detailsContainer) detailsContainer.innerHTML = '';

    this.optimizationContainer.style.display = 'block';
  }

  /**
   * Show optimization loading state
   */
  showOptimizationLoading() {
    console.log('⏳ Showing optimization loading state');

    if (this.optimizationContainer) {
      const loadingElement = this.optimizationContainer.querySelector('.optimization-loading');
      if (loadingElement) {
        loadingElement.style.display = 'flex';
      }

      // Hide results while loading
      const contentElement = this.optimizationContainer.querySelector('.optimization-content');
      if (contentElement) {
        contentElement.style.opacity = '0.5';
      }
    }
  }

  /**
   * Hide optimization loading state
   */
  hideOptimizationLoading() {
    if (this.optimizationContainer) {
      const loadingElement = this.optimizationContainer.querySelector('.optimization-loading');
      if (loadingElement) {
        loadingElement.style.display = 'none';
      }

      // Restore results opacity
      const contentElement = this.optimizationContainer.querySelector('.optimization-content');
      if (contentElement) {
        contentElement.style.opacity = '1';
      }
    }
  }

  /**
   * Trigger cart optimization
   */
  async triggerCartOptimization(reason = 'manual') {
    if (!this.smartCartOptimizer) {
      console.log('⚠️ Smart Cart Optimizer not available');
      return;
    }

    try {
      console.log(`🧮 Triggering cart optimization: ${reason}`);
      const result = await this.smartCartOptimizer.optimizeCurrentCart({
        reason,
        enableAPIRefresh: false // Disable API in fullscreen for now
      });

      return result;
    } catch (error) {
      console.error('❌ Error triggering optimization:', error);
      return null;
    }
  }

  /**
   * Load history data
   */
  async loadHistoryData() {
    try {
      this.showLoadingState('history-items');

      const data = await this.service.getHistoryData();
      this.renderHistoryData(data);

      this.trigger('dataLoaded', {
        type: 'history',
        items: data
      });

    } catch (error) {
      console.error('Error loading history data:', error);
      this.showErrorState('history-items', error.message);
    }
  }

  /**
   * Update statistics
   */
  async updateStats() {
    try {
      const stats = await this.service.getWatchlistStats();
      console.log('📈 Stats loaded:', stats);

      // Update stat cards
      this.updateStatCard('total-items', stats.totalItems, 'کل آیتم‌ها');
      this.updateStatCard('active-items', stats.activeItems, 'فعال');
      this.updateStatCard('alerts-count', stats.alertsCount, 'هشدارها');
      this.updateStatCard('discounts-count', stats.discountsCount, 'تخفیف‌ها');

      // Update sidebar badge
      this.updateSidebarBadges({ watchlist: stats.totalItems });

    } catch (error) {
      console.error('Error updating stats:', error);
    }
  }

  /**
   * Update individual stat card
   */
  updateStatCard(cardId, value, label) {
    // The cardId IS the stat-number element itself
    const numberElement = document.getElementById(cardId);
    if (numberElement) {
      numberElement.textContent = value;
      console.log(`✅ Updated stat ${cardId}: ${value}`);

      // Find the label element (sibling)
      const labelElement = numberElement.parentElement.querySelector('.stat-label');
      if (labelElement && label) {
        labelElement.textContent = label;
      }
    } else {
      console.error(`❌ Stat element ${cardId} not found!`);
    }
  }

  /**
   * Render watchlist data
   */
  renderWatchlistData(items) {
    const itemsContainer = document.getElementById('watchlist-items');
    const emptyContainer = document.getElementById('watchlist-empty');

    if (!itemsContainer) {
      console.error('❌ Container #watchlist-items not found!');
      return;
    }

    console.log(`🎨 Rendering ${items.length} watchlist items`);

    if (items.length === 0) {
      console.log('📭 No items - showing empty state');
      // Hide items container and show empty state
      itemsContainer.style.display = 'none';
      if (emptyContainer) {
        emptyContainer.style.display = 'block';
        // Set up empty state button listeners
        this.setupEmptyStateListeners();
      }
      return;
    }

    console.log('🏗️ Generating items HTML...');
    const itemsHTML = items.map(item => this.getWatchlistItemHTML(item)).join('');
    console.log(`📝 Generated HTML for ${items.length} items, length: ${itemsHTML.length} chars`);

    // Show items container and hide empty state
    itemsContainer.style.display = 'grid';
    itemsContainer.innerHTML = itemsHTML;
    if (emptyContainer) {
      emptyContainer.style.display = 'none';
    }
    console.log('✅ Items rendered successfully');

    // Set up item event listeners
    this.setupWatchlistItemListeners();
  }

  /**
   * Setup event listeners for empty state buttons
   */
  setupEmptyStateListeners() {
    // Clear search button
    const clearSearchBtn = document.querySelector('.clear-search-btn');
    if (clearSearchBtn) {
      clearSearchBtn.addEventListener('click', () => {
        this.clearSearch();
      });
    }

    // View all button
    const viewAllBtn = document.querySelector('.view-all-btn');
    if (viewAllBtn) {
      viewAllBtn.addEventListener('click', () => {
        this.setCurrentFilter('all');
        this.loadWatchlistData();
      });
    }
  }

  /**
   * Render history data
   */
  renderHistoryData(data) {
    const container = document.getElementById('history-items');
    if (!container) return;

    // Get actual watchlist items to display their price history
    const watchlistItems = this.watchlistItems || [];

    if (watchlistItems.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📊</div>
          <h3>تاریخچه‌ای وجود ندارد</h3>
          <p>هنوز محصولی به لیست پیگیری اضافه نشده است</p>
          <button class="btn-primary" onclick="window.prizoFullPageUI.switchTab('watchlist')">رفتن به لیست پیگیری</button>
        </div>
      `;
      return;
    }

    // Render price history for each product
    const historyHTML = watchlistItems.map(item => this.renderProductPriceHistory(item)).join('');
    container.innerHTML = historyHTML;
  }

  /**
   * Render price history for a single product
   */
  renderProductPriceHistory(item) {
    const priceHistory = item.priceHistory || [];
    const currentPrice = item.currentPrice || item.lastKnownPrice || 0;
    const originalPrice = item.originalPrice || currentPrice;

    // Calculate price change
    const priceChange = originalPrice > 0 ? ((currentPrice - originalPrice) / originalPrice * 100) : 0;
    const priceChangeClass = priceChange < 0 ? 'decrease' : priceChange > 0 ? 'increase' : 'stable';
    const priceChangeIcon = priceChange < 0 ? '📉' : priceChange > 0 ? '📈' : '➡️';

    // Get last update time
    const lastUpdate = this.service.getTimeAgo(item.updatedAt);

    // Generate simple text-based price chart
    const chartHTML = this.generatePriceChart(item);

    return `
      <div class="history-item-card">
        <div class="history-item-header">
          <div class="history-item-image">
            <img src="${this.service.resizeDigikalaImage(item.productImage, 100, 100) || this.getPlaceholderImage()}"
                 alt="${item.productTitle}"
                 loading="lazy">
          </div>
          <div class="history-item-info">
            <h3 class="history-item-title">${item.productTitle}</h3>
            <div class="history-item-meta">
              <span class="update-time">آخرین بروزرسانی: ${lastUpdate}</span>
            </div>
          </div>
        </div>

        <div class="history-item-body">
          <div class="price-stats">
            <div class="price-stat">
              <span class="price-stat-label">قیمت فعلی:</span>
              <span class="price-stat-value current">${this.service.formatPrice(currentPrice)}</span>
            </div>
            ${originalPrice !== currentPrice ? `
              <div class="price-stat">
                <span class="price-stat-label">قیمت اولیه:</span>
                <span class="price-stat-value">${this.service.formatPrice(originalPrice)}</span>
              </div>
            ` : ''}
            <div class="price-stat change ${priceChangeClass}">
              <span class="price-stat-label">تغییرات:</span>
              <span class="price-stat-value">
                ${priceChangeIcon} ${Math.abs(priceChange).toFixed(1)}%
                ${priceChange < 0 ? ' (کاهش)' : priceChange > 0 ? ' (افزایش)' : ' (بدون تغییر)'}
              </span>
            </div>
          </div>

          ${chartHTML}

          ${priceHistory.length > 0 ? `
            <div class="price-history-timeline">
              <h4>تاریخچه تغییرات (${priceHistory.length} رکورد)</h4>
              <div class="timeline-items">
                ${priceHistory.slice(-5).reverse().map(entry => `
                  <div class="timeline-item">
                    <span class="timeline-date">${new Date(entry.timestamp || entry.date).toLocaleDateString('fa-IR')}</span>
                    <span class="timeline-price">${this.service.formatPrice(entry.price)}</span>
                  </div>
                `).join('')}
              </div>
            </div>
          ` : `
            <div class="no-history">
              <p>📊 هنوز تاریخچه قیمتی ثبت نشده است</p>
              <p class="hint">قیمت‌ها به صورت خودکار در بازه‌های زمانی مشخص شده ثبت می‌شوند</p>
            </div>
          `}
        </div>

        <div class="history-item-actions">
          <a href="${item.productUrl}" target="_blank" class="btn-secondary">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
              <polyline points="15 3 21 3 21 9"></polyline>
              <line x1="10" y1="14" x2="21" y2="3"></line>
            </svg>
            مشاهده در دیجی‌کالا
          </a>
        </div>
      </div>
    `;
  }

  /**
   * Generate a simple ASCII-style price chart
   */
  generatePriceChart(item) {
    const priceHistory = item.priceHistory || [];

    if (priceHistory.length < 2) {
      return `
        <div class="price-chart">
          <div class="chart-placeholder">
            <svg width="100%" height="120" viewBox="0 0 400 120">
              <line x1="20" y1="100" x2="380" y2="100" stroke="#ddd" stroke-width="2"/>
              <line x1="20" y1="20" x2="20" y2="100" stroke="#ddd" stroke-width="2"/>
              <text x="200" y="60" text-anchor="middle" fill="#999" font-size="14">
                داده کافی برای نمایش نمودار وجود ندارد
              </text>
            </svg>
          </div>
        </div>
      `;
    }

    // Get recent prices (last 30 entries)
    const recentHistory = priceHistory.slice(-30);
    const prices = recentHistory.map(entry => entry.price || 0);
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const priceRange = maxPrice - minPrice || 1;

    // Generate SVG line chart
    const chartWidth = 400;
    const chartHeight = 120;
    const padding = 30;
    const graphWidth = chartWidth - padding * 2;
    const graphHeight = chartHeight - padding * 2;

    const points = recentHistory.map((entry, index) => {
      const x = padding + (index / (recentHistory.length - 1)) * graphWidth;
      const y = padding + graphHeight - ((entry.price - minPrice) / priceRange) * graphHeight;
      return `${x},${y}`;
    }).join(' ');

    return `
      <div class="price-chart">
        <h4>نمودار روند قیمت</h4>
        <svg width="100%" height="${chartHeight}" viewBox="0 0 ${chartWidth} ${chartHeight}">
          <!-- Grid lines -->
          <line x1="${padding}" y1="${padding}" x2="${padding}" y2="${chartHeight - padding}" stroke="#e0e0e0" stroke-width="1"/>
          <line x1="${padding}" y1="${chartHeight - padding}" x2="${chartWidth - padding}" y2="${chartHeight - padding}" stroke="#e0e0e0" stroke-width="1"/>

          <!-- Price line -->
          <polyline points="${points}" fill="none" stroke="#4f46e5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>

          <!-- Data points -->
          ${recentHistory.map((entry, index) => {
      const x = padding + (index / (recentHistory.length - 1)) * graphWidth;
      const y = padding + graphHeight - ((entry.price - minPrice) / priceRange) * graphHeight;
      return `<circle cx="${x}" cy="${y}" r="3" fill="#4f46e5"/>`;
    }).join('')}

          <!-- Labels -->
          <text x="${padding}" y="${padding - 10}" fill="#666" font-size="12">${this.service.formatPrice(maxPrice)}</text>
          <text x="${padding}" y="${chartHeight - padding + 15}" fill="#666" font-size="12">${this.service.formatPrice(minPrice)}</text>
        </svg>
      </div>
    `;
  }

  /**
   * Get watchlist item HTML
   */
  getWatchlistItemHTML(item) {
    console.log('🔧 Generating HTML for item:', item.productTitle || item.id);
    const productImage = this.service.resizeDigikalaImage(item.productImage, 200, 200);
    const conditions = this.service.formatConditions(item.conditions || {}, item.checkInterval);
    const timeAgo = this.service.getTimeAgo(item.updatedAt);
    const hasDiscount = this.service.hasDiscount(item);
    const discountPercentage = this.service.getDiscountPercentage(item);
    const isSelected = this.selectedItems.has(item.id);

    return `
      <div class="item-card ${isSelected ? 'selected' : ''}" data-product-id="${item.id}">
        <div class="item-checkbox-container" style="display: ${this.bulkSelectionMode ? 'block' : 'none'};">
          <input type="checkbox"
                 class="item-checkbox"
                 data-product-id="${item.id}"
                 ${isSelected ? 'checked' : ''}
                 aria-label="انتخاب ${item.productTitle}">
        </div>
        <div class="item-image">
          <img src="${productImage || this.getPlaceholderImage()}" alt="${item.productTitle}" loading="lazy" class="product-image" data-product-id="${item.id}">
          <div class="item-status ${item.isActive ? 'active' : 'inactive'}"></div>
          ${hasDiscount && discountPercentage > 0 ? `
            <div class="discount-badge">${discountPercentage}% تخفیف</div>
          ` : ''}
        </div>
        <div class="item-content">
          <h4 class="item-title">${item.productTitle}</h4>
          <div class="item-prices">
            <div class="current-price">
              <span class="price-label">قیمت فعلی:</span>
              <span class="price-value">${this.service.formatPrice(item.currentPrice || item.lastKnownPrice)}</span>
            </div>
            ${item.originalPrice && item.originalPrice !== item.currentPrice ? `
              <div class="lowest-price">
                <span class="price-label">قیمت اصلی:</span>
                <span class="price-value">${this.service.formatPrice(item.originalPrice)}</span>
              </div>
            ` : ''}
          </div>
          ${conditions ? `<div class="item-meta">${conditions}</div>` : ''}
          <div class="item-meta">آخرین بروزرسانی: ${timeAgo}</div>
        </div>
        <div class="item-actions">
          <button class="btn-icon refresh-btn" data-product-id="${item.id}" title="بروزرسانی قیمت" aria-label="بروزرسانی قیمت ${item.productTitle}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="23 4 23 10 17 10"></polyline>
              <polyline points="1 20 1 14 7 14"></polyline>
              <path d="m3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
            </svg>
          </button>
          <button class="btn-icon edit-btn" data-product-id="${item.id}" title="ویرایش شرایط" aria-label="ویرایش شرایط ${item.productTitle}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
          </button>
          <button class="btn-icon toggle-btn" data-product-id="${item.id}" title="${item.isActive ? 'غیرفعال کردن' : 'فعال کردن'}" aria-label="${item.isActive ? 'غیرفعال کردن' : 'فعال کردن'} ${item.productTitle}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              ${item.isActive ?
        '<path d="M6 18L18 6M6 6l12 12"></path>' :
        '<polyline points="20 6 9 17 4 12"></polyline>'
      }
            </svg>
          </button>
          <button class="btn-icon btn-danger delete-btn" data-product-id="${item.id}" title="حذف از لیست" aria-label="حذف ${item.productTitle}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="m19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
          </button>
          <a href="${item.productUrl}" target="_blank" class="btn-icon" title="مشاهده در دیجی‌کالا" aria-label="مشاهده ${item.productTitle} در دیجی‌کالا">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
              <polyline points="15 3 21 3 21 9"></polyline>
              <line x1="10" y1="14" x2="21" y2="3"></line>
            </svg>
          </a>
        </div>
      </div>
    `;
  }

  /**
   * Get empty state HTML
   */
  getEmptyStateHTML() {
    if (this.currentSearchQuery) {
      return `
        <div class="empty-state">
          <div class="empty-icon">🔍</div>
          <h3>نتیجه‌ای یافت نشد</h3>
          <p>برای "${this.currentSearchQuery}" محصولی در لیست شما وجود ندارد</p>
          <button class="btn-secondary clear-search-btn">پاک کردن جستجو</button>
        </div>
      `;
    }

    if (this.currentFilter !== 'all') {
      return `
        <div class="empty-state">
          <div class="empty-icon">📋</div>
          <h3>آیتمی با این فیلتر وجود ندارد</h3>
          <p>محصولی با فیلتر انتخابی شما پیدا نشد</p>
          <button class="btn-secondary view-all-btn">مشاهده همه</button>
        </div>
      `;
    }

    return `
      <div class="empty-state">
        <div class="empty-icon">⭐</div>
        <h3>لیست پیگیری شما خالی است</h3>
        <p>برای شروع، محصولات مورد نظرتان را از دیجی‌کالا به لیست پیگیری اضافه کنید</p>
        <a href="https://digikala.com" target="_blank" class="btn-primary">رفتن به دیجی‌کالا</a>
      </div>
    `;
  }

  /**
   * Setup watchlist item listeners
   */
  setupWatchlistItemListeners() {
    // Checkbox listeners for bulk selection
    document.querySelectorAll('.item-checkbox').forEach(checkbox => {
      checkbox.addEventListener('change', (e) => {
        e.stopPropagation();
        const productId = e.target.getAttribute('data-product-id');
        this.toggleItemSelection(productId);
      });
    });

    // Refresh buttons
    document.querySelectorAll('.refresh-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.preventDefault();
        const productId = e.currentTarget.getAttribute('data-product-id');
        await this.refreshWatchlistItem(productId, e.currentTarget);
      });
    });

    // Edit buttons
    document.querySelectorAll('.edit-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.preventDefault();
        const productId = e.currentTarget.getAttribute('data-product-id');
        await this.editWatchlistItem(productId);
      });
    });

    // Toggle buttons
    document.querySelectorAll('.toggle-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.preventDefault();
        const productId = e.currentTarget.getAttribute('data-product-id');
        await this.toggleWatchlistItem(productId);
      });
    });

    // Delete buttons
    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.preventDefault();
        const productId = e.currentTarget.getAttribute('data-product-id');
        await this.deleteWatchlistItem(productId);
      });
    });
  }

  /**
   * Refresh watchlist item
   */
  async refreshWatchlistItem(productId, buttonElement) {
    const originalContent = buttonElement.innerHTML;

    try {
      // Show loading state
      buttonElement.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin">
          <path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"/>
        </svg>
      `;
      buttonElement.disabled = true;

      const result = await this.service.refreshWatchlistItem(productId);

      if (result === true) {
        // Reload data to show updated item
        await this.loadWatchlistData();
        this.announce(`محصول با موفقیت بروزرسانی شد`);
      } else if (result?.isThrottled) {
        // Restore button state
        buttonElement.innerHTML = originalContent;
        buttonElement.disabled = false;
        this.announce(result.message);
      }

    } catch (error) {
      console.error('Error refreshing item:', error);

      // Restore button state
      buttonElement.innerHTML = originalContent;
      buttonElement.disabled = false;

      this.announce(`خطا در بروزرسانی: ${error.message}`);
    }
  }

  /**
   * Toggle watchlist item active state
   */
  async toggleWatchlistItem(productId) {
    try {
      await this.service.toggleWatchlistItem(productId);

      // Reload data to show updated state
      await this.loadWatchlistData();
      await this.updateStats();

      this.announce(`وضعیت محصول تغییر کرد`);

    } catch (error) {
      console.error('Error toggling item:', error);
      this.announce(`خطا در تغییر وضعیت: ${error.message}`);
    }
  }

  /**
   * Delete watchlist item
   */
  async deleteWatchlistItem(productId) {
    // Find the item to get its title for the confirmation
    const item = this.watchlistItems.find(item => item.id === productId);
    const itemTitle = item ? item.productTitle : 'این محصول';

    if (!confirm(`آیا از حذف "${itemTitle}" از لیست پیگیری اطمینان دارید؟`)) {
      return;
    }

    try {
      await this.service.removeWatchlistItem(productId);

      // Reload data to show updated list
      await this.loadWatchlistData();
      await this.updateStats();

      this.announce(`محصول از لیست حذف شد`);

    } catch (error) {
      console.error('Error deleting item:', error);
      this.announce(`خطا در حذف: ${error.message}`);
    }
  }

  /**
   * Handle filter option clicks
   */
  handleFilterClick(event) {
    const option = event.currentTarget;
    const filter = option.getAttribute('data-filter');

    // Update active state
    document.querySelectorAll('.filter-option').forEach(opt => {
      opt.classList.remove('active');
    });
    option.classList.add('active');

    // Close filter menu
    const filterMenu = document.getElementById('filterMenu');
    if (filterMenu) {
      filterMenu.classList.remove('show');
    }

    // Update filter button text
    const filterToggle = document.getElementById('filterToggle');
    if (filterToggle) {
      const filterText = option.textContent;
      filterToggle.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polygon points="22,3 2,3 10,12.46 10,19 14,21 14,12.46"/>
        </svg>
        ${filterText}
      `;
    }

    // Update current filter and reload data
    this.setCurrentFilter(filter);
    this.loadWatchlistData();

    // Trigger filter hook
    this.trigger('filterChanged', { filter, option });
  }

  /**
   * Handle FAQ item clicks
   */
  handleFAQClick(event) {
    const question = event.currentTarget;
    const faqItem = question.parentElement;

    faqItem.classList.toggle('active');

    // Update ARIA attributes
    const isExpanded = faqItem.classList.contains('active');
    question.setAttribute('aria-expanded', isExpanded);
  }

  /**
   * Handle search input
   */
  handleSearch(event) {
    const query = event.target.value.trim();
    this.setCurrentSearchQuery(query);
    this.loadWatchlistData();
    this.trigger('searchChanged', { query, element: event.target });
  }

  /**
   * Clear search
   */
  clearSearch() {
    const searchInput = document.getElementById('search-watchlist');
    if (searchInput) {
      searchInput.value = '';
      this.setCurrentSearchQuery('');
      this.loadWatchlistData();
    }
  }

  /**
   * Handle refresh all watchlist button click
   * Refreshes selected items if any are selected, otherwise refreshes all items
   */
  async handleRefreshAllWatchlist() {
    const button = document.getElementById('refresh-all-watchlist');
    if (!button) return;

    const originalContent = button.innerHTML;

    try {
      // Show loading state
      button.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="animate-spin">
          <path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"/>
        </svg>
        در حال به‌روزرسانی...
      `;
      button.disabled = true;

      // TODO: Check for selected items when selection feature is implemented
      // For now, refresh all items
      const selectedItems = this.getSelectedWatchlistItems();
      const productIds = selectedItems.length > 0
        ? selectedItems.map(item => item.id)
        : this.watchlistItems.map(item => item.id);

      if (productIds.length === 0) {
        this.showNotification('لیست نظارت خالی است', 'info');
        button.innerHTML = originalContent;
        button.disabled = false;
        return;
      }

      // Send refresh request to background script for batch processing
      const result = await this.sendRefreshBatchRequest(productIds);

      if (result.success) {
        await this.loadWatchlistData();
        await this.updateStats();
        this.showNotification(
          `${result.refreshedCount} محصول به‌روزرسانی شد`,
          'success'
        );
      } else {
        this.showNotification(result.message || 'خطا در به‌روزرسانی', 'error');
      }

    } catch (error) {
      console.error('Error in handleRefreshAllWatchlist:', error);
      this.showNotification(`خطا در به‌روزرسانی: ${error.message}`, 'error');
    } finally {
      // Restore button state
      button.innerHTML = originalContent;
      button.disabled = false;
    }
  }

  /**
   * Get selected watchlist items (placeholder for future selection feature)
   */
  getSelectedWatchlistItems() {
    // TODO: Implement selection feature
    // For now, return empty array (will refresh all items)
    const selectedCheckboxes = document.querySelectorAll('#watchlist-items input[type="checkbox"]:checked');
    const selectedItems = [];

    selectedCheckboxes.forEach(checkbox => {
      const productId = checkbox.closest('[data-product-id]')?.dataset?.productId;
      if (productId) {
        const item = this.watchlistItems.find(item => item.id === productId);
        if (item) selectedItems.push(item);
      }
    });

    return selectedItems;
  }

  /**
   * Send batch refresh request to background script
   */
  async sendRefreshBatchRequest(productIds) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        action: 'refreshWatchlistBatch',
        productIds: productIds
      }, (response) => {
        if (chrome.runtime.lastError) {
          resolve({
            success: false,
            message: 'خطا در ارتباط با سرویس پس‌زمینه'
          });
        } else {
          resolve(response || { success: false, message: 'پاسخی دریافت نشد' });
        }
      });
    });
  }

  /**
   * Export watchlist
   */
  /**
   * Toggle bulk selection mode
   */
  toggleBulkSelectionMode() {
    this.bulkSelectionMode = !this.bulkSelectionMode;
    this.selectedItems.clear();

    // Update UI
    const bulkActionsBtn = document.getElementById('bulk-actions');
    const bulkPanel = document.getElementById('bulk-actions-panel');
    const watchlistItems = document.getElementById('watchlist-items');

    if (this.bulkSelectionMode) {
      bulkActionsBtn?.classList.add('active');
      bulkPanel?.classList.add('visible');
      watchlistItems?.classList.add('bulk-selection-mode');

      // Show all checkboxes
      document.querySelectorAll('.item-checkbox-container').forEach(container => {
        container.style.display = 'block';
      });
    } else {
      bulkActionsBtn?.classList.remove('active');
      bulkPanel?.classList.remove('visible');
      watchlistItems?.classList.remove('bulk-selection-mode');

      // Hide all checkboxes
      document.querySelectorAll('.item-checkbox-container').forEach(container => {
        container.style.display = 'none';
      });

      // Remove all selections
      document.querySelectorAll('.item-checkbox').forEach(checkbox => {
        checkbox.checked = false;
      });
      document.querySelectorAll('.item-card').forEach(card => {
        card.classList.remove('selected');
      });
    }

    this.updateBulkActionsUI();
  }

  /**
   * Toggle item selection
   */
  toggleItemSelection(productId) {
    if (this.selectedItems.has(productId)) {
      this.selectedItems.delete(productId);
    } else {
      this.selectedItems.add(productId);
    }

    // Update checkbox state immediately
    const checkbox = document.querySelector(`.item-checkbox[data-product-id="${productId}"]`);
    if (checkbox) {
      checkbox.checked = this.selectedItems.has(productId);
    }

    // Update card selected state immediately
    const card = document.querySelector(`.item-card[data-product-id="${productId}"]`);
    if (card) {
      if (this.selectedItems.has(productId)) {
        card.classList.add('selected');
      } else {
        card.classList.remove('selected');
      }
    }

    this.updateBulkActionsUI();
  }

  /**
   * Select all items
   */
  selectAllItems() {
    const filteredItems = this.getFilteredWatchlistItems();
    filteredItems.forEach(item => this.selectedItems.add(item.id));

    // Update all checkboxes and cards immediately
    document.querySelectorAll('.item-checkbox').forEach(checkbox => {
      const productId = checkbox.dataset.productId;
      if (this.selectedItems.has(productId)) {
        checkbox.checked = true;
        const card = checkbox.closest('.item-card');
        if (card) card.classList.add('selected');
      }
    });

    this.updateBulkActionsUI();
  }

  /**
   * Deselect all items
   */
  deselectAllItems() {
    this.selectedItems.clear();

    // Update all checkboxes and cards immediately
    document.querySelectorAll('.item-checkbox').forEach(checkbox => {
      checkbox.checked = false;
      const card = checkbox.closest('.item-card');
      if (card) card.classList.remove('selected');
    });

    this.updateBulkActionsUI();
  }

  /**
   * Update bulk actions UI based on selection
   */
  updateBulkActionsUI() {
    const selectedCount = this.selectedItems.size;
    const selectAllBtn = document.getElementById('bulk-select-all');
    const deleteBtn = document.getElementById('bulk-delete');
    const changeIntervalBtn = document.getElementById('bulk-change-interval');
    const selectionInfo = document.getElementById('bulk-selection-info');

    if (selectAllBtn) {
      if (selectedCount === 0) {
        selectAllBtn.textContent = 'انتخاب همه';
      } else {
        selectAllBtn.textContent = 'لغو انتخاب';
      }
    }

    if (deleteBtn) deleteBtn.disabled = selectedCount === 0;
    if (changeIntervalBtn) changeIntervalBtn.disabled = selectedCount === 0;

    if (selectionInfo) {
      selectionInfo.textContent = selectedCount > 0
        ? `${selectedCount} مورد انتخاب شده`
        : 'هیچ موردی انتخاب نشده';
    }
  }

  /**
   * Bulk delete selected items
   */
  async bulkDeleteItems() {
    if (this.selectedItems.size === 0) return;

    const count = this.selectedItems.size;
    const confirmed = confirm(`آیا مطمئن هستید که می‌خواهید ${count} مورد را حذف کنید؟\nاین عمل قابل بازگشت نیست.`);

    if (!confirmed) return;

    const results = { success: 0, failed: 0, errors: [] };
    const itemsToDelete = Array.from(this.selectedItems);

    // Show progress notification
    this.showNotification(`در حال حذف ${count} مورد...`, 'info');

    for (const productId of itemsToDelete) {
      try {
        await this.deleteWatchlistItemInternal(productId);
        results.success++;
      } catch (error) {
        console.error(`Failed to delete item ${productId}:`, error);
        results.failed++;
        results.errors.push({ productId, error: error.message });
      }
    }

    // Clear selection
    this.selectedItems.clear();

    // Reload data
    await this.loadWatchlistData();

    // Show summary
    if (results.failed === 0) {
      this.showNotification(`${results.success} مورد با موفقیت حذف شد`, 'success');
    } else {
      this.showNotification(
        `${results.success} مورد حذف شد، ${results.failed} مورد با خطا مواجه شد`,
        'warning'
      );
    }

    // Exit bulk mode if no items left
    const filteredItems = this.getFilteredWatchlistItems();
    if (filteredItems.length === 0) {
      this.toggleBulkSelectionMode();
    }
  }

  /**
   * Bulk change interval for selected items
   */
  async bulkChangeInterval() {
    if (this.selectedItems.size === 0) return;

    const count = this.selectedItems.size;

    // Create interval selection dialog
    const intervals = [
      { value: 1800000, label: '30 دقیقه' },
      { value: 3600000, label: '1 ساعت' },
      { value: 7200000, label: '2 ساعت' },
      { value: 14400000, label: '4 ساعت' },
      { value: 21600000, label: '6 ساعت' },
      { value: 43200000, label: '12 ساعت' },
      { value: 86400000, label: '24 ساعت' }
    ];

    const intervalOptions = intervals.map((int, idx) =>
      `${idx + 1}. ${int.label}`
    ).join('\n');

    const choice = prompt(
      `تغییر بازه زمانی بررسی برای ${count} مورد\n\n${intervalOptions}\n\nشماره بازه زمانی مورد نظر را وارد کنید (1-7):`,
      '4'
    );

    if (!choice) return;

    const selectedIdx = parseInt(choice) - 1;
    if (selectedIdx < 0 || selectedIdx >= intervals.length) {
      this.showNotification('انتخاب نامعتبر', 'error');
      return;
    }

    const newInterval = intervals[selectedIdx].value;
    const intervalLabel = intervals[selectedIdx].label;

    const confirmed = confirm(
      `بازه زمانی بررسی ${count} مورد به "${intervalLabel}" تغییر می‌کند.\nادامه می‌دهید؟`
    );

    if (!confirmed) return;

    const results = { success: 0, failed: 0, errors: [] };
    const itemsToUpdate = Array.from(this.selectedItems);

    // Show progress notification
    this.showNotification(`در حال بروزرسانی ${count} مورد...`, 'info');

    for (const productId of itemsToUpdate) {
      try {
        await this.updateItemIntervalInternal(productId, newInterval);
        results.success++;
      } catch (error) {
        console.error(`Failed to update interval for item ${productId}:`, error);
        results.failed++;
        results.errors.push({ productId, error: error.message });
      }
    }

    // Clear selection
    this.selectedItems.clear();

    // Reload data
    await this.loadWatchlistData();

    // Show summary
    if (results.failed === 0) {
      this.showNotification(
        `بازه زمانی ${results.success} مورد به "${intervalLabel}" تغییر کرد`,
        'success'
      );
    } else {
      this.showNotification(
        `${results.success} مورد بروزرسانی شد، ${results.failed} مورد با خطا مواجه شد`,
        'warning'
      );
    }
  }

  /**
   * Internal delete without confirmation (for batch operations)
   */
  async deleteWatchlistItemInternal(productId) {
    await this.service.removeWatchlistItem(productId);
  }

  /**
   * Internal interval update (for batch operations)
   */
  async updateItemIntervalInternal(productId, intervalMinutes) {
    await this.service.updateWatchlistItem(productId, {
      checkInterval: intervalMinutes
    });
  }

  /**
   * Handle optimize cart button click
   */
  async handleOptimizeCartClick() {
    console.log('🎯 UI TRIGGER - Optimize Cart button clicked');

    // Ensure cart items are loaded from storage
    if (!this.smartCartItems) {
      console.log('📦 Loading cart items from storage...');
      await this.loadSmartCartData();
    }

    console.log('📋 UI TRIGGER - Cart data available for optimization:');
    console.log('  Smart Cart Items count:', this.smartCartItems?.length || 0);
    console.log('  Smart Cart Items:', this.smartCartItems?.map(item => ({
      id: item.id,
      productId: item.pId || item.productId,
      title: item._c?.t || item.productTitle || 'Unknown',
      price: item.price || 0,
      quantity: item.qty || item.quantity || 1,
      hasApiData: !!(item.price && (item._c?.t || item.productTitle))
    })));

    // Check if there are any cart items
    if (!this.smartCartItems || this.smartCartItems.length === 0) {
      this.showNotification('سبد هوشمند خالی است. لطفاً ابتدا محصولاتی اضافه کنید.', 'warning');
      return;
    }

    console.log(`📋 Found ${this.smartCartItems.length} cart items for optimization`);

    const optimizeBtn = document.getElementById('optimize-cart-btn');
    if (optimizeBtn) {
      optimizeBtn.disabled = true;
      optimizeBtn.innerHTML = `
        <div class="loading-spinner animate-spin" style="width: 16px; height: 16px; border: 2px solid currentColor; border-top-color: transparent; border-radius: 50%; margin-left: 0.5rem;"></div>
        در حال محاسبه بهینه‌سازی...
      `;
    }

    try {
      // Check if optimizer is available
      if (!this.smartCartOptimizer) {
        console.warn('⚠️ Smart Cart Optimizer not initialized, attempting to initialize...');
        await this.initializeSmartCartOptimizer();

        if (!this.smartCartOptimizer) {
          throw new Error('Smart Cart Optimizer could not be initialized');
        }
      }

      // Update the optimizer's cart manager with current cart items
      if (this.smartCartOptimizer.smartCartManager && this.smartCartOptimizer.smartCartManager.cart) {
        this.smartCartOptimizer.smartCartManager.cart = this.smartCartItems;
        console.log('🔄 Updated optimizer cart with current items');
      }

      console.log('🚀 Starting multi-mode cart optimization...');

      // Run optimizations for all three modes
      const optimizationModes = [
        { mode: 'COST', label: 'کمترین هزینه کل' },
        { mode: 'SELLERS_FIRST', label: 'کمترین تعداد مرسوله' },
        { mode: 'MAX_SELLERS', label: 'تعداد مرسوله دلخواه', maxSellers: 3 }
      ];

      const results = {};

      for (const modeConfig of optimizationModes) {
        console.log(`🔄 Running optimization for mode: ${modeConfig.mode}`);

        const options = {
          mode: modeConfig.mode,
          reason: 'multi_mode_optimization'
        };

        if (modeConfig.maxSellers) {
          options.maxSellers = modeConfig.maxSellers;
        }

        const result = await this.smartCartOptimizer.optimizeCurrentCart(options);
        results[modeConfig.mode] = {
          ...result,
          modeLabel: modeConfig.label
        };

        console.log(`✅ ${modeConfig.mode} optimization completed:`, result?.success ? 'success' : 'failed');
      }

      // Display all optimization results
      this.displayMultiModeOptimizationResults(results);

      // Show the optimization results section
      const resultsContainer = document.querySelector('.optimization-results-container');
      if (resultsContainer) {
        resultsContainer.style.display = 'block';
        resultsContainer.scrollIntoView({ behavior: 'smooth' });
      }

      this.showNotification('بهینه‌سازی سبد هوشمند با موفقیت انجام شد', 'success');

    } catch (error) {
      console.error('❌ Error during cart optimization:', error);
      this.showNotification(`خطا در بهینه‌سازی: ${error.message}`, 'error');
    } finally {
      // Reset optimize button
      if (optimizeBtn) {
        optimizeBtn.disabled = false;
        optimizeBtn.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
          </svg>
          بهینه‌سازی سبد
        `;
      }
    }
  }

  async exportWatchlist() {
    try {
      await this.service.exportWatchlist('json');
      this.announce('لیست پیگیری صادر شد');
    } catch (error) {
      console.error('Error exporting watchlist:', error);
      this.announce(`خطا در صدور: ${error.message}`);
    }
  }

  /**
   * Update extension status
   */
  async updateExtensionStatus() {
    try {
      const statusElement = document.querySelector('.status-text');
      if (!statusElement) return;

      // Simple status check
      statusElement.textContent = 'فعال و آماده';

      this.trigger('statusUpdated', { status: 'active' });
    } catch (error) {
      console.error('Error updating extension status:', error);
    }
  }

  /**
   * Show loading state
   */
  showLoadingState(containerId) {
    const container = document.getElementById(containerId);
    if (container) {
      container.innerHTML = `
        <div class="loading-state">
          <div class="loading-spinner"></div>
          <p>در حال بارگذاری...</p>
        </div>
      `;
    }
  }

  /**
   * Show error state
   */
  showErrorState(containerId, message) {
    const container = document.getElementById(containerId);
    if (container) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">⚠️</div>
          <h3>خطا در بارگذاری</h3>
          <p>${message}</p>
          <button onclick="location.reload()" class="btn-primary">تلاش مجدد</button>
        </div>
      `;
    }
  }

  /**
   * Setup accessibility features
   */
  setupAccessibility() {
    // Keyboard navigation for tabs
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Tab' && e.shiftKey) {
        // Handle reverse tab navigation
      } else if (e.key === 'Tab') {
        // Handle forward tab navigation
      }
    });

    // Screen reader announcements
    const announceElement = document.createElement('div');
    announceElement.setAttribute('aria-live', 'polite');
    announceElement.setAttribute('aria-atomic', 'true');
    announceElement.className = 'sr-only';
    document.body.appendChild(announceElement);
    this.announceElement = announceElement;
  }

  /**
   * Announce message for screen readers
   */
  announce(message) {
    if (this.announceElement) {
      this.announceElement.textContent = message;
      setTimeout(() => {
        this.announceElement.textContent = '';
      }, 1000);
    }
  }

  /**
   * Toggle fullscreen mode
   */
  toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(err => {
        console.log('Error attempting to enable fullscreen:', err);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  }

  /**
   * Update sidebar badge counts
   */
  updateSidebarBadges(counts) {
    const watchlistBadge = document.querySelector('[data-tab="watchlist"] .nav-badge');
    if (watchlistBadge && counts.watchlist !== undefined) {
      watchlistBadge.textContent = counts.watchlist;
      watchlistBadge.style.display = counts.watchlist > 0 ? 'inline-block' : 'none';
    }

    const smartCartBadge = document.querySelector('[data-tab="smart-cart"] .nav-badge');
    if (smartCartBadge && counts.smartCart !== undefined) {
      smartCartBadge.textContent = counts.smartCart;
      smartCartBadge.style.display = counts.smartCart > 0 ? 'inline-block' : 'none';
    }
  }

  /**
   * Setup Add Product Modal
   */
  setupAddProductModal() {
    // Get modal elements
    const modal = document.getElementById('addProductModal');
    const addButtons = document.querySelectorAll('[data-hook="addWatchlistItem"]');
    const closeButton = document.getElementById('closeAddProduct');
    const cancelButton = document.getElementById('cancelAddProduct');
    const form = document.getElementById('addProductForm');
    const submitButton = document.getElementById('submitAddProduct');

    // Add event listeners to all add product buttons
    addButtons.forEach(button => {
      button.addEventListener('click', () => this.showAddProductModal());
    });

    // Close modal events
    if (closeButton) {
      closeButton.addEventListener('click', () => this.hideAddProductModal());
    }
    if (cancelButton) {
      cancelButton.addEventListener('click', () => this.hideAddProductModal());
    }

    // Close modal when clicking overlay
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          this.hideAddProductModal();
        }
      });
    }

    // Handle checkbox toggles for advanced settings
    this.setupAdvancedSettingsToggles();

    // Handle form submission
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleAddProduct();
      });
    }

    // Close modal on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal && modal.style.display !== 'none') {
        this.hideAddProductModal();
      }
    });
  }

  /**
   * Setup advanced settings toggles
   */
  setupAdvancedSettingsToggles() {
    const priceCheckbox = document.getElementById('priceThresholdEnabled');
    const priceInput = document.getElementById('priceThreshold');
    const discountCheckbox = document.getElementById('discountThresholdEnabled');
    const discountInput = document.getElementById('discountThreshold');

    if (priceCheckbox && priceInput) {
      priceCheckbox.addEventListener('change', () => {
        priceInput.disabled = !priceCheckbox.checked;
        if (!priceCheckbox.checked) priceInput.value = '';
      });
    }

    if (discountCheckbox && discountInput) {
      discountCheckbox.addEventListener('change', () => {
        discountInput.disabled = !discountCheckbox.checked;
        if (!discountCheckbox.checked) discountInput.value = '';
      });
    }
  }

  /**
   * Show add product modal
   */
  showAddProductModal() {
    const modal = document.getElementById('addProductModal');
    if (modal) {
      modal.style.display = 'flex';
      // Focus on URL input
      const urlInput = document.getElementById('productUrl');
      if (urlInput) {
        setTimeout(() => urlInput.focus(), 100);
      }
    }
  }

  /**
   * Hide add product modal
   */
  hideAddProductModal() {
    const modal = document.getElementById('addProductModal');
    if (modal) {
      modal.style.display = 'none';
      this.resetAddProductForm();
    }
  }

  /**
   * Reset add product form
   */
  resetAddProductForm() {
    const form = document.getElementById('addProductForm');
    if (form) {
      form.reset();

      // Reset disabled state of conditional inputs
      document.getElementById('priceThreshold').disabled = true;
      document.getElementById('discountThreshold').disabled = true;
    }
  }

  /**
   * Handle add product form submission
   */
  async handleAddProduct() {
    const submitButton = document.getElementById('submitAddProduct');
    const btnText = submitButton.querySelector('.btn-text');
    const btnSpinner = submitButton.querySelector('.btn-spinner');

    try {
      // Show loading state
      btnText.style.display = 'none';
      btnSpinner.style.display = 'inline-block';
      submitButton.disabled = true;

      // Get form data
      const productUrl = document.getElementById('productUrl').value.trim();
      const checkInterval = parseInt(document.getElementById('checkInterval').value);

      // Build conditions object
      const conditions = {};

      if (document.getElementById('priceThresholdEnabled').checked) {
        const threshold = parseInt(document.getElementById('priceThreshold').value);
        if (threshold > 0) {
          conditions.priceThreshold = threshold * 10; // Convert to Rials
        }
      }

      if (document.getElementById('discountThresholdEnabled').checked) {
        const discount = parseInt(document.getElementById('discountThreshold').value);
        if (discount > 0 && discount <= 100) {
          conditions.minDiscountPercent = discount;
        }
      }

      if (document.getElementById('notifyLowestEnabled').checked) {
        conditions.notifyOnLowest30Days = true;
      }

      // Extract product ID from URL
      const productId = this.extractProductIdFromUrl(productUrl);
      if (!productId) {
        throw new Error('لینک محصول نامعتبر است. لطفاً لینک صحیح دیجی‌کالا را وارد کنید.');
      }

      // Create product data object
      const productData = {
        productId: productId,
        productUrl: productUrl,
        conditions: conditions,
        checkInterval: checkInterval
      };

      // Add to watchlist via service
      const result = await this.service.addWatchlistItem(productData);

      if (result) {
        // Success - refresh watchlist and close modal
        await this.loadWatchlistData();
        await this.updateStats();
        this.hideAddProductModal();

        // Show success message
        this.showNotification('محصول با موفقیت اضافه شد!', 'success');
      }

    } catch (error) {
      console.error('Error adding product:', error);
      this.showNotification(error.message || 'خطا در افزودن محصول', 'error');
    } finally {
      // Reset loading state
      btnText.style.display = 'inline';
      btnSpinner.style.display = 'none';
      submitButton.disabled = false;
    }
  }

  /**
   * Setup Edit Watchlist Item Modal
   */
  setupEditWatchlistModal() {
    const modal = document.getElementById('editWatchlistModal');
    const closeButton = document.getElementById('closeEditModal');
    const cancelButton = document.getElementById('cancelEditBtn');
    const form = document.getElementById('editWatchlistForm');

    // Close modal events
    if (closeButton) {
      closeButton.addEventListener('click', () => this.hideEditWatchlistModal());
    }
    if (cancelButton) {
      cancelButton.addEventListener('click', () => this.hideEditWatchlistModal());
    }

    // Close modal when clicking overlay
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          this.hideEditWatchlistModal();
        }
      });
    }

    // Handle form submission
    if (form) {
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.handleEditWatchlistItem();
      });
    }
  }

  /**
   * Edit watchlist item - show modal with item details
   */
  async editWatchlistItem(productId) {
    const item = this.watchlistItems.find(item => item.id === productId);
    if (!item) {
      this.showNotification('محصول مورد نظر یافت نشد', 'error');
      return;
    }

    this.currentEditingItem = item;

    // Populate edit form
    const editProductTitle = document.getElementById('editProductTitle');
    const editPriceThreshold = document.getElementById('editPriceThreshold');
    const editDiscountThreshold = document.getElementById('editDiscountThreshold');
    const editNotifyLowest30Days = document.getElementById('editNotifyLowest30Days');
    const editCheckInterval = document.getElementById('editCheckInterval');

    if (editProductTitle) {
      editProductTitle.textContent = item.productTitle;
    }
    if (editPriceThreshold) {
      editPriceThreshold.value = item.conditions?.priceThreshold ?
        Math.round(item.conditions.priceThreshold / 10) : '';
    }
    if (editDiscountThreshold) {
      editDiscountThreshold.value = item.conditions?.minDiscountPercent || '';
    }
    if (editNotifyLowest30Days) {
      editNotifyLowest30Days.checked = item.conditions?.notifyOnLowest30Days || false;
    }
    if (editCheckInterval) {
      editCheckInterval.value = item.checkInterval || 14400000;
    }

    // Show modal
    this.showEditWatchlistModal();
  }

  /**
   * Show edit watchlist modal
   */
  showEditWatchlistModal() {
    const modal = document.getElementById('editWatchlistModal');
    if (modal) {
      modal.style.display = 'flex';
    }
  }

  /**
   * Hide edit watchlist modal
   */
  hideEditWatchlistModal() {
    const modal = document.getElementById('editWatchlistModal');
    if (modal) {
      modal.style.display = 'none';
      this.currentEditingItem = null;
    }
  }

  /**
   * Handle edit watchlist item form submission
   */
  async handleEditWatchlistItem() {
    if (!this.currentEditingItem) {
      this.showNotification('خطا در ویرایش محصول', 'error');
      return;
    }

    const saveButton = document.getElementById('saveEditBtn');
    const originalText = saveButton?.textContent;

    try {
      if (saveButton) {
        saveButton.disabled = true;
        saveButton.textContent = 'در حال ذخیره...';
      }

      // Get form values
      const priceThreshold = document.getElementById('editPriceThreshold').value;
      const discountThreshold = document.getElementById('editDiscountThreshold').value;
      const notifyLowest30Days = document.getElementById('editNotifyLowest30Days').checked;
      const checkInterval = parseInt(document.getElementById('editCheckInterval').value);

      // Update item
      const updatedItem = {
        ...this.currentEditingItem,
        conditions: {
          ...this.currentEditingItem.conditions,
          priceThreshold: priceThreshold ? parseInt(priceThreshold) * 10 : null,
          minDiscountPercent: discountThreshold ? parseInt(discountThreshold) : null,
          notifyOnLowest30Days: notifyLowest30Days
        },
        checkInterval: checkInterval
      };

      // Send to background to update
      const response = await chrome.runtime.sendMessage({
        action: 'updateWatchlistItem',
        data: updatedItem
      });

      if (response && response.success) {
        this.showNotification('تغییرات با موفقیت ذخیره شد', 'success');
        this.hideEditWatchlistModal();
        await this.loadWatchlistData();
      } else {
        throw new Error(response?.error || 'خطا در ذخیره تغییرات');
      }
    } catch (error) {
      console.error('Error updating watchlist item:', error);
      this.showNotification('خطا در ذخیره تغییرات: ' + error.message, 'error');
    } finally {
      if (saveButton) {
        saveButton.disabled = false;
        saveButton.textContent = originalText;
      }
    }
  }

  /**
   * Extract product ID from Digikala URL
   */
  extractProductIdFromUrl(url) {
    if (!url) return null;

    // Support various Digikala URL formats
    const patterns = [
      /\/product\/dkp-(\d+)\//,  // /product/dkp-123456/
      /\/product\/(\d+)\//,      // /product/123456/
      /dkp-(\d+)/,               // anywhere with dkp-123456
      /product\/.*?(\d{6,})/     // product with 6+ digits
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }

    return null;
  }

  /**
   * Show notification message
   */
  showNotification(message, type = 'info') {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('notification');
    if (!notification) {
      notification = document.createElement('div');
      notification.id = 'notification';
      notification.className = 'notification';
      document.body.appendChild(notification);
    }

    // Set message and type
    notification.textContent = message;
    notification.className = `notification ${type} show`;

    // Auto hide after 4 seconds
    setTimeout(() => {
      notification.classList.remove('show');
    }, 4000);
  }

  /**
   * Setup storage listener for real-time updates
   */
  setupStorageListener() {
    console.log('🔧 Setting up storage listener for fullscreen view...');

    // Listen for storage changes to keep data in sync
    if (chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, namespace) => {
        console.log('📡 Storage change detected:', { changes, namespace });

        if (namespace === 'local') {
          // Handle Smart Cart changes
          if (changes.digikala_extension_smart_cart_items) {
            console.log('📦 Smart Cart storage changed:', changes.digikala_extension_smart_cart_items);
            console.log('📦 Old value:', changes.digikala_extension_smart_cart_items.oldValue);
            console.log('📦 New value:', changes.digikala_extension_smart_cart_items.newValue);

            const newItems = changes.digikala_extension_smart_cart_items.newValue || [];
            this.smartCartItems = newItems;

            // Always update if we're currently viewing Smart Cart
            if (this.getCurrentTab() === 'smart-cart') {
              console.log('📱 Currently on Smart Cart tab, updating display...');
              this.renderSmartCartData(this.smartCartItems);
              this.updateSmartCartSummary(this.smartCartItems);
            } else {
              console.log('📱 Not on Smart Cart tab, will update when switched');
            }

            // Always update sidebar badge
            this.updateSidebarBadges({ smartCart: this.smartCartItems.length });

            console.log(`✅ Smart Cart synced: ${this.smartCartItems.length} items`);
          }

          // Handle watchlist changes
          if (changes.watchlist_data) {
            console.log('📋 Watchlist storage changed:', changes.watchlist_data);
            const newData = changes.watchlist_data.newValue || [];
            this.watchlistItems = newData;

            // Only update if we're currently viewing watchlist
            if (this.getCurrentTab() === 'watchlist') {
              this.renderWatchlistData(this.watchlistItems);
            }

            // Always update sidebar badge
            this.updateSidebarBadges({ watchlist: this.watchlistItems.length });
          }

          // Handle comparison sites changes
          if (changes.digikala_extension_comparison_sites) {
            console.log('🔗 Comparison sites storage changed:', changes.digikala_extension_comparison_sites);
            const newSites = changes.digikala_extension_comparison_sites.newValue || [];
            this.comparisonSites = newSites;

            // Update display if we're on settings tab
            if (this.getCurrentTab() === 'settings') {
              console.log('🔗 Currently on settings tab, updating sites display...');
              this.renderComparisonSites();
            }

            console.log(`✅ Comparison sites synced: ${this.comparisonSites.length} sites`);
          }

          // Handle settings changes from popup
          const settingsKeys = [
            'persistentMode',
            'sortFeatureEnabled',
            'cartFeatureEnabled',
            'networkStabilityCheck',
            'globalDelay',
            'comparisonFeatureEnabled'
          ];

          const changedSettings = {};
          let hasSettingsChanges = false;

          settingsKeys.forEach(key => {
            if (changes[key]) {
              console.log(`⚙️ Setting ${key} changed:`, changes[key]);
              changedSettings[key] = changes[key].newValue;
              hasSettingsChanges = true;
            }
          });

          if (hasSettingsChanges) {
            console.log('⚙️ Settings synchronized from popup:', changedSettings);
            // Reload settings to get the full settings object with defaults
            this.loadSettings();
          }
        }
      });
    }
  }

  /**
   * Setup image error handling for product images
   */
  setupImageErrorHandling() {
    // Use event delegation to handle image errors
    document.addEventListener('error', (e) => {
      if (e.target.tagName === 'IMG' && e.target.classList.contains('product-image')) {
        e.target.src = this.getPlaceholderImage();
      }
    }, true);
  }

  /**
   * Get placeholder image data URL
   */
  getPlaceholderImage() {
    // SVG placeholder with Persian text
    const svgPlaceholder = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200'%3E%3Crect width='200' height='200' fill='%23f8f9fa'/%3E%3Crect x='20' y='20' width='160' height='160' fill='none' stroke='%23dee2e6' stroke-width='2' stroke-dasharray='8,4'/%3E%3Cg fill='%236c757d' text-anchor='middle'%3E%3Ctext x='100' y='90' font-size='16' font-family='Arial, sans-serif'%3E%D8%AA%D8%B5%D9%88%DB%8C%D8%B1%3C/text%3E%3Ctext x='100' y='110' font-size='12' font-family='Arial, sans-serif'%3E%D9%85%D8%AD%D8%B5%D9%88%D9%84%3C/text%3E%3Cpath d='M80 120 L90 130 L110 110 L130 125 L140 115 L140 140 L80 140 Z' fill='%23adb5bd'/%3E%3Ccircle cx='90' cy='125' r='3' fill='%23fff'/%3E%3C/g%3E%3C/svg%3E`;
    return svgPlaceholder;
  }

  /**
   * Debounce utility function
   */
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Hook management methods
  on(hookName, callback) {
    if (!this.hooks[hookName]) {
      this.hooks[hookName] = [];
    }
    this.hooks[hookName].push(callback);
  }

  off(hookName, callback) {
    if (this.hooks[hookName]) {
      this.hooks[hookName] = this.hooks[hookName].filter(cb => cb !== callback);
    }
  }

  trigger(hookName, data = {}) {
    if (this.hooks[hookName]) {
      this.hooks[hookName].forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error(`Error in hook ${hookName}:`, error);
        }
      });
    }
  }

  // Getters and setters
  getCurrentTab() {
    const activeLink = document.querySelector('.nav-link.active');
    return activeLink ? activeLink.getAttribute('data-tab') : 'watchlist';
  }

  getCurrentFilter() {
    return this.currentFilter;
  }

  setCurrentFilter(filter) {
    this.currentFilter = filter;
  }

  getCurrentSearchQuery() {
    return this.currentSearchQuery;
  }

  setCurrentSearchQuery(query) {
    this.currentSearchQuery = query;
  }

  getWatchlistItems() {
    return this.watchlistItems;
  }

  isInitialized() {
    return this.initialized;
  }

  getService() {
    return this.service;
  }

  isSidebarOpen() {
    return this.sidebarOpen;
  }

  // Test and debug methods
  async testSmartCartDisplay() {
    console.log('🧪 Testing Smart Cart display in fullpage...');

    const testData = [
      {
        id: 'fullpage_test_1',
        productId: 'dkp-fullpage-1',
        productTitle: 'تست محصول فول‌پیج - لپ‌تاپ گیمینگ',
        productUrl: 'https://www.digikala.com/product/dkp-fullpage-1/',
        productImage: null,
        price: 500000000, // 50 million rials = 5 million tomans
        quantity: 1,
        variantId: 'variant_rtx4060_16gb',
        variantDetails: {
          color: { title: 'مشکی' },
          size: { title: 'RTX 4060 - 16GB RAM' }
        },
        addedAt: Date.now(),
        updatedAt: Date.now()
      },
      {
        id: 'fullpage_test_2',
        productId: 'dkp-fullpage-2',
        productTitle: 'تست محصول فول‌پیج - هدست بی‌سیم',
        productUrl: 'https://www.digikala.com/product/dkp-fullpage-2/',
        productImage: 'https://dkstatics-public.digikala.com/digikala-products/120x120_dir/test2.jpg',
        price: 80000000, // 8 million rials = 800k tomans
        quantity: 3,
        variantId: null,
        variantDetails: null,
        addedAt: Date.now() - 7200000, // 2 hours ago
        updatedAt: Date.now() - 7200000
      }
    ];

    // Update storage
    await chrome.storage.local.set({ smart_cart_items: testData });

    // Update local data
    this.smartCartItems = testData;

    // Switch to Smart Cart tab and render
    this.switchTab('smart-cart');
    this.renderSmartCartData(this.smartCartItems);
    this.updateSmartCartSummary(this.smartCartItems);
    this.updateSidebarBadges({ smartCart: this.smartCartItems.length });

    console.log('✅ Test data added to fullpage Smart Cart:', testData);
    return testData;
  }

  debugSmartCartState() {
    console.log('🔍 Fullpage Smart Cart Debug Info:');
    console.log('- Smart Cart Items:', this.smartCartItems);
    console.log('- Current Tab:', this.getCurrentTab());
    console.log('- Container Element:', document.getElementById('current-cart-items'));

    // Check storage
    chrome.storage.local.get(['digikala_extension_smart_cart_items']).then(result => {
      console.log('- Storage Data:', result.digikala_extension_smart_cart_items);
    });

    return {
      smartCartItems: this.smartCartItems,
      currentTab: this.getCurrentTab(),
      containerExists: !!document.getElementById('current-cart-items')
    };
  }

  /**
   * Add test data to Smart Cart for debugging
   */
  async addTestSmartCartData() {
    console.log('🧪 Adding test Smart Cart data...');

    const testItems = [
      {
        id: 'test_fullpage_1',
        productId: 'dkp-fullpage-1',
        productTitle: 'گوشی موبایل سامسونگ Galaxy S23 Ultra - ظرفیت 256 گیگابایت',
        productUrl: 'https://www.digikala.com/product/dkp-fullpage-1/',
        productImage: 'https://dkstatics-public.digikala.com/digikala-products/120x120_dir/12345.jpg',
        price: 450000000, // 45 million rials
        quantity: 1,
        variantId: 'variant_black_256gb',
        variantDetails: {
          color: { title: 'مشکی' },
          size: { title: '256 گیگابایت' }
        },
        addedAt: Date.now() - 3600000, // 1 hour ago
        updatedAt: Date.now() - 3600000
      },
      {
        id: 'test_fullpage_2',
        productId: 'dkp-fullpage-2',
        productTitle: 'هدفون بی‌سیم اپل AirPods Pro',
        productUrl: 'https://www.digikala.com/product/dkp-fullpage-2/',
        productImage: null,
        price: 120000000, // 12 million rials
        quantity: 2,
        variantId: null,
        variantDetails: null,
        addedAt: Date.now() - 7200000, // 2 hours ago
        updatedAt: Date.now() - 7200000
      }
    ];

    try {
      // Save to storage
      await chrome.storage.local.set({ digikala_extension_smart_cart_items: testItems });
      console.log('✅ Test Smart Cart data saved to storage');

      // Update local state
      this.smartCartItems = testItems;

      // Re-render the Smart Cart
      this.renderSmartCartData(testItems);
      this.updateSmartCartSummary(testItems);

      console.log('✅ Smart Cart updated with test data');
      return testItems;
    } catch (error) {
      console.error('❌ Error adding test Smart Cart data:', error);
      throw error;
    }
  }

  /**
   * Setup settings event listeners
   */
  setupSettingsEventListeners() {
    // Auto activation toggle
    const persistentModeCheckbox = document.getElementById('persistentMode');
    const toggleSwitchContainer = document.getElementById('toggleSwitchContainer');
    if (persistentModeCheckbox && toggleSwitchContainer) {
      persistentModeCheckbox.addEventListener('change', async (e) => {
        await this.handleSettingChange('persistentMode', e.target.checked);
        this.updateToggleSwitch(toggleSwitchContainer, e.target.checked);
      });

      toggleSwitchContainer.addEventListener('click', () => {
        persistentModeCheckbox.checked = !persistentModeCheckbox.checked;
        persistentModeCheckbox.dispatchEvent(new Event('change'));
      });
    }

    // Sort feature toggle
    const sortFeatureCheckbox = document.getElementById('sortFeatureMode');
    const sortToggleSwitchContainer = document.getElementById('sortToggleSwitchContainer');
    if (sortFeatureCheckbox && sortToggleSwitchContainer) {
      sortFeatureCheckbox.addEventListener('change', async (e) => {
        await this.handleSettingChange('sortFeatureEnabled', e.target.checked);
        this.updateToggleSwitch(sortToggleSwitchContainer, e.target.checked);
      });

      sortToggleSwitchContainer.addEventListener('click', () => {
        sortFeatureCheckbox.checked = !sortFeatureCheckbox.checked;
        sortFeatureCheckbox.dispatchEvent(new Event('change'));
      });
    }

    // Cart feature toggle
    const cartFeatureCheckbox = document.getElementById('cartFeatureMode');
    const cartToggleSwitchContainer = document.getElementById('cartToggleSwitchContainer');
    if (cartFeatureCheckbox && cartToggleSwitchContainer) {
      cartFeatureCheckbox.addEventListener('change', async (e) => {
        await this.handleSettingChange('cartFeatureEnabled', e.target.checked);
        this.updateToggleSwitch(cartToggleSwitchContainer, e.target.checked);
      });

      cartToggleSwitchContainer.addEventListener('click', () => {
        cartFeatureCheckbox.checked = !cartFeatureCheckbox.checked;
        cartFeatureCheckbox.dispatchEvent(new Event('change'));
      });
    }

    // Network stability toggle
    const networkStabilityCheckbox = document.getElementById('networkStabilityCheck');
    const networkStabilityToggleContainer = document.getElementById('networkStabilityToggleContainer');
    if (networkStabilityCheckbox && networkStabilityToggleContainer) {
      networkStabilityCheckbox.addEventListener('change', async (e) => {
        await this.handleSettingChange('networkStabilityCheck', e.target.checked);
        this.updateToggleSwitch(networkStabilityToggleContainer, e.target.checked);
      });

      networkStabilityToggleContainer.addEventListener('click', () => {
        networkStabilityCheckbox.checked = !networkStabilityCheckbox.checked;
        networkStabilityCheckbox.dispatchEvent(new Event('change'));
      });
    }

    // Global delay range
    const globalDelayRange = document.getElementById('globalDelayRange');
    const globalDelayValue = document.getElementById('globalDelayValue');
    if (globalDelayRange && globalDelayValue) {
      globalDelayRange.addEventListener('input', (e) => {
        const value = parseInt(e.target.value);
        globalDelayValue.textContent = value;
      });

      globalDelayRange.addEventListener('change', async (e) => {
        const value = parseInt(e.target.value);
        await this.handleSettingChange('globalDelay', value);
      });
    }

    // Comparison feature toggle
    const comparisonFeatureCheckbox = document.getElementById('comparisonFeatureMode');
    const comparisonToggleSwitchContainer = document.getElementById('comparisonToggleSwitchContainer');
    const comparisonSitesManagement = document.getElementById('comparisonSitesManagement');

    if (comparisonFeatureCheckbox && comparisonToggleSwitchContainer) {
      comparisonFeatureCheckbox.addEventListener('change', async (e) => {
        await this.handleSettingChange('comparisonFeatureEnabled', e.target.checked);
        this.updateToggleSwitch(comparisonToggleSwitchContainer, e.target.checked);

        // Show/hide sites management
        if (comparisonSitesManagement) {
          comparisonSitesManagement.style.display = e.target.checked ? 'block' : 'none';
        }
      });

      comparisonToggleSwitchContainer.addEventListener('click', () => {
        comparisonFeatureCheckbox.checked = !comparisonFeatureCheckbox.checked;
        comparisonFeatureCheckbox.dispatchEvent(new Event('change'));
      });
    }

    // Comparison sites management
    this.setupComparisonSitesEventListeners();
    this.loadComparisonSites();

    // Control buttons
    this.setupControlButtonsEventListeners();

    // Load initial settings
    this.loadSettings();
  }

  /**
   * Setup comparison sites event listeners
   */
  setupComparisonSitesEventListeners() {
    const addSiteBtn = document.getElementById('addSiteBtn');
    const addSiteForm = document.getElementById('addSiteForm');
    const saveSiteBtn = document.getElementById('saveSiteBtn');
    const cancelSiteBtn = document.getElementById('cancelSiteBtn');
    const comparisonHelpBtn = document.getElementById('comparisonHelpBtn');

    if (addSiteBtn && addSiteForm) {
      addSiteBtn.addEventListener('click', () => {
        addSiteForm.style.display = addSiteForm.style.display === 'none' ? 'block' : 'none';
        addSiteBtn.style.display = 'none';
      });
    }

    if (cancelSiteBtn && addSiteForm && addSiteBtn) {
      cancelSiteBtn.addEventListener('click', () => {
        addSiteForm.style.display = 'none';
        addSiteBtn.style.display = 'block';
      });
    }

    if (saveSiteBtn) {
      saveSiteBtn.addEventListener('click', () => {
        this.saveSite();
      });
    }

    if (comparisonHelpBtn) {
      comparisonHelpBtn.addEventListener('click', () => {
        this.showComparisonHelp();
      });
    }

    // Popular sites dropdown
    const popularSites = document.getElementById('popularSites');
    const siteName = document.getElementById('siteName');
    const siteUrl = document.getElementById('siteUrl');

    if (popularSites && siteName && siteUrl) {
      popularSites.addEventListener('change', (e) => {
        const option = e.target.selectedOptions[0];
        if (option && option.dataset.name) {
          siteName.value = option.dataset.name;
          siteUrl.value = option.dataset.url;
        }
      });
    }
  }

  /**
   * Setup control buttons event listeners
   */
  setupControlButtonsEventListeners() {
    const toggleMainBtn = document.getElementById('toggleMainBtn');
    const updateMainBtn = document.getElementById('updateMainBtn');
    const emergencyStopMainBtn = document.getElementById('emergencyStopMainBtn');
    const clearDisplayMainBtn = document.getElementById('clearDisplayMainBtn');
    const clearCacheMainBtn = document.getElementById('clearCacheMainBtn');
    const resetAllMainBtn = document.getElementById('resetAllMainBtn');

    if (toggleMainBtn) {
      toggleMainBtn.addEventListener('click', () => this.toggleExtension());
    }
    if (updateMainBtn) {
      updateMainBtn.addEventListener('click', () => this.updateAllData());
    }
    if (emergencyStopMainBtn) {
      emergencyStopMainBtn.addEventListener('click', () => this.emergencyStop());
    }
    if (clearDisplayMainBtn) {
      clearDisplayMainBtn.addEventListener('click', () => this.clearDisplay());
    }
    if (clearCacheMainBtn) {
      clearCacheMainBtn.addEventListener('click', () => this.clearCache());
    }
    if (resetAllMainBtn) {
      resetAllMainBtn.addEventListener('click', () => this.resetAll());
    }
  }

  /**
   * Handle setting change
   */
  async handleSettingChange(key, value) {
    try {
      await chrome.storage.local.set({ [key]: value });
      console.log(`Setting ${key} changed to:`, value);
    } catch (error) {
      console.error(`Error saving setting ${key}:`, error);
    }
  }

  /**
   * Update toggle switch visual state
   */
  updateToggleSwitch(container, active) {
    if (container) {
      container.classList.toggle('active', active);
    }
  }

  /**
   * Load settings from storage
   */
  async loadSettings() {
    try {
      const settings = await chrome.storage.local.get([
        'persistentMode',
        'sortFeatureEnabled',
        'cartFeatureEnabled',
        'networkStabilityCheck',
        'globalDelay',
        'comparisonFeatureEnabled'
      ]);

      // Update UI elements based on loaded settings
      this.updateSettingsUI(settings);
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  }

  /**
   * Update settings UI elements
   */
  updateSettingsUI(settings) {
    // Update checkboxes with proper defaults (true if not explicitly set to false)
    const persistentModeCheckbox = document.getElementById('persistentMode');
    if (persistentModeCheckbox) {
      persistentModeCheckbox.checked = settings.persistentMode !== undefined ? settings.persistentMode : true;
      this.updateToggleSwitch(document.getElementById('toggleSwitchContainer'), persistentModeCheckbox.checked);
    }

    const sortFeatureCheckbox = document.getElementById('sortFeatureMode');
    if (sortFeatureCheckbox) {
      sortFeatureCheckbox.checked = settings.sortFeatureEnabled !== undefined ? settings.sortFeatureEnabled : true;
      this.updateToggleSwitch(document.getElementById('sortToggleSwitchContainer'), sortFeatureCheckbox.checked);
    }

    const cartFeatureCheckbox = document.getElementById('cartFeatureMode');
    if (cartFeatureCheckbox) {
      cartFeatureCheckbox.checked = settings.cartFeatureEnabled !== undefined ? settings.cartFeatureEnabled : true;
      this.updateToggleSwitch(document.getElementById('cartToggleSwitchContainer'), cartFeatureCheckbox.checked);
    }

    const networkStabilityCheckbox = document.getElementById('networkStabilityCheck');
    if (networkStabilityCheckbox) {
      networkStabilityCheckbox.checked = settings.networkStabilityCheck !== undefined ? settings.networkStabilityCheck : true;
      this.updateToggleSwitch(document.getElementById('networkStabilityToggleContainer'), networkStabilityCheckbox.checked);
    }

    const comparisonFeatureCheckbox = document.getElementById('comparisonFeatureMode');
    const comparisonSitesManagement = document.getElementById('comparisonSitesManagement');
    if (comparisonFeatureCheckbox) {
      comparisonFeatureCheckbox.checked = settings.comparisonFeatureEnabled !== undefined ? settings.comparisonFeatureEnabled : true;
      this.updateToggleSwitch(document.getElementById('comparisonToggleSwitchContainer'), comparisonFeatureCheckbox.checked);

      // Show/hide sites management
      if (comparisonSitesManagement) {
        comparisonSitesManagement.style.display = comparisonFeatureCheckbox.checked ? 'block' : 'none';
      }
    }

    // Update delay range
    const globalDelayRange = document.getElementById('globalDelayRange');
    const globalDelayValue = document.getElementById('globalDelayValue');
    if (globalDelayRange && globalDelayValue) {
      const delay = settings.globalDelay || 1000;
      globalDelayRange.value = delay;
      globalDelayValue.textContent = delay;
    }
  }

  // Control button actions
  toggleExtension() {
    console.log('Toggle extension clicked');
    // Add extension toggle logic here
  }

  updateAllData() {
    console.log('Update all data clicked');
    // Add update logic here
  }

  emergencyStop() {
    console.log('Emergency stop clicked');
    // Add emergency stop logic here
  }

  clearDisplay() {
    console.log('Clear display clicked');
    // Add clear display logic here
  }

  clearCache() {
    console.log('Clear cache clicked');
    // Add clear cache logic here
  }

  resetAll() {
    if (confirm('آیا مطمئن هستید که می‌خواهید همه تنظیمات و داده‌ها را ریست کنید؟')) {
      console.log('Reset all clicked');
      // Add reset logic here
    }
  }

  async saveSite() {
    const siteName = document.getElementById('siteName').value.trim();
    const siteUrl = document.getElementById('siteUrl').value.trim();

    if (!siteName || !siteUrl) {
      alert('لطفا نام سایت و آدرس URL را وارد کنید.');
      return;
    }

    if (!siteUrl.includes('PRODUCT_NAME')) {
      alert('آدرس URL باید شامل PRODUCT_NAME باشد.');
      return;
    }

    try {
      // Check for duplicates (exclude current editing site)
      const duplicate = this.comparisonSites.find(site =>
        site.name.toLowerCase() === siteName.toLowerCase() &&
        (!this.currentEditingSite || site.id !== this.currentEditingSite.id)
      );

      if (duplicate) {
        alert('سایتی با این نام قبلاً اضافه شده است');
        return;
      }

      if (this.currentEditingSite) {
        // Update existing site
        const siteIndex = this.comparisonSites.findIndex(site => site.id === this.currentEditingSite.id);
        if (siteIndex !== -1) {
          this.comparisonSites[siteIndex] = {
            ...this.comparisonSites[siteIndex],
            name: siteName,
            url: siteUrl,
            faviconUrl: this.getFaviconUrl(siteUrl)
          };
          console.log(`✅ Updated site: ${siteName}`);
        }
        this.currentEditingSite = null;
      } else {
        // Add new site
        const newSite = {
          id: this.generateSiteId(),
          name: siteName,
          url: siteUrl,
          faviconUrl: this.getFaviconUrl(siteUrl)
        };
        this.comparisonSites.push(newSite);
        console.log(`✅ Added new site: ${siteName}`);
      }

      // Save to storage and re-render
      await this.saveComparisonSites();
      this.renderComparisonSites();

      // Reset form
      document.getElementById('siteName').value = '';
      document.getElementById('siteUrl').value = '';
      document.getElementById('popularSites').selectedIndex = 0;
      document.getElementById('addSiteForm').style.display = 'none';
      document.getElementById('addSiteBtn').style.display = 'block';

    } catch (error) {
      console.error('Error saving site:', error);
      alert('خطا در ذخیره سایت');
    }
  }

  showComparisonHelp() {
    console.log('Show comparison help clicked');
    const modal = document.getElementById('comparisonHelpModal');
    if (modal) {
      modal.style.display = 'flex';

      // Setup close button
      const closeBtn = document.getElementById('closeComparisonHelp');
      if (closeBtn) {
        closeBtn.onclick = () => {
          modal.style.display = 'none';
        };
      }

      // Close on overlay click
      modal.onclick = (e) => {
        if (e.target === modal) {
          modal.style.display = 'none';
        }
      };
    }
  }

  /**
   * Get value from storage with default fallback
   */
  async getStorage(key, defaultValue) {
    try {
      const result = await chrome.storage.local.get(key);
      return result[key] !== undefined ? result[key] : defaultValue;
    } catch (error) {
      console.error(`Error getting ${key} from storage:`, error);
      return defaultValue;
    }
  }

  /**
   * Set value in storage
   */
  async setStorage(key, value) {
    try {
      await chrome.storage.local.set({ [key]: value });
    } catch (error) {
      console.error(`Error setting ${key} in storage:`, error);
      throw error;
    }
  }

  /**
   * Load comparison sites from storage and display them
   */
  async loadComparisonSites() {
    try {
      const sites = await this.getStorage('digikala_extension_comparison_sites', this.getDefaultComparisonSites());
      this.comparisonSites = sites;
      this.renderComparisonSites();
      console.log(`✅ Loaded ${this.comparisonSites.length} comparison sites`);
    } catch (error) {
      console.error('Error loading comparison sites:', error);
      this.comparisonSites = this.getDefaultComparisonSites();
      this.renderComparisonSites();
    }
  }

  /**
   * Get default comparison sites
   */
  getDefaultComparisonSites() {
    return [
      {
        id: 'torob',
        name: 'Torob',
        url: 'https://torob.com/search/?query=PRODUCT_NAME',
        faviconUrl: 'https://torob.com/favicon.ico'
      },
      {
        id: 'digikalajet',
        name: 'DigiKala Jet',
        url: 'https://www.digikalajet.com/search/v2/result?q=PRODUCT_NAME',
        faviconUrl: 'https://www.digikalajet.com/favicon.ico'
      },
      {
        id: 'janebi',
        name: 'Janebi',
        url: 'https://janebi.com/search?q=PRODUCT_NAME',
        faviconUrl: 'https://janebi.com/favicon.ico'
      },
      {
        id: 'emalls',
        name: 'Emalls',
        url: 'https://www.emalls.ir/search?q=PRODUCT_NAME',
        faviconUrl: 'https://www.emalls.ir/favicon.ico'
      }
    ];
  }

  /**
   * Render comparison sites list
   */
  renderComparisonSites() {
    const comparisonSitesList = document.getElementById('comparisonSitesList');
    if (!comparisonSitesList) return;

    if (this.comparisonSites.length === 0) {
      comparisonSitesList.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🔍</div>
          <h4>هیچ سایت مقایسه‌ای تعریف نشده</h4>
          <p>برای شروع مقایسه قیمت، سایت‌های مورد نظر خود را اضافه کنید</p>
        </div>
      `;
      return;
    }

    const sitesHTML = this.comparisonSites.map(site => this.generateSiteHTML(site)).join('');
    comparisonSitesList.innerHTML = sitesHTML;
    this.setupSiteEventHandlers();
  }

  /**
   * Generate HTML for a comparison site
   */
  generateSiteHTML(site) {
    return `
      <div class="comparison-site-item" data-site-id="${site.id}">
        <div class="comparison-site-info">
          <div class="comparison-site-icon">
            <img src="${site.faviconUrl}" alt="${site.name}" class="site-favicon" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" style="display: none;" class="site-fallback-icon">
              <path d="M10.59 13.41c.41.39.41 1.03 0 1.42-.39.39-1.03.39-1.42 0a5.003 5.003 0 0 1 0-7.07l3.54-3.54a5.003 5.003 0 0 1 7.07 0 5.003 5.003 0 0 1 0 7.07l-1.49 1.49c.01-.82-.12-1.64-.4-2.42l.47-.48a2.982 2.982 0 0 0 0-4.24 2.982 2.982 0 0 0-4.24 0l-3.53 3.53a2.982 2.982 0 0 0 0 4.24zm2.82-4.24c.39-.39 1.03-.39 1.42 0a5.003 5.003 0 0 1 0 7.07l-3.54 3.54a5.003 5.003 0 0 1-7.07 0 5.003 5.003 0 0 1 0-7.07l1.49-1.49c-.01.82.12 1.64.4 2.42l-.47.48a2.982 2.982 0 0 0 0 4.24 2.982 2.982 0 0 0 4.24 0l3.53-3.53a2.982 2.982 0 0 0 0-4.24.973.973 0 0 1 0-1.42z" />
            </svg>
          </div>
          <div class="comparison-site-details">
            <div class="comparison-site-name">${site.name}</div>
            <div class="comparison-site-url">${this.truncateUrl(site.url)}</div>
          </div>
        </div>
        <div class="comparison-site-actions">
          <button class="comparison-site-action edit" title="ویرایش سایت" data-site-id="${site.id}">
            ✏️
          </button>
          <button class="comparison-site-action delete" title="حذف سایت" data-site-id="${site.id}">
            🗑️
          </button>
        </div>
      </div>
    `;
  }

  /**
   * Setup event handlers for site actions
   */
  setupSiteEventHandlers() {
    const comparisonSitesList = document.getElementById('comparisonSitesList');
    if (!comparisonSitesList) return;

    // Remove site buttons
    const removeButtons = comparisonSitesList.querySelectorAll('.comparison-site-action.delete');
    removeButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const siteId = btn.dataset.siteId;
        this.handleRemoveSite(siteId);
      });
    });

    // Edit site buttons
    const editButtons = comparisonSitesList.querySelectorAll('.comparison-site-action.edit');
    editButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const siteId = btn.dataset.siteId;
        this.handleEditSite(siteId);
      });
    });
  }

  /**
   * Handle removing a comparison site
   */
  async handleRemoveSite(siteId) {
    const siteIndex = this.comparisonSites.findIndex(site => site.id === siteId);
    if (siteIndex === -1) {
      console.warn(`Site not found: ${siteId}`);
      return;
    }

    const site = this.comparisonSites[siteIndex];
    const confirmed = confirm(`آیا مطمئن هستید که می‌خواهید سایت "${site.name}" را حذف کنید؟`);

    if (confirmed) {
      this.comparisonSites.splice(siteIndex, 1);
      await this.saveComparisonSites();
      this.renderComparisonSites();
      this.showMessage(`سایت "${site.name}" حذف شد`, 'success');
    }
  }

  /**
   * Handle editing a comparison site
   */
  handleEditSite(siteId) {
    const site = this.comparisonSites.find(s => s.id === siteId);
    if (!site) {
      console.warn(`Site not found: ${siteId}`);
      return;
    }

    // Populate edit form
    const siteNameInput = document.getElementById('siteName');
    const siteUrlInput = document.getElementById('siteUrl');
    if (siteNameInput) siteNameInput.value = site.name;
    if (siteUrlInput) siteUrlInput.value = site.url;

    // Show form and set editing mode
    const addSiteForm = document.getElementById('addSiteForm');
    const addSiteBtn = document.getElementById('addSiteBtn');
    if (addSiteForm) addSiteForm.style.display = 'block';
    if (addSiteBtn) addSiteBtn.style.display = 'none';

    this.currentEditingSite = site;
  }

  /**
   * Save comparison sites to storage
   */
  async saveComparisonSites() {
    try {
      await this.setStorage('digikala_extension_comparison_sites', this.comparisonSites);
      console.log('✅ Comparison sites saved');
    } catch (error) {
      console.error('Error saving comparison sites:', error);
    }
  }

  /**
   * Truncate URL for display
   */
  truncateUrl(url) {
    if (url.length > 50) {
      return url.substring(0, 47) + '...';
    }
    return url;
  }

  /**
   * Generate site ID
   */
  generateSiteId() {
    return `site_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get favicon URL for a site
   */
  getFaviconUrl(url) {
    try {
      const domain = new URL(url.replace('PRODUCT_NAME', 'test')).origin;
      return `${domain}/favicon.ico`;
    } catch (error) {
      return null;
    }
  }
}

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.prizoFullPageUI = new PrizoFullPageUI();
});

// Make it available globally for debugging
if (typeof window !== 'undefined') {
  window.PrizoFullPageUI = PrizoFullPageUI;

  // Global test functions for debugging Smart Cart
  window.testFullpageSmartCart = function () {
    console.log('🧪 Testing fullpage Smart Cart...');
    if (window.prizoFullPageUI) {
      return window.prizoFullPageUI.addTestSmartCartData();
    } else {
      console.error('❌ PrizoFullPageUI not initialized');
    }
  };

  window.clearFullpageSmartCart = function () {
    console.log('🧹 Clearing fullpage Smart Cart...');
    if (window.prizoFullPageUI) {
      chrome.storage.local.set({ digikala_extension_smart_cart_items: [] }).then(() => {
        window.prizoFullPageUI.smartCartItems = [];
        window.prizoFullPageUI.renderSmartCartData([]);
        window.prizoFullPageUI.updateSmartCartSummary([]);
        console.log('✅ Smart Cart cleared');
      });
    } else {
      console.error('❌ PrizoFullPageUI not initialized');
    }
  };

  window.checkSmartCartStorage = function () {
    console.log('🔍 Checking Smart Cart storage vs UI state...');
    if (window.prizoFullPageUI) {
      chrome.storage.local.get(['digikala_extension_smart_cart_items']).then(result => {
        const storageItems = result.digikala_extension_smart_cart_items || [];
        const uiItems = window.prizoFullPageUI.smartCartItems || [];

        console.log('📦 Storage items:', storageItems.length, storageItems);
        console.log('📱 UI items:', uiItems.length, uiItems);
        console.log('🔄 Current tab:', window.prizoFullPageUI.getCurrentTab());

        if (storageItems.length !== uiItems.length) {
          console.warn('⚠️ Mismatch detected! Storage has', storageItems.length, 'items but UI shows', uiItems.length);

          // Force sync
          console.log('🔧 Force syncing...');
          window.prizoFullPageUI.smartCartItems = storageItems;
          if (window.prizoFullPageUI.getCurrentTab() === 'smart-cart') {
            window.prizoFullPageUI.renderSmartCartData(storageItems);
            window.prizoFullPageUI.updateSmartCartSummary(storageItems);
          }
          console.log('✅ Force sync completed');
        } else {
          console.log('✅ Storage and UI are in sync');
        }
      });
    } else {
      console.error('❌ PrizoFullPageUI not initialized');
    }
  };

  window.forceRefreshSmartCart = function () {
    console.log('🔄 Force refreshing Smart Cart...');
    if (window.prizoFullPageUI) {
      window.prizoFullPageUI.loadSmartCartData().then(() => {
        console.log('✅ Smart Cart force refreshed');
      });
    } else {
      console.error('❌ PrizoFullPageUI not initialized');
    }
  };

  window.manualStorageCheck = function () {
    console.log('🔍 Manual storage check...');
    chrome.storage.local.get(null).then(result => {
      console.log('📦 All storage data:', result);
      if (result.digikala_extension_smart_cart_items) {
        console.log('✅ Smart Cart items found in storage:', result.digikala_extension_smart_cart_items.length, result.digikala_extension_smart_cart_items);
      } else {
        console.log('❌ No digikala_extension_smart_cart_items found in storage');
      }
    });
  };

  window.testStorageListener = function () {
    console.log('🧪 Testing storage listener...');
    // Add a test item to trigger storage change
    chrome.storage.local.get(['digikala_extension_smart_cart_items']).then(result => {
      const currentItems = result.digikala_extension_smart_cart_items || [];
      const testItem = {
        id: 'listener_test_' + Date.now(),
        productId: 'test',
        productTitle: 'Storage Listener Test',
        price: 1000,
        quantity: 1,
        addedAt: Date.now()
      };
      const updatedItems = [...currentItems, testItem];

      console.log('📝 Adding test item to trigger storage change...');
      return chrome.storage.local.set({ digikala_extension_smart_cart_items: updatedItems });
    }).then(() => {
      console.log('✅ Test item added, check console for storage change events');
    });
  };

  window.testEnhancedSmartCart = function () {
    console.log('🧪 Testing enhanced Smart Cart with management features...');
    if (window.prizoFullPageUI) {
      const enhancedTestItems = [
        {
          id: 'enhanced_test_1_' + Date.now(),
          productId: 'dkp-enhanced-1',
          productTitle: 'تست محصول اول - گوشی موبایل سامسونگ',
          productUrl: 'https://www.digikala.com/product/dkp-enhanced-1/',
          productImage: 'https://dkstatics-public.digikala.com/digikala-products/120x120_dir/test1.jpg',
          price: 25000000,
          quantity: 2,
          variantId: 'variant_black_128gb',
          variantDetails: {
            color: { id: 'black', title: 'مشکی' },
            size: { id: '128gb', title: '128 گیگابایت' },
            warranty: { id: 'official', title: 'گارانتی رسمی' }
          },
          availableVariants: {
            colors: [
              { id: 'black', title: 'مشکی' },
              { id: 'white', title: 'سفید' },
              { id: 'blue', title: 'آبی' }
            ],
            sizes: [
              { id: '128gb', title: '128 گیگابایت' },
              { id: '256gb', title: '256 گیگابایت' },
              { id: '512gb', title: '512 گیگابایت' }
            ],
            warranties: [
              { id: 'official', title: 'گارانتی رسمی' },
              { id: 'distributor', title: 'گارانتی نمایندگی' }
            ]
          },
          selectedSeller: 'digikala',
          originalPrice: 28000000,
          addedAt: Date.now() - 3600000,
          updatedAt: Date.now() - 1800000
        },
        {
          id: 'enhanced_test_2_' + Date.now(),
          productId: 'dkp-enhanced-2',
          productTitle: 'تست محصول دوم - هدفون بی‌سیم',
          productUrl: 'https://www.digikala.com/product/dkp-enhanced-2/',
          productImage: null,
          price: 5500000,
          quantity: 1,
          variantId: null,
          variantDetails: null,
          selectedSeller: 'all',
          addedAt: Date.now() - 7200000,
          updatedAt: Date.now() - 3600000
        }
      ];

      return chrome.storage.local.set({ digikala_extension_smart_cart_items: enhancedTestItems }).then(() => {
        window.prizoFullPageUI.smartCartItems = enhancedTestItems;
        window.prizoFullPageUI.renderSmartCartData(enhancedTestItems);
        window.prizoFullPageUI.updateSmartCartSummary(enhancedTestItems);
        console.log('✅ Enhanced Smart Cart test data added with management features');
        console.log('📋 Features to test:');
        console.log('  • Quantity controls (+/- buttons and direct input)');
        console.log('  • Seller selection dropdown');
        console.log('  • Variation selection (first item has color, size, warranty)');
        console.log('  • Price refresh button');
        console.log('  • Remove item button');
      });
    } else {
      console.error('❌ PrizoFullPageUI not initialized');
    }
  };

  window.testQuantityChange = function (itemId, newQuantity) {
    console.log(`🧪 Testing quantity change for item ${itemId} to ${newQuantity}`);
    if (window.prizoFullPageUI) {
      return window.prizoFullPageUI.setQuantity(itemId, newQuantity);
    } else {
      console.error('❌ PrizoFullPageUI not initialized');
    }
  };

  window.testSellerChange = function (itemId, sellerId) {
    console.log(`🧪 Testing seller change for item ${itemId} to ${sellerId}`);
    if (window.prizoFullPageUI) {
      return window.prizoFullPageUI.changeSeller(itemId, sellerId);
    } else {
      console.error('❌ PrizoFullPageUI not initialized');
    }
  };

  window.testVariationChange = function (itemId, variationType, value) {
    console.log(`🧪 Testing variation change for item ${itemId}: ${variationType} = ${value}`);
    if (window.prizoFullPageUI) {
      return window.prizoFullPageUI.changeVariation(itemId, variationType, value);
    } else {
      console.error('❌ PrizoFullPageUI not initialized');
    }
  };

  window.testOptimization = function () {
    console.log('🧪 Testing Smart Cart optimization...');
    console.log('EnhancedSmartCartOptimizer available:', !!window.EnhancedSmartCartOptimizer);
    console.log('BasketOptimizer available:', !!window.BasketOptimizer);
    console.log('BasketValidator available:', !!window.BasketValidator);
    console.log('CostCalculator available:', !!window.CostCalculator);

    if (window.prizoFullPageUI && window.prizoFullPageUI.smartCartOptimizer) {
      console.log('✅ Smart Cart Optimizer is initialized');
      return window.prizoFullPageUI.triggerCartOptimization('manual_test');
    } else {
      console.error('❌ Smart Cart Optimizer not initialized');
      return null;
    }
  };

  window.testOptimizerComponents = function () {
    console.log('🔍 Testing optimizer component availability:');
    console.log('EnhancedSmartCartOptimizer:', typeof window.EnhancedSmartCartOptimizer);
    console.log('BasketOptimizer:', typeof window.BasketOptimizer);
    console.log('BasketValidator:', typeof window.BasketValidator);
    console.log('CostCalculator:', typeof window.CostCalculator);
    console.log('ExhaustiveSearchOptimizer:', typeof window.ExhaustiveSearchOptimizer);
    console.log('GreedyLocalSearchOptimizer:', typeof window.GreedyLocalSearchOptimizer);

    // Check if we can create instances
    if (window.BasketValidator) {
      try {
        const validator = new window.BasketValidator();
        console.log('✅ BasketValidator instance created:', validator);
      } catch (error) {
        console.error('❌ BasketValidator creation failed:', error);
      }
    }

    if (window.CostCalculator) {
      try {
        const costCalc = new window.CostCalculator();
        console.log('✅ CostCalculator instance created:', costCalc);
      } catch (error) {
        console.error('❌ CostCalculator creation failed:', error);
      }
    }

    // Test simple optimization
    if (window.BasketOptimizer) {
      const optimizer = new window.BasketOptimizer();
      const testData = {
        products: [
          {
            id: "test1",
            sellers: [
              { sellerId: "seller1", price: 100, inventory: 5, shipsDirectly: true }
            ]
          }
        ],
        sellers: {
          "seller1": { shippingCost: 10 }
        },
        marketplaceShipping: 5,
        optimizationMode: "COST"
      };

      return optimizer.optimizeBasket(testData).then(result => {
        console.log('🧮 Test optimization result:', result);
        return result;
      }).catch(error => {
        console.error('❌ Test optimization failed:', error);
        return null;
      });
    }
  };

  // Test function for optimize cart button
  window.testOptimizeCartButton = async function () {
    console.log('🧪 Testing Optimize Cart button functionality...');

    if (window.prizoFullPageUI) {
      // Add some test cart items if none exist
      if (!window.prizoFullPageUI.smartCartItems || window.prizoFullPageUI.smartCartItems.length === 0) {
        console.log('📦 Adding test cart items...');
        window.prizoFullPageUI.smartCartItems = [
          {
            id: 'test_opt_1',
            productId: 'dkp-test-1',
            productTitle: 'Test Product 1',
            price: 100000,
            quantity: 2,
            addedAt: Date.now(),
            updatedAt: Date.now(),
            sellers: [
              { id: 'seller1', name: 'Seller 1', price: 100000, shipsDirectly: true },
              { id: 'seller2', name: 'Seller 2', price: 95000, shipsDirectly: false }
            ],
            selectedSeller: 'all'
          },
          {
            id: 'test_opt_2',
            productId: 'dkp-test-2',
            productTitle: 'Test Product 2',
            price: 200000,
            quantity: 1,
            addedAt: Date.now(),
            updatedAt: Date.now(),
            sellers: [
              { id: 'seller1', name: 'Seller 1', price: 200000, shipsDirectly: true },
              { id: 'seller3', name: 'Seller 3', price: 180000, shipsDirectly: true }
            ],
            selectedSeller: 'all'
          }
        ];

        // Save to storage
        await window.prizoFullPageUI.saveSmartCartData();
      }

      // Trigger the optimize cart button click
      const optimizeBtn = document.getElementById('optimize-cart-btn');
      if (optimizeBtn) {
        optimizeBtn.click();
        console.log('✅ Optimize cart button clicked');
      } else {
        console.error('❌ Optimize cart button not found');
      }
    } else {
      console.error('❌ PrizoFullPageUI not available');
    }
  };
}