/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Cart Controller - Handles shopping cart pages
 */
class CartController extends BaseController {
  constructor(services) {
    super(services, 'cart');
    this.cartItems = [];
    this.cartObserver = null;
    this.lastCartHash = null;
  }

  async initialize() {
    console.log('🔄 Initializing cart controller');
    
    // Check if we're on a cart page
    if (!this.isCartPage()) {
      console.log('❌ Not a cart page, skipping initialization');
      return;
    }

    // Set up periodic cart checking
    this.setupCartMonitoring();
  }

  isCartPage() {
    const url = window.location.href;
    const path = window.location.pathname;
    
    // Check for cart page patterns
    const cartPagePatterns = [
      /\/cart/,
      /\/checkout/,
      /\/basket/
    ];

    return cartPagePatterns.some(pattern => pattern.test(url) || pattern.test(path)) ||
           document.querySelector('[data-testid="cart"]') ||
           document.querySelector('.cart-container') ||
           document.querySelector('[data-testid="cart-item"]');
  }

  setupCartMonitoring() {
    // Find cart container to observe
    const cartContainer = this.findCartContainer();
    
    if (!cartContainer) {
      console.log('⚠️ Cart container not found, falling back to document observation');
      // Fall back to observing document body if specific cart container not found
      this.observeCartChanges(document.body);
      return;
    }
    
    console.log('🔍 Setting up cart mutation observer on container:', cartContainer);
    this.observeCartChanges(cartContainer);
  }

  findCartContainer() {
    // Try to find the most specific cart container first
    const selectors = [
      '[data-testid="cart"]',
      '.cart-container',
      '[class*="cart-items"]',
      '[class*="shopping-cart"]',
      // Fallback to containers that might contain cart items
      'main',
      '[role="main"]'
    ];

    for (const selector of selectors) {
      const container = document.querySelector(selector);
      if (container) {
        // Verify this container actually contains or can contain cart items
        const hasCartItems = container.querySelector('[data-testid="cart-item"]') ||
                           container.querySelector('.cart-item') ||
                           container.querySelector('[data-product-id]');
        
        if (hasCartItems || selector.includes('cart') || selector.includes('main')) {
          return container;
        }
      }
    }
    
    return null;
  }

  observeCartChanges(container) {
    // Disconnect existing observer if any
    if (this.cartObserver) {
      this.cartObserver.disconnect();
    }

    // Create new mutation observer
    this.cartObserver = new MutationObserver((mutations) => {
      // Only process if controller is active
      if (!this.isActive) {
        return;
      }

      // Check if any mutations are relevant to cart items
      let hasRelevantChanges = false;
      
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          // Check if added or removed nodes include cart items
          const allNodes = [...mutation.addedNodes, ...mutation.removedNodes];
          for (const node of allNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              if (this.isCartItemOrContainer(node)) {
                hasRelevantChanges = true;
                break;
              }
            }
          }
        }
        
        if (hasRelevantChanges) break;
      }

      // Debounce the cart changes check to avoid excessive processing
      if (hasRelevantChanges) {
        this.debouncedCartCheck();
      }
    });

    // Start observing with childList and subtree options
    this.cartObserver.observe(container, {
      childList: true,
      subtree: true
    });

    console.log('✅ Cart mutation observer started');
  }

  isCartItemOrContainer(element) {
    // Check if element is a cart item or contains cart items
    const cartItemSelectors = [
      '[data-testid="cart-item"]',
      '.cart-item',
      '[data-product-id]',
      '[class*="cart-item"]',
      '[class*="product-item"]'
    ];

    return cartItemSelectors.some(selector => 
      element.matches && element.matches(selector) || 
      (element.querySelector && element.querySelector(selector))
    );
  }

  debouncedCartCheck() {
    // Clear existing timeout
    if (this.cartCheckTimeout) {
      clearTimeout(this.cartCheckTimeout);
    }

    // Debounce cart changes check to avoid excessive calls
    this.cartCheckTimeout = setTimeout(() => {
      this.checkForCartChanges();
    }, 500);
  }

  setupEventListeners() {
    // Listen for cart item changes
    this.cartChangeHandler = this.debounce(() => {
      if (this.isActive) {
        this.processCartItems();
      }
    }, 1000);

    // Listen for various cart-related events
    document.addEventListener('click', this.cartChangeHandler);
    document.addEventListener('change', this.cartChangeHandler);
  }

  removeEventListeners() {
    if (this.cartChangeHandler) {
      document.removeEventListener('click', this.cartChangeHandler);
      document.removeEventListener('change', this.cartChangeHandler);
      this.cartChangeHandler = null;
    }

    // Disconnect mutation observer
    if (this.cartObserver) {
      this.cartObserver.disconnect();
      this.cartObserver = null;
      console.log('🔌 Cart mutation observer disconnected');
    }

    // Clear any pending timeouts
    if (this.cartCheckTimeout) {
      clearTimeout(this.cartCheckTimeout);
      this.cartCheckTimeout = null;
    }
  }

  cleanup() {
    this.cartItems = [];
    this.lastCartHash = null;
    
    // Ensure observer is disconnected during cleanup
    if (this.cartObserver) {
      this.cartObserver.disconnect();
      this.cartObserver = null;
    }

    // Clear any pending timeouts
    if (this.cartCheckTimeout) {
      clearTimeout(this.cartCheckTimeout);
      this.cartCheckTimeout = null;
    }
  }

  async isCartFeatureEnabled() {
    try {
      const result = await ExtensionCore.BrowserCompat.safeStorageGet(['cartFeatureEnabled'], { cartFeatureEnabled: true });
      return result.cartFeatureEnabled !== undefined ? result.cartFeatureEnabled : true;
    } catch (error) {
      console.warn('⚠️ Failed to check cart feature setting, assuming enabled:', error);
      return true;
    }
  }

  async processInitialElements() {
    // Check cartFeatureEnabled setting from storage instead of showCartPrices
    const cartFeatureEnabled = await this.isCartFeatureEnabled();

    if (!cartFeatureEnabled) {
      console.log('🚫 Cart feature disabled - skipping cart processing');
      return;
    }

    console.log('✅ Cart feature enabled - processing cart items');
    console.log('🛒 Processing initial cart items');
    await this.processCartItems();
  }

  async processCartItems() {
    try {
      // Check cartFeatureEnabled setting before processing
      const cartFeatureEnabled = await this.isCartFeatureEnabled();

      if (!cartFeatureEnabled) {
        console.log('🚫 Cart feature disabled - skipping cart processing');
        return;
      }

      console.log('🔄 Processing cart items');

      // Wait for cart items to load
      const cartItems = await this.waitForCartItems();
      
      if (cartItems.length === 0) {
        console.log('ℹ️ No cart items found');
        this.showEmptyCartMessage();
        return;
      }

      console.log(`🛒 Found ${cartItems.length} cart items`);
      this.cartItems = cartItems;

      // Process each cart item
      const promises = cartItems.map(item => this.processCartItem(item));
      await Promise.allSettled(promises);

      this.services.eventBus.emit('cart:processed', { 
        itemCount: cartItems.length 
      });

      console.log(`✅ Successfully processed ${cartItems.length} cart items`);

    } catch (error) {
      console.error('❌ Error processing cart items:', error);
      this.showNotification({
        type: 'warning',
        title: 'خطا در بارگذاری سبد خرید',
        message: 'امکان نمایش اطلاعات قیمت برای برخی محصولات وجود ندارد',
        autoHide: true,
        duration: 5000
      });
    }
  }

  async waitForCartItems() {
    if (this.services.domManager && this.services.domManager.waitForCartItemsAndProcess) {
      return await this.services.domManager.waitForCartItemsAndProcess();
    }

    // Fallback cart item detection
    const selectors = [
      '[data-testid="cart-item"]',
      '.cart-item',
      '[data-product-id]'
    ];

    for (const selector of selectors) {
      const items = await this.waitForElements(selector, 10, 1000);
      if (items.length > 0) {
        return items.filter(item => this.isValidCartItem(item));
      }
    }

    return [];
  }

  isValidCartItem(item) {
    // Check if the item has product-related content
    const hasProductContent = item.querySelector('img') || 
                             item.querySelector('[data-product-id]') || 
                             item.querySelector('a[href*="/dp/"]') ||
                             item.querySelector('a[href*="/product/"]');
    
    return hasProductContent && this.isElementVisible(item);
  }

  async processCartItem(cartItem) {
    try {
      // Extract product ID
      const productId = this.extractCartItemProductId(cartItem);
      if (!productId) {
        console.log('⚠️ Could not extract product ID from cart item');
        return;
      }

      if (this.processedElements.has(cartItem)) {
        console.log(`⏭️ Cart item for product ${productId} already processed`);
        return;
      }

      console.log(`🔄 Processing cart item for product ${productId}`);

      // Fetch cart item data
      const dataResult = await this.fetchCartItemData(productId);
      if (!dataResult) {
        console.log(`⚠️ No data found for product ${productId}`);
        return;
      }

      // Extract cart item details
      const { monthlyLowPrice, cartItemDetails } = await this.extractCartItemDetails(dataResult, cartItem);

      // Update cart item UI
      this.updateCartItemUI(cartItem, { monthlyLowPrice, cartItemDetails });

      this.processedElements.add(cartItem);
      console.log(`✅ Successfully processed cart item for product ${productId}`);

    } catch (error) {
      console.error('❌ Error processing cart item:', error);
    }
  }

  /**
   * Extract cart item product ID
   * @param {HTMLElement} cartItem - The cart item DOM element
   * @returns {string|null} - The extracted product ID or null if not found
   */
  extractCartItemProductId(cartItem) {
    if (this.services.domManager && this.services.domManager.extractProductIdFromCartItem) {
      return this.services.domManager.extractProductIdFromCartItem(cartItem);
    }

    // Enhanced fallback product ID extraction (matching DOM manager logic)
    console.log('🔍 Using fallback product ID extraction for cart item');

    // 1. Check data attributes
    if (cartItem.dataset.productId) {
      return cartItem.dataset.productId;
    }

    // 2. Check various URL patterns
    const productLinks = cartItem.querySelectorAll('a[href]');
    for (const link of productLinks) {
      const href = link.getAttribute('href');
      
      const patterns = [
        /\/dp\/(\d+)\//,
        /\/product\/(\d+)\//,
        /\/dkp-(\d+)/,
        /product-id[=:](\d+)/,
        /\/(\d{6,})\//,
        /[?&]id=(\d+)/,
        /\/([0-9]+)$/,
        /dkp(\d+)/,
        /product\/dkp-(\d+)/
      ];
      
      for (const pattern of patterns) {
        const match = href.match(pattern);
        if (match && match[1]) {
          console.log('✅ Found product ID from fallback URL pattern:', match[1]);
          return match[1];
        }
      }
    }

    // 3. Check text content patterns
    const textContent = cartItem.textContent;
    const idPatterns = [
      /دیجی‌کالا-(\d+)/,
      /DKP-?(\d+)/i,
      /کد[:\s]*(\d+)/,
      /شناسه[:\s]*(\d+)/
    ];

    for (const pattern of idPatterns) {
      const match = textContent.match(pattern);
      if (match && match[1]) {
        console.log('✅ Found product ID from fallback text content:', match[1]);
        return match[1];
      }
    }

    console.log('❌ Fallback product ID extraction failed');
    return null;
  }

  /**
   * Fetch cart item data using the product ID
   * @param {string} productId - The product ID to fetch data for
   * @returns {Promise<Object|null>} - The fetched product data or null if failed
   */
  async fetchCartItemData(productId) {
    console.log(`📡 Fetching product data for cart item: ${productId}`);
    const dataResult = await this.services.dataManager.fetchProductDataForProductPage(productId);
    console.log(`📊 Data result for product ${productId}:`, dataResult);
    return dataResult;
  }

  /**
   * Extract cart item details from data result
   * @param {Object} dataResult - The fetched product data
   * @param {HTMLElement} cartItem - The cart item DOM element
   * @returns {Promise<Object>} - Object containing monthlyLowPrice and cartItemDetails
   */
  async extractCartItemDetails(dataResult, cartItem) {
    // Extract product ID for logging purposes
    const productId = this.extractCartItemProductId(cartItem);
    
    // Extract monthly low price
    console.log(`💰 Extracting monthly low price for product ${productId}`);
    const monthlyLowPrice = await this.services.dataManager.extractMonthlyLowPrice(dataResult, productId);
    console.log(`💰 Monthly low price for product ${productId}: ${monthlyLowPrice}`);

    // Extract additional cart item details
    console.log(`📋 Extracting cart item details for product ${productId}`);
    const cartItemDetails = await this.services.dataManager.extractCartItemDetails(dataResult, cartItem);
    console.log(`📋 Cart item details for product ${productId}:`, cartItemDetails);

    return { monthlyLowPrice, cartItemDetails };
  }

  /**
   * Update cart item UI with enhanced price information
   * @param {HTMLElement} cartItem - The cart item DOM element
   * @param {Object} priceData - Object containing monthlyLowPrice and cartItemDetails
   */
  updateCartItemUI(cartItem, { monthlyLowPrice, cartItemDetails }) {
    // Use the DOM manager's addCartPriceInfo method if available
    if (this.services.domManager && typeof this.services.domManager.addCartPriceInfo === 'function') {
      this.services.domManager.addCartPriceInfo(cartItem, {
        monthlyLowPrice,
        cartItemDetails
      });
    } else {
      console.warn('⚠️ DOMManager not available, cannot add cart price info');
      // Fallback: Add simple price info directly
      this.addSimpleCartPriceInfo(cartItem, monthlyLowPrice);
    }
  }

  addCartPriceInfo(cartItem, priceData) {
    // Use the DOM manager's addCartPriceInfo method if available
    if (this.services.domManager && typeof this.services.domManager.addCartPriceInfo === 'function') {
      this.services.domManager.addCartPriceInfo(cartItem, priceData);
    } else {
      console.warn('⚠️ DOMManager not available, cannot add cart price info');
      // Fallback: Add simple price info directly
      const monthlyLowPrice = typeof priceData === 'number' ? priceData : priceData?.monthlyLowPrice;
      this.addSimpleCartPriceInfo(cartItem, monthlyLowPrice);
    }
  }

  addSimpleCartPriceInfo(cartItem, monthlyLowPrice) {
    try {
      // Create a modern styled price info element
      const existingPriceInfo = cartItem.querySelector('.cart-monthly-price-info');
      if (existingPriceInfo) {
        existingPriceInfo.remove();
      }

      // Use StyleService if available, otherwise fallback to inline styles
      let priceInfoElement;
      if (window.StyleService && this.services.styleService) {
        priceInfoElement = this.services.styleService.createPriceElement('cartPrice', {
          monthlyLowPrice
        });
      } else {
        // Fallback with modern styling
        priceInfoElement = document.createElement('div');
        priceInfoElement.className = 'cart-monthly-price-info';
        
        const formattedPrice = Math.round(monthlyLowPrice / 10).toLocaleString('fa-IR');
        priceInfoElement.innerHTML = `
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 14px;">💰</span>
            <div style="flex: 1;">
              <div style="font-weight: 700; color: white;">کمترین قیمت ۳۰ روز اخیر</div>
              <div style="margin-top: 2px; font-size: 11px; color: rgba(255,255,255,0.9);">${formattedPrice} تومان</div>
            </div>
          </div>
        `;
      }

      // Find a good place to insert the price info
      const priceContainer = cartItem.querySelector('.c-cart-item-price, .cart-item-price, [class*="price"]');
      if (priceContainer) {
        priceContainer.appendChild(priceInfoElement);
      } else {
        cartItem.appendChild(priceInfoElement);
      }

      // Add a subtle entrance animation
      if (priceInfoElement.animate) {
        priceInfoElement.animate([
          { opacity: 0, transform: 'translateY(10px)' },
          { opacity: 1, transform: 'translateY(0)' }
        ], {
          duration: 300,
          easing: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)'
        });
      }

    } catch (error) {
      console.error('❌ Error adding simple cart price info:', error);
    }
  }

  checkForCartChanges() {
    const currentCartItems = this.getCurrentCartItems();
    const currentHash = this.generateCartHash(currentCartItems);

    if (currentHash !== this.lastCartHash) {
      console.log('🔄 Cart changes detected');
      this.lastCartHash = currentHash;
      this.processCartItems();
    }
  }

  getCurrentCartItems() {
    const selectors = [
      '[data-testid="cart-item"]',
      '.cart-item'
    ];

    for (const selector of selectors) {
      const items = Array.from(document.querySelectorAll(selector));
      if (items.length > 0) {
        return items.filter(item => this.isValidCartItem(item));
      }
    }

    return [];
  }

  generateCartHash(items) {
    return items.map(item => {
      const productId = this.extractCartItemProductId(item);
      const quantity = this.extractCartItemQuantity(item);
      return `${productId}-${quantity}`;
    }).join('|');
  }

  extractCartItemQuantity(cartItem) {
    const quantitySelectors = [
      'input[type="number"]',
      '.quantity-input',
      '[data-testid="quantity"]'
    ];

    for (const selector of quantitySelectors) {
      const quantityElement = cartItem.querySelector(selector);
      if (quantityElement) {
        return quantityElement.value || quantityElement.textContent || '1';
      }
    }

    return '1';
  }

  showEmptyCartMessage() {
    const existingMessage = document.querySelector('.extension-empty-cart-message');
    if (existingMessage) return;

    const message = document.createElement('div');
    message.className = 'extension-empty-cart-message';
    message.style.cssText = `
      text-align: center;
      padding: 20px;
      color: #6c757d;
      font-size: 14px;
    `;
    message.textContent = 'سبد خرید خالی است';

    const cartContainer = document.querySelector('[data-testid="cart"]') || 
                         document.querySelector('.cart-container') ||
                         document.body;

    cartContainer.appendChild(message);
  }

  isElementVisible(element) {
    if (this.services.domManager) {
      return this.services.domManager.isElementVisible(element);
    }
    
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    
    return rect.width > 0 && 
           rect.height > 0 && 
           style.display !== 'none' && 
           style.visibility !== 'hidden';
  }

  async processNewElements() {
    // Check cartFeatureEnabled setting before processing new elements
    const cartFeatureEnabled = await this.isCartFeatureEnabled();

    if (!cartFeatureEnabled) {
      console.log('🚫 Cart feature disabled - skipping new element processing');
      return;
    }

    // Check for new cart items
    const currentItems = this.getCurrentCartItems();
    const newItems = currentItems.filter(item =>
      !this.processedElements.has(item)
    );

    if (newItems.length > 0) {
      console.log(`🛒 Found ${newItems.length} new cart items`);
      const promises = newItems.map(item => this.processCartItem(item));
      await Promise.allSettled(promises);
    }
  }

  isElementRelevant(element) {
    const selectors = [
      '[data-testid="cart-item"]',
      '.cart-item',
      '[data-product-id]'
    ];

    return selectors.some(selector => 
      element.matches(selector) || element.querySelector(selector)
    );
  }

  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  async clearCartPriceInfo() {
    if (this.services.domManager && this.services.domManager.removeCartPriceInfo) {
      this.services.domManager.removeCartPriceInfo();
    } else {
      // Fallback removal
      const priceInfoElements = document.querySelectorAll('.cart-monthly-price-info, .cart-selected-shipping-info');
      priceInfoElements.forEach(element => element.remove());
    }

    console.log('🧹 Cart price information cleared');
  }
}

window.CartController = CartController;