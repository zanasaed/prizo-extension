/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Validation Utils - Input validation and sanitization utilities
 */
class ValidationUtils {
  static validateProductId(productId) {
    if (!productId) {
      return { valid: false, error: 'Product ID is required' };
    }

    if (typeof productId !== 'string' && typeof productId !== 'number') {
      return { valid: false, error: 'Product ID must be a string or number' };
    }

    const idString = String(productId);
    
    if (!/^\d+$/.test(idString)) {
      return { valid: false, error: 'Product ID must contain only digits' };
    }

    if (idString.length < 1 || idString.length > 15) {
      return { valid: false, error: 'Product ID must be between 1-15 digits' };
    }

    return { valid: true, productId: idString };
  }

  static validateURL(url) {
    if (!url || typeof url !== 'string') {
      return { valid: false, error: 'URL is required and must be a string' };
    }

    try {
      const urlObj = new URL(url);
      
      // Check if it's HTTP or HTTPS
      if (!['http:', 'https:'].includes(urlObj.protocol)) {
        return { valid: false, error: 'URL must use HTTP or HTTPS protocol' };
      }

      // Check for basic domain validation
      if (!urlObj.hostname || urlObj.hostname.length < 3) {
        return { valid: false, error: 'Invalid hostname' };
      }

      return { valid: true, url: urlObj.href };
      
    } catch (error) {
      return { valid: false, error: 'Invalid URL format' };
    }
  }

  static validatePrice(price) {
    if (price === null || price === undefined) {
      return { valid: false, error: 'Price is required' };
    }

    const numericPrice = Number(price);
    
    if (isNaN(numericPrice)) {
      return { valid: false, error: 'Price must be a valid number' };
    }

    if (numericPrice < 0) {
      return { valid: false, error: 'Price cannot be negative' };
    }

    if (numericPrice > 999999999999) { // 999 billion limit
      return { valid: false, error: 'Price exceeds maximum allowed value' };
    }

    return { valid: true, price: numericPrice };
  }

  static sanitizeText(text, maxLength = 1000) {
    if (!text) return '';
    
    if (typeof text !== 'string') {
      text = String(text);
    }

    // Remove potentially dangerous characters
    text = text.replace(/[<>'"&]/g, (match) => {
      const escapes = {
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
        '&': '&amp;'
      };
      return escapes[match];
    });

    // Trim whitespace
    text = text.trim();

    // Limit length
    if (text.length > maxLength) {
      text = text.substring(0, maxLength) + '...';
    }

    return text;
  }

  static sanitizeHTML(html) {
    if (!html) return '';
    
    // Create a temporary div to parse HTML
    const tempDiv = document.createElement('div');
    tempDiv.textContent = html;
    return tempDiv.innerHTML;
  }

  static validateEmail(email) {
    if (!email || typeof email !== 'string') {
      return { valid: false, error: 'Email is required' };
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    if (!emailRegex.test(email)) {
      return { valid: false, error: 'Invalid email format' };
    }

    if (email.length > 254) {
      return { valid: false, error: 'Email too long' };
    }

    return { valid: true, email: email.toLowerCase().trim() };
  }

  static validateNumber(value, min = null, max = null) {
    const num = Number(value);
    
    if (isNaN(num)) {
      return { valid: false, error: 'Value must be a valid number' };
    }

    if (min !== null && num < min) {
      return { valid: false, error: `Value must be at least ${min}` };
    }

    if (max !== null && num > max) {
      return { valid: false, error: `Value must be at most ${max}` };
    }

    return { valid: true, number: num };
  }

  static validateString(value, minLength = 0, maxLength = Infinity) {
    if (value === null || value === undefined) {
      return { valid: false, error: 'Value is required' };
    }

    const str = String(value).trim();

    if (str.length < minLength) {
      return { valid: false, error: `Value must be at least ${minLength} characters` };
    }

    if (str.length > maxLength) {
      return { valid: false, error: `Value must be at most ${maxLength} characters` };
    }

    return { valid: true, string: str };
  }

  static isValidJSON(jsonString) {
    try {
      JSON.parse(jsonString);
      return true;
    } catch (error) {
      return false;
    }
  }

  static sanitizeFileName(fileName) {
    if (!fileName) return 'unnamed';
    
    // Remove invalid characters for file names
    return fileName
      .replace(/[<>:"/\\|?*]/g, '')
      .replace(/\s+/g, '_')
      .substring(0, 255);
  }

  static validateColorCode(color) {
    if (!color || typeof color !== 'string') {
      return { valid: false, error: 'Color code is required' };
    }

    // Check hex color format
    const hexRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
    
    if (hexRegex.test(color)) {
      return { valid: true, color: color.toLowerCase() };
    }

    // Check RGB format
    const rgbRegex = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/;
    const rgbMatch = color.match(rgbRegex);
    
    if (rgbMatch) {
      const [, r, g, b] = rgbMatch;
      if (r <= 255 && g <= 255 && b <= 255) {
        return { valid: true, color };
      }
    }

    return { valid: false, error: 'Invalid color format' };
  }

  static extractNumbers(text) {
    if (!text) return [];
    
    const numbers = String(text).match(/\d+/g);
    return numbers ? numbers.map(Number) : [];
  }

  static isEmptyOrWhitespace(value) {
    return !value || (typeof value === 'string' && value.trim().length === 0);
  }

  static normalizeWhitespace(text) {
    if (!text) return '';
    
    return String(text)
      .replace(/\s+/g, ' ')
      .trim();
  }

  static validateDateString(dateString) {
    if (!dateString) {
      return { valid: false, error: 'Date string is required' };
    }

    const date = new Date(dateString);
    
    if (isNaN(date.getTime())) {
      return { valid: false, error: 'Invalid date format' };
    }

    return { valid: true, date };
  }

  static escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  static validateSettings(settings, schema) {
    const errors = [];
    const validatedSettings = {};

    for (const [key, rules] of Object.entries(schema)) {
      const value = settings[key];

      if (rules.required && (value === undefined || value === null)) {
        errors.push(`${key} is required`);
        continue;
      }

      if (value !== undefined) {
        if (rules.type && typeof value !== rules.type) {
          errors.push(`${key} must be of type ${rules.type}`);
          continue;
        }

        if (rules.validator && !rules.validator(value)) {
          errors.push(`${key} failed validation`);
          continue;
        }

        validatedSettings[key] = value;
      } else if (rules.default !== undefined) {
        validatedSettings[key] = rules.default;
      }
    }

    return {
      valid: errors.length === 0,
      errors,
      settings: validatedSettings
    };
  }
}

window.ValidationUtils = ValidationUtils;