/**
 * Unified Smart Cart API
 * Single interface for all contexts (popup, fullpage, content scripts)
 */
class UnifiedSmartCartAPI {
  constructor(context = 'unknown') {
    this.context = context;
    this.state = window.smartCartState;
    this.apiService = null;
    this.cache = new Map();
    this.requestQueue = new Map(); // Deduplication
    this.rateLimiter = {
      requests: 0,
      resetTime: Date.now() + 30000,
      maxRequests: 10
    };

    console.log(`🔗 [SmartCartAPI] Initialized for context: ${context}`);
  }

  /**
   * Initialize API and load initial data
   */
  async initialize() {
    console.log(`🏗️ [SmartCartAPI] Initializing for ${this.context}`);

    // Initialize API service if available
    if (typeof OptimizedDigikalaAPIService !== 'undefined') {
      this.apiService = new OptimizedDigikalaAPIService();
      await this.apiService.initialize();
    }

    // Load initial cart data
    await this.state.loadCart();

    console.log(`✅ [SmartCartAPI] Ready for ${this.context}`);
  }

  /**
   * Subscribe to cart state changes
   */
  subscribe(callback) {
    return this.state.subscribe(callback);
  }

  /**
   * Add item with deduplication and proper logging
   */
  async addItem(productId, variantId = null, quantity = 1) {
    console.log(`➕ [SmartCartAPI:${this.context}] addItem(${productId}, ${variantId}, ${quantity})`);

    try {
      const item = await this.state.addItem(productId, variantId, quantity);

      // Fetch fresh API data in background
      this.fetchProductData(productId, variantId).catch(error => {
        console.warn(`⚠️ [SmartCartAPI] Background API fetch failed: ${error.message}`);
      });

      return { success: true, item };
    } catch (error) {
      console.error(`❌ [SmartCartAPI:${this.context}] addItem error:`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Remove item
   */
  async removeItem(itemId) {
    console.log(`🗑️ [SmartCartAPI:${this.context}] removeItem(${itemId})`);

    try {
      const success = await this.state.removeItem(itemId);
      return { success };
    } catch (error) {
      console.error(`❌ [SmartCartAPI:${this.context}] removeItem error:`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Update quantity with validation
   */
  async updateQuantity(itemId, newQuantity) {
    console.log(`🔄 [SmartCartAPI:${this.context}] updateQuantity(${itemId}, ${newQuantity})`);

    // Validate quantity
    if (typeof newQuantity !== 'number' || newQuantity < 0) {
      return { success: false, error: 'Invalid quantity' };
    }

    if (newQuantity > 99) {
      return { success: false, error: 'Maximum quantity is 99' };
    }

    try {
      const item = await this.state.updateQuantity(itemId, newQuantity);
      return { success: true, item };
    } catch (error) {
      console.error(`❌ [SmartCartAPI:${this.context}] updateQuantity error:`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get current cart
   */
  getCart() {
    return this.state.getCart();
  }

  /**
   * Get cart summary
   */
  getSummary() {
    return this.state.getSummary();
  }

  /**
   * Clear cart
   */
  async clearCart() {
    console.log(`🧹 [SmartCartAPI:${this.context}] clearCart()`);

    try {
      await this.state.clearCart();
      return { success: true };
    } catch (error) {
      console.error(`❌ [SmartCartAPI:${this.context}] clearCart error:`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Refresh cart data from API
   */
  async refreshCartData(force = false) {
    console.log(`🔄 [SmartCartAPI:${this.context}] refreshCartData(force=${force})`);

    if (!this.apiService) {
      console.warn('⚠️ [SmartCartAPI] No API service available');
      return { success: false, error: 'API service not available' };
    }

    const cart = this.state.getCart();
    if (cart.length === 0) {
      return { success: true, updatedCount: 0 };
    }

    try {
      const updates = [];

      for (const item of cart) {
        const productId = item.pId || item.productId;
        const variantId = item.vId || item.variantId;

        // Skip if recently fetched and not forced
        if (!force && item._c?.lf && (Date.now() - item._c.lf < 2 * 60 * 1000)) {
          continue;
        }

        const productData = await this.fetchProductData(productId, variantId);
        if (productData) {
          updates.push({ item, productData });
        }
      }

      console.log(`✅ [SmartCartAPI:${this.context}] Refreshed ${updates.length} items`);
      return { success: true, updatedCount: updates.length };
    } catch (error) {
      console.error(`❌ [SmartCartAPI:${this.context}] refreshCartData error:`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Fetch product data with deduplication and caching
   */
  async fetchProductData(productId, variantId = null) {
    const cacheKey = `${productId}_${variantId || 'default'}`;

    // Check cache first
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < 2 * 60 * 1000) {
      return cached.data;
    }

    // Check if request already in flight
    if (this.requestQueue.has(cacheKey)) {
      return this.requestQueue.get(cacheKey);
    }

    // Rate limiting
    if (!this.checkRateLimit()) {
      console.warn(`⚠️ [SmartCartAPI] Rate limited for ${cacheKey}`);
      return null;
    }

    console.log(`🌐 [SmartCartAPI:${this.context}] Fetching product data: ${cacheKey}`);

    const requestPromise = this.fetchProductDataInternal(productId, variantId);
    this.requestQueue.set(cacheKey, requestPromise);

    try {
      const data = await requestPromise;

      // Cache result
      this.cache.set(cacheKey, {
        data,
        timestamp: Date.now()
      });

      return data;
    } catch (error) {
      console.error(`❌ [SmartCartAPI] Fetch error for ${cacheKey}:`, error);
      return null;
    } finally {
      this.requestQueue.delete(cacheKey);
    }
  }

  /**
   * Internal product data fetching
   */
  async fetchProductDataInternal(productId, variantId) {
    if (!this.apiService) {
      throw new Error('API service not available');
    }

    const result = await this.apiService.fetchProduct(productId, {
      variant: variantId,
      priority: 'normal',
      freshData: false
    });

    if (result.success && result.data) {
      return result.data;
    } else {
      throw new Error(result.error || 'API request failed');
    }
  }

  /**
   * Rate limiting check
   */
  checkRateLimit() {
    const now = Date.now();

    if (now > this.rateLimiter.resetTime) {
      this.rateLimiter.requests = 0;
      this.rateLimiter.resetTime = now + 30000;
    }

    if (this.rateLimiter.requests >= this.rateLimiter.maxRequests) {
      return false;
    }

    this.rateLimiter.requests++;
    return true;
  }

  /**
   * Build unique variants list
   */
  buildUniqueVariants(productData) {
    if (!productData.variants || !Array.isArray(productData.variants)) {
      return [];
    }

    const uniqueVariants = new Map();

    productData.variants.forEach(variant => {
      const key = variant.id || JSON.stringify(variant.attributes || {});

      if (!uniqueVariants.has(key)) {
        const minPrice = this.getVariantMinPrice(variant);

        uniqueVariants.set(key, {
          id: variant.id,
          title: this.buildVariantTitle(variant),
          attributes: variant.attributes || {},
          minPrice,
          isAvailable: variant.stock > 0,
          stock: variant.stock || 0
        });
      }
    });

    return Array.from(uniqueVariants.values());
  }

  /**
   * Build unique sellers list
   */
  buildUniqueSellers(productData, selectedVariantId = null) {
    const sellers = new Map();

    // Add sellers from default variant
    if (productData.default_variant?.seller) {
      const seller = productData.default_variant.seller;
      sellers.set(seller.id, {
        id: seller.id,
        name: seller.title || seller.name,
        price: productData.default_variant.price?.selling_price || 0,
        rating: seller.rating?.total_rate || 0,
        isDefault: true
      });
    }

    // Add sellers from other variants
    if (productData.variants) {
      productData.variants.forEach(variant => {
        // Filter by selected variant if specified
        if (selectedVariantId && variant.id !== selectedVariantId) {
          return;
        }

        if (variant.seller && !sellers.has(variant.seller.id)) {
          sellers.set(variant.seller.id, {
            id: variant.seller.id,
            name: variant.seller.title || variant.seller.name,
            price: variant.price?.selling_price || 0,
            rating: variant.seller.rating?.total_rate || 0,
            isDefault: false
          });
        }
      });
    }

    return Array.from(sellers.values()).sort((a, b) => a.price - b.price);
  }

  /**
   * Get displayed price with 3-layer logic
   */
  getDisplayedPrice(productData, selectedVariantId = null, selectedSellerId = null) {
    console.log(`💰 [SmartCartAPI] getDisplayedPrice(variant=${selectedVariantId}, seller=${selectedSellerId})`);

    // Layer 3: Specific variant + seller
    if (selectedVariantId && selectedSellerId) {
      const variant = productData.variants?.find(v => v.id === selectedVariantId);
      if (variant && variant.seller?.id === selectedSellerId) {
        return variant.price?.selling_price || 0;
      }
    }

    // Layer 2: Specific variant, lowest seller price
    if (selectedVariantId) {
      const variantPrices = productData.variants
        ?.filter(v => v.id === selectedVariantId)
        .map(v => v.price?.selling_price || 0)
        .filter(price => price > 0);

      if (variantPrices && variantPrices.length > 0) {
        return Math.min(...variantPrices);
      }
    }

    // Layer 1: Lowest price across all variants and sellers
    const allPrices = [];

    // Default variant price
    if (productData.default_variant?.price?.selling_price) {
      allPrices.push(productData.default_variant.price.selling_price);
    }

    // All variant prices
    if (productData.variants) {
      productData.variants.forEach(variant => {
        if (variant.price?.selling_price) {
          allPrices.push(variant.price.selling_price);
        }
      });
    }

    return allPrices.length > 0 ? Math.min(...allPrices) : 0;
  }

  /**
   * Helper: Build variant title
   */
  buildVariantTitle(variant) {
    const parts = [];

    if (variant.color?.title) parts.push(`رنگ: ${variant.color.title}`);
    if (variant.size?.title) parts.push(`سایز: ${variant.size.title}`);
    if (variant.warranty?.title) parts.push(`گارانتی: ${variant.warranty.title}`);

    return parts.length > 0 ? parts.join(', ') : 'پیش‌فرض';
  }

  /**
   * Helper: Get variant minimum price
   */
  getVariantMinPrice(variant) {
    return variant.price?.selling_price || 0;
  }

  /**
   * Get API statistics
   */
  getStats() {
    return {
      context: this.context,
      cacheSize: this.cache.size,
      queueSize: this.requestQueue.size,
      rateLimiter: { ...this.rateLimiter },
      stateStats: this.state.getStats()
    };
  }

  /**
   * Cleanup resources
   */
  cleanup() {
    console.log(`🧹 [SmartCartAPI:${this.context}] Cleaning up`);
    this.cache.clear();
    this.requestQueue.clear();
  }
}

// Export for use in different contexts
window.UnifiedSmartCartAPI = UnifiedSmartCartAPI;