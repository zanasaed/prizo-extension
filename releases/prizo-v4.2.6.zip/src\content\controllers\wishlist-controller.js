/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Wishlist Controller - Handles wishlist/favorites pages
 */
class WishlistController extends BaseController {
  constructor(services) {
    super(services, 'wishlist');
    this.batchSize = 3; // Smaller batch size for wishlist
  }

  async initialize() {
    console.log('🔄 Initializing wishlist controller');
    
    if (!this.isWishlistPage()) {
      console.log('❌ Not a wishlist page, skipping initialization');
      return;
    }
  }

  isWishlistPage() {
    const url = window.location.href;
    const path = window.location.pathname;
    
    const wishlistPagePatterns = [
      /\/profile\/lists/,  // Digikala's wishlist page pattern
      /\/wishlist/,
      /\/favorites/,
      /\/saved/,
      /\/bookmarks/
    ];

    return wishlistPagePatterns.some(pattern => pattern.test(url) || pattern.test(path)) ||
           document.querySelector('[data-testid="wishlist"]') ||
           document.querySelector('.wishlist-container') ||
           document.querySelector('[data-testid="product-card"]') && (url.includes('profile/lists') || path.includes('profile/lists'));
  }

  async processInitialElements() {
    if (!this.isFeatureEnabled('showSellerPrices') && 
        !this.isFeatureEnabled('showMonthlyPrices')) {
      console.log('ℹ️ Price features disabled, skipping wishlist processing');
      return;
    }

    console.log('❤️ Processing wishlist items');
    
    const wishlistElements = this.getWishlistElements();
    console.log(`❤️ Found ${wishlistElements.length} wishlist items`);

    if (wishlistElements.length === 0) {
      console.log('ℹ️ No wishlist items found');
      return;
    }

    // Process wishlist items in small batches
    await this.processBatch(wishlistElements);
  }

  getWishlistElements() {
    if (this.services.domManager && this.services.domManager.getWishlistProductElements) {
      return this.services.domManager.getWishlistProductElements();
    }

    // Fallback selectors
    const selectors = [
      '[data-testid="product-card"]', // Standard Digikala product card selector
      '[data-testid="wishlist-item"]',
      '.wishlist-item',
      '[data-product-id]'
    ];

    for (const selector of selectors) {
      const elements = Array.from(document.querySelectorAll(selector));
      if (elements.length > 0) {
        return elements.filter(el => this.isElementVisible(el));
      }
    }

    return [];
  }

  async processBatch(elements) {
    for (let i = 0; i < elements.length; i += this.batchSize) {
      const batch = elements.slice(i, i + this.batchSize);
      
      const promises = batch.map(element => {
        const productId = this.extractProductId(element);
        if (productId) {
          return this.processElement(element, productId);
        }
        return Promise.resolve();
      });

      await Promise.allSettled(promises);
      
      // Add longer delay for wishlist processing
      if (i + this.batchSize < elements.length) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  }

  async handleElement(element, productId) {
    try {
      console.log(`❤️ Processing wishlist product ${productId}`);

      const dataResult = await this.services.dataManager.fetchProductData(productId);
      
      if (!dataResult || !dataResult.success || !dataResult.data) {
        console.log(`⚠️ No data found for product ${productId}`);
        return;
      }

      const productData = dataResult.data;

      // For wishlist, focus on monthly price info
      const monthlyLowPrice = await this.services.dataManager.extractMonthlyLowPrice(
        productData, 
        productId
      );

      if (this.isFeatureEnabled('showMonthlyPrices') && monthlyLowPrice > 0) {
        this.addWishlistPriceInfo(element, monthlyLowPrice);
      }

      console.log(`✅ Successfully processed wishlist product ${productId}`);

    } catch (error) {
      console.error(`❌ Error processing wishlist product ${productId}:`, error);
    }
  }

  addWishlistPriceInfo(element, monthlyLowPrice) {
    if (this.services.domManager && this.services.domManager.addMonthlyPriceSectionOnly) {
      this.services.domManager.addMonthlyPriceSectionOnly(element, monthlyLowPrice);
      return;
    }

    // Fallback implementation
    const existingInfo = element.querySelector('.wishlist-price-info');
    if (existingInfo) {
      existingInfo.remove();
    }

    const priceInfo = document.createElement('div');
    priceInfo.className = 'wishlist-price-info';
    priceInfo.style.cssText = `
      background: #fff3cd;
      border: 1px solid #ffeeba;
      border-radius: 4px;
      padding: 6px;
      margin-top: 8px;
      font-size: 11px;
      color: #856404;
      display: flex;
      align-items: center;
      gap: 4px;
    `;

    priceInfo.innerHTML = `
      <span>📊</span>
      <span>کمترین قیمت ماه: ${this.services.dataManager.formatPrice(monthlyLowPrice)}</span>
    `;

    element.appendChild(priceInfo);
  }

  isElementVisible(element) {
    if (this.services.domManager) {
      return this.services.domManager.isElementVisible(element);
    }
    
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    
    return rect.width > 0 && 
           rect.height > 0 && 
           style.display !== 'none' && 
           style.visibility !== 'hidden';
  }

  async processNewElements() {
    const newWishlistElements = this.getWishlistElements().filter(element => 
      !this.processedElements.has(element)
    );

    if (newWishlistElements.length > 0) {
      console.log(`❤️ Found ${newWishlistElements.length} new wishlist items`);
      await this.processBatch(newWishlistElements);
    }
  }

  isElementRelevant(element) {
    const selectors = [
      '[data-testid="product-card"]', // Standard Digikala product card selector
      '[data-testid="wishlist-item"]',
      '.wishlist-item',
      '[data-product-id]'
    ];

    return selectors.some(selector => 
      element.matches(selector) || element.querySelector(selector)
    );
  }
}

window.WishlistController = WishlistController;