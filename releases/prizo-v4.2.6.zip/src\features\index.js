/**
 * Features Index
 * Exports all feature modules for the extension
 */

// Price tracking features
export { DataManager } from './price-tracking/data-manager.js';

// First time welcome
export { WelcomeManager } from './first-time-welcome/welcome-manager.js';

// Storage features
export { StorageManager } from './storage/storage-manager.js';

// Validation features
export { ValidationManager } from './validation/validation-manager.js';

// Error recovery
export { ErrorRecoveryManager } from './error-recovery/error-recovery-manager.js';

// Security features
export { UrlSafetyManager } from './security/url-safety-manager.js';