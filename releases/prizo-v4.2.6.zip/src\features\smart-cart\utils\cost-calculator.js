/**
 * @Author: Smart Cart System
 * @Date: 2025-01-18
 * Cost Calculator - Handles all cost calculations including shipping optimization
 */

class CostCalculator {
  constructor() {
    this.debug = false;
  }

  /**
   * Calculate total cost for given assignments
   * @param {Array} assignments - Product-seller assignments
   * @param {Object} data - Basket data with sellers and shipping info
   * @returns {Object} Cost breakdown
   */
  calculateTotalCost(assignments, data) {
    const productCost = this.calculateProductCost(assignments);
    const shippingCalculation = this.calculateOptimalShipping(assignments, data);

    return {
      productCost,
      shippingCost: shippingCalculation.totalShippingCost,
      totalCost: productCost + shippingCalculation.totalShippingCost,
      shippingBreakdown: shippingCalculation.breakdown
    };
  }

  /**
   * Calculate total product cost
   */
  calculateProductCost(assignments) {
    return assignments.reduce((total, assignment) => total + assignment.price, 0);
  }

  /**
   * Calculate optimal shipping cost considering marketplace shipping eligibility
   * @param {Array} assignments - Product-seller assignments
   * @param {Object} data - Basket data
   * @returns {Object} Shipping cost breakdown
   */
  calculateOptimalShipping(assignments, data) {
    const sellersUsed = this.groupAssignmentsBySeller(assignments, data);
    const shippingOptions = this.generateShippingOptions(sellersUsed, data);

    // Find the cheapest shipping option
    let bestOption = null;
    let bestCost = Infinity;

    for (const option of shippingOptions) {
      if (option.totalCost < bestCost) {
        bestCost = option.totalCost;
        bestOption = option;
      }
    }

    return {
      totalShippingCost: bestOption ? bestOption.totalCost : 0,
      breakdown: bestOption ? bestOption.breakdown : {}
    };
  }

  /**
   * Group assignments by seller with product details
   */
  groupAssignmentsBySeller(assignments, data) {
    const sellersUsed = {};

    for (const assignment of assignments) {
      const sellerId = assignment.sellerId;

      if (!sellersUsed[sellerId]) {
        sellersUsed[sellerId] = {
          sellerId,
          shippingCost: data.sellers[sellerId]?.shippingCost || 0,
          products: []
        };
      }

      // Find product details to check shipping eligibility
      const product = data.products.find(p => p.id === assignment.productId);
      const sellerInfo = product?.sellers.find(s => s.sellerId === sellerId);

      sellersUsed[sellerId].products.push({
        productId: assignment.productId,
        price: assignment.price,
        shipsDirectly: sellerInfo?.shipsDirectly ?? true
      });
    }

    return sellersUsed;
  }

  /**
   * Generate all possible shipping options
   */
  generateShippingOptions(sellersUsed, data) {
    const options = [];

    // Option 1: Individual seller shipping for all
    const individualShipping = this.calculateIndividualShipping(sellersUsed);
    options.push({
      type: 'individual',
      totalCost: individualShipping.totalCost,
      breakdown: individualShipping.breakdown
    });

    // Option 2: Marketplace shipping where eligible + individual for rest
    if (data.marketplaceShipping > 0) {
      const marketplaceShipping = this.calculateMarketplaceShipping(sellersUsed, data);
      options.push({
        type: 'marketplace_hybrid',
        totalCost: marketplaceShipping.totalCost,
        breakdown: marketplaceShipping.breakdown
      });
    }

    // Option 3: Mixed optimization (try different combinations)
    const mixedOptions = this.generateMixedShippingOptions(sellersUsed, data);
    options.push(...mixedOptions);

    return options;
  }

  /**
   * Calculate cost with individual seller shipping for all
   */
  calculateIndividualShipping(sellersUsed) {
    let totalCost = 0;
    const breakdown = {
      type: 'individual',
      sellerShipping: {},
      marketplaceShipping: 0
    };

    for (const [sellerId, sellerData] of Object.entries(sellersUsed)) {
      const shippingCost = sellerData.shippingCost;
      totalCost += shippingCost;
      breakdown.sellerShipping[sellerId] = shippingCost;
    }

    return { totalCost, breakdown };
  }

  /**
   * Calculate cost with marketplace shipping where possible
   */
  calculateMarketplaceShipping(sellersUsed, data) {
    let totalCost = 0;
    const breakdown = {
      type: 'marketplace_hybrid',
      sellerShipping: {},
      marketplaceShipping: 0,
      marketplaceEligibleProducts: []
    };

    const marketplaceEligibleProducts = [];
    const directShippingRequired = {};

    // Categorize products by shipping eligibility
    for (const [sellerId, sellerData] of Object.entries(sellersUsed)) {
      for (const product of sellerData.products) {
        if (product.shipsDirectly === false) {
          // Marketplace shipping available
          marketplaceEligibleProducts.push({
            ...product,
            sellerId
          });
        } else {
          // Must use direct seller shipping
          if (!directShippingRequired[sellerId]) {
            directShippingRequired[sellerId] = {
              ...sellerData,
              products: []
            };
          }
          directShippingRequired[sellerId].products.push(product);
        }
      }
    }

    // Add marketplace shipping cost if there are eligible products
    if (marketplaceEligibleProducts.length > 0) {
      totalCost += data.marketplaceShipping;
      breakdown.marketplaceShipping = data.marketplaceShipping;
      breakdown.marketplaceEligibleProducts = marketplaceEligibleProducts.map(p => p.productId);
    }

    // Add individual shipping costs for sellers with direct-only products
    for (const [sellerId, sellerData] of Object.entries(directShippingRequired)) {
      totalCost += sellerData.shippingCost;
      breakdown.sellerShipping[sellerId] = sellerData.shippingCost;
    }

    return { totalCost, breakdown };
  }

  /**
   * Generate mixed shipping options (advanced optimization)
   */
  generateMixedShippingOptions(sellersUsed, data) {
    const options = [];

    // For each seller, try both marketplace and individual shipping
    // This is useful when some products from a seller can use marketplace shipping
    // while others must use direct shipping

    for (const [sellerId, sellerData] of Object.entries(sellersUsed)) {
      const marketplaceEligible = sellerData.products.filter(p => p.shipsDirectly === false);
      const directOnly = sellerData.products.filter(p => p.shipsDirectly !== false);

      if (marketplaceEligible.length > 0 && directOnly.length > 0) {
        // This seller has mixed shipping requirements
        // Calculate cost of splitting vs. using all direct shipping

        const splitCost = this.calculateSplitShippingCost(sellerId, sellerData, data, sellersUsed);
        if (splitCost) {
          options.push({
            type: 'split_seller',
            sellerId,
            totalCost: splitCost.totalCost,
            breakdown: splitCost.breakdown
          });
        }
      }
    }

    return options;
  }

  /**
   * Calculate cost when splitting a seller's products between shipping methods
   */
  calculateSplitShippingCost(targetSellerId, targetSellerData, data, allSellersUsed) {
    // This is a complex calculation that would need to consider
    // the impact on the entire shipping strategy

    // For now, return null to indicate this optimization is not implemented
    // In a full implementation, this would calculate the optimal split
    return null;
  }

  /**
   * Estimate shipping cost for a quick comparison (used in greedy algorithms)
   * This is a simplified version that doesn't do full optimization
   */
  estimateShippingCost(assignments, data) {
    const sellersUsed = new Set(assignments.map(a => a.sellerId));

    // Simple heuristic: use marketplace shipping if it covers >50% of products
    const marketplaceEligibleCount = assignments.filter(assignment => {
      const product = data.products.find(p => p.id === assignment.productId);
      const seller = product?.sellers.find(s => s.sellerId === assignment.sellerId);
      return seller?.shipsDirectly === false;
    }).length;

    if (data.marketplaceShipping > 0 && marketplaceEligibleCount > assignments.length * 0.5) {
      // Estimate using marketplace shipping
      let cost = data.marketplaceShipping;

      // Add individual shipping for sellers with direct-only products
      const directOnlySellers = new Set();
      for (const assignment of assignments) {
        const product = data.products.find(p => p.id === assignment.productId);
        const seller = product?.sellers.find(s => s.sellerId === assignment.sellerId);
        if (seller?.shipsDirectly !== false) {
          directOnlySellers.add(assignment.sellerId);
        }
      }

      for (const sellerId of directOnlySellers) {
        cost += data.sellers[sellerId]?.shippingCost || 0;
      }

      return cost;
    } else {
      // Estimate using individual shipping
      let cost = 0;
      for (const sellerId of sellersUsed) {
        cost += data.sellers[sellerId]?.shippingCost || 0;
      }
      return cost;
    }
  }

  /**
   * Enable debug logging
   */
  enableDebug() {
    this.debug = true;
  }

  /**
   * Debug log helper
   */
  debugLog(message, data) {
    if (this.debug) {
      console.log(`🧮 CostCalculator: ${message}`, data);
    }
  }
}

// Browser extension compatibility
if (typeof window !== 'undefined') {
  window.CostCalculator = CostCalculator;
}