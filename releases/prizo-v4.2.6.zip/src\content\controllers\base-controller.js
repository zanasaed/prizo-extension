/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Base Controller - Common functionality for all page controllers
 */
class BaseController {
  constructor(services, pageType) {
    this.services = services;
    this.pageType = pageType;
    this.isActive = false;
    this.observer = null;
    this.processingQueue = new Set();
    this.processedElements = new Set(); // Use Set instead of WeakSet for storing strings/IDs
  }

  async activate() {
    if (this.isActive) return;
    
    console.log(`🔄 Activating ${this.pageType} controller`);
    this.isActive = true;
    
    try {
      await this.initialize();
      this.setupEventListeners();
      this.setupMutationObserver();
      await this.processInitialElements();
      
      // Notify background script about activation
      await this.notifyBackgroundState(true);
      
      this.services.eventBus.emit('controller:activated', { 
        pageType: this.pageType 
      });
      
      console.log(`✅ ${this.pageType} controller activated`);
    } catch (error) {
      console.error(`❌ Failed to activate ${this.pageType} controller:`, error);
      this.services.eventBus.emit('controller:activation-error', { 
        pageType: this.pageType, 
        error 
      });
    }
  }

  async deactivate() {
    if (!this.isActive) return;
    
    console.log(`🔄 Deactivating ${this.pageType} controller`);
    this.isActive = false;
    
    this.cleanup();
    this.removeEventListeners();
    this.disconnectObserver();
    
    // Notify background script about deactivation
    await this.notifyBackgroundState(false);
    
    this.services.eventBus.emit('controller:deactivated', { 
      pageType: this.pageType 
    });
    
    console.log(`✅ ${this.pageType} controller deactivated`);
  }

  async initialize() {
    // Override in child controllers
  }

  setupEventListeners() {
    // Override in child controllers
  }

  removeEventListeners() {
    // Override in child controllers  
  }

  cleanup() {
    // Override in child controllers
  }

  setupMutationObserver() {
    if (this.observer) {
      this.observer.disconnect();
    }

    this.observer = new MutationObserver((mutations) => {
      if (!this.isActive) return;
      
      const hasRelevantChanges = mutations.some(mutation => 
        mutation.type === 'childList' && 
        (mutation.addedNodes.length > 0 || mutation.removedNodes.length > 0)
      );

      if (hasRelevantChanges) {
        this.debounceProcessNewElements();
      }
    });

    this.observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  disconnectObserver() {
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
  }

  debounceProcessNewElements() {
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }
    
    this.debounceTimer = setTimeout(() => {
      this.processNewElements();
    }, 500);
  }

  debounce(func, delay) {
    let timeoutId;
    return function (...args) {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
  }

  async processNewElements() {
    // Override in child controllers
  }

  async processInitialElements() {
    // Override in child controllers
  }

  async processElement(element, productId) {
    if (!element || !productId || this.processedElements.has(element)) {
      return;
    }

    if (this.processingQueue.has(productId)) {
      console.log(`⏳ Product ${productId} already being processed`);
      return;
    }

    this.processingQueue.add(productId);
    this.processedElements.add(element);

    try {
      await this.handleElement(element, productId);
    } catch (error) {
      console.error(`❌ Error processing element for product ${productId}:`, error);
      this.services.eventBus.emit('controller:element-error', {
        pageType: this.pageType,
        productId,
        error
      });
    } finally {
      this.processingQueue.delete(productId);
    }
  }

  async handleElement(element, productId) {
    // Override in child controllers
  }

  isElementRelevant(element) {
    // Override in child controllers
    return false;
  }

  extractProductId(element) {
    // Use DOM manager to extract product ID
    if (this.services.domManager) {
      return this.services.domManager.extractProductId(element);
    }
    return null;
  }

  showNotification(options) {
    if (this.services.notificationService) {
      return this.services.notificationService.show(options);
    }
  }

  getSettings() {
    return this.services.storageService?.settings || {};
  }

  isFeatureEnabled(featureName) {
    const settings = this.getSettings();
    return settings[featureName] !== false;
  }

  async waitForElements(selector, maxAttempts = 10, interval = 1000) {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        return Array.from(elements);
      }
      
      if (attempt < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, interval));
      }
    }
    
    return [];
  }

  async notifyBackgroundState(isActive) {
    try {
      await chrome.runtime.sendMessage({
        action: 'updateIcon',
        active: isActive
      });
      
      console.log(`🎨 Notified background script: ${isActive ? 'active' : 'inactive'}`);
    } catch (error) {
      console.error('❌ Failed to notify background script of state change:', error);
    }
  }

  getProcessingStats() {
    return {
      pageType: this.pageType,
      isActive: this.isActive,
      queueSize: this.processingQueue.size,
      hasObserver: !!this.observer
    };
  }
}

window.BaseController = BaseController;