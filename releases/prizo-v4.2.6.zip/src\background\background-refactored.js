/**
 * @Author: Zana Saedpanah
 * @Date:   2025-06-12 09:06:04
 * @Last Modified by:   Claude
 * @Last Modified time: 2025-09-17
 *
 * Refactored Background Service - Modular Architecture
 */

import { BackgroundLogger } from './utils/logger.js';
import { RequestManager } from './services/request-manager.js';
import { MessageHandler } from './handlers/message-handler.js';
import { TabHandler } from './handlers/tab-handler.js';
import { WatchlistMonitor } from './services/watchlist-monitor.js';
import { SmartCartStateManager } from './services/smart-cart-state-manager.js';

// Digikala Real Seller Prices - Background Service Worker (Refactored)
class BackgroundService {
  constructor() {
    try {
      this.requestManager = new RequestManager();
      this.messageHandler = new MessageHandler(this);
      this.tabHandler = new TabHandler(this);
      this.watchlistMonitor = new WatchlistMonitor(this);
      this.smartCartStateManager = new SmartCartStateManager();
      this.notificationContexts = new Map();
      this.initialized = false;

      console.log('🔧 All service components instantiated successfully');

      // Initialize asynchronously to avoid blocking constructor
      this.initialize();
    } catch (error) {
      console.error('❌ Failed to instantiate background service components:', error);
      throw error;
    }
  }

  async initialize() {
    try {
      await this.init();
      this.initialized = true;
      console.log('✅ Background service initialized successfully');
    } catch (error) {
      console.error('❌ Background service initialization failed:', error);
    }
  }

  async init() {
    console.log('🔧 DBG:bg:init - Background service initializing');

    // Verify Chrome APIs are available
    if (!chrome || !chrome.runtime) {
      throw new Error('Chrome runtime API not available');
    }

    // Handle extension installation
    chrome.runtime.onInstalled.addListener((details) => {
      console.log('🔧 DBG:bg:installed', details);
      this.handleInstallation(details);
      this.ensureBackwardCompatibility();
    });

    // Handle tab updates (navigation, refresh, etc.)
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      this.tabHandler.handleTabUpdate(tabId, changeInfo, tab);
    });

    // Handle tab removal to clean up storage
    chrome.tabs.onRemoved.addListener((tabId) => {
      this.tabHandler.cleanupTabStorage(tabId);
    });

    // Handle messages from content script or popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      // Check if service is initialized
      if (!this.initialized) {
        console.warn('⚠️ Background service not yet initialized, queuing message');
        setTimeout(() => {
          this.handleMessage(request, sender, sendResponse);
        }, 100);
        return true;
      }

      this.handleMessage(request, sender, sendResponse);
      return true; // Keep the message channel open for async responses
    });

    // Handle startup to restore active states
    chrome.runtime.onStartup.addListener(() => {
      this.handleStartup();
      this.ensureBackwardCompatibility();
    });

    // Handle alarm events for reliable price monitoring
    chrome.alarms.onAlarm.addListener((alarm) => {
      this.watchlistMonitor.handleAlarm(alarm);
    });

    // Initialize watchlist monitoring
    this.watchlistMonitor.startWatchlistMonitoring();

    // Initialize Smart Cart state manager
    this.initializeSmartCart();
  }

  handleMessage(request, sender, sendResponse) {
    console.log(`🔧 DBG:bg:msg:${request.action || 'unknown'}`, {
      action: request.action,
      tabId: sender.tab?.id,
      url: sender.tab?.url?.substring(0, 100),
      hasProductId: !!request.productId,
      hasCartData: !!request.cartData
    });

    this.messageHandler.handleMessage(request, sender, sendResponse)
      .then(() => {
        console.log(`✅ DBG:bg:response:${request.action || 'unknown'} - Message handled successfully`);
      })
      .catch((error) => {
        console.error(`❌ DBG:bg:error:${request.action || 'unknown'}`, error);
        try {
          sendResponse({
            success: false,
            error: 'Internal error occurred',
            errorType: 'INTERNAL_ERROR'
          });
        } catch (responseError) {
          console.error('❌ Failed to send error response:', responseError);
        }
      });
  }

  async initializeSmartCart() {
    try {
      await this.smartCartStateManager.initialize();
      BackgroundLogger.info('✅ Smart Cart State Manager initialized in background service');
    } catch (error) {
      console.error('❌ Failed to initialize Smart Cart State Manager:', error);
    }
  }

  handleInstallation(details) {
    BackgroundLogger.info('Prizo extension installed/updated');

    if (details.reason === 'install') {
      BackgroundLogger.info('First time installation');
    } else if (details.reason === 'update') {
      BackgroundLogger.info('Extension updated');
    }
  }

  async handleStartup() {
    BackgroundLogger.info('Extension startup - checking for active tabs and recovering watchlist monitoring');

    try {
      // Apply startup delay to ensure system is ready
      await this.applyStartupDelay();

      // Wait for network stability
      await this.waitForNetworkStability();

      // Query all tabs to check which ones should be reactivated
      const tabs = await chrome.tabs.query({});

      for (const tab of tabs) {
        if (tab.url && this.isDigikalaSellerPage(tab.url)) {
          try {
            const storageKey = `seller_prices_active_${tab.id}`;
            const result = await chrome.storage.local.get([storageKey]);
            const wasActive = result[storageKey] || false;

            if (wasActive) {
              // Try to reconnect to the tab
              await this.tabHandler.reactivateTab(tab.id);
            }
          } catch (error) {
            console.error(`Error checking tab ${tab.id} during startup:`, error);
          }
        }
      }

      // Restart watchlist monitoring with recovery check
      BackgroundLogger.info('🔄 Restarting watchlist monitoring after startup...');
      await this.watchlistMonitor.startWatchlistMonitoring();

    } catch (error) {
      console.error('Error during startup recovery:', error);
    }
  }

  // Delegate methods to appropriate handlers
  updateExtensionIcon(tabId, isActive) {
    return this.tabHandler.updateExtensionIcon(tabId, isActive);
  }

  // Core business logic methods
  isDigikalaSellerPage(url) {
    return url.includes('digikala.com');
  }

  async injectContentScriptIfNeeded(tabId) {
    try {
      await chrome.tabs.sendMessage(tabId, { action: 'ping' });
      return true; // Content script already loaded
    } catch (error) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tabId },
          files: ['content/main.js']
        });
        BackgroundLogger.info(`Injected content script into tab ${tabId}`);
        return true;
      } catch (injectionError) {
        console.error(`Failed to inject content script into tab ${tabId}:`, injectionError);
        return false;
      }
    }
  }

  async getTabStatus(tabId) {
    try {
      const storageKey = `seller_prices_active_${tabId}`;
      const result = await chrome.storage.local.get([storageKey]);
      return result[storageKey] || false;
    } catch (error) {
      console.error('Error getting tab status:', error);
      return false;
    }
  }

  async updateTabStatus(tabId, active) {
    try {
      const storageKey = `seller_prices_active_${tabId}`;
      await chrome.storage.local.set({ [storageKey]: active });
      await this.updateExtensionIcon(tabId, active);
      BackgroundLogger.info(`Updated tab ${tabId} status to ${active ? 'active' : 'inactive'}`);
    } catch (error) {
      console.error('Error updating tab status:', error);
    }
  }

  async updateExtensionBadge(tabId, pageType) {
    try {
      const badges = {
        'product-detail': { text: 'P', color: '#4CAF50', title: 'Prizo - Product Page' },
        'search': { text: 'S', color: '#2196F3', title: 'Prizo - Search Page' },
        'seller': { text: 'R', color: '#FF9800', title: 'Prizo - Seller Page' },
        'cart': { text: 'C', color: '#9C27B0', title: 'Prizo - Cart Page' },
        'fresh': { text: 'F', color: '#8BC34A', title: 'Prizo - Fresh Page' },
        'unknown': { text: '', color: '#607D8B', title: 'Prizo' }
      };

      const badge = badges[pageType] || badges['unknown'];

      await chrome.action.setBadgeText({ text: badge.text, tabId: tabId });
      await chrome.action.setBadgeBackgroundColor({ color: badge.color, tabId: tabId });
      await chrome.action.setTitle({ title: badge.title, tabId: tabId });

    } catch (error) {
      console.error('Error updating extension badge:', error);
    }
  }

  // Product data fetching methods
  async fetchProductData(productId, pageType = 'seller', sendResponse, currentUrl = null) {
    try {
      const result = await this.requestManager.fetchWithDeduplication(productId, pageType, currentUrl);

      if (result.success) {
        sendResponse({
          success: true,
          data: result.data,
          source: result.source
        });
      } else {
        // Try alternative method as fallback (important for shipping cost data)
        console.log('🔄 Trying alternative method for product data');
        await this.fetchProductDataAlternative(productId, sendResponse);
      }
    } catch (error) {
      console.error('Error in fetchProductData:', error);
      sendResponse({
        success: false,
        error: error.message || 'Internal error'
      });
    }
  }

  async fetchProductDataAlternative(productId, sendResponse) {
    try {
      const productUrl = `https://www.digikala.com/product/dkp-${encodeURIComponent(productId)}/`;

      const response = await fetch(productUrl, {
        method: 'GET',
        headers: {
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });

      if (response.ok) {
        const htmlContent = await response.text();

        // Extract JSON data from HTML (commonly embedded in script tags)
        const jsonMatch = htmlContent.match(/"default_variant":\s*({.+?})/);

        if (jsonMatch) {
          const variantData = JSON.parse(jsonMatch[1]);

          // Debug: Log shipping data from alternative method
          console.log(`🔧 DBG:api:alternative - Extracted variant data:`, {
            hasShipmentMethods: !!variantData.shipment_methods,
            hasProperties: !!variantData.properties,
            isShipBySeller: variantData.properties?.is_ship_by_seller
          });

          sendResponse({
            success: true,
            data: { default_variant: variantData },
            source: 'alternative'
          });
          return;
        }
      }

      // If alternative method fails, send error response
      sendResponse({
        success: false,
        error: 'Alternative fetch method failed'
      });

    } catch (error) {
      console.error('❌ Alternative fetch method error:', error);
      sendResponse({
        success: false,
        error: error.message || 'Alternative fetch failed'
      });
    }
  }

  async batchFetchProducts(requests, currentUrl = null) {
    try {
      return await this.requestManager.processBatch(requests, currentUrl);
    } catch (error) {
      console.error('Error in batchFetchProducts:', error);
      return [];
    }
  }

  async fetchPriceChart(productId, sendResponse) {
    try {
      // Price chart implementation would go here
      // For now, return a simple success response
      sendResponse({
        success: true,
        data: { message: 'Price chart feature coming soon' }
      });
    } catch (error) {
      console.error('Error in fetchPriceChart:', error);
      sendResponse({
        success: false,
        error: error.message || 'Failed to fetch price chart'
      });
    }
  }

  // Utility methods
  async applyStartupDelay() {
    // Random delay between 1-3 seconds to avoid overwhelming the system
    const delay = 1000 + (Math.random() * 2000);
    await new Promise(resolve => setTimeout(resolve, delay));
  }

  async waitForNetworkStability() {
    // Simple network check - try to reach a reliable endpoint
    try {
      await fetch('https://www.google.com', {
        method: 'HEAD',
        mode: 'no-cors',
        cache: 'no-cache'
      });
      return true;
    } catch (error) {
      BackgroundLogger.info('Network not yet stable, waiting...');
      await new Promise(resolve => setTimeout(resolve, 2000));
      return false;
    }
  }

  async ensureBackwardCompatibility() {
    try {
      // Check for old storage formats and migrate if needed
      const oldKeys = ['prizo_active_tabs', 'prizo_watchlist_old'];
      const result = await chrome.storage.local.get(oldKeys);

      if (Object.keys(result).length > 0) {
        BackgroundLogger.info('Found old storage format, migrating...');
        // Migration logic would go here
        await chrome.storage.local.remove(oldKeys);
        BackgroundLogger.info('Migration completed');
      }
    } catch (error) {
      console.error('Error during backward compatibility check:', error);
    }
  }

  // Delegate watchlist monitoring methods
  async monitorSingleProduct(watchlistItem) {
    // Implementation for monitoring a single product
    try {
      BackgroundLogger.info(`Monitoring product: ${watchlistItem.productTitle}`, watchlistItem.productId);

      // Fetch current product data
      const result = await this.requestManager.fetchWithDeduplication(
        watchlistItem.productId,
        'product-detail'
      );

      if (result.success) {
        // Extract price using the message handler's helper method
        const price = this.messageHandler.extractPriceFromResponse(result.data);
        BackgroundLogger.info(`💾 [MONITOR] Product ${watchlistItem.productId} price: ${price}`);

        // Update the watchlist item with new data
        await this.updateWatchlistEntry(watchlistItem.id, {
          lastCheckedAt: Date.now(),
          lastKnownPrice: price || watchlistItem.lastKnownPrice
        });

        BackgroundLogger.info(`Successfully monitored product ${watchlistItem.productId}`);
        return true;
      } else {
        console.error(`Failed to monitor product ${watchlistItem.productId}:`, result.error);
        return false;
      }
    } catch (error) {
      console.error(`Error monitoring product ${watchlistItem.productId}:`, error);
      return false;
    }
  }

  async updateWatchlistEntry(entryId, updates) {
    try {
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];

      const entryIndex = watchlist.findIndex(item => item.id === entryId);
      if (entryIndex !== -1) {
        watchlist[entryIndex] = { ...watchlist[entryIndex], ...updates };
        await chrome.storage.local.set({ 'digikala_extension_watchlist': watchlist });
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error updating watchlist entry:', error);
      return false;
    }
  }
}

// Initialize the background service
const backgroundService = new BackgroundService();

// Initialize notification handlers
function initializeNotificationHandlers() {
  if (!chrome.notifications) {
    console.log('Notifications API not available');
    return;
  }

  // Handle notification clicks
  chrome.notifications.onClicked.addListener((notificationId) => {
    BackgroundLogger.info(`Notification clicked: ${notificationId}`);

    const context = backgroundService.notificationContexts?.get(notificationId);
    if (context) {
      if (context.productUrl) {
        chrome.tabs.create({ url: context.productUrl });
      }
      backgroundService.notificationContexts?.delete(notificationId);
    }

    chrome.notifications.clear(notificationId);
  });

  // Handle notification button clicks
  chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
    const context = backgroundService.notificationContexts?.get(notificationId);
    if (context) {
      if (buttonIndex === 0) {
        // "View Product" button
        if (context.productUrl) {
          chrome.tabs.create({ url: context.productUrl });
        }
      } else if (buttonIndex === 1) {
        // "Dismiss" button
        if (chrome.notifications && chrome.notifications.create) {
          chrome.notifications.clear(notificationId);
        }
      }
      backgroundService.notificationContexts?.delete(notificationId);
    }
  });

  BackgroundLogger.info('Notification handlers initialized');
}

initializeNotificationHandlers();

// Tab activation listener to update badge and icon when switching tabs
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);

    if (tab.url && tab.url.includes('digikala.com')) {
      await backgroundService.updateExtensionIcon(activeInfo.tabId, true);

      try {
        const response = await chrome.tabs.sendMessage(activeInfo.tabId, {
          action: 'getPageType'
        });

        if (response && response.pageType) {
          await backgroundService.updateExtensionBadge(activeInfo.tabId, response.pageType);
        }
      } catch (error) {
        await backgroundService.updateExtensionBadge(activeInfo.tabId, 'unknown');
      }
    } else {
      await backgroundService.updateExtensionIcon(activeInfo.tabId, false);
      await chrome.action.setBadgeText({ text: '', tabId: activeInfo.tabId });
      await chrome.action.setTitle({
        title: 'Prizo',
        tabId: activeInfo.tabId
      });
    }
  } catch (error) {
    console.error('Error updating badge and icon on tab change:', error);
  }
});

// Tab update listener to update badge and icon when URL changes
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('digikala.com')) {
    await backgroundService.updateExtensionIcon(tabId, true);

    try {
      const response = await chrome.tabs.sendMessage(tabId, {
        action: 'getPageType'
      });

      if (response && response.pageType) {
        await backgroundService.updateExtensionBadge(tabId, response.pageType);
      }
    } catch (error) {
      await backgroundService.updateExtensionBadge(tabId, 'unknown');
    }
  } else if (changeInfo.status === 'complete') {
    await backgroundService.updateExtensionIcon(tabId, false);
  }
});

export { backgroundService };