/**
 * @Author: Zana Saedpanah
 * @Date:   2025-06-17 11:51:23
 * @Last Modified by:   Zana Saedpanah
 * @Last Modified time: 2025-09-15 12:00:00
 *
 * Popup Controller - Slim orchestration layer for modular popup interface
 *
 * This file has been refactored from 3,221 lines to a minimal controller.
 * All functionality has been extracted into focused modules for better maintainability.
 */

class PopupController {
  constructor() {
    this.initialized = false;
    this.modules = new Map();
    this.isActive = false;
    this.pageType = 'unknown';

    // Legacy element references for backward compatibility
    this.statusElement = document.getElementById('status');
    this.pageTypeElement = document.getElementById('pageType');
    this.loadingElement = document.getElementById('loading');
    this.errorElement = document.getElementById('error');

    // Initialize the controller
    this.init();
  }

  async init() {
    if (this.initialized) {
      console.warn('PopupController already initialized');
      return;
    }

    try {
      // Wait for modular integration to be ready
      await this.waitForModularSystem();

      // Get references to initialized modules
      this.getModuleReferences();

      // Setup legacy event listeners for backward compatibility
      this.setupLegacyEventListeners();

      // Load initial state
      await this.loadInitialState();

      this.initialized = true;
      console.log('✅ PopupController initialized as slim orchestration layer');

      // Notify integration system that controller is ready
      if (window.popupEventBus) {
        window.popupEventBus.emit('popup:controller-ready', { controller: this });
      }

      // Ensure fallback listeners are set up after a brief delay
      // This handles cases where the DOM elements are not immediately available
      setTimeout(() => {
        this.setupFallbackButtonListeners();
        console.log('🔄 Fallback button listeners re-applied after delay');
      }, 500);

    } catch (error) {
      console.error('❌ Failed to initialize PopupController:', error);
      this.showError('خطا در راه‌اندازی رابط کاربری');
    }
  }

  async waitForModularSystem() {
    return new Promise((resolve) => {
      const checkSystem = () => {
        if (window.popupIntegration && window.popupIntegration.isInitialized()) {
          resolve();
        } else {
          setTimeout(checkSystem, 50);
        }
      };
      checkSystem();
    });
  }

  getModuleReferences() {
    if (!window.popupIntegration) {
      console.warn('Modular system not available');
      return;
    }

    // Get references to modules for legacy compatibility
    const moduleNames = [
      'WatchlistManager', 'SettingsManager', 'TabManager', 'ExtensionBridge',
      'MessageHandler', 'UIHelpers', 'ModalManager', 'ComparisonManager', 'ButtonManager'
    ];

    const moduleMap = {
      'WatchlistManager': 'watchlist',
      'SettingsManager': 'settings',
      'TabManager': 'tabs',
      'ExtensionBridge': 'extension',
      'MessageHandler': 'messages',
      'UIHelpers': 'ui',
      'ModalManager': 'modals',
      'ComparisonManager': 'comparison',
      'ButtonManager': 'buttons'
    };

    console.log('🔍 Checking module availability:');
    moduleNames.forEach(moduleName => {
      const module = window.popupIntegration.getModule(moduleName);
      const mapKey = moduleMap[moduleName];

      if (module) {
        this.modules.set(mapKey, module);
        console.log(`✅ ${moduleName} → Available`);
      } else {
        console.warn(`❌ ${moduleName} → Not found`);
      }
    });

    console.log(`📦 Retrieved ${this.modules.size} module references`);

    // Special check for ButtonManager
    const buttonManager = this.modules.get('buttons');
    if (buttonManager) {
      console.log('🔘 ButtonManager found - checking if initialized');
      console.log('🔘 ButtonManager init state:', buttonManager.initialized);
    } else {
      console.warn('⚠️ ButtonManager not available - fallback buttons will be used');
    }
  }

  setupLegacyEventListeners() {
    // Listen for events from the modular system
    if (window.popupEventBus) {
      window.popupEventBus.on('extension:status-received', (data) => {
        this.isActive = data.status.active;
        this.pageType = data.status.pageType;
        this.updateUI();
      });

      window.popupEventBus.on('extension:toggled', (data) => {
        this.isActive = data.isActive;
        this.updateUI();
      });

      window.popupEventBus.on('ui:page-type-updated', (data) => {
        this.pageType = data.pageType;
      });
    }

    // Setup fallback button event listeners for General Controls
    // This ensures buttons work even if ButtonManager fails to initialize
    this.setupFallbackButtonListeners();
  }

  setupFallbackButtonListeners() {
    // General Controls buttons - setup direct event listeners as fallback
    const buttons = [
      { id: 'toggleMainBtn', handler: 'handleToggle', label: 'Toggle Extension' },
      { id: 'updateMainBtn', handler: 'handleUpdate', label: 'Update Prices' },
      { id: 'emergencyStopMainBtn', handler: 'handleEmergencyStop', label: 'Emergency Stop' },
      { id: 'clearDisplayMainBtn', handler: 'handleClearDisplay', label: 'Clear Display' },
      { id: 'clearCacheMainBtn', handler: 'handleClearCache', label: 'Clear Cache' },
      { id: 'resetAllMainBtn', handler: 'handleResetAll', label: 'Reset All' }
    ];

    buttons.forEach(({ id, handler, label }) => {
      const element = document.getElementById(id);
      if (element) {
        // Remove any existing listeners to avoid duplicates
        element.replaceWith(element.cloneNode(true));
        const freshElement = document.getElementById(id);

        freshElement.addEventListener('click', async (e) => {
          e.preventDefault();
          console.log(`🔘 Fallback: ${label} clicked`);

          try {
            // Try to use the modular system first
            const extensionBridge = this.modules.get('extension');
            if (extensionBridge && typeof extensionBridge[handler] === 'function') {
              console.log(`✅ Using ExtensionBridge.${handler}()`);
              await extensionBridge[handler]();
            } else if (typeof this[handler] === 'function') {
              // Fall back to PopupController methods
              console.log(`✅ Using PopupController.${handler}()`);
              await this[handler]();
            } else {
              console.error(`❌ No handler found for ${handler}`);
              this.showError(`خطا: عملکرد ${label} در دسترس نیست`);
            }
          } catch (error) {
            console.error(`❌ Error in ${handler}:`, error);
            this.showError(`خطا در ${label}: ${error.message}`);
          }
        });

        console.log(`🔗 Fallback listener attached to ${id}`);
      } else {
        console.warn(`⚠️ Button element not found: ${id}`);
      }
    });
  }

  async loadInitialState() {
    // Delegate to ExtensionBridge for status
    const extensionBridge = this.modules.get('extension');
    if (extensionBridge) {
      try {
        const status = await extensionBridge.getExtensionStatus();
        this.isActive = status.active || false;
        this.pageType = status.pageType || 'unknown';
        this.updateUI();
      } catch (error) {
        console.error('Error loading initial state:', error);
      }
    }
  }

  updateUI() {
    // Basic UI updates - most UI management is now in modules
    if (this.statusElement) {
      if (this.isActive) {
        this.statusElement.innerHTML = '<span>وضعیت: فعال</span><div class="status-icon">🟢</div>';
        this.statusElement.className = 'status active';
      } else {
        this.statusElement.innerHTML = '<span>وضعیت: غیرفعال</span><div class="status-icon">⚪</div>';
        this.statusElement.className = 'status inactive';
      }
    }

    // Emit event for modules to respond
    if (window.popupEventBus) {
      window.popupEventBus.emit('popup:ui-updated', {
        isActive: this.isActive,
        pageType: this.pageType
      });
    }
  }

  // Legacy methods for backward compatibility - delegate to modules
  async getExtensionStatus() {
    const extensionBridge = this.modules.get('extension');
    return extensionBridge ? await extensionBridge.getExtensionStatus() : null;
  }

  async handleToggle() {
    const extensionBridge = this.modules.get('extension');
    return extensionBridge ? await extensionBridge.handleToggle() : null;
  }

  async handleUpdate() {
    const extensionBridge = this.modules.get('extension');
    return extensionBridge ? await extensionBridge.handleUpdate() : null;
  }

  async handleEmergencyStop() {
    const extensionBridge = this.modules.get('extension');
    return extensionBridge ? await extensionBridge.handleEmergencyStop() : null;
  }

  async handleClearDisplay() {
    const extensionBridge = this.modules.get('extension');
    return extensionBridge ? await extensionBridge.handleClearDisplay() : null;
  }

  async handleClearCache() {
    const extensionBridge = this.modules.get('extension');
    return extensionBridge ? await extensionBridge.handleClearCache() : null;
  }

  async handleResetAll() {
    const extensionBridge = this.modules.get('extension');
    return extensionBridge ? await extensionBridge.handleResetAll() : null;
  }

  showSuccess(message) {
    const uiHelpers = this.modules.get('ui');
    if (uiHelpers) {
      uiHelpers.showSuccess(message);
    } else {
      // Fallback for legacy compatibility
      console.log('Success:', message);
    }
  }

  showError(message) {
    const uiHelpers = this.modules.get('ui');
    if (uiHelpers) {
      uiHelpers.showError(message);
    } else {
      // Fallback for legacy compatibility
      if (this.errorElement) {
        this.errorElement.innerHTML = `<strong>⚠️ خطا:</strong> ${message}`;
        this.errorElement.style.display = 'block';
      }
      console.error('Error:', message);
    }
  }

  showLoading(show = true, message = 'در حال بارگذاری...') {
    const uiHelpers = this.modules.get('ui');
    if (uiHelpers) {
      uiHelpers.showLoading(show, message);
    } else {
      // Fallback for legacy compatibility
      if (this.loadingElement) {
        if (show) {
          this.loadingElement.textContent = message;
          this.loadingElement.style.display = 'block';
        } else {
          this.loadingElement.style.display = 'none';
        }
      }
    }
  }

  hideError() {
    if (window.popupEventBus) {
      window.popupEventBus.emit('ui:hideError');
    }
  }

  // Watchlist methods - delegate to WatchlistManager
  async loadWatchlistSummary() {
    const watchlistManager = this.modules.get('watchlist');
    return watchlistManager ? await watchlistManager.loadWatchlistSummary() : null;
  }

  async showWatchlistModal() {
    const watchlistManager = this.modules.get('watchlist');
    return watchlistManager ? await watchlistManager.showWatchlistModal() : null;
  }

  async refreshWatchlist() {
    const watchlistManager = this.modules.get('watchlist');
    return watchlistManager ? await watchlistManager.refreshWatchlist() : null;
  }

  // Settings methods - delegate to SettingsManager
  async loadSettingsFromStorage() {
    const settingsManager = this.modules.get('settings');
    return settingsManager ? await settingsManager.loadAllSettings() : null;
  }

  // Tab methods - delegate to TabManager
  switchToTab(index) {
    const tabManager = this.modules.get('tabs');
    if (tabManager) {
      tabManager.switchToTab(index);
    }
  }

  initTabs() {
    // Tabs are already initialized by TabManager
    if (window.popupEventBus) {
      window.popupEventBus.emit('tabs:legacy-init-requested');
    }
  }

  // Module access for debugging and advanced usage
  getModule(name) {
    return this.modules.get(name);
  }

  getAllModules() {
    return new Map(this.modules);
  }

  // Debug utilities
  logStatus() {
    console.log('📊 PopupController Status:');
    console.log(`- Initialized: ${this.initialized}`);
    console.log(`- Active: ${this.isActive}`);
    console.log(`- Page Type: ${this.pageType}`);
    console.log(`- Modules: ${this.modules.size}`);

    for (const [name, module] of this.modules) {
      console.log(`  - ${name}: ${module ? '✅' : '❌'}`);
      if (module && module.initialized !== undefined) {
        console.log(`    └─ Initialized: ${module.initialized}`);
      }
    }

    // Check button elements
    console.log('🔘 Button elements check:');
    const buttonIds = ['toggleMainBtn', 'updateMainBtn', 'emergencyStopMainBtn',
                      'clearDisplayMainBtn', 'clearCacheMainBtn', 'resetAllMainBtn'];
    buttonIds.forEach(id => {
      const element = document.getElementById(id);
      console.log(`  - ${id}: ${element ? '✅ Found' : '❌ Missing'}`);
    });

    // Check ButtonManager specifically
    const buttonManager = this.modules.get('buttons');
    if (buttonManager) {
      console.log('🔘 ButtonManager Details:');
      console.log(`  - Name: ${buttonManager.name}`);
      console.log(`  - Initialized: ${buttonManager.initialized}`);
      console.log(`  - Elements loaded: ${Object.keys(buttonManager.elements || {}).length}`);
    }

    // Delegate to integration for full stats
    if (window.popupIntegration) {
      window.popupIntegration.logStatus();
    }
  }

  // Test button functionality
  testButtons() {
    console.log('🧪 Testing General Controls buttons:');
    const buttons = ['toggleMainBtn', 'updateMainBtn', 'emergencyStopMainBtn',
                    'clearDisplayMainBtn', 'clearCacheMainBtn', 'resetAllMainBtn'];

    buttons.forEach(id => {
      const element = document.getElementById(id);
      if (element) {
        const listeners = element.onclick ? 'onclick set' : 'no onclick';
        const eventListeners = element.hasAttribute('data-listeners') ? 'has event listeners' : 'no event listeners';
        console.log(`  - ${id}: Found, ${listeners}, ${eventListeners}`);
      } else {
        console.log(`  - ${id}: ❌ Not found`);
      }
    });
  }

  // Legacy compatibility shims
  detectPageTypeFromUrl(url) {
    const extensionBridge = this.modules.get('extension');
    return extensionBridge ? extensionBridge.detectPageTypeFromUrl(url) : 'unknown';
  }

  updatePageTypeDisplay(pageType) {
    if (window.popupEventBus) {
      window.popupEventBus.emit('ui:update-page-type', { pageType });
    }
  }

  addSystemMessage(type, message) {
    if (window.popupEventBus) {
      window.popupEventBus.emit('messages:add', { type, message });
    }
  }

  // Cleanup
  async destroy() {
    console.log('🧹 PopupController cleanup started');

    // Let integration handle module cleanup
    if (window.popupIntegration) {
      await window.popupIntegration.destroy();
    }

    this.modules.clear();
    this.initialized = false;

    console.log('✅ PopupController cleanup complete');
  }
}

// Initialize popup when DOM is ready
let popupController;
document.addEventListener('DOMContentLoaded', () => {
  popupController = new PopupController();

  // Make debug functions globally available
  window.debugPopup = () => popupController.logStatus();
  window.testButtons = () => popupController.testButtons();
});

// Make available globally for debugging
window.PopupController = PopupController;