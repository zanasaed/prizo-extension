/**
 * @Author: Smart Cart System
 * @Date: 2025-01-18
 * Smart Cart Optimizer Integration - Main API for basket optimization
 * This file integrates the basket optimizer with the existing Smart Cart system
 */

/**
 * Smart Cart Optimizer - Integrates basket optimization with Smart Cart Manager
 */
class SmartCartOptimizer {
  constructor(smartCartManager) {
    this.smartCartManager = smartCartManager;
    this.basketOptimizer = null;
    this.initialized = false;
  }

  /**
   * Initialize the optimizer with required dependencies
   */
  async initialize() {
    try {
      // Dynamically import optimizer components
      await this.loadOptimizerComponents();

      this.basketOptimizer = new window.BasketOptimizer();
      this.initialized = true;

      console.log('✅ Smart Cart Optimizer initialized');
      return true;
    } catch (error) {
      console.error('❌ Failed to initialize Smart Cart Optimizer:', error);
      return false;
    }
  }

  /**
   * Load optimizer components (for browser extension environment)
   */
  async loadOptimizerComponents() {
    // In a browser extension, we would load these as separate script files
    // For now, assume they're already loaded in the global scope
    const requiredComponents = [
      'BasketOptimizer',
      'BasketValidator',
      'CostCalculator',
      'ExhaustiveSearchOptimizer',
      'GreedyLocalSearchOptimizer'
    ];

    for (const component of requiredComponents) {
      if (!window[component]) {
        throw new Error(`Required component ${component} not found`);
      }
    }
  }

  /**
   * Optimize current Smart Cart items
   * @param {Object} sellerData - Available sellers and pricing data
   * @param {Object} options - Optimization options
   * @returns {Object} Optimization result
   */
  async optimizeCurrentCart(sellerData, options = {}) {
    if (!this.initialized) {
      throw new Error('Optimizer not initialized. Call initialize() first.');
    }

    if (!this.smartCartManager) {
      throw new Error('Smart Cart Manager not available');
    }

    try {
      // Get current cart items
      const cartItems = this.smartCartManager.getCartItems();

      if (cartItems.length === 0) {
        return {
          success: false,
          error: 'No items in cart to optimize',
          suggestions: ['Add some products to your Smart Cart first']
        };
      }

      // Convert cart items to basket optimization format
      const basketData = this.convertCartToBasketData(cartItems, sellerData, options);

      // Run optimization
      const result = await this.basketOptimizer.optimizeBasket(basketData);

      // Process and return results with Smart Cart integration
      return this.processOptimizationResult(result, cartItems, options);

    } catch (error) {
      console.error('❌ Cart optimization failed:', error);
      return {
        success: false,
        error: error.message,
        suggestions: ['Check your cart items and seller data']
      };
    }
  }

  /**
   * Convert Smart Cart items to basket optimization format
   */
  convertCartToBasketData(cartItems, sellerData, options) {
    const products = cartItems.map(item => ({
      id: item.productId,
      quantity: item.quantity || 1,
      sellers: this.getAvailableSellersForProduct(item.productId, sellerData),
      preferredSeller: options.preferredSellers?.[item.productId]
    }));

    return {
      products,
      sellers: sellerData.sellers || {},
      marketplaceShipping: sellerData.marketplaceShipping || 0,
      optimizationMode: options.mode || 'COST',
      maxSellers: options.maxSellers
    };
  }

  /**
   * Get available sellers for a specific product
   */
  getAvailableSellersForProduct(productId, sellerData) {
    // This would typically fetch real seller data from Digikala API
    // For now, return mock data structure
    return sellerData.productSellers?.[productId] || [
      {
        sellerId: 'digikala',
        price: 100000,
        inventory: 5,
        shipsDirectly: false
      }
    ];
  }

  /**
   * Process optimization result for Smart Cart integration
   */
  processOptimizationResult(result, originalCartItems, options) {
    if (!result.success) {
      return {
        success: false,
        error: result.error,
        suggestions: this.generateErrorSuggestions(result.error)
      };
    }

    // Calculate savings compared to current configuration
    const currentCost = this.calculateCurrentCartCost(originalCartItems);
    const savings = currentCost - result.totalCost;

    // Generate user-friendly recommendations
    const recommendations = this.generateRecommendations(result, originalCartItems, savings);

    return {
      success: true,
      optimization: {
        strategy: result.strategy,
        totalCost: result.totalCost,
        totalSavings: savings,
        savingsPercentage: currentCost > 0 ? ((savings / currentCost) * 100) : 0,
        sellersUsed: result.sellersUsed,
        assignments: result.assignments
      },
      recommendations,
      canApplyAutomatically: this.canApplyAutomatically(result, options),
      metadata: {
        optimizedAt: Date.now(),
        itemCount: originalCartItems.length,
        algorithm: result.strategy
      }
    };
  }

  /**
   * Calculate current cart cost (simplified)
   */
  calculateCurrentCartCost(cartItems) {
    // This is a simplified calculation
    // In reality, would need to fetch current seller assignments and shipping costs
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  }

  /**
   * Generate user-friendly recommendations
   */
  generateRecommendations(result, cartItems, savings) {
    const recommendations = [];

    if (savings > 0) {
      recommendations.push({
        type: 'savings',
        message: `Save ${savings.toLocaleString()} rials by switching sellers`,
        priority: 'high',
        actionable: true
      });
    }

    if (result.sellersUsed.length < cartItems.length) {
      recommendations.push({
        type: 'consolidation',
        message: `Consolidate to ${result.sellersUsed.length} sellers for better shipping rates`,
        priority: 'medium',
        actionable: true
      });
    }

    // Add shipping optimization recommendations
    if (result.shippingBreakdown?.type === 'marketplace_hybrid') {
      recommendations.push({
        type: 'shipping',
        message: 'Use marketplace shipping for eligible items to save on delivery',
        priority: 'medium',
        actionable: false
      });
    }

    return recommendations;
  }

  /**
   * Check if optimization can be applied automatically
   */
  canApplyAutomatically(result, options) {
    // Don't auto-apply if it involves changing preferred sellers
    if (options.respectPreferences === true) {
      return false;
    }

    // Don't auto-apply if savings are minimal
    const minSavingsThreshold = 10000; // 10,000 rials
    if (result.totalSavings < minSavingsThreshold) {
      return false;
    }

    return true;
  }

  /**
   * Generate suggestions for error cases
   */
  generateErrorSuggestions(error) {
    const suggestions = [];

    if (error.includes('no available sellers')) {
      suggestions.push('Check if products are still in stock');
      suggestions.push('Try removing out-of-stock items from cart');
    }

    if (error.includes('preferred seller')) {
      suggestions.push('Check preferred seller availability');
      suggestions.push('Consider removing seller preferences for better optimization');
    }

    if (error.includes('invalid input')) {
      suggestions.push('Refresh the page and try again');
      suggestions.push('Contact support if the problem persists');
    }

    return suggestions.length > 0 ? suggestions : ['Try again later'];
  }

  /**
   * Get optimization statistics for debugging
   */
  async getOptimizationStats(sellerData) {
    if (!this.initialized) return null;

    const cartItems = this.smartCartManager.getCartItems();
    if (cartItems.length === 0) return null;

    const basketData = this.convertCartToBasketData(cartItems, sellerData);
    return this.basketOptimizer.getOptimizationStats?.(basketData);
  }

  /**
   * Test the optimizer with sample data
   */
  async runOptimizationTest() {
    if (!this.initialized) {
      await this.initialize();
    }

    // Use test data from the test suite
    const testData = window.testScenarios?.smallBasket;
    if (!testData) {
      throw new Error('Test scenarios not available');
    }

    return await this.basketOptimizer.optimizeBasket(testData);
  }
}

/**
 * Factory function to create and initialize the optimizer
 */
async function createSmartCartOptimizer(smartCartManager) {
  const optimizer = new SmartCartOptimizer(smartCartManager);
  await optimizer.initialize();
  return optimizer;
}

/**
 * Simple API for quick optimization without Smart Cart integration
 */
async function optimizeBasket(basketData) {
  const optimizer = new window.BasketOptimizer();
  return await optimizer.optimizeBasket(basketData);
}

// Browser extension compatibility
if (typeof window !== 'undefined') {
  window.SmartCartOptimizer = SmartCartOptimizer;
  window.createSmartCartOptimizer = createSmartCartOptimizer;
  window.optimizeBasket = optimizeBasket;
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    SmartCartOptimizer,
    createSmartCartOptimizer,
    optimizeBasket
  };
}