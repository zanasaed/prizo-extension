/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-16
 * First-Time Welcome Guide - Shows introductory guide for new users
 */

class FirstTimeWelcome {
  constructor() {
    this.storageKey = 'prizo_welcome_completed';
    this.guideContainer = null;
    this.currentStep = 0;
    this.totalSteps = 6;
    this.isActive = false;

    // Features to showcase
    this.features = [
      {
        title: '🎯 خوش آمدید به Prizo!',
        subtitle: 'دستیار هوشمند Prizo برای دیجی‌کالا',
        description: 'Prizo به شما کمک می‌کند تا بهترین قیمت‌ها را پیدا کنید و خرید هوشمندانه‌تری داشته باشید.',
        icon: '🎉',
        details: [
          'رابط کاربری جدید با 5 تب مجزا',
          'نظارت هوشمند بر قیمت‌ها ',
          'عملیات گروهی و مدیریت پیشرفته',
          'مقایسه قیمت در سایت‌های دیگر',
          'اطلاع‌رسانی خودکار تخفیف‌ها'
        ]
      },
      {
        title: '📋 نظارت و مدیریت قیمت',
        subtitle: 'لیست نظارت هوشمند با تصاویر و قابلیت‌های جدید',
        description: 'محصولات مورد نظر را به لیست نظارت اضافه کنید و از تغییرات قیمت مطلع شوید.',
        icon: '📊',
        details: [
          'عملیات گروهی (Bulk Actions) برای چند محصول',
          'بروزرسانی دسته‌ای قیمت‌ها',
          'فیلترینگ و جستجوی پیشرفته',
          'ویرایش سریع شرایط نظارت',
          'اطلاع‌رسانی خودکار تغییرات'
        ]
      },
      {
        title: '🎛️ مدیریت ویژگی‌ها',
        subtitle: 'کنترل آسان ویژگی‌های افزونه',
        description: 'از تب ویژگی‌ها، قابلیت‌های مختلف افزونه را به راحتی فعال یا غیرفعال کنید.',
        icon: '⚙️',
        details: [
          'فعال‌سازی خودکار در همه صفحات',
          'مرتب‌سازی بر اساس بیشترین تخفیف',
          'نمایش بهترین قیمت فعلی در سبد خرید',
          'مقایسه قیمت در سایت‌های دیگر'
        ]
      },
      {
        title: '🔧 تنظیمات پیشرفته',
        subtitle: 'پیکربندی دقیق عملکرد افزونه',
        description: 'در تب پیکربندی، تنظیمات پیشرفته افزونه را مطابق نیاز خود تنظیم کنید.',
        icon: '⚙️',
        details: [
          'تنظیم تأخیر شروع افزونه',
          'انتظار برای ثبات شبکه',
          'کنترل‌های کلی (فعال‌سازی، توقف)',
          'پاک کردن کش و ریست کامل'
        ]
      },
      {
        title: '🔗 مقایسه قیمت خارجی',
        subtitle: 'لینک‌های مقایسه قیمت در سایت‌های دیگر',
        description: 'لینک‌هایی برای مقایسه قیمت محصولات در سایت‌های مختلف در زیر عنوان محصول نمایش دهید.',
        icon: '🌐',
        details: [
          'افزودن سایت‌های مقایسه قیمت جدید',
          'نمایش آیکون‌های سایت‌ها',
          'پیش‌نمایش قبل از افزودن',
          'حذف و ویرایش سایت‌های موجود',
          'نمایش کوپن‌های تخفیف فروشنده'
        ]
      },
      {
        title: '💬 پیام‌ها و راهنما',
        subtitle: 'رابط ساده‌شده برای دسترسی سریع',
        description: 'تب‌های پیام‌ها و راهنما حالا با آیکون‌های ساده برای دسترسی آسان‌تر طراحی شده‌اند.',
        icon: 'ℹ️',
        details: [
          'مشاهده پیام‌های سیستم و هشدارها',
          'راهنمای کامل استفاده از افزونه',
          'دسترسی به راهنمای مقدماتی',
          'رابط کاربری بهینه‌شده برای موبایل'
        ]
      }
    ];
  }

  async initialize() {
    console.log('👋 Initializing First-Time Welcome Guide');

    // Check if user has already seen the welcome guide
    const hasSeenWelcome = await this.checkWelcomeStatus();

    if (!hasSeenWelcome) {
      console.log('🎉 First-time user detected, showing welcome guide');
      await this.showWelcomeGuide();
    } else {
      console.log('👤 Returning user, welcome guide skipped');
    }
  }

  async checkWelcomeStatus() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        const result = await chrome.storage.local.get([this.storageKey]);
        return result[this.storageKey] || false;
      }

      // Fallback to localStorage
      return localStorage.getItem(this.storageKey) === 'true';
    } catch (error) {
      console.error('❌ Error checking welcome status:', error);
      return false;
    }
  }

  async markWelcomeCompleted() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        await chrome.storage.local.set({ [this.storageKey]: true });
      } else {
        // Fallback to localStorage
        localStorage.setItem(this.storageKey, 'true');
      }
      console.log('✅ Welcome guide marked as completed');
    } catch (error) {
      console.error('❌ Error saving welcome status:', error);
    }
  }

  async showWelcomeGuide() {
    // Wait for page to be ready
    if (document.readyState === 'loading') {
      await new Promise(resolve => {
        document.addEventListener('DOMContentLoaded', resolve, { once: true });
      });
    }

    // Add small delay to ensure page is stable
    await new Promise(resolve => setTimeout(resolve, 1000));

    this.createWelcomeGuide();
    this.showStep(0);
    this.isActive = true;
  }

  createWelcomeGuide() {
    // Remove existing guide if any
    this.removeWelcomeGuide();

    // Create main container
    this.guideContainer = document.createElement('div');
    this.guideContainer.id = 'prizo-welcome-guide';
    this.guideContainer.innerHTML = `
      <div class="prizo-welcome-overlay">
        <div class="prizo-welcome-modal">
          <div class="prizo-welcome-header">
            <div class="prizo-welcome-logo">
              <span class="prizo-logo-icon">🎯</span>
              <span class="prizo-logo-text">Prizo</span>
            </div>
            <button class="prizo-welcome-close" aria-label="بستن راهنما">✕</button>
          </div>
          
          <div class="prizo-welcome-content">
            <div class="prizo-welcome-step-indicator">
              <span class="prizo-step-current">1</span>
              <span class="prizo-step-divider">/</span>
              <span class="prizo-step-total">${this.totalSteps}</span>
            </div>
            
            <div class="prizo-welcome-step-content">
              <div class="prizo-feature-icon">🎉</div>
              <h2 class="prizo-feature-title">عنوان مرحله</h2>
              <p class="prizo-feature-subtitle">زیرعنوان</p>
              <p class="prizo-feature-description">توضیحات</p>
              
              <ul class="prizo-feature-details">
                <!-- Details will be populated by JavaScript -->
              </ul>
            </div>
          </div>
          
          <div class="prizo-welcome-footer">
            <button class="prizo-btn prizo-btn-secondary" id="prizo-prev-step">
              قبلی
            </button>
            <div class="prizo-welcome-dots">
              ${Array.from({ length: this.totalSteps }, (_, i) =>
      `<span class="prizo-dot ${i === 0 ? 'active' : ''}" data-step="${i}"></span>`
    ).join('')}
            </div>
            <button class="prizo-btn prizo-btn-primary" id="prizo-next-step">
              بعدی
            </button>
          </div>
        </div>
      </div>
    `;

    // Add styles
    this.addWelcomeStyles();

    // Add event listeners
    this.setupEventListeners();

    // Add to page
    document.body.appendChild(this.guideContainer);
  }

  addWelcomeStyles() {
    if (document.getElementById('prizo-welcome-styles')) {
      return;
    }

    const styles = document.createElement('style');
    styles.id = 'prizo-welcome-styles';
    styles.textContent = `
      .prizo-welcome-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        font-family: 'Iranian Sans', 'Tahoma', sans-serif;
        direction: rtl;
        backdrop-filter: blur(3px);
      }

      .prizo-welcome-modal {
        background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
        border-radius: 16px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        max-width: 480px;
        width: 90%;
        max-height: 80vh;
        overflow: hidden;
        position: relative;
        border: 1px solid rgba(148, 163, 184, 0.1);
      }

      .prizo-welcome-header {
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        color: white;
        padding: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }

      .prizo-welcome-logo {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .prizo-logo-icon {
        font-size: 24px;
      }

      .prizo-logo-text {
        font-size: 20px;
        font-weight: bold;
      }

      .prizo-welcome-close {
        background: rgba(255, 255, 255, 0.2);
        border: none;
        color: white;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s;
        font-size: 18px;
      }

      .prizo-welcome-close:hover {
        background: rgba(255, 255, 255, 0.3);
      }

      .prizo-welcome-content {
        padding: 24px;
      }

      .prizo-welcome-step-indicator {
        text-align: center;
        color: #64748b;
        font-size: 14px;
        margin-bottom: 20px;
      }

      .prizo-step-current {
        color: #3b82f6;
        font-weight: bold;
      }

      .prizo-welcome-step-content {
        text-align: center;
      }

      .prizo-feature-icon {
        font-size: 48px;
        margin-bottom: 16px;
      }

      .prizo-feature-title {
        font-size: 24px;
        font-weight: bold;
        color: #1e293b;
        margin: 0 0 8px 0;
      }

      .prizo-feature-subtitle {
        font-size: 16px;
        color: #3b82f6;
        margin: 0 0 16px 0;
        font-weight: 500;
      }

      .prizo-feature-description {
        font-size: 14px;
        color: #475569;
        line-height: 1.6;
        margin: 0 0 20px 0;
      }

      .prizo-feature-details {
        list-style: none;
        padding: 0;
        margin: 0;
        display: grid;
        gap: 8px;
      }

      .prizo-feature-details li {
        display: flex;
        align-items: center;
        gap: 8px;
        background: #f1f5f9;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 13px;
        color: #334155;
      }

      .prizo-feature-details li:before {
        content: '✓';
        color: #10b981;
        font-weight: bold;
      }

      .prizo-welcome-footer {
        background: #f8fafc;
        padding: 16px 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-top: 1px solid #e2e8f0;
      }

      .prizo-btn {
        padding: 8px 16px;
        border-radius: 6px;
        border: none;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        transition: all 0.2s;
        min-width: 80px;
      }

      .prizo-btn-primary {
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        color: white;
      }

      .prizo-btn-primary:hover {
        background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
        transform: translateY(-1px);
      }

      .prizo-btn-primary:disabled {
        background: #94a3b8;
        cursor: not-allowed;
        transform: none;
      }

      .prizo-btn-secondary {
        background: #e2e8f0;
        color: #475569;
      }

      .prizo-btn-secondary:hover {
        background: #cbd5e1;
      }

      .prizo-btn-secondary:disabled {
        background: #f1f5f9;
        color: #cbd5e1;
        cursor: not-allowed;
      }

      .prizo-welcome-dots {
        display: flex;
        gap: 8px;
      }

      .prizo-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #cbd5e1;
        cursor: pointer;
        transition: background 0.2s;
      }

      .prizo-dot.active {
        background: #3b82f6;
      }

      .prizo-dot:hover {
        background: #94a3b8;
      }

      .prizo-dot.active:hover {
        background: #2563eb;
      }

      /* Animations */
      @keyframes prizo-fade-in {
        from {
          opacity: 0;
          transform: scale(0.95);
        }
        to {
          opacity: 1;
          transform: scale(1);
        }
      }

      .prizo-welcome-modal {
        animation: prizo-fade-in 0.3s ease-out;
      }

      .prizo-welcome-step-content {
        animation: prizo-fade-in 0.2s ease-out;
      }

      /* Mobile responsiveness */
      @media (max-width: 480px) {
        .prizo-welcome-modal {
          width: 95%;
          max-height: 85vh;
        }
        
        .prizo-feature-title {
          font-size: 20px;
        }
        
        .prizo-feature-icon {
          font-size: 40px;
        }
        
        .prizo-welcome-footer {
          padding: 12px 16px;
        }
      }
    `;

    document.head.appendChild(styles);
  }

  setupEventListeners() {
    const container = this.guideContainer;

    // Close button
    const closeBtn = container.querySelector('.prizo-welcome-close');
    closeBtn.addEventListener('click', () => this.closeGuide());

    // Navigation buttons
    const prevBtn = container.querySelector('#prizo-prev-step');
    const nextBtn = container.querySelector('#prizo-next-step');

    prevBtn.addEventListener('click', () => this.previousStep());
    nextBtn.addEventListener('click', () => this.nextStep());

    // Dot navigation
    const dots = container.querySelectorAll('.prizo-dot');
    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => this.showStep(index));
    });

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
      if (!this.isActive) return;

      if (e.key === 'Escape') {
        this.closeGuide();
      } else if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
        e.preventDefault();
        if (e.key === 'ArrowRight') {
          this.nextStep();
        } else {
          this.previousStep();
        }
      }
    });

    // Click outside to close
    const overlay = container.querySelector('.prizo-welcome-overlay');
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        this.closeGuide();
      }
    });
  }

  showStep(stepIndex) {
    if (stepIndex < 0 || stepIndex >= this.totalSteps) return;

    this.currentStep = stepIndex;
    const feature = this.features[stepIndex];

    // Update content
    const container = this.guideContainer;

    container.querySelector('.prizo-step-current').textContent = stepIndex + 1;
    container.querySelector('.prizo-feature-icon').textContent = feature.icon;
    container.querySelector('.prizo-feature-title').textContent = feature.title;
    container.querySelector('.prizo-feature-subtitle').textContent = feature.subtitle;
    container.querySelector('.prizo-feature-description').textContent = feature.description;

    // Update details list
    const detailsList = container.querySelector('.prizo-feature-details');
    detailsList.innerHTML = feature.details.map(detail => `<li>${detail}</li>`).join('');

    // Update navigation buttons
    const prevBtn = container.querySelector('#prizo-prev-step');
    const nextBtn = container.querySelector('#prizo-next-step');

    prevBtn.disabled = stepIndex === 0;

    if (stepIndex === this.totalSteps - 1) {
      nextBtn.textContent = 'شروع استفاده';
      nextBtn.classList.remove('prizo-btn-primary');
      nextBtn.classList.add('prizo-btn-primary');
    } else {
      nextBtn.textContent = 'بعدی';
    }

    // Update dots
    const dots = container.querySelectorAll('.prizo-dot');
    dots.forEach((dot, index) => {
      dot.classList.toggle('active', index === stepIndex);
    });
  }

  nextStep() {
    if (this.currentStep < this.totalSteps - 1) {
      this.showStep(this.currentStep + 1);
    } else {
      this.completeGuide();
    }
  }

  previousStep() {
    if (this.currentStep > 0) {
      this.showStep(this.currentStep - 1);
    }
  }

  async completeGuide() {
    await this.markWelcomeCompleted();
    this.closeGuide();

    // Show completion notification
    this.showCompletionNotification();
  }

  closeGuide() {
    if (this.guideContainer) {
      this.guideContainer.remove();
      this.guideContainer = null;
    }

    const styles = document.getElementById('prizo-welcome-styles');
    if (styles) {
      styles.remove();
    }

    this.isActive = false;
    console.log('👋 Welcome guide closed');
  }

  showCompletionNotification() {
    // Create a simple notification
    const notification = document.createElement('div');
    notification.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 10px 25px -12px rgba(0, 0, 0, 0.25);
        z-index: 10000;
        font-family: 'Iranian Sans', 'Tahoma', sans-serif;
        direction: rtl;
        animation: slideIn 0.3s ease-out;
      ">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 16px;">✅</span>
          <span style="font-weight: 500;">خوش آمدید! افزونه Prizo آماده استفاده است.</span>
        </div>
      </div>
      <style>
        @keyframes slideIn {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      </style>
    `;

    document.body.appendChild(notification);

    // Auto-remove notification after 4 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        notification.style.animation = 'slideIn 0.3s ease-out reverse';
        setTimeout(() => notification.remove(), 300);
      }
    }, 4000);
  }

  removeWelcomeGuide() {
    const existing = document.getElementById('prizo-welcome-guide');
    if (existing) {
      existing.remove();
    }
  }

  // Public method to manually show guide (for testing or re-showing)
  async showGuideAgain() {
    console.log('🔄 Manually showing welcome guide');
    await this.showWelcomeGuide();
  }

  // Public method to reset welcome status (for testing)
  async resetWelcomeStatus() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        await chrome.storage.local.remove([this.storageKey]);
      } else {
        localStorage.removeItem(this.storageKey);
      }
      console.log('🔄 Welcome status reset - guide will show on next page load');
    } catch (error) {
      console.error('❌ Error resetting welcome status:', error);
    }
  }
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.FirstTimeWelcome = FirstTimeWelcome;
}