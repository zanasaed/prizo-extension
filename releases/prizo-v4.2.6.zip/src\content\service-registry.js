/**
 * Service Registry for Content Script
 * Manages dependency injection and service initialization
 */
class ServiceRegistry {
  constructor() {
    this.services = new Map();
    this.initialized = false;
  }

  register(name, serviceClass, dependencies = []) {
    this.services.set(name, {
      class: serviceClass,
      dependencies,
      instance: null
    });
  }

  async get(name) {
    const service = this.services.get(name);
    if (!service) {
      throw new Error(`Service ${name} not registered`);
    }

    if (!service.instance) {
      // Resolve dependencies
      const deps = await Promise.all(
        service.dependencies.map(dep => this.get(dep))
      );
      service.instance = new service.class(...deps);

      if (typeof service.instance.initialize === 'function') {
        await service.instance.initialize();
      }
    }

    return service.instance;
  }

  async initializeServices() {
    // Register services with their dependencies
    if (typeof window.DOMManager !== 'undefined') {
      this.register('domManager', window.DOMManager);
    }

    if (typeof window.DataManager !== 'undefined') {
      this.register('dataManager', window.DataManager, ['domManager']);
    }

    if (typeof window.ValidationManager !== 'undefined') {
      this.register('validationManager', window.ValidationManager);
    }

    if (typeof window.StorageManager !== 'undefined') {
      this.register('storageManager', window.StorageManager);
    }

    if (typeof window.URLSafetyManager !== 'undefined') {
      this.register('urlSafety', window.URLSafetyManager);
    }

    if (typeof window.LoggerService !== 'undefined') {
      this.register('loggerService', window.LoggerService);
    }

    if (typeof window.SmartCartManager !== 'undefined') {
      this.register('smartCartManager', window.SmartCartManager, ['eventBus', 'storageService']);
    }

    this.initialized = true;
  }

  isInitialized() {
    return this.initialized;
  }

  listRegisteredServices() {
    return Array.from(this.services.keys());
  }
}

window.ServiceRegistry = ServiceRegistry;