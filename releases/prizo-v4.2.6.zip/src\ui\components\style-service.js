/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-05
 * Style Service - Manages modern CSS injection and styling for extension elements
 */
class StyleService {
  constructor(eventBus) {
    this.eventBus = eventBus;
    this.injectedStyles = new Set();
    this.styleElement = null;
    this.darkModeObserver = null;
  }

  initialize() {
    this.injectMainStyles();
    this.setupDarkModeDetection();
    this.eventBus.on('style:inject', this.injectStyles.bind(this));
    console.log('✅ Style service initialized');
  }

  injectMainStyles() {
    if (this.styleElement) return;

    this.styleElement = document.createElement('style');
    this.styleElement.id = 'digikala-extension-styles';
    this.styleElement.textContent = this.getMainStylesheet();
    
    // Insert at the beginning of head to allow override
    document.head.insertBefore(this.styleElement, document.head.firstChild);
    
    console.log('💅 Main extension styles injected');
  }

  getMainStylesheet() {
    return `
      /* Digikala Price Extension - Modern Styles */
      :root {
        --ext-primary: #3b82f6;
        --ext-primary-light: #60a5fa;
        --ext-success: #10b981;
        --ext-success-light: #34d399;
        --ext-warning: #f59e0b;
        --ext-warning-light: #fbbf24;
        --ext-error: #ef4444;
        --ext-error-light: #f87171;
        --ext-info: #0ea5e9;
        --ext-info-light: #38bdf8;
        
        --ext-gray-50: #f9fafb;
        --ext-gray-100: #f3f4f6;
        --ext-gray-200: #e5e7eb;
        --ext-gray-500: #6b7280;
        --ext-gray-700: #374151;
        
        --ext-transition: 200ms ease-in-out;
        --ext-transition-spring: 300ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
        --ext-shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
        --ext-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        --ext-shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        --ext-blur: blur(8px);
      }

      /* Dark mode adaptations */
      @media (prefers-color-scheme: dark) {
        :root {
          --ext-gray-50: #1e293b;
          --ext-gray-100: #334155;
          --ext-gray-200: #475569;
          --ext-gray-500: #94a3b8;
          --ext-gray-700: #f1f5f9;
        }
      }

      /* Base extension styles */
      .monthly-price-section,
      .monthly-price-main-section,
      .cart-monthly-price-info,
      .seller-price-section,
      .extension-price-info {
        font-family: 'Segoe UI', 'Vazir', system-ui, -apple-system, sans-serif !important;
        box-sizing: border-box !important;
        transition: all var(--ext-transition) !important;
        position: relative !important;
        overflow: hidden !important;
        backdrop-filter: var(--ext-blur) !important;
        animation: slideInUp 0.4s var(--ext-transition-spring) !important;
      }

      /* Monthly price section for product lists */
      .monthly-price-section {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%) !important;
        border: 1px solid #ffeeba !important;
        border-radius: 6px !important;
        padding: 6px 8px !important;
        margin: 4px 0 !important;
        font-size: 11px !important;
        color: #856404 !important;
        display: flex !important;
        align-items: center !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1) !important;
        font-weight: normal !important;
        position: relative !important;
        overflow: visible !important;
        animation: none !important;
      }

      .monthly-price-section::before {
        display: none !important;
      }

      .monthly-price-section:hover {
        transform: none !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1) !important;
      }

      /* Main monthly price section for product detail pages */
      .monthly-price-main-section {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%) !important;
        border: 1px solid #ffeeba !important;
        border-radius: 8px !important;
        padding: 12px 16px !important;
        margin-top: 16px !important;
        font-size: 14px !important;
        color: #856404 !important;
        font-weight: normal !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1) !important;
        position: relative !important;
        overflow: visible !important;
        animation: none !important;
      }

      .monthly-price-main-section::before {
        display: none !important;
      }

      .monthly-price-main-section:hover {
        transform: none !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1) !important;
      }

      /* Cart price info */
      .cart-monthly-price-info {
        background: linear-gradient(135deg, #e1f5fe 0%, #b3e5fc 100%) !important;
        border: 1px solid #81d4fa !important;
        border-radius: 4px !important;
        padding: 4px 6px !important;
        margin: 3px 0 !important;
        font-size: 10px !important;
        color: #0277bd !important;
        display: flex !important;
        align-items: center !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.08) !important;
        font-weight: normal !important;
        position: relative !important;
        overflow: visible !important;
        animation: none !important;
      }

      .cart-monthly-price-info::before {
        display: none !important;
      }

      .cart-monthly-price-info:hover {
        transform: none !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.08) !important;
      }

      /* Seller price section */
      .seller-price-section {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%) !important;
        border: 1px solid #ffeeba !important;
        border-radius: 6px !important;
        padding: 8px !important;
        margin-top: 8px !important;
        font-size: 12px !important;
        color: #856404 !important;
        font-weight: normal !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1) !important;
        position: relative !important;
        overflow: visible !important;
        animation: none !important;
      }

      .seller-price-section::before {
        display: none !important;
      }

      .seller-price-section:hover {
        transform: none !important;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1) !important;
      }

      /* Price indicators */
      .extension-price-indicator {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        width: 20px !important;
        height: 20px !important;
        border-radius: 4px !important;
        font-size: 10px !important;
        font-weight: bold !important;
        margin-left: 6px !important;
        transition: all var(--ext-transition) !important;
        position: relative !important;
        overflow: hidden !important;
      }

      .extension-price-indicator::after {
        content: '' !important;
        position: absolute !important;
        inset: 0 !important;
        background: linear-gradient(135deg, rgba(255,255,255,0.3), rgba(255,255,255,0.1)) !important;
        border-radius: inherit !important;
        pointer-events: none !important;
      }

      .extension-price-indicator--good {
        background: var(--ext-success) !important;
        color: white !important;
        box-shadow: 0 2px 4px rgba(16, 185, 129, 0.3) !important;
      }

      .extension-price-indicator--warning {
        background: var(--ext-warning) !important;
        color: white !important;
        box-shadow: 0 2px 4px rgba(245, 158, 11, 0.3) !important;
      }

      .extension-price-indicator--high {
        background: var(--ext-error) !important;
        color: white !important;
        box-shadow: 0 2px 4px rgba(239, 68, 68, 0.3) !important;
      }

      /* Status indicators */
      .seller-updated-indicator,
      .seller-unavailable-indicator,
      .seller-error-indicator {
        position: absolute !important;
        top: 4px !important;
        right: 4px !important;
        z-index: 1000 !important;
        border-radius: 4px !important;
        padding: 2px 6px !important;
        font-size: 9px !important;
        font-weight: 500 !important;
        animation: none !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        box-shadow: 0 1px 1px rgba(0,0,0,0.08) !important;
      }

      .seller-updated-indicator {
        background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%) !important;
        color: #2e7d32 !important;
        border: 1px solid #c8e6c9 !important;
      }

      .seller-unavailable-indicator {
        background: linear-gradient(135deg, #ffcdd2 0%, #ef9a9a 100%) !important;
        color: #c62828 !important;
        border: 1px solid #ffcdd2 !important;
      }

      .seller-error-indicator {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%) !important;
        color: #856404 !important;
        border: 1px solid #ffeeba !important;
      }

      /* Icon styles within extension elements */
      [class*="monthly-price"] .extension-icon,
      [class*="cart-monthly-price"] .extension-icon,
      [class*="seller-price"] .extension-icon {
        display: inline-flex !important;
        align-items: center !important;
        margin-left: 6px !important;
        font-size: 14px !important;
      }

      /* Price text styling */
      .extension-price-text {
        font-weight: 700 !important;
        direction: rtl !important;
        unicode-bidi: bidi-override !important;
      }

      /* Animations */
      @keyframes slideInUp {
        from {
          opacity: 0;
          transform: translateY(15px) scale(0.95);
        }
        to {
          opacity: 1;
          transform: translateY(0) scale(1);
        }
      }

      @keyframes slideInRight {
        from {
          opacity: 0;
          transform: translateX(20px);
        }
        to {
          opacity: 1;
          transform: translateX(0);
        }
      }

      @keyframes glow {
        0%, 100% {
          box-shadow: var(--ext-shadow);
        }
        50% {
          box-shadow: var(--ext-shadow-lg), 0 0 20px rgba(59, 130, 246, 0.3);
        }
      }

      @keyframes fadeInScale {
        from {
          opacity: 0;
          transform: scale(0.8);
        }
        to {
          opacity: 1;
          transform: scale(1);
        }
      }

      @keyframes pulse {
        0%, 100% {
          opacity: 1;
        }
        50% {
          opacity: 0.7;
        }
      }

      /* Loading states */
      .extension-loading {
        position: relative !important;
        overflow: hidden !important;
      }

      .extension-loading::after {
        content: '' !important;
        position: absolute !important;
        top: 0 !important;
        right: -200px !important;
        width: 200px !important;
        height: 100% !important;
        background: linear-gradient(
          90deg,
          transparent,
          rgba(255, 255, 255, 0.4),
          transparent
        ) !important;
        animation: shimmer 1.5s infinite !important;
      }

      @keyframes shimmer {
        0% {
          right: -200px;
        }
        100% {
          right: calc(200px + 100%);
        }
      }

      /* Dark mode adaptations */
      @media (prefers-color-scheme: dark) {
        .monthly-price-section {
          background: linear-gradient(135deg, rgba(16, 185, 129, 0.9), rgba(16, 185, 129, 0.7)) !important;
          color: #ecfdf5 !important;
        }
        
        .monthly-price-main-section {
          background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(245, 158, 11, 0.15)) !important;
          border-color: rgba(245, 158, 11, 0.4) !important;
          color: #fcd34d !important;
        }
        
        .cart-monthly-price-info {
          background: linear-gradient(135deg, rgba(14, 165, 233, 0.9), rgba(14, 165, 233, 0.7)) !important;
          color: #e0f2fe !important;
        }
        
        .seller-price-section {
          background: linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(245, 158, 11, 0.15)) !important;
          border-color: rgba(245, 158, 11, 0.4) !important;
          color: #fcd34d !important;
        }
      }

      /* Responsive design */
      @media (max-width: 768px) {
        .monthly-price-main-section {
          margin-top: 12px !important;
          padding: 12px 16px !important;
          font-size: 13px !important;
        }
        
        .monthly-price-section,
        .cart-monthly-price-info {
          padding: 6px 10px !important;
          font-size: 11px !important;
        }
        
        .seller-price-section {
          padding: 10px 14px !important;
          font-size: 12px !important;
        }
      }

      /* Accessibility - Reduced motion */
      @media (prefers-reduced-motion: reduce) {
        .monthly-price-section,
        .monthly-price-main-section,
        .cart-monthly-price-info,
        .seller-price-section,
        .extension-price-indicator,
        .seller-updated-indicator,
        .seller-unavailable-indicator,
        .seller-error-indicator {
          transition: none !important;
          animation: none !important;
        }
        
        .monthly-price-section:hover,
        .monthly-price-main-section:hover,
        .cart-monthly-price-info:hover,
        .seller-price-section:hover {
          transform: none !important;
        }
      }

      /* High contrast mode */
      @media (prefers-contrast: high) {
        .monthly-price-section,
        .monthly-price-main-section,
        .cart-monthly-price-info,
        .seller-price-section {
          border-width: 2px !important;
          font-weight: 700 !important;
        }
      }
    `;
  }

  setupDarkModeDetection() {
    // Watch for dark mode changes
    if (window.matchMedia) {
      const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
      darkModeQuery.addListener(() => {
        this.eventBus.emit('style:dark-mode-changed', darkModeQuery.matches);
      });
    }
  }

  injectStyles(customStyles) {
    if (typeof customStyles === 'string' && !this.injectedStyles.has(customStyles)) {
      const styleEl = document.createElement('style');
      styleEl.textContent = customStyles;
      document.head.appendChild(styleEl);
      this.injectedStyles.add(customStyles);
    }
  }

  createStyledElement(tag, className, styles = {}) {
    const element = document.createElement(tag);
    element.className = className;
    
    // Apply custom styles
    Object.keys(styles).forEach(key => {
      element.style[key] = styles[key];
    });
    
    return element;
  }

  getPriceIndicatorClass(currentPrice, monthlyLowPrice) {
    if (!currentPrice || !monthlyLowPrice) return 'extension-price-indicator--warning';
    
    const difference = ((currentPrice - monthlyLowPrice) / monthlyLowPrice) * 100;
    
    if (difference <= 5) return 'extension-price-indicator--good';
    if (difference <= 15) return 'extension-price-indicator--warning';
    return 'extension-price-indicator--high';
  }

  formatPrice(priceInRials) {
    if (!priceInRials || priceInRials <= 0) return '';
    const priceInTomans = Math.round(priceInRials / 10);
    return priceInTomans.toLocaleString('fa-IR') + ' تومان';
  }

  createPriceElement(type, data) {
    const elements = {
      monthlyPrice: () => this.createMonthlyPriceElement(data),
      cartPrice: () => this.createCartPriceElement(data),
      sellerPrice: () => this.createSellerPriceElement(data)
    };
    
    return elements[type] ? elements[type]() : null;
  }

  createMonthlyPriceElement(data) {
    const { monthlyLowPrice, currentPrice, isMainSection = false } = data;
    const className = isMainSection ? 'monthly-price-main-section' : 'monthly-price-info';
    
    const element = this.createStyledElement('div', className);
    const formattedPrice = this.formatPrice(monthlyLowPrice);
    const difference = currentPrice && monthlyLowPrice ? 
      Math.round(((currentPrice - monthlyLowPrice) / monthlyLowPrice) * 100) : 0;
    
    element.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <span class="extension-icon">💰</span>
        <div style="flex: 1;">
          <div style="font-weight: 700;">کمترین قیمت ۳۰ روز اخیر</div>
          <div style="margin-top: 4px; opacity: 0.9;">${formattedPrice}</div>
          ${difference > 0 ? `<div style="font-size: 10px; margin-top: 2px; opacity: 0.8;">
            ${difference}% کمتر از قیمت فعلی
          </div>` : ''}
        </div>
      </div>
    `;
    
    return element;
  }

  createCartPriceElement(data) {
    const { monthlyLowPrice } = data;
    const element = this.createStyledElement('div', 'cart-monthly-price-info');
    const formattedPrice = this.formatPrice(monthlyLowPrice);
    
    element.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <span class="extension-icon">💰</span>
        <div>
          <div style="font-weight: 700;">کمترین قیمت ۳۰ روز اخیر</div>
          <div style="margin-top: 2px; font-size: 11px;">${formattedPrice}</div>
        </div>
      </div>
    `;
    
    return element;
  }

  createSellerPriceElement(data) {
    const { sellerPrice, monthlyLowPrice, sellerName } = data;
    const element = this.createStyledElement('div', 'seller-price-section');
    const formattedSellerPrice = this.formatPrice(sellerPrice);
    const formattedMonthlyPrice = this.formatPrice(monthlyLowPrice);
    
    element.innerHTML = `
      <div style="margin-bottom: 8px;">
        <div style="font-weight: 700; color: #7f1d1d;">قیمت ${sellerName || 'فروشنده'}</div>
        <div style="font-size: 14px; font-weight: 700; color: #ef4444; margin-top: 4px;">
          ${formattedSellerPrice}
        </div>
      </div>
      ${monthlyLowPrice ? `
        <div style="border-top: 1px solid rgba(245, 158, 11, 0.3); padding-top: 8px;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span class="extension-icon">📊</span>
            <div>
              <div style="font-size: 11px; opacity: 0.8;">کمترین قیمت ۳۰ روز</div>
              <div style="font-weight: 600;">${formattedMonthlyPrice}</div>
            </div>
          </div>
        </div>
      ` : ''}
    `;
    
    return element;
  }

  cleanup() {
    if (this.styleElement) {
      this.styleElement.remove();
      this.styleElement = null;
    }
    
    if (this.darkModeObserver) {
      this.darkModeObserver.disconnect();
      this.darkModeObserver = null;
    }
    
    this.injectedStyles.clear();
    console.log('🧹 Style service cleaned up');
  }
}

window.StyleService = StyleService;