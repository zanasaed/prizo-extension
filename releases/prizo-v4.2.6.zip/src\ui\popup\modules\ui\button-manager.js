/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Button Manager - Handles all button event listeners that were missing from modules
 */

class ButtonManager extends BaseModule {
  constructor(eventBus, domManager) {
    super('ButtonManager', eventBus, domManager);
  }

  async initializeElements() {
    this.elements = this.domManager.getElements({
      // Watchlist buttons
      openFullPageBtn: '#openFullPageBtn',
      testNotificationBtn: '#testNotificationBtn',
      showWatchlistBtn: '#showWatchlistBtn',
      refreshWatchlistBtn: '#refreshWatchlistBtn',

      // Control buttons
      toggleMainBtn: '#toggleMainBtn',
      updateMainBtn: '#updateMainBtn',
      emergencyStopMainBtn: '#emergencyStopMainBtn',
      clearDisplayMainBtn: '#clearDisplayMainBtn',
      clearCacheMainBtn: '#clearCacheMainBtn',
      resetAllMainBtn: '#resetAllMainBtn',

      // Feature toggles
      persistentMode: '#persistentMode',
      toggleSwitchContainer: '#toggleSwitchContainer',
      sortFeatureMode: '#sortFeatureMode',
      sortToggleSwitchContainer: '#sortToggleSwitchContainer',
      cartFeatureMode: '#cartFeatureMode',
      cartToggleSwitchContainer: '#cartToggleSwitchContainer',
      networkStabilityCheck: '#networkStabilityCheck',
      networkStabilityToggleContainer: '#networkStabilityToggleContainer',

      // Welcome guide
      showWelcomeGuide: '#showWelcomeGuide',

      // Help button
      comparisonHelpBtn: '#comparisonHelpBtn',

      // Delay settings
      globalDelayRange: '#globalDelayRange',
      globalDelayValue: '#globalDelayValue'
    });
  }

  async setupEventListeners() {
    // Set up all button event listeners
    this.setupWatchlistButtons();
    this.setupControlButtons();
    this.setupFeatureToggles();
    this.setupMiscButtons();
    this.setupDelaySettings();
  }

  setupWatchlistButtons() {
    const { openFullPageBtn, testNotificationBtn, showWatchlistBtn, refreshWatchlistBtn } = this.elements;

    // Open full page UI
    if (openFullPageBtn) {
      this.domManager.addEventListener(openFullPageBtn, 'click', () => {
        this.emit('extension:open-tab', {
          url: chrome.runtime.getURL('src/ui/fullpage/fullpage.html')
        });
      });
    }

    // Test notification
    if (testNotificationBtn) {
      this.domManager.addEventListener(testNotificationBtn, 'click', () => {
        const extensionBridge = window.popupIntegration?.getModule('ExtensionBridge');
        if (extensionBridge) {
          extensionBridge.handleTestNotification();
        }
      });
    }

    // Show watchlist modal
    if (showWatchlistBtn) {
      this.domManager.addEventListener(showWatchlistBtn, 'click', () => {
        // Get the watchlist manager and call its method directly
        const watchlistManager = window.popupIntegration?.getModule('WatchlistManager');
        if (watchlistManager) {
          watchlistManager.showWatchlistModal();
        }
      });
    }

    // Refresh watchlist
    if (refreshWatchlistBtn) {
      this.domManager.addEventListener(refreshWatchlistBtn, 'click', () => {
        const watchlistManager = window.popupIntegration?.getModule('WatchlistManager');
        if (watchlistManager) {
          watchlistManager.refreshWatchlist();
        }
      });
    }
  }

  setupControlButtons() {
    const {
      toggleMainBtn, updateMainBtn, emergencyStopMainBtn,
      clearDisplayMainBtn, clearCacheMainBtn, resetAllMainBtn
    } = this.elements;

    // Toggle extension
    if (toggleMainBtn) {
      this.domManager.addEventListener(toggleMainBtn, 'click', () => {
        const extensionBridge = window.popupIntegration?.getModule('ExtensionBridge');
        if (extensionBridge) {
          extensionBridge.handleToggle();
        }
      });
    }

    // Update prices
    if (updateMainBtn) {
      this.domManager.addEventListener(updateMainBtn, 'click', () => {
        const extensionBridge = window.popupIntegration?.getModule('ExtensionBridge');
        if (extensionBridge) {
          extensionBridge.handleUpdate();
        }
      });
    }

    // Emergency stop
    if (emergencyStopMainBtn) {
      this.domManager.addEventListener(emergencyStopMainBtn, 'click', () => {
        const extensionBridge = window.popupIntegration?.getModule('ExtensionBridge');
        if (extensionBridge) {
          extensionBridge.handleEmergencyStop();
        }
      });
    }

    // Clear display
    if (clearDisplayMainBtn) {
      this.domManager.addEventListener(clearDisplayMainBtn, 'click', () => {
        const extensionBridge = window.popupIntegration?.getModule('ExtensionBridge');
        if (extensionBridge) {
          extensionBridge.handleClearDisplay();
        }
      });
    }

    // Clear cache
    if (clearCacheMainBtn) {
      this.domManager.addEventListener(clearCacheMainBtn, 'click', () => {
        const extensionBridge = window.popupIntegration?.getModule('ExtensionBridge');
        if (extensionBridge) {
          extensionBridge.handleClearCache();
        }
      });
    }

    // Reset all
    if (resetAllMainBtn) {
      this.domManager.addEventListener(resetAllMainBtn, 'click', () => {
        const extensionBridge = window.popupIntegration?.getModule('ExtensionBridge');
        if (extensionBridge) {
          extensionBridge.handleResetAll();
        }
      });
    }
  }

  setupFeatureToggles() {
    const {
      persistentMode, toggleSwitchContainer,
      sortFeatureMode, sortToggleSwitchContainer,
      cartFeatureMode, cartToggleSwitchContainer,
      networkStabilityCheck, networkStabilityToggleContainer
    } = this.elements;

    // Persistent mode toggle
    if (toggleSwitchContainer && persistentMode) {
      this.domManager.addEventListener(toggleSwitchContainer, 'click', () => {
        persistentMode.checked = !persistentMode.checked;
        this.updateToggleSwitch(persistentMode, toggleSwitchContainer);
        this.emit('settings:persistent-mode-changed', { enabled: persistentMode.checked });
      });

      this.domManager.addEventListener(persistentMode, 'change', () => {
        this.updateToggleSwitch(persistentMode, toggleSwitchContainer);
        this.emit('settings:persistent-mode-changed', { enabled: persistentMode.checked });
      });
    }

    // Sort feature toggle
    if (sortToggleSwitchContainer && sortFeatureMode) {
      this.domManager.addEventListener(sortToggleSwitchContainer, 'click', () => {
        sortFeatureMode.checked = !sortFeatureMode.checked;
        this.updateToggleSwitch(sortFeatureMode, sortToggleSwitchContainer);
        this.emit('settings:sort-feature-changed', { enabled: sortFeatureMode.checked });
      });

      this.domManager.addEventListener(sortFeatureMode, 'change', () => {
        this.updateToggleSwitch(sortFeatureMode, sortToggleSwitchContainer);
        this.emit('settings:sort-feature-changed', { enabled: sortFeatureMode.checked });
      });
    }

    // Cart feature toggle
    if (cartToggleSwitchContainer && cartFeatureMode) {
      this.domManager.addEventListener(cartToggleSwitchContainer, 'click', () => {
        cartFeatureMode.checked = !cartFeatureMode.checked;
        this.updateToggleSwitch(cartFeatureMode, cartToggleSwitchContainer);
        this.emit('settings:cart-feature-changed', { enabled: cartFeatureMode.checked });
      });

      this.domManager.addEventListener(cartFeatureMode, 'change', () => {
        this.updateToggleSwitch(cartFeatureMode, cartToggleSwitchContainer);
        this.emit('settings:cart-feature-changed', { enabled: cartFeatureMode.checked });
      });
    }


    // Network stability toggle
    if (networkStabilityToggleContainer && networkStabilityCheck) {
      this.domManager.addEventListener(networkStabilityToggleContainer, 'click', () => {
        networkStabilityCheck.checked = !networkStabilityCheck.checked;
        this.updateToggleSwitch(networkStabilityCheck, networkStabilityToggleContainer);
        this.emit('settings:network-stability-changed', { enabled: networkStabilityCheck.checked });
      });

      this.domManager.addEventListener(networkStabilityCheck, 'change', () => {
        this.updateToggleSwitch(networkStabilityCheck, networkStabilityToggleContainer);
        this.emit('settings:network-stability-changed', { enabled: networkStabilityCheck.checked });
      });
    }
  }

  setupMiscButtons() {
    const { showWelcomeGuide, comparisonHelpBtn } = this.elements;

    // Welcome guide
    if (showWelcomeGuide) {
      this.domManager.addEventListener(showWelcomeGuide, 'click', () => {
        this.emit('ui:show-welcome-guide');
      });
    }

    // Comparison help
    if (comparisonHelpBtn) {
      this.domManager.addEventListener(comparisonHelpBtn, 'click', () => {
        this.emit('ui:show-comparison-help');
      });
    }
  }

  setupDelaySettings() {
    const { globalDelayRange, globalDelayValue } = this.elements;

    if (globalDelayRange && globalDelayValue) {
      this.domManager.addEventListener(globalDelayRange, 'input', () => {
        const value = globalDelayRange.value;
        this.domManager.setText(globalDelayValue, value);
        this.emit('settings:global-delay-changed', { delay: parseInt(value) });
      });
    }
  }

  updateToggleSwitch(checkbox, container) {
    if (!checkbox || !container) return;

    if (checkbox.checked) {
      this.domManager.addClass(container, 'active');
    } else {
      this.domManager.removeClass(container, 'active');
    }
  }

  // Load settings and update UI
  async loadInitialData() {
    try {
      const result = await chrome.storage.local.get([
        'persistentMode',
        'sortFeatureEnabled',
        'cartFeatureEnabled',
        'networkStabilityCheck',
        'globalDelay'
      ]);

      this.updateSettingsUI(result);
    } catch (error) {
      this.error('Error loading settings:', error);
    }
  }

  updateSettingsUI(settings) {
    const {
      persistentMode, toggleSwitchContainer,
      sortFeatureMode, sortToggleSwitchContainer,
      cartFeatureMode, cartToggleSwitchContainer,
      networkStabilityCheck, networkStabilityToggleContainer,
      globalDelayRange, globalDelayValue
    } = this.elements;

    // Update persistent mode
    if (persistentMode) {
      persistentMode.checked = settings.persistentMode || false;
      this.updateToggleSwitch(persistentMode, toggleSwitchContainer);
    }

    // Update sort feature
    if (sortFeatureMode) {
      sortFeatureMode.checked = settings.sortFeatureEnabled || false;
      this.updateToggleSwitch(sortFeatureMode, sortToggleSwitchContainer);
    }

    // Update cart feature
    if (cartFeatureMode) {
      cartFeatureMode.checked = settings.cartFeatureEnabled !== false; // Default enabled
      this.updateToggleSwitch(cartFeatureMode, cartToggleSwitchContainer);
    }


    // Update network stability
    if (networkStabilityCheck) {
      networkStabilityCheck.checked = settings.networkStabilityCheck || false;
      this.updateToggleSwitch(networkStabilityCheck, networkStabilityToggleContainer);
    }

    // Update delay settings
    if (globalDelayRange && globalDelayValue) {
      const delay = settings.globalDelay || 1000;
      globalDelayRange.value = delay;
      this.domManager.setText(globalDelayValue, delay.toString());
    }
  }

  async cleanup() {
    // ButtonManager doesn't need specific cleanup
  }
}

// Make available globally
window.ButtonManager = ButtonManager;