/**
 * Enhanced Error Handling System
 * Provides user-friendly error messages and comprehensive logging
 */

class EnhancedErrorHandler {
  constructor() {
    this.errorCounts = new Map();
    this.maxRetries = 3;
    this.userErrorMessages = new Map();
    this.sensitivePatterns = [
      /key|token|password|secret/i,
      /api[_-]?key/i,
      /authorization/i,
      /bearer/i
    ];
    this.isHandlingError = false; // Prevent recursive error handling
    
    this.initializeUserMessages();
    this.setupGlobalErrorHandling();
  }

  initializeUserMessages() {
    // User-friendly error messages in Persian
    this.userErrorMessages.set('NETWORK_ERROR', {
      title: 'خطای اتصال',
      message: 'مشکل در اتصال به اینترنت. لطفاً اتصال خود را بررسی کنید.',
      action: 'retry',
      severity: 'warning'
    });

    this.userErrorMessages.set('RATE_LIMITED', {
      title: 'محدودیت سرعت',
      message: 'تعداد درخواست‌ها زیاد است. لطفاً چند ثانیه صبر کنید.',
      action: 'wait',
      severity: 'info'
    });

    this.userErrorMessages.set('API_ERROR', {
      title: 'خطای سرور',
      message: 'مشکل موقت در سرور دیجی‌کالا. لطفاً دوباره تلاش کنید.',
      action: 'retry',
      severity: 'warning'
    });

    this.userErrorMessages.set('STORAGE_ERROR', {
      title: 'خطای ذخیره‌سازی',
      message: 'مشکل در ذخیره اطلاعات. حافظه مرورگر ممکن است پر باشد.',
      action: 'clear_cache',
      severity: 'warning'
    });

    this.userErrorMessages.set('PERMISSION_ERROR', {
      title: 'مشکل دسترسی',
      message: 'افزونه دسترسی لازم را ندارد. لطفاً تنظیمات مرورگر را بررسی کنید.',
      action: 'check_permissions',
      severity: 'error'
    });

    this.userErrorMessages.set('PARSER_ERROR', {
      title: 'خطای پردازش',
      message: 'مشکل در پردازش اطلاعات صفحه. ممکن است ساختار صفحه تغییر کرده باشد.',
      action: 'refresh',
      severity: 'warning'
    });

    this.userErrorMessages.set('TIMEOUT_ERROR', {
      title: 'اتمام زمان',
      message: 'عملیات خیلی طول کشید و متوقف شد. لطفاً دوباره تلاش کنید.',
      action: 'retry',
      severity: 'warning'
    });

    this.userErrorMessages.set('UNKNOWN_ERROR', {
      title: 'خطای نامشخص',
      message: 'مشکل غیرمنتظره‌ای رخ داد. لطفاً صفحه را تازه‌سازی کنید.',
      action: 'refresh',
      severity: 'error'
    });
  }

  setupGlobalErrorHandling() {
    // Catch unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      console.error('🚨 Unhandled promise rejection:', event.reason);
      if (event.reason) {
        this.handleError(event.reason, 'UNHANDLED_PROMISE');
      } else {
        console.warn('⚠️ Unhandled promise rejection with null/undefined reason');
      }
      event.preventDefault(); // Prevent console spam
    });

    // Catch global errors
    window.addEventListener('error', (event) => {
      console.error('🚨 Global error:', event.error);
      if (event.error) {
        this.handleError(event.error, 'GLOBAL_ERROR');
      } else {
        console.warn('⚠️ Global error event with null/undefined error');
      }
    });
  }

  classifyError(error) {
    if (!error) return 'UNKNOWN_ERROR';

    const message = error.message || error.toString();
    const lowerMessage = message.toLowerCase();

    // Network-related errors
    if (lowerMessage.includes('fetch') || lowerMessage.includes('network') || 
        lowerMessage.includes('connection') || error.name === 'NetworkError') {
      return 'NETWORK_ERROR';
    }

    // Rate limiting
    if (lowerMessage.includes('rate limit') || lowerMessage.includes('429') ||
        lowerMessage.includes('too many requests')) {
      return 'RATE_LIMITED';
    }

    // API errors
    if (lowerMessage.includes('api') || lowerMessage.includes('server') ||
        /[45]\d\d/.test(message)) {
      return 'API_ERROR';
    }

    // Storage errors
    if (lowerMessage.includes('storage') || lowerMessage.includes('quota') ||
        lowerMessage.includes('disk space')) {
      return 'STORAGE_ERROR';
    }

    // Permission errors
    if (lowerMessage.includes('permission') || lowerMessage.includes('access') ||
        lowerMessage.includes('unauthorized') || lowerMessage.includes('forbidden')) {
      return 'PERMISSION_ERROR';
    }

    // Timeout errors
    if (error.name === 'AbortError' || lowerMessage.includes('timeout')) {
      return 'TIMEOUT_ERROR';
    }

    // Parser/DOM errors
    if (lowerMessage.includes('parse') || lowerMessage.includes('dom') ||
        lowerMessage.includes('element') || lowerMessage.includes('selector')) {
      return 'PARSER_ERROR';
    }

    return 'UNKNOWN_ERROR';
  }

  sanitizeError(error) {
    if (!error) return 'Unknown error occurred';

    let message = error.message || error.toString();

    // Remove sensitive information
    for (const pattern of this.sensitivePatterns) {
      message = message.replace(pattern, '[REDACTED]');
    }

    // Remove URLs and file paths that might contain sensitive info
    message = message.replace(/https?:\/\/[^\s]+/gi, '[URL]');
    message = message.replace(/\/[^\s]*\.(js|ts|html)/gi, '[FILE]');

    // Limit message length
    if (message.length > 200) {
      message = message.substring(0, 197) + '...';
    }

    return message;
  }

  incrementErrorCount(errorType) {
    const count = this.errorCounts.get(errorType) || 0;
    this.errorCounts.set(errorType, count + 1);
    return count + 1;
  }

  shouldRetry(errorType, count) {
    // Don't retry critical errors
    const noRetryErrors = ['PERMISSION_ERROR', 'PARSER_ERROR'];
    if (noRetryErrors.includes(errorType)) {
      return false;
    }

    return count < this.maxRetries;
  }

  async handleError(error, context = 'UNKNOWN', options = {}) {
    // Prevent recursive error loops by checking for null/undefined errors
    if (!error) {
      console.warn(`⚠️ Null/undefined error passed to handleError in context: ${context}`);
      return;
    }

    // Prevent recursive error handling
    if (this.isHandlingError) {
      console.warn(`⚠️ Recursive error handling prevented in context: ${context}`);
      return;
    }

    try {
      this.isHandlingError = true;
      
      const errorType = this.classifyError(error);
      const errorCount = this.incrementErrorCount(`${context}_${errorType}`);
      const sanitizedMessage = this.sanitizeError(error);

      // Log for developers with safe stack access
      console.error(`❌ [${context}] ${errorType}:`, {
        message: sanitizedMessage,
        count: errorCount,
        stack: error && error.stack ? error.stack.substring(0, 500) : 'No stack trace available',
        timestamp: new Date().toISOString()
      });

      // Get user-friendly message
      const userMessage = this.userErrorMessages.get(errorType) || this.userErrorMessages.get('UNKNOWN_ERROR');

      // Handle based on severity and retry capability
      if (this.shouldRetry(errorType, errorCount) && options.retryCallback) {
        console.log(`🔄 Retrying ${context} (attempt ${errorCount}/${this.maxRetries})`);
        
        // Show brief retry notification
        this.showNotification({
          type: 'info',
          title: 'تلاش مجدد',
          message: `تلاش ${errorCount} از ${this.maxRetries}...`,
          autoHide: true,
          duration: 2000
        });

        // Wait before retry
        const delay = Math.min(1000 * Math.pow(2, errorCount - 1), 10000); // Exponential backoff, max 10s
        await new Promise(resolve => setTimeout(resolve, delay));

        try {
          return await options.retryCallback();
        } catch (retryError) {
          return this.handleError(retryError, context, { ...options, retryCallback: null });
        }
      }

      // Show user-friendly error
      this.showUserError(userMessage, errorType, context, options);

      // Throw for caller to handle if needed
      if (options.rethrow !== false) {
        throw new Error(`${errorType}: ${sanitizedMessage}`);
      }
    } finally {
      this.isHandlingError = false;
    }
  }

  showUserError(userMessage, errorType, context, options) {
    const actions = this.getErrorActions(userMessage.action, options);

    this.showNotification({
      type: userMessage.severity,
      title: userMessage.title,
      message: userMessage.message,
      autoHide: userMessage.severity !== 'error',
      duration: userMessage.severity === 'info' ? 3000 : 8000,
      actions: actions
    });
  }

  getErrorActions(actionType, options) {
    const actions = [];

    switch (actionType) {
      case 'retry':
        if (options.retryCallback) {
          actions.push({
            text: 'تلاش مجدد',
            action: () => options.retryCallback()
          });
        }
        break;

      case 'refresh':
        actions.push({
          text: 'تازه‌سازی صفحه',
          action: () => window.location.reload()
        });
        break;

      case 'clear_cache':
        actions.push({
          text: 'پاک کردن کش',
          action: () => options.clearCacheCallback?.()
        });
        break;

      case 'check_permissions':
        actions.push({
          text: 'راهنمای رفع مشکل',
          action: () => this.showPermissionHelp()
        });
        break;
    }

    // Always add dismiss action for error messages
    actions.push({
      text: 'بستن',
      action: 'dismiss'
    });

    return actions;
  }

  showPermissionHelp() {
    this.showNotification({
      type: 'info',
      title: 'راهنمای رفع مشکل',
      message: 'برای رفع مشکل: 1. تنظیمات مرورگر > افزونه‌ها 2. افزونه دیجی‌کالا را فعال کنید 3. دسترسی‌های لازم را بدهید',
      autoHide: false,
      actions: [
        { text: 'متوجه شدم', action: 'dismiss' }
      ]
    });
  }

  showNotification(options) {
    // This will be implemented by the main extension
    if (window.digikalaExtension && window.digikalaExtension.showNotification) {
      window.digikalaExtension.showNotification(options);
    } else {
      // Fallback to console
      console.log(`📢 ${options.type.toUpperCase()}: ${options.title} - ${options.message}`);
    }
  }

  // Wrapper for async operations with error handling
  async withErrorHandling(operation, context, options = {}) {
    try {
      return await operation();
    } catch (error) {
      return this.handleError(error, context, options);
    }
  }

  // Create error-safe version of a function
  makeErrorSafe(func, context, options = {}) {
    return async (...args) => {
      return this.withErrorHandling(
        () => func.apply(this, args),
        context,
        options
      );
    };
  }

  // Reset error counts (useful for testing or after successful operations)
  resetErrorCounts(pattern = null) {
    if (pattern) {
      // Reset specific error types
      for (const [key] of this.errorCounts) {
        if (key.includes(pattern)) {
          this.errorCounts.delete(key);
        }
      }
    } else {
      // Reset all
      this.errorCounts.clear();
    }
  }

  // Get error statistics
  getErrorStats() {
    const stats = {};
    for (const [key, count] of this.errorCounts) {
      stats[key] = count;
    }
    return stats;
  }
}

// Export for use in other modules
window.EnhancedErrorHandler = EnhancedErrorHandler;