/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Data Manager - Handles product data fetching, validation, and processing
 */
class DataManager {
  constructor() {
    this.processedProducts = new Set();
    this.processedCartItems = new Set();
  }

  async fetchProductData(productId) {
    try {
      console.log(`📡 Fetching product data for: ${productId}`);

      // DISABLED: Skip optimized API service to use direct API calls
      // This bypasses network interception to ensure reliable data extraction
      console.log(`🔄 [DirectAPI] DISABLED network interception - using direct API method for product ${productId}`);
      if (false && typeof OptimizedAPIService !== 'undefined') {
        // OptimizedAPIService disabled to avoid data structure issues
      }

      // Fallback to messaging API
      try {
        console.log(`🔄 Falling back to messaging API for product ${productId}`);
        const response = await ExtensionCore.BrowserCompat.safeSendMessage({
          action: 'fetchProductData',
          productId: productId,
          pageType: 'product',
          timeout: 15000 // Shorter timeout for better UX
        });

        if (response && response.success) {
          console.log('✅ Successfully fetched product data via messaging API');

          // [ShippingCost:API] Log messaging API response for shipping cost debugging
          const productData = response.data.product || response.data;
          console.log(`[ShippingCost:API] Messaging API response structure for ${productId}:`, {
            has_response_data: !!response.data,
            has_product: !!productData,
            has_variants: !!productData?.variants,
            variants_count: productData?.variants?.length || 0,
            first_variant_shipping: productData?.variants?.[0]?.shipment_methods || null,
            default_variant_shipping: productData?.default_variant?.shipment_methods || null,
            response_keys: Object.keys(response),
            product_keys: productData ? Object.keys(productData) : null
          });

          return { success: true, data: productData };
        } else {
          const errorMsg = response?.error || 'Failed to fetch product data';
          console.log('❌ API call failed:', errorMsg);
          throw new Error(errorMsg);
        }
      } catch (messagingError) {
        console.warn('📡 Messaging API failed, trying direct fetch:', messagingError.message);

        // Final fallback to direct fetch
        return await this.fetchProductDataDirect(productId);
      }
    } catch (error) {
      console.error(`❌ Failed to fetch product data for ${productId}:`, error);
      return { success: false, error: error.message };
    }
  }

  async fetchProductDataDirect(productId) {
    try {
      console.log(`🔄 Attempting direct fetch for product: ${productId}`);
      
      // Try the main API endpoint directly
      const apiUrl = `https://api.digikala.com/v2/product/${encodeURIComponent(productId)}/`;
      
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Accept': 'application/json, text/plain, */*',
          'Accept-Language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
          'Cache-Control': 'no-cache',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        },
        cache: 'no-cache'
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data && data.data && data.data.product) {
        console.log('✅ Successfully fetched product data via direct API');

        // [ShippingCost:API] Log direct API response for shipping cost debugging
        console.log(`[ShippingCost:API] Direct API response structure for ${productId}:`, {
          has_data: !!data.data,
          has_product: !!data.data.product,
          has_variants: !!data.data.product?.variants,
          variants_count: data.data.product?.variants?.length || 0,
          first_variant_shipping: data.data.product?.variants?.[0]?.shipment_methods || null,
          default_variant_shipping: data.data.product?.default_variant?.shipment_methods || null,
          data_keys: Object.keys(data),
          product_keys: Object.keys(data.data.product)
        });

        return { success: true, data: data.data.product };
      } else {
        throw new Error('Invalid API response structure');
      }
    } catch (directError) {
      console.error(`❌ Direct fetch failed for ${productId}:`, directError);
      return { success: false, error: `Direct fetch failed: ${directError.message}` };
    }
  }

  async fetchProductDataForProductPage(productId, retryCount = 0, maxRetries = 3) {
    // Use constants if available, otherwise fallback to defaults
    const constants = typeof ExtensionConstants !== 'undefined' ? ExtensionConstants : null;
    const actualMaxRetries = constants?.API?.MAX_RETRIES || maxRetries;
    const timeout = constants?.API?.TIMEOUT || 10000;
    const retryDelay = constants?.TIMING?.RETRY_DELAY || 1000;
    
    try {
      console.log(`📡 Fetching product data for product page: ${productId} (attempt ${retryCount + 1}/${actualMaxRetries + 1})`);

      // DISABLED: Skip optimized API service to use direct API calls for product pages
      // This bypasses network interception to ensure reliable data extraction
      console.log(`🔄 [DirectAPI] DISABLED network interception for product page - using direct API method for product ${productId}`);
      if (false && typeof OptimizedAPIService !== 'undefined') {
        // OptimizedAPIService disabled to avoid data structure issues
      }

      // Fallback to messaging API
      try {
        console.log(`🔄 Falling back to messaging API for product page ${productId}`);
        const response = await ExtensionCore.BrowserCompat.safeSendMessage({
          action: 'fetchProductData',
          productId: productId,
          pageType: 'product',
          timeout: timeout
        });

        if (response && response.success) {
          console.log('✅ Successfully fetched product data for product page via messaging API');
          return response.data.product || response.data;
        } else {
          const errorMsg = response?.error || 'Failed to fetch product data';
          console.log('❌ API call failed:', errorMsg);
          throw new Error(errorMsg);
        }
      } catch (messagingError) {
        console.warn('📡 Messaging API failed for product page, trying direct fetch:', messagingError.message);

        // Final fallback to direct fetch
        const directResult = await this.fetchProductDataDirect(productId);
        if (directResult.success) {
          return directResult.data;
        } else {
          throw new Error(directResult.error);
        }
      }
    } catch (error) {
      console.error(`❌ Failed to fetch product data for ${productId}:`, error);

      if (retryCount < actualMaxRetries && this.shouldRetryError(error.message)) {
        const delay = Math.min(retryDelay * Math.pow(2, retryCount), 5000);
        console.log(`🔄 Retrying fetch in ${delay}ms due to error: ${error.message}`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.fetchProductDataForProductPage(productId, retryCount + 1, actualMaxRetries);
      }

      return null;
    }
  }

  async fetchMonthlyLowPriceFromChart(productId) {
    try {
      console.log(`📊 Fetching monthly price chart for product: ${productId}`);
      
      // Use background script messaging instead of direct fetch
      const response = await ExtensionCore.BrowserCompat.safeSendMessage({
        action: 'fetchPriceChart',
        productId: productId,
        timeout: 15000
      });

      if (response && response.success && response.data) {
        console.log(`✅ Successfully fetched price chart for product: ${productId}`);
        const minPrice = this.parseMinPriceFromChart(response.data);
        return minPrice;
      } else {
        console.log(`⚠️ Failed to fetch price chart for product: ${productId}`, response?.error);
        return null;
      }
    } catch (error) {
      console.error(`❌ Error fetching price chart for product ${productId}:`, error);
      return null;
    }
  }

  parseMinPriceFromChart(priceChartData) {
    if (!priceChartData?.price_chart || !Array.isArray(priceChartData.price_chart)) {
      return null;
    }

    let minPrice = null;
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);

    try {
      // Use efficient iteration with bounds checking
      for (let i = 0; i < priceChartData.price_chart.length; i++) {
        const chartEntry = priceChartData.price_chart[i];
        
        if (!chartEntry?.history || !Array.isArray(chartEntry.history)) {
          continue;
        }

        const history = chartEntry.history;
        
        for (let j = 0; j < history.length; j++) {
          const historyEntry = history[j];
          
          if (!historyEntry?.date || !historyEntry?.selling_price) continue;
          
          const entryDate = new Date(historyEntry.date).getTime();
          
          if (entryDate >= thirtyDaysAgo && historyEntry.selling_price > 0) {
            if (minPrice === null || historyEntry.selling_price < minPrice) {
              minPrice = historyEntry.selling_price;
            }
          }
        }
      }

      return minPrice !== null ? Math.round(minPrice) : null;
    } catch (error) {
      console.warn('Error parsing price chart:', error);
      return null;
    }
  }

  validateProductData(productData) {
    if (!productData) return false;
    if (!productData.variants || !Array.isArray(productData.variants)) return false;
    if (productData.variants.length === 0) return false;
    return true;
  }

  async extractMonthlyLowPrice(productData, productId) {
    try {
      // Try different possible paths for monthly low price (exactly like original)
      const paths = [
        productData.properties?.min_price_in_last_month,
        productData.product?.properties?.min_price_in_last_month,
        productData.min_price_in_last_month
      ];

      for (const price of paths) {
        if (price && typeof price === 'number' && price > 0) {
          console.log('📊 Found monthly low price from primary data:', price);
          return price;
        }
      }

      console.log('⚠️ No monthly low price found in primary data, price chart fallback disabled');
      console.log('❌ No monthly low price found from primary data source');
      return null;
    } catch (error) {
      console.error('❌ Error extracting monthly low price:', error);
      return null;
    }
  }

  async extractCurrentLowestPrice(productData, productId) {
    try {
      console.log(`🔄 [PRICE EXTRACTION] Starting for requested product ID: ${productId}`);
      console.log(`🔄 [PRICE EXTRACTION] Product data ID from API: ${productData.id}`);
      console.log(`🔄 [PRICE EXTRACTION] Product title from API: ${productData.title_fa || productData.title_en || 'unknown'}`);

      // Extract main product ID for filtering
      const mainProductId = productData.id || productId;
      console.log(`🔍 [PRICE EXTRACTION] Final main product ID: ${mainProductId}`);

      // CRITICAL: Verify if requested product ID matches API response product ID
      if (productId && productData.id && String(productId) !== String(productData.id)) {
        console.error(`❌ [PRICE EXTRACTION] MISMATCH DETECTED!`);
        console.error(`   Requested product ID: ${productId}`);
        console.error(`   API returned product ID: ${productData.id}`);
        console.error(`   API product title: ${productData.title_fa || productData.title_en}`);
        console.error(`   This means we're extracting price for WRONG PRODUCT!`);
      }

      console.log(`🔍 Product data structure:`, {
        hasPrice: !!productData.price,
        hasMinPrice: !!productData.min_price,
        hasPriceRange: !!productData.price_range,
        hasDefaultVariant: !!productData.default_variant,
        variantsCount: productData.variants?.length || 0,
        productId: mainProductId,
        keys: Object.keys(productData).slice(0, 10) // Show first 10 keys
      });

      if (!this.validateProductData(productData)) {
        console.log('❌ Invalid product data for current lowest price extraction');
        return null;
      }

      // Look for current lowest price in various data paths
      let lowestPrice = null;
      let lowestVariant = null;

      // Check main product price first
      const mainPrice = productData.price_range?.min_price ||
                       productData.min_price ||
                       productData.price?.selling_price ||
                       productData.price?.rrp_price ||
                       productData.price;
      console.log(`🔍 Main price paths:`, {
        price_range_min: productData.price_range?.min_price,
        min_price: productData.min_price,
        price_selling: productData.price?.selling_price,
        price_rrp: productData.price?.rrp_price,
        price_object: productData.price,
        computed: mainPrice
      });

      if (mainPrice && typeof mainPrice === 'number' && mainPrice > 0) {
        console.log(`✅ Found main price: ${mainPrice}`);
        lowestPrice = mainPrice;
        lowestVariant = {
          price: mainPrice,
          seller: productData.seller || { title: 'دیجی‌کالا' },
          is_main_product: true
        };
      } else {
        console.log(`⚠️ No valid main price found`);
      }

      // Check default_variant for the main product seller
      if (productData.default_variant) {
        const defaultVariantPrice = productData.default_variant.price?.selling_price ||
                                   productData.default_variant.price?.rrp_price ||
                                   productData.default_variant.price;

        if (defaultVariantPrice && typeof defaultVariantPrice === 'number' && defaultVariantPrice > 0) {
          console.log(`✅ Found default variant price: ${defaultVariantPrice}`);
          if (!lowestPrice || defaultVariantPrice < lowestPrice) {
            console.log(`✅ Default variant has lower price: ${defaultVariantPrice} (was ${lowestPrice})`);
            lowestPrice = defaultVariantPrice;
            lowestVariant = {
              price: defaultVariantPrice,
              seller: productData.default_variant.seller || { title: 'دیجی‌کالا' },
              variant_id: productData.default_variant.id,
              is_main_product: true
            };
          }
        }
      }

      // Check variants for lower prices
      // All variants in this array are legitimate variants of the same product (different colors/sellers)
      const variants = productData.variants || [];
      console.log(`🔍 Checking ${variants.length} variants for prices`);

      for (let i = 0; i < variants.length; i++) {
        const variant = variants[i];
        if (!variant || typeof variant !== 'object') {
          console.log(`⚠️ Invalid variant ${i}, skipping`);
          continue;
        }

        const variantPrice = variant.price?.selling_price ||
                         variant.price?.rrp_price ||
                         variant.price ||
                         variant.price_before_discount;
        console.log(`🔍 Variant ${i}:`, {
          variant_id: variant.id,
          price_selling: variant.price?.selling_price,
          price_rrp: variant.price?.rrp_price,
          computed: variantPrice,
          seller: variant.seller?.title || variant.seller?.name
        });

        if (variantPrice && typeof variantPrice === 'number' && variantPrice > 0) {
          console.log(`✅ Valid variant price found: ${variantPrice}`);
          if (!lowestPrice || variantPrice < lowestPrice) {
            console.log(`✅ New lowest price: ${variantPrice} (was ${lowestPrice})`);
            lowestPrice = variantPrice;
            lowestVariant = {
              price: variantPrice,
              seller: variant.seller || { title: 'نامشخص' },
              variant_id: variant.id,
              is_main_product: false
            };
          }
        } else {
          console.log(`⚠️ No valid price in variant ${i}`);
        }
      }

      console.log(`📊 Processed ${variants.length} variants for price comparison`);

      // Also check shipment_methods in default_variant for alternative sellers
      if (productData.default_variant?.shipment_methods && Array.isArray(productData.default_variant.shipment_methods)) {
        console.log(`🔍 Checking ${productData.default_variant.shipment_methods.length} shipment methods for alternative sellers`);

        for (let i = 0; i < productData.default_variant.shipment_methods.length; i++) {
          const shipmentMethod = productData.default_variant.shipment_methods[i];

          if (!shipmentMethod || !shipmentMethod.price) continue;

          const shipmentPrice = shipmentMethod.price.selling_price ||
                               shipmentMethod.price.rrp_price ||
                               shipmentMethod.price;

          if (shipmentPrice && typeof shipmentPrice === 'number' && shipmentPrice > 0) {
            console.log(`✅ Found shipment method price: ${shipmentPrice}`);
            if (!lowestPrice || shipmentPrice < lowestPrice) {
              console.log(`✅ Shipment method has lower price: ${shipmentPrice} (was ${lowestPrice})`);
              lowestPrice = shipmentPrice;
              lowestVariant = {
                price: shipmentPrice,
                seller: shipmentMethod.seller || { title: 'فروشنده جایگزین' },
                variant_id: productData.default_variant.id,
                is_main_product: true
              };
            }
          }
        }
      }

      if (lowestPrice && lowestVariant) {
        const sellerName = lowestVariant.seller.title || lowestVariant.seller.name || 'نامشخص';

        // Find the full variant data to extract detailed information
        let fullVariantData = null;
        if (lowestVariant.variant_id && productData.variants) {
          fullVariantData = productData.variants.find(v => v.id === lowestVariant.variant_id);
        }

        // Extract variant details like the extractCurrentSellingPrice method
        let variantDetails = [];
        if (fullVariantData) {
          // Check themes
          if (fullVariantData.themes && Array.isArray(fullVariantData.themes)) {
            variantDetails = fullVariantData.themes.map(theme => theme.title || theme.name).filter(Boolean);
          }

          // If no themes, check color
          if (variantDetails.length === 0 && fullVariantData.color?.title) {
            variantDetails.push(fullVariantData.color.title);
          }

          // Check size
          if (fullVariantData.size?.title) {
            variantDetails.push(fullVariantData.size.title);
          }

          // Check warranty
          if (fullVariantData.warranty?.title_fa) {
            variantDetails.push(fullVariantData.warranty.title_fa);
          }
        }

        const variantText = variantDetails.length > 0 ? variantDetails.join(' - ') : 'استاندارد';

        // Extract shipping information for the lowest price variant
        let shippingInfo = null;
        if (fullVariantData) {
          console.log('📞 CALLING extractSellerShippingCost from extractCurrentLowestPrice');
          shippingInfo = this.extractSellerShippingCost(fullVariantData, productData);
        }

        // Build display text with all information
        let displayParts = [
          `قیمت کمترین: ${this.formatPrice(lowestPrice)}`,
          `فروشنده: ${sellerName}`,
          `تنوع: ${variantText}`
        ];

        if (shippingInfo) {
          displayParts.push(shippingInfo.display_text);
        }

        const result = {
          price: lowestPrice,
          seller_name: sellerName,
          seller_code: lowestVariant.seller.code || null,
          is_main_product: lowestVariant.is_main_product,
          variant_id: lowestVariant.variant_id || null,
          variant_details: variantText,
          shipping_info: shippingInfo,
          display_text: displayParts.join(' - ')
        };

        console.log(`✅ [PRICE EXTRACTION] RESULT for product ${productId}:`);
        console.log(`   Product ID (requested): ${productId}`);
        console.log(`   Product ID (from API): ${productData.id}`);
        console.log(`   Product Title: ${productData.title_fa || productData.title_en || 'unknown'}`);
        console.log(`   Extracted Price: ${lowestPrice} Rials (${Math.round(lowestPrice / 10).toLocaleString('fa-IR')} Tomans)`);
        console.log(`   Seller: ${sellerName}`);
        console.log(`   Variant ID: ${lowestVariant.variant_id || 'main product'}`);
        console.log(`   Full result:`, result);
        return result;
      }

      // Fallback: try to extract from product structure
      console.log(`🔍 Trying default variant fallback`);
      if (productData.default_variant) {
        console.log(`🔍 Default variant:`, {
          price_range_min: productData.default_variant.price_range?.min_price,
          price_selling: productData.default_variant.price?.selling_price,
          price_rrp: productData.default_variant.price?.rrp_price,
          price_object: productData.default_variant.price,
          seller: productData.default_variant.seller?.title
        });
        
        const defaultPrice = productData.default_variant.price_range?.min_price ||
                            productData.default_variant.price?.selling_price ||
                            productData.default_variant.price?.rrp_price ||
                            productData.default_variant.price;
        if (defaultPrice && typeof defaultPrice === 'number' && defaultPrice > 0) {
          const fallbackResult = {
            price: defaultPrice,
            seller_name: productData.default_variant.seller?.title || 'دیجی‌کالا',
            seller_code: productData.default_variant.seller?.code || null,
            is_main_product: true,
            variant_id: productData.default_variant.id || null
          };
          
          console.log(`💰 Found current lowest price from default variant for product ${productId}:`, fallbackResult);
          return fallbackResult;
        } else {
          console.log(`⚠️ No valid price in default variant`);
        }
      } else {
        console.log(`⚠️ No default variant available`);
      }

      console.log(`⚠️ No current lowest price found for product ${productId}`);
      return null;

    } catch (error) {
      console.error(`❌ Error extracting current lowest price for product ${productId}:`, error);
      return null;
    }
  }

  async findSellerVariant(productData, sellerCode, productId) {
    if (!this.validateProductData(productData) || !sellerCode) {
      return null;
    }

    const variants = productData.variants;
    for (let i = 0; i < variants.length; i++) {
      const variant = variants[i];
      
      if (!variant || typeof variant !== 'object') {
        continue;
      }

      if (variant.seller?.code === sellerCode || variant.seller_code === sellerCode) {
        const monthlyLowPrice = await this.extractMonthlyLowPrice(productData, productId);
        return { ...variant, monthly_low_price: monthlyLowPrice };
      }
    }

    if (productData.seller?.code === sellerCode || productData.seller_code === sellerCode) {
      const monthlyLowPrice = await this.extractMonthlyLowPrice(productData, productId);
      return { 
        ...productData, 
        monthly_low_price: monthlyLowPrice,
        is_main_product: true 
      };
    }

    return null;
  }

  extractAndSortVariants(productData) {
    if (!this.validateProductData(productData)) return [];

    return productData.variants
      .filter(variant => variant.price?.selling_price > 0)
      .map(variant => ({
        ...variant,
        display_name: [
          variant.color?.title,
          variant.size?.title,
          variant.warranty?.title_fa
        ].filter(Boolean).join(' - ') || 'پایه',
        price_value: variant.price.selling_price,
        seller_name: variant.seller?.title || 'نامشخص',
        // Preserve full objects for visual indicators
        color: variant.color,
        size: variant.size,
        warranty: variant.warranty,
        variantId: variant.id,
        // Extract shipping information
        shipping_info: (() => {
          console.log(`🚚 Extracting shipping for variant ${variant.id}:`, {
            has_shipment_methods: !!variant.shipment_methods,
            providers_count: variant.shipment_methods?.providers?.length || 0,
            is_ship_by_seller: variant.properties?.is_ship_by_seller,
            first_provider_structure: variant.shipment_methods?.providers?.[0] || null
          });
          const result = this.extractShippingInfo(variant);
          console.log(`🚚 Shipping extraction result for variant ${variant.id}:`, result);
          return result;
        })(),
        // Extract order limit information
        order_limit: this.extractOrderLimit(variant)
      }))
      .sort((a, b) => a.price_value - b.price_value);
  }

  extractShippingInfo(variant) {
    try {
      // [ShippingCost:Parse] DUPLICATE FUNCTION WARNING
      console.warn(`[ShippingCost:Parse] ⚠️ WARNING: extractShippingInfo function called in data-manager.js`);
      console.warn(`[ShippingCost:Parse] ⚠️ This function may have duplicates in test files - ensure correct one is used`);

      // Get shipping method data
      const shipmentMethods = variant.shipment_methods;
      if (!shipmentMethods?.providers || !Array.isArray(shipmentMethods.providers) || shipmentMethods.providers.length === 0) {
        return null;
      }

      // Find the appropriate provider (seller shipping if available, otherwise first provider)
      let provider = shipmentMethods.providers[0];

      // If there are multiple providers and seller handles shipping, prefer seller provider
      if (shipmentMethods.providers.length > 1 && variant.properties?.is_ship_by_seller) {
        const sellerProvider = shipmentMethods.providers.find(p =>
          p.type === 'seller' ||
          p.shipping_mode === 'seller' ||
          p.title?.includes('فروشنده')
        );
        if (sellerProvider) {
          provider = sellerProvider;
        }
      }
      
      // Check if shipping is free (check both provider level and price level)
      if (provider.is_free || provider.price?.is_free) {
        return {
          is_free: true,
          cost: 0,
          display_text: 'ارسال رایگان'
        };
      }

      // Get shipping cost with robust parsing - handle null values better
      let shippingCost = provider.price?.value;

      console.log('🔍 Shipping cost extraction debug:', {
        provider_price: provider.price,
        raw_value: provider.price?.value,
        value_type: typeof shippingCost,
        is_null: shippingCost === null,
        is_undefined: shippingCost === undefined,
        full_provider_structure: provider
      });

      // Convert string values to numbers if needed
      if (typeof shippingCost === 'string') {
        shippingCost = parseInt(shippingCost.replace(/[^\d]/g, '')) || 0;
      }

      if (typeof shippingCost === 'number' && shippingCost > 0) {
        console.log('✅ Found valid shipping cost:', shippingCost);
        return {
          is_free: false,
          cost: shippingCost,
          display_text: `هزینه ارسال: ${this.formatPrice(shippingCost)}`
        };
      }

      // If price.value is null but price object exists, check for alternative price fields immediately
      if (provider.price && (shippingCost === null || shippingCost === undefined)) {
        console.log('🔍 price.value is null/undefined, checking alternative price fields:', {
          price_keys: Object.keys(provider.price),
          all_price_values: provider.price
        });

        // Check for other possible value fields in price object
        const alternativeValue = provider.price.amount || provider.price.cost ||
                                provider.price.price || provider.price.shipping_cost ||
                                provider.price.delivery_cost;

        if (alternativeValue) {
          let parsedValue = alternativeValue;
          if (typeof parsedValue === 'string') {
            parsedValue = parseInt(parsedValue.replace(/[^\d]/g, '')) || 0;
          }

          if (typeof parsedValue === 'number' && parsedValue > 0) {
            console.log('✅ Found alternative shipping value in price object:', parsedValue);
            return {
              is_free: false,
              cost: parsedValue,
              display_text: `هزینه ارسال: ${this.formatPrice(parsedValue)}`
            };
          }
        }
      }

      // Enhanced fallback: check for alternative price structures and provider-level shipping info
      if (provider.price && typeof provider.price === 'object') {
        console.log('🔍 Checking alternative price structures:', {
          price_keys: Object.keys(provider.price),
          all_price_values: provider.price
        });

        // Check for other possible value fields
        const alternativeValue = provider.price.amount || provider.price.cost || provider.price.price;
        if (alternativeValue && alternativeValue > 0) {
          console.log('✅ Found alternative shipping value:', alternativeValue);
          return {
            is_free: false,
            cost: alternativeValue,
            display_text: `هزینه ارسال: ${this.formatPrice(alternativeValue)}`
          };
        }
      }

      // Check if shipping cost is stored directly in provider (not in price object)
      console.log('🔍 Checking provider-level shipping fields:', {
        provider_cost: provider.cost,
        provider_amount: provider.amount,
        provider_fee: provider.fee,
        provider_shipping_cost: provider.shipping_cost,
        provider_delivery_cost: provider.delivery_cost
      });

      const providerLevelCost = provider.cost || provider.amount || provider.fee ||
                               provider.shipping_cost || provider.delivery_cost;

      if (providerLevelCost) {
        let parsedCost = providerLevelCost;
        if (typeof parsedCost === 'string') {
          parsedCost = parseInt(parsedCost.replace(/[^\d]/g, '')) || 0;
        }

        if (typeof parsedCost === 'number' && parsedCost > 0) {
          console.log('✅ Found provider-level shipping cost:', parsedCost);
          return {
            is_free: false,
            cost: parsedCost,
            display_text: `هزینه ارسال: ${this.formatPrice(parsedCost)}`
          };
        }
      }

      // Final fallback: if provider exists but no price info, check if it's seller shipping without explicit cost
      if (provider.type === 'seller' || provider.shipping_mode === 'seller' ||
          provider.title?.includes('فروشنده') || provider.title?.includes('seller')) {
        console.log('✅ Found seller shipping without explicit cost');
        return {
          is_free: false,
          cost: null,
          display_text: 'ارسال توسط فروشنده'
        };
      }

      console.log('❌ No valid shipping cost found, returning null');
      return null;
    } catch (error) {
      console.warn('Error extracting shipping info:', error);
      return null;
    }
  }

  extractOrderLimit(variant) {
    try {
      const orderLimit = variant.price?.order_limit;
      
      if (!orderLimit || orderLimit <= 0) {
        return null;
      }

      if (orderLimit === 1) {
        return {
          limit: 1,
          display_text: 'سقف خرید ۱ عدد'
        };
      }

      return {
        limit: orderLimit,
        display_text: `حداکثر تعداد سفارش: ${orderLimit}`
      };
    } catch (error) {
      console.warn('Error extracting order limit:', error);
      return null;
    }
  }

  async extractCartItemDetails(productData, cartItemElement = null) {
    try {
      // [ShippingCost:Manager] Function entry logging
      console.log(`[ShippingCost:Manager] ===== extractCartItemDetails ENTRY =====`);
      console.log(`[ShippingCost:Manager] Input productData:`, {
        has_productData: !!productData,
        has_default_variant: !!productData?.default_variant,
        has_cartItemElement: !!cartItemElement,
        default_variant_id: productData?.default_variant?.id,
        default_variant_seller: productData?.default_variant?.seller?.title
      });

      if (!productData || !productData.default_variant) {
        console.log(`[ShippingCost:Manager] Missing required data, returning null`);
        return null;
      }

      const defaultVariant = productData.default_variant;

      // Extract current lowest price among all sellers instead of selected seller's price
      // This ensures cart shows the same lowest price logic used on product detail pages
      const currentLowestPriceData = await this.extractCurrentLowestPrice(productData, 'cart-item');
      const currentPriceInfo = currentLowestPriceData || this.extractCurrentSellingPrice(defaultVariant);

      // Extract seller shipping cost (this is for the lowest price seller)
      console.log('📞 CALLING extractSellerShippingCost from extractCartItemDetails');
      console.log(`[ShippingCost:Manager] About to call extractSellerShippingCost with:`, {
        variant_id: defaultVariant?.id,
        variant_seller: defaultVariant?.seller?.title,
        has_shipping_methods: !!defaultVariant?.shipment_methods
      });

      const shippingCostInfo = this.extractSellerShippingCost(defaultVariant, productData);

      console.log(`🔧 DBG:shipping:extract - Shipping cost info:`, shippingCostInfo);
      console.log(`[ShippingCost:Manager] extractSellerShippingCost result:`, {
        returned_result: shippingCostInfo,
        has_result: !!shippingCostInfo,
        result_cost: shippingCostInfo?.cost,
        result_is_free: shippingCostInfo?.is_free,
        result_display: shippingCostInfo?.display_text
      });

      // Extract selected seller shipping cost (this is what user actually has in cart)
      const selectedSellerShipping = this.extractSelectedSellerShipping(productData, cartItemElement);
      console.log(`🔧 DBG:shipping:selected - Selected seller shipping:`, selectedSellerShipping);

      const result = {
        current_price: currentPriceInfo,
        shipping_cost: shippingCostInfo,
        selected_seller_shipping: selectedSellerShipping,
        is_ship_by_seller: defaultVariant.properties?.is_ship_by_seller === true
      };

      console.log(`[ShippingCost:Manager] ===== extractCartItemDetails RESULT =====`);
      console.log(`[ShippingCost:Manager] Final cart item details:`, {
        has_current_price: !!result.current_price,
        has_shipping_cost: !!result.shipping_cost,
        shipping_cost_value: result.shipping_cost?.cost,
        shipping_cost_is_free: result.shipping_cost?.is_free,
        has_selected_seller_shipping: !!result.selected_seller_shipping,
        is_ship_by_seller: result.is_ship_by_seller,
        full_result: result
      });

      return result;
    } catch (error) {
      console.warn('Error extracting cart item details:', error);
      console.log(`[ShippingCost:Manager] ===== extractCartItemDetails ERROR =====`);
      console.log(`[ShippingCost:Manager] Error in extractCartItemDetails:`, error);
      return null;
    }
  }

  extractSelectedSellerShipping(productData, cartItemElement = null) {
    try {
      console.log('🔍 Extracting selected seller shipping from cart item...');
      
      // Strategy 1: Extract selected seller info from cart item DOM
      let selectedSellerInfo = null;
      if (cartItemElement) {
        selectedSellerInfo = this.extractSelectedSellerFromCartDOM(cartItemElement);
        console.log('🔍 Selected seller from DOM:', selectedSellerInfo);
      }
      
      // Strategy 2: Look for selected variant in product data
      let selectedVariant = null;
      
      // Check if there's a selected_variant field
      if (productData.selected_variant) {
        selectedVariant = productData.selected_variant;
        console.log('✅ Found selected_variant in product data');
      }
      // Check if there's a cart_variant field
      else if (productData.cart_variant) {
        selectedVariant = productData.cart_variant;
        console.log('✅ Found cart_variant in product data');
      }
      // Check variants array for selected or cart variant
      else if (productData.variants && productData.variants.length > 0) {
        selectedVariant = productData.variants.find(v => v.is_selected || v.in_cart) || null;
        if (selectedVariant) {
          console.log('✅ Found selected variant in variants array');
        }
      }
      
      // Strategy 3: If we have seller info from DOM, find matching variant
      if (selectedSellerInfo && !selectedVariant && productData.variants) {
        selectedVariant = productData.variants.find(v => 
          v.seller?.title === selectedSellerInfo.seller_name ||
          v.seller?.code === selectedSellerInfo.seller_code
        );
        if (selectedVariant) {
          console.log('✅ Matched variant using DOM seller info');
        }
      }
      
      // Strategy 4: If still no selected variant found, use default (but log this)
      if (!selectedVariant) {
        console.warn('⚠️ No specific selected variant found, using default_variant');
        selectedVariant = productData.default_variant;
      }
      
      if (!selectedVariant) {
        console.warn('❌ No variant data available for selected seller extraction');
        return null;
      }
      
      // Extract shipping information for the selected variant
      console.log('📞 CALLING extractSellerShippingCost from extractSelectedSellerShipping');
      const shipping = this.extractSellerShippingCost(selectedVariant, productData);
      console.log('🚚 Extracted shipping for selected seller:', shipping);
      
      if (shipping) {
        return {
          ...shipping,
          seller_name: selectedSellerInfo?.seller_name || selectedVariant.seller?.title || 'نامشخص',
          is_selected: true,
          is_ship_by_seller: selectedVariant.properties?.is_ship_by_seller === true,
          source: selectedSellerInfo ? 'dom' : 'api'
        };
      }
      
      // Enhanced fallback: Try alternative shipping extraction methods before giving up
      console.log('⚠️ Primary shipping extraction failed, trying alternatives...');
      
      // Alternative 1: Try extracting from any available shipping provider
      if (selectedVariant.shipment_methods?.providers && selectedVariant.shipment_methods.providers.length > 0) {
        console.log('🔄 Trying alternative shipping extraction from available providers');
        const providers = selectedVariant.shipment_methods.providers;
        
        // Look for any provider with cost or free shipping
        for (const provider of providers) {
          if (provider.is_free || provider.price?.is_free) {
            console.log('✅ Found free shipping in alternative extraction');
            return {
              is_free: true,
              cost: 0,
              display_text: `ارسال رایگان`,
              seller_name: selectedSellerInfo?.seller_name || selectedVariant.seller?.title || 'نامشخص',
              is_selected: true,
              is_ship_by_seller: selectedVariant.properties?.is_ship_by_seller === true,
              source: selectedSellerInfo ? 'dom' : 'api-alternative'
            };
          }
          
          // Check for shipping cost with robust parsing - handle null values better
          let shippingCost = provider.price?.value;

          console.log('🔍 Selected seller alternative shipping cost extraction debug:', {
            raw_value: shippingCost,
            value_type: typeof shippingCost,
            is_null: shippingCost === null,
            is_undefined: shippingCost === undefined,
            full_price_object: provider.price
          });

          if (typeof shippingCost === 'string') {
            shippingCost = parseInt(shippingCost.replace(/[^\d]/g, '')) || 0;
          }

          if (typeof shippingCost === 'number' && shippingCost > 0) {
            console.log('✅ Found shipping cost in alternative extraction:', shippingCost);
            return {
              is_free: false,
              cost: shippingCost,
              display_text: `هزینه ارسال: ${this.formatPrice(shippingCost)}`,
              seller_name: selectedSellerInfo?.seller_name || selectedVariant.seller?.title || 'نامشخص',
              is_selected: true,
              is_ship_by_seller: selectedVariant.properties?.is_ship_by_seller === true,
              source: selectedSellerInfo ? 'dom' : 'api-alternative'
            };
          }

          // If price.value is null but price object exists, check for alternative price fields immediately
          if (provider.price && (shippingCost === null || shippingCost === undefined)) {
            console.log('🔍 Selected seller price.value is null/undefined, checking alternative price fields:', {
              price_keys: Object.keys(provider.price),
              all_price_values: provider.price
            });

            // Check for other possible value fields in price object
            const alternativeValue = provider.price.amount || provider.price.cost ||
                                    provider.price.price || provider.price.shipping_cost ||
                                    provider.price.delivery_cost;

            if (alternativeValue) {
              let parsedValue = alternativeValue;
              if (typeof parsedValue === 'string') {
                parsedValue = parseInt(parsedValue.replace(/[^\d]/g, '')) || 0;
              }

              if (typeof parsedValue === 'number' && parsedValue > 0) {
                console.log('✅ Found alternative selected seller shipping value in price object:', parsedValue);
                return {
                  is_free: false,
                  cost: parsedValue,
                  display_text: `هزینه ارسال: ${this.formatPrice(parsedValue)}`,
                  seller_name: selectedSellerInfo?.seller_name || selectedVariant.seller?.title || 'نامشخص',
                  is_selected: true,
                  is_ship_by_seller: selectedVariant.properties?.is_ship_by_seller === true,
                  source: selectedSellerInfo ? 'dom' : 'api-alternative'
                };
              }
            }
          }
        }
      }
      
      // Final fallback: Return basic info only if we truly have no shipping data
      const sellerName = selectedSellerInfo?.seller_name || selectedVariant.seller?.title;
      if (sellerName) {
        console.log('⚠️ Using final fallback with seller name only');
        return {
          is_free: null,
          cost: null,
          display_text: `فروشنده انتخابی: ${sellerName}`,
          seller_name: sellerName,
          is_selected: true,
          is_ship_by_seller: selectedVariant.properties?.is_ship_by_seller === true,
          no_shipping_info: true,
          source: selectedSellerInfo ? 'dom' : 'api'
        };
      }
      
      console.warn('❌ Could not extract selected seller shipping information');
      return null;
    } catch (error) {
      console.warn('Error extracting selected seller shipping:', error);
      return null;
    }
  }

  extractSelectedSellerFromCartDOM(cartItemElement) {
    try {
      console.log('🔍 Analyzing cart item DOM for selected seller info...');
      
      let sellerName = null;
      let sellerElement = null;
      
      // Strategy 1: Look for the specific seller structure with SVG icon
      // <div class="flex"><div class="flex mt-1"><svg><use xlink:href="#seller"></use></svg></div><p class="text-body-2 text-neutral-600 mr-2">یورو ویت</p></div>
      const sellerIconElements = cartItemElement.querySelectorAll('svg use[*|href="#seller"], svg use[href="#seller"]');
      console.log(`🔍 Found ${sellerIconElements.length} seller icon elements`);
      
      for (const iconElement of sellerIconElements) {
        // Navigate up to find the seller container
        const svgElement = iconElement.closest('svg');
        if (svgElement) {
          // Find the parent flex container that contains the SVG: <div class="flex mt-1">
          const innerFlexContainer = svgElement.closest('div.flex');
          if (innerFlexContainer) {
            // Find the outer flex container: <div class="flex">
            const outerFlexContainer = innerFlexContainer.parentElement;
            if (outerFlexContainer && outerFlexContainer.classList.contains('flex')) {
              // Look for the paragraph element with seller name that should be a sibling of innerFlexContainer
              const sellerParagraph = outerFlexContainer.querySelector('p.text-body-2.text-neutral-600.mr-2');
              if (sellerParagraph) {
                const text = sellerParagraph.textContent?.trim();
                if (text && text.length > 0 && text.length < 100) {
                  // Additional validation to ensure it's seller name, not guarantee text
                  if (!text.includes('تاریخ') && !text.includes('انقضا') && 
                      !text.includes('گارانتی') && !text.includes('ضمانت') &&
                      !text.includes('ارسال') && !text.includes('تحویل')) {
                    sellerName = text;
                    sellerElement = sellerParagraph;
                    console.log(`✅ Found seller name from correct SVG structure: "${sellerName}"`);
                    break;
                  }
                }
              }
              
              // If no specific paragraph found, look for any p element in the outer flex container
              if (!sellerName) {
                const allParagraphs = outerFlexContainer.querySelectorAll('p');
                for (const p of allParagraphs) {
                  const text = p.textContent?.trim();
                  if (text && text.length > 0 && text.length < 100 &&
                      !text.includes('تاریخ') && !text.includes('انقضا') && 
                      !text.includes('گارانتی') && !text.includes('ضمانت') &&
                      !text.includes('ارسال') && !text.includes('تحویل') &&
                      !text.includes('svg') && !text.includes('icon')) {
                    sellerName = text;
                    sellerElement = p;
                    console.log(`✅ Found seller name from outer flex container paragraph: "${sellerName}"`);
                    break;
                  }
                }
              }
            }
          }
        }
        
        if (sellerName) break;
      }
      
      // Strategy 2: Look for seller name in common CSS class patterns
      if (!sellerName) {
        const sellerSelectors = [
          '.text-caption',                   // Legacy format: "فروشنده: نام"
          'p.text-body-2.text-neutral-600',  // New format from provided HTML
          'p.text-body-2',
          '.text-neutral-600',
          '.seller-name',
          '[data-seller]',
          '[data-seller-name]',
          '.cart-seller',
          '.text-secondary'
        ];
        
        for (const selector of sellerSelectors) {
          const element = cartItemElement.querySelector(selector);
          if (element) {
            const text = element.textContent?.trim() || '';
            console.log(`🔍 Checking selector ${selector}: "${text}"`);
            
            // Filter out common non-seller text
            if (text && text.length > 0 && 
                !text.includes('تومان') && 
                !text.includes('₽') &&
                !text.includes('قیمت') &&
                !text.includes('تخفیف') &&
                !text.includes('موجود') &&
                !text.includes('تاریخ') && !text.includes('انقضا') && 
                !text.includes('گارانتی') && !text.includes('ضمانت') &&
                !text.includes('ارسال') && !text.includes('تحویل') &&
                text.length < 100) {  // Seller names shouldn't be too long
              
              // Handle both formats: "فروشنده: نام" and just "نام"
              let extractedName = text;
              const sellerPrefixMatch = text.match(/فروشنده[:\s]+(.+)/i);
              if (sellerPrefixMatch && sellerPrefixMatch[1]) {
                extractedName = sellerPrefixMatch[1].trim();
              }
              
              // Additional cleanup for seller name
              extractedName = extractedName.split(/[،\s]/)[0].trim(); // Take first part before comma or space
              
              if (extractedName && extractedName.length > 0) {
                sellerName = extractedName;
                sellerElement = element;
                console.log(`✅ Found seller name from selector "${selector}": "${sellerName}"`);
                break;
              }
            }
          }
        }
      }
      
      // Strategy 3: Look for text patterns near seller SVG icons
      if (!sellerName) {
        // Find any element containing seller-related SVG and look around it
        const potentialSellerElements = cartItemElement.querySelectorAll('*');
        for (const element of potentialSellerElements) {
          const innerHTML = element.innerHTML || '';
          if (innerHTML.includes('#seller') || innerHTML.includes('seller')) {
            // Look in siblings and children for text
            const nearbyElements = [
              ...Array.from(element.parentElement?.children || []),
              ...Array.from(element.children || [])
            ];
            
            for (const nearby of nearbyElements) {
              const text = nearby.textContent?.trim();
              if (text && text.length > 0 && text.length < 50 &&
                  !text.includes('تومان') && !text.includes('₽') &&
                  !text.includes('svg') && !text.includes('icon')) {
                sellerName = text;
                console.log(`✅ Found seller name near SVG: "${sellerName}"`);
                break;
              }
            }
            
            if (sellerName) break;
          }
        }
      }
      
      // Strategy 4: Look for explicit seller text patterns
      if (!sellerName) {
        const allText = cartItemElement.textContent || '';
        const sellerMatches = allText.match(/فروشنده[:\s]+([^\n\r،]+)/gi);
        if (sellerMatches && sellerMatches.length > 0) {
          const match = sellerMatches[0].match(/فروشنده[:\s]+(.+)/i);
          if (match && match[1]) {
            sellerName = match[1].trim().split(/[،\s]/)[0];
            console.log(`✅ Found seller from text pattern: "${sellerName}"`);
          }
        }
      }
      
      // Also look for variant information (color, size, etc.)
      let variantInfo = [];
      const variantSelectors = [
        '.variant-info',
        '.product-variant',
        '[data-variant]',
        '.color-name',
        '.size-name'
      ];
      
      for (const selector of variantSelectors) {
        const element = cartItemElement.querySelector(selector);
        if (element) {
          const text = element.textContent?.trim();
          if (text && !text.includes('تومان') && text !== sellerName) {
            variantInfo.push(text);
            console.log(`✅ Found variant info: "${text}"`);
          }
        }
      }
      
      if (sellerName) {
        console.log(`✅ Successfully extracted seller: "${sellerName}"`);
        return {
          seller_name: sellerName,
          variant_info: variantInfo.length > 0 ? variantInfo.join(' - ') : null,
          source: 'cart_dom',
          extraction_method: sellerElement ? 'element_based' : 'text_pattern'
        };
      }
      
      console.log('⚠️ Could not extract seller info from cart item DOM');
      console.log('🔍 Cart item HTML preview:', cartItemElement.innerHTML.substring(0, 300));
      return null;
      
    } catch (error) {
      console.warn('Error extracting selected seller from cart DOM:', error);
      return null;
    }
  }

  extractCurrentSellingPrice(defaultVariant) {
    try {
      const sellingPrice = defaultVariant.price?.selling_price;
      const sellerName = defaultVariant.seller?.title || 'نامشخص';
      
      // Extract variant details
      let variantDetails = [];
      
      // Check themes
      if (defaultVariant.themes && Array.isArray(defaultVariant.themes)) {
        variantDetails = defaultVariant.themes.map(theme => theme.title || theme.name).filter(Boolean);
      }
      
      // If no themes, check color
      if (variantDetails.length === 0 && defaultVariant.color?.title) {
        variantDetails.push(defaultVariant.color.title);
      }
      
      // Check size
      if (defaultVariant.size?.title) {
        variantDetails.push(defaultVariant.size.title);
      }
      
      // Check warranty
      if (defaultVariant.warranty?.title_fa) {
        variantDetails.push(defaultVariant.warranty.title_fa);
      }

      const variantText = variantDetails.length > 0 ? variantDetails.join(' - ') : 'استاندارد';

      return {
        price: sellingPrice,
        seller_name: sellerName,
        variant_details: variantText,
        display_text: `قیمت فعلی: ${this.formatPrice(sellingPrice)} - فروشنده: ${sellerName} - تنوع: ${variantText}`
      };
    } catch (error) {
      console.warn('Error extracting current selling price:', error);
      return null;
    }
  }

  /**
   * Check if product has seller-only shipping (ارسال فروشنده) as the only shipping method
   * @param {Object} variant - Product variant data
   * @returns {Boolean} - True if seller-only shipping is the only method
   */
  isSellerOnlyShipping(variant) {
    try {
      console.log('🚚 Checking if seller-only shipping:', {
        isShipBySeller: variant.properties?.is_ship_by_seller,
        inDigikalaWarehouse: variant.properties?.in_digikala_warehouse,
        hasShipmentMethods: !!variant.shipment_methods,
        hasProviders: !!variant.shipment_methods?.providers,
        providersCount: variant.shipment_methods?.providers?.length || 0
      });
      
      // Must be ship by seller
      if (!variant.properties?.is_ship_by_seller) {
        console.log('⚠️ Not ship by seller');
        return false;
      }

      // Must not be in Digikala warehouse
      if (variant.properties?.in_digikala_warehouse) {
        console.log('⚠️ In Digikala warehouse');
        return false;
      }

      // Check shipment methods - must have only seller shipping
      const shipmentMethods = variant.shipment_methods;
      if (!shipmentMethods?.providers || !Array.isArray(shipmentMethods.providers)) {
        console.log('⚠️ No shipment providers found');
        return false;
      }

      // If there are multiple providers, it's not seller-only
      if (shipmentMethods.providers.length > 1) {
        console.log('⚠️ Multiple shipping providers found, not seller-only');
        return false;
      }

      // The single provider should be seller shipping
      const provider = shipmentMethods.providers[0];
      if (!provider) {
        console.log('⚠️ No provider data');
        return false;
      }

      console.log('✅ Is seller-only shipping');
      return true;
    } catch (error) {
      console.warn('Error checking seller-only shipping:', error);
      return false;
    }
  }

  /**
   * Extract seller shipping cost for seller-only shipping products
   * @param {Object} variant - Product variant data
   * @returns {Object|null} - Shipping cost info or null
   */
  extractSellerOnlyShippingCost(variant) {
    try {
      console.log('🚚 Checking shipping cost for variant:', {
        hasShipmentMethods: !!variant.shipment_methods,
        hasProviders: !!variant.shipment_methods?.providers,
        providersCount: variant.shipment_methods?.providers?.length || 0,
        isShipBySeller: variant.properties?.is_ship_by_seller,
        inDigikalaWarehouse: variant.properties?.in_digikala_warehouse
      });
      
      // First check if this is seller-only shipping
      if (!this.isSellerOnlyShipping(variant)) {
        console.log('⚠️ Not seller-only shipping, trying alternative shipping extraction');
        // Try alternative approach - check if any provider has shipping cost
        return this.extractAnySellerShippingCost(variant);
      }

      const provider = variant.shipment_methods.providers[0];
      console.log('🚚 Extracting from seller-only shipping provider:', provider);

      // RAW DATA LOGGING FOR DEBUGGING - SELLER ONLY
      console.log('🔍 RAW SELLER-ONLY Provider:');
      console.log('  📍 title:', provider.title);
      console.log('  📍 type:', provider.type);
      console.log('  📍 price:', provider.price);
      console.log('  📍 price_type:', typeof provider.price);
      console.log('  📍 price_is_null:', provider.price === null);
      console.log('  📍 price_is_object:', provider.price && typeof provider.price === 'object');
      console.log('  📍 all_keys:', Object.keys(provider));
      console.log('  📍 full_provider:', provider);

      // CRITICAL DEBUG: Check if price should be an object with value field
      console.log('🚨 CRITICAL DEBUG - Expected vs Actual:');
      console.log('  🎯 Expected: price object with value field');
      console.log('  🎯 Actual:', {
        price: provider.price,
        hasValue: provider.price && 'value' in provider.price,
        valueField: provider.price?.value,
        isExpectedStructure: provider.price && typeof provider.price === 'object' && 'value' in provider.price
      });

      // Show ALL properties on the provider object
      console.log('  📍 ALL_PROVIDER_PROPERTIES:');
      for (const [key, value] of Object.entries(provider)) {
        console.log(`    📍 ${key}:`, value, `(type: ${typeof value})`);
      }

      // If price exists and is an object, show its contents
      if (provider.price && typeof provider.price === 'object') {
        console.log('  📍 price_object_contents:', provider.price);
        console.log('  📍 price_object_keys:', Object.keys(provider.price));
      }

      // Check for direct cost fields on provider
      const directCostFields = {
        cost: provider.cost,
        amount: provider.amount,
        value: provider.value,
        shipping_cost: provider.shipping_cost,
        delivery_cost: provider.delivery_cost,
        fee: provider.fee,
        price_value: provider.price_value
      };
      console.log('  📍 direct_cost_fields:', directCostFields);

      console.log('🔍 Provider structure debug:', {
        provider_keys: Object.keys(provider),
        price_value: provider.price?.value,
        price_object: provider.price,
        has_price_key: 'price' in provider,
        all_price_related_keys: Object.keys(provider).filter(key => key.toLowerCase().includes('price') || key.toLowerCase().includes('cost') || key.toLowerCase().includes('amount'))
      });
      
      // Get seller information
      const sellerName = variant.seller?.title || variant.seller?.name || 'فروشنده';
      
      // Check if shipping is free (check both provider level and price level)
      if (provider.is_free || provider.price?.is_free) {
        console.log('✅ Found free seller-only shipping');
        return {
          is_free: true,
          cost: 0,
          display_text: 'ارسال رایگان',
          seller_name: sellerName,
          is_seller_only: true
        };
      }

      // Get shipping cost with robust parsing - handle null values better
      let shippingCost = provider.price?.value;

      console.log('🔍 Seller-only shipping cost extraction debug:', {
        raw_value: shippingCost,
        value_type: typeof shippingCost,
        is_null: shippingCost === null,
        is_undefined: shippingCost === undefined,
        full_price_object: provider.price
      });

      if (typeof shippingCost === 'string') {
        shippingCost = parseInt(shippingCost.replace(/[^\d]/g, '')) || 0;
      }

      if (typeof shippingCost === 'number' && shippingCost > 0) {
        console.log('✅ Found seller-only shipping cost:', shippingCost);
        return {
          is_free: false,
          cost: shippingCost,
          display_text: `هزینه ارسال: ${this.formatPrice(shippingCost)}`,
          seller_name: sellerName,
          is_seller_only: true
        };
      }

      // If price object exists and is not null, check for alternative price fields
      if (provider.price && typeof provider.price === 'object' && provider.price !== null) {
        console.log('🔍 price.value is null/undefined for seller-only, checking alternative price fields:', {
          price_keys: Object.keys(provider.price),
          all_price_values: provider.price
        });

        // Check for other possible value fields in price object
        const alternativeValue = provider.price.amount || provider.price.cost ||
                                provider.price.price || provider.price.shipping_cost ||
                                provider.price.delivery_cost;

        if (alternativeValue) {
          let parsedValue = alternativeValue;
          if (typeof parsedValue === 'string') {
            parsedValue = parseInt(parsedValue.replace(/[^\d]/g, '')) || 0;
          }

          if (typeof parsedValue === 'number' && parsedValue > 0) {
            console.log('✅ Found alternative seller-only shipping value in price object:', parsedValue);
            const result = {
              is_free: false,
              cost: parsedValue,
              display_text: `هزینه ارسال: ${this.formatPrice(parsedValue)}`,
              seller_name: sellerName,
              is_seller_only: true
            };
            console.log('🎯 FINAL SELLER-ONLY RESULT (alternative price field):', result);
            return result;
          }
        }
      }

      // NEW: Check for direct cost fields on the provider when price is null/missing
      console.log('🔍 Seller-only price object is null/missing, checking direct provider cost fields');
      const directCost = provider.cost || provider.amount || provider.value ||
                        provider.shipping_cost || provider.delivery_cost ||
                        provider.fee || provider.price_value;

      if (directCost) {
        let parsedCost = directCost;
        if (typeof parsedCost === 'string') {
          parsedCost = parseInt(parsedCost.replace(/[^\d]/g, '')) || 0;
        }

        if (typeof parsedCost === 'number' && parsedCost > 0) {
          console.log('✅ Found direct seller-only provider cost field:', parsedCost);
          const result = {
            is_free: false,
            cost: parsedCost,
            display_text: `هزینه ارسال: ${this.formatPrice(parsedCost)}`,
            seller_name: sellerName,
            is_seller_only: true
          };
          console.log('🎯 FINAL SELLER-ONLY RESULT (direct provider field):', result);
          return result;
        }
      }

      // Enhanced fallback: check for provider-level shipping costs
      console.log('🔍 Checking provider-level shipping fields:', {
        provider_cost: provider.cost,
        provider_amount: provider.amount,
        provider_fee: provider.fee,
        provider_shipping_cost: provider.shipping_cost,
        provider_delivery_cost: provider.delivery_cost
      });

      const providerLevelCost = provider.cost || provider.amount || provider.fee ||
                               provider.shipping_cost || provider.delivery_cost;

      if (providerLevelCost) {
        let parsedCost = providerLevelCost;
        if (typeof parsedCost === 'string') {
          parsedCost = parseInt(parsedCost.replace(/[^\d]/g, '')) || 0;
        }

        if (typeof parsedCost === 'number' && parsedCost > 0) {
          console.log('✅ Found provider-level seller shipping cost:', parsedCost);
          return {
            is_free: false,
            cost: parsedCost,
            display_text: `هزینه ارسال: ${this.formatPrice(parsedCost)}`,
            seller_name: sellerName,
            is_seller_only: true
          };
        }
      }

      // If it's seller shipping but no explicit cost, show as seller shipping without cost
      if (provider.type === 'seller' || variant.properties?.is_ship_by_seller) {
        console.log('✅ Found seller shipping without explicit cost');
        const result = {
          is_free: false,
          cost: null,
          display_text: `ارسال توسط فروشنده`,
          seller_name: sellerName,
          is_seller_only: true
        };
        console.log('🎯 FINAL SELLER-ONLY RESULT (no explicit cost):', result);
        return result;
      }

      console.log('⚠️ No shipping cost found in seller-only shipping');
      console.log('🎯 FINAL SELLER-ONLY RESULT: null');
      return null;
    } catch (error) {
      console.warn('Error extracting seller-only shipping cost:', error);
      return null;
    }
  }

  /**
   * Alternative method to extract shipping costs for any seller shipping
   * @param {Object} variant - Product variant data
   * @returns {Object|null} - Shipping cost info or null
   */
  extractAnySellerShippingCost(variant) {
    try {
      console.log('🚚 Trying alternative seller shipping extraction');

      // Get shipping method data
      const shipmentMethods = variant.shipment_methods;
      if (!shipmentMethods?.providers || !Array.isArray(shipmentMethods.providers) || shipmentMethods.providers.length === 0) {
        console.log('⚠️ No shipping providers found');
        return null;
      }

      console.log(`🚚 Found ${shipmentMethods.providers.length} shipping providers`);
      
      // Get seller information
      const sellerName = variant.seller?.title || variant.seller?.name || 'فروشنده';
      
      // Try each provider to find shipping cost
      for (let i = 0; i < shipmentMethods.providers.length; i++) {
        const provider = shipmentMethods.providers[i];
        console.log(`🚚 Checking provider ${i}:`, {
          is_free: provider.is_free,
          price: provider.price,
          title: provider.title
        });
        console.log(`🔍 Provider ${i} structure debug:`, {
          provider_keys: Object.keys(provider),
          price_value: provider.price?.value,
          price_object: provider.price,
          has_price_key: 'price' in provider,
          all_price_related_keys: Object.keys(provider).filter(key => key.toLowerCase().includes('price') || key.toLowerCase().includes('cost') || key.toLowerCase().includes('amount'))
        });
        
        // Check if shipping is free (check both provider level and price level)
        if (provider.is_free || provider.price?.is_free) {
          console.log('✅ Found free shipping from seller');
          return {
            is_free: true,
            cost: 0,
            display_text: 'ارسال رایگان',
            seller_name: sellerName,
            is_seller_only: false
          };
        }

        // Get shipping cost with robust parsing - handle null values better
        let shippingCost = provider.price?.value;

        console.log(`🔍 Provider ${i} shipping cost extraction debug:`, {
          raw_value: shippingCost,
          value_type: typeof shippingCost,
          is_null: shippingCost === null,
          is_undefined: shippingCost === undefined,
          full_price_object: provider.price
        });

        if (typeof shippingCost === 'string') {
          shippingCost = parseInt(shippingCost.replace(/[^\d]/g, '')) || 0;
        }

        if (typeof shippingCost === 'number' && shippingCost > 0) {
          console.log('✅ Found seller shipping cost:', shippingCost);
          return {
            is_free: false,
            cost: shippingCost,
            display_text: `هزینه ارسال: ${this.formatPrice(shippingCost)}`,
            seller_name: sellerName,
            is_seller_only: false
          };
        }

        // If price.value is null but price object exists, check for alternative price fields immediately
        if (provider.price && (shippingCost === null || shippingCost === undefined)) {
          console.log(`🔍 Provider ${i} price.value is null/undefined, checking alternative price fields:`, {
            price_keys: Object.keys(provider.price),
            all_price_values: provider.price
          });

          // Check for other possible value fields in price object
          const alternativeValue = provider.price.amount || provider.price.cost ||
                                  provider.price.price || provider.price.shipping_cost ||
                                  provider.price.delivery_cost;

          if (alternativeValue) {
            let parsedValue = alternativeValue;
            if (typeof parsedValue === 'string') {
              parsedValue = parseInt(parsedValue.replace(/[^\d]/g, '')) || 0;
            }

            if (typeof parsedValue === 'number' && parsedValue > 0) {
              console.log(`✅ Found alternative shipping value in provider ${i} price object:`, parsedValue);
              return {
                is_free: false,
                cost: parsedValue,
                display_text: `هزینه ارسال: ${this.formatPrice(parsedValue)}`,
                seller_name: sellerName,
                is_seller_only: false
              };
            }
          }
        }

        // Enhanced fallback: check for provider-level shipping costs
        console.log(`🔍 Checking provider ${i} level shipping fields:`, {
          provider_cost: provider.cost,
          provider_amount: provider.amount,
          provider_fee: provider.fee,
          provider_shipping_cost: provider.shipping_cost,
          provider_delivery_cost: provider.delivery_cost
        });

        const providerLevelCost = provider.cost || provider.amount || provider.fee ||
                                 provider.shipping_cost || provider.delivery_cost;

        if (providerLevelCost) {
          let parsedCost = providerLevelCost;
          if (typeof parsedCost === 'string') {
            parsedCost = parseInt(parsedCost.replace(/[^\d]/g, '')) || 0;
          }

          if (typeof parsedCost === 'number' && parsedCost > 0) {
            console.log(`✅ Found provider ${i} level shipping cost:`, parsedCost);
            return {
              is_free: false,
              cost: parsedCost,
              display_text: `هزینه ارسال: ${this.formatPrice(parsedCost)}`,
              seller_name: sellerName,
              is_seller_only: false
            };
          }
        }

        // Check if this provider is seller shipping without explicit cost
        if (provider.type === 'seller' || provider.shipping_mode === 'seller' ||
            provider.title?.includes('فروشنده') || provider.title?.includes('seller')) {
          console.log(`✅ Found provider ${i} seller shipping without explicit cost`);
          return {
            is_free: false,
            cost: null,
            display_text: 'ارسال توسط فروشنده',
            seller_name: sellerName,
            is_seller_only: false
          };
        }
      }

      console.log('⚠️ No shipping costs found in any provider');
      return null;
    } catch (error) {
      console.warn('Error extracting alternative seller shipping cost:', error);
      return null;
    }
  }

  extractSellerShippingCost(defaultVariant, productData = null) {
    try {
      // [ShippingCost:Parse] DUPLICATE FUNCTION WARNING
      console.warn(`[ShippingCost:Parse] ⚠️ WARNING: extractSellerShippingCost function called in data-manager.js`);
      console.warn(`[ShippingCost:Parse] ⚠️ DUPLICATE CHECK: There may be other extractSellerShippingCost functions in test files`);
      console.warn(`[ShippingCost:Parse] ⚠️ If you see this warning, ensure this is the correct function being used`);

      // [ShippingCost:Parse] Function entry logging
      console.log(`[ShippingCost:Parse] ===== extractSellerShippingCost ENTRY =====`);
      console.log(`[ShippingCost:Parse] Input variant:`, {
        variant_id: defaultVariant?.id,
        seller_title: defaultVariant?.seller?.title,
        seller_code: defaultVariant?.seller?.code,
        is_ship_by_seller: defaultVariant?.properties?.is_ship_by_seller,
        in_digikala_warehouse: defaultVariant?.properties?.in_digikala_warehouse,
        has_shipment_methods: !!defaultVariant?.shipment_methods,
        shipment_methods_keys: defaultVariant?.shipment_methods ? Object.keys(defaultVariant.shipment_methods) : null
      });
      console.log(`[ShippingCost:Parse] Input productData info:`, {
        has_productData: !!productData,
        productData_variants_count: productData?.variants?.length || 0,
        productData_default_variant_id: productData?.default_variant?.id
      });

      // [ShippingCost:Parse] RAW SHIPMENT METHODS DEBUG
      console.log(`[ShippingCost:Parse] 🚨 COMPLETE SHIPMENT_METHODS:`, defaultVariant?.shipment_methods);
      console.log(`[ShippingCost:Parse] 🚨 VARIANT INFO FOR DEBUGGING:`, {
        variant_id: defaultVariant?.id,
        seller_title: defaultVariant?.seller?.title,
        seller_code: defaultVariant?.seller?.code,
        price: defaultVariant?.price,
        properties: defaultVariant?.properties,
        complete_variant: defaultVariant
      });

      if (defaultVariant?.shipment_methods?.providers) {
        console.log(`[ShippingCost:Parse] 🚨 ALL PROVIDERS:`, defaultVariant.shipment_methods.providers);
        console.log(`[ShippingCost:Parse] 🚨 PROVIDERS COUNT:`, defaultVariant.shipment_methods.providers.length);
        defaultVariant.shipment_methods.providers.forEach((provider, index) => {
          console.log(`[ShippingCost:Parse] 🚨 PROVIDER[${index}]:`, {
            title: provider.title,
            type: provider.type,
            shipping_mode: provider.shipping_mode,
            price: provider.price,
            price_type: typeof provider.price,
            has_price_value: provider.price?.value,
            complete_provider: provider
          });
        });
      }

      // [ShippingCost:Parse] CHECK IF PRICES EXIST ELSEWHERE IN VARIANT
      console.log(`[ShippingCost:Parse] 🚨 SEARCHING FOR PRICES IN OTHER VARIANT FIELDS:`, {
        variant_price: defaultVariant?.price,
        variant_selling_price: defaultVariant?.selling_price,
        variant_cost: defaultVariant?.cost,
        variant_delivery_cost: defaultVariant?.delivery_cost,
        variant_shipping_fee: defaultVariant?.shipping_fee,
        all_variant_keys: defaultVariant ? Object.keys(defaultVariant) : null
      });

      console.log('🔍 Extracting seller shipping cost for variant:', {
        is_ship_by_seller: defaultVariant.properties?.is_ship_by_seller,
        in_digikala_warehouse: defaultVariant.properties?.in_digikala_warehouse,
        has_shipment_methods: !!defaultVariant.shipment_methods,
        seller_title: defaultVariant.seller?.title,
        has_productData: !!productData,
        productData_variants_count: productData?.variants?.length || 0
      });

      // RAW DATA LOGGING FOR DEBUGGING
      console.log('🔍 RAW shipment_methods data:', defaultVariant.shipment_methods);
      if (defaultVariant.shipment_methods?.providers) {
        console.log('🔍 RAW providers array:', defaultVariant.shipment_methods.providers);
        defaultVariant.shipment_methods.providers.forEach((provider, index) => {
          console.log(`🔍 RAW Provider ${index}:`, {
            title: provider.title,
            type: provider.type,
            price: provider.price,
            price_type: typeof provider.price,
            price_is_null: provider.price === null,
            price_is_object: provider.price && typeof provider.price === 'object',
            has_lead_time: provider.has_lead_time,
            all_keys: Object.keys(provider),
            full_provider: provider
          });

          // If price exists and is an object, show its contents
          if (provider.price && typeof provider.price === 'object') {
            console.log(`🔍 RAW Provider ${index} price object:`, provider.price);
          }

          // Check for direct cost fields on provider
          const directCostFields = {
            cost: provider.cost,
            amount: provider.amount,
            value: provider.value,
            shipping_cost: provider.shipping_cost,
            delivery_cost: provider.delivery_cost,
            fee: provider.fee
          };
          console.log(`🔍 RAW Provider ${index} direct cost fields:`, directCostFields);
        });
      } else {
        console.log('⚠️ NO PROVIDERS FOUND in defaultVariant.shipment_methods');
      }

      // Get shipping method data first to check what's available
      let shipmentMethods = defaultVariant.shipment_methods;
      let variantToUse = defaultVariant;

      // If no shipping data in defaultVariant, try to find it in productData.variants
      if ((!shipmentMethods?.providers || !Array.isArray(shipmentMethods.providers) || shipmentMethods.providers.length === 0) && productData?.variants) {
        console.log('⚠️ No shipment providers in defaultVariant, searching in productData.variants...');
        console.log('🔍 RAW productData.variants:', productData.variants);

        // Look for a variant with shipping data, preferably matching the default variant seller
        let foundVariant = null;
        const defaultSeller = defaultVariant.seller?.code || defaultVariant.seller?.title;

        for (const [index, variant] of productData.variants.entries()) {
          console.log(`🔍 RAW Variant ${index} (ID: ${variant.id}):`, {
            seller: variant.seller?.title,
            seller_code: variant.seller?.code,
            has_shipment_methods: !!variant.shipment_methods,
            providers_count: variant.shipment_methods?.providers?.length || 0,
            raw_shipment_methods: variant.shipment_methods
          });

          if (variant.shipment_methods?.providers && variant.shipment_methods.providers.length > 0) {
            console.log(`🔍 RAW Variant ${index} providers:`, variant.shipment_methods.providers);

            // If we have a seller match, prefer that
            if (defaultSeller && (variant.seller?.code === defaultSeller || variant.seller?.title === defaultSeller)) {
              foundVariant = variant;
              console.log('✅ Found matching seller variant with shipping data');
              break;
            }
            // Otherwise, take the first one with shipping data
            if (!foundVariant) {
              foundVariant = variant;
              console.log(`📝 Temporarily selecting variant ${index} as candidate`);
            }
          }
        }

        if (foundVariant) {
          variantToUse = foundVariant;
          shipmentMethods = foundVariant.shipment_methods;
          console.log('✅ Using variant with shipping data:', {
            variant_id: foundVariant.id,
            seller: foundVariant.seller?.title,
            providers_count: foundVariant.shipment_methods?.providers?.length,
            raw_shipment_methods: foundVariant.shipment_methods
          });
        }
      }

      if (!shipmentMethods?.providers || !Array.isArray(shipmentMethods.providers) || shipmentMethods.providers.length === 0) {
        console.log('⚠️ No shipment providers found in any variant');
        return null;
      }

      console.log(`🔍 Found ${shipmentMethods.providers.length} shipping providers`);

      // For products with multiple shipping options, find seller shipping provider
      let sellerProvider = null;

      // [ShippingCost:Parse] DETAILED PROVIDER ANALYSIS BEFORE SELECTION
      console.log(`[ShippingCost:Parse] ===== ALL PROVIDERS BEFORE SELECTION =====`);
      shipmentMethods.providers.forEach((provider, index) => {
        console.log(`[ShippingCost:Parse] 🚨 PROVIDER[${index}] DETAILS:`, {
          index: index,
          title: provider.title,
          type: provider.type,
          shipping_mode: provider.shipping_mode,
          price: provider.price,
          price_is_null: provider.price === null,
          price_is_undefined: provider.price === undefined,
          price_value: provider.price?.value,
          has_price_value: !!provider.price?.value,
          is_free: provider.is_free,
          has_lead_time: provider.has_lead_time,
          delivery_day: provider.delivery_day,
          complete_object: provider
        });
      });

      console.log('🔧 PROVIDER SELECTION PROCESS STARTING...');
      console.log('🔧 is_ship_by_seller:', variantToUse.properties?.is_ship_by_seller);

      // Strategy 1: Look for seller shipping provider specifically
      if (variantToUse.properties?.is_ship_by_seller) {
        console.log('🔧 PRIORITY 1: Looking for explicit seller provider (type === "seller")');

        // PRIORITY 1: Find explicit seller provider (type === 'seller')
        sellerProvider = shipmentMethods.providers.find(p => p.type === 'seller');
        if (sellerProvider) {
          console.log('✅ PRIORITY 1 SUCCESS: Found seller provider:', sellerProvider);
        } else {
          console.log('❌ PRIORITY 1 FAILED: No provider with type="seller"');
        }

        if (!sellerProvider) {
          console.log('🔧 PRIORITY 2: Looking for provider with seller-related title');

          // PRIORITY 2: Find provider with seller-related title
          sellerProvider = shipmentMethods.providers.find(p =>
            p.title?.includes('فروشنده') || p.title?.includes('seller')
          );
          if (sellerProvider) {
            console.log('✅ PRIORITY 2 SUCCESS: Found provider with seller title:', sellerProvider);
          } else {
            console.log('❌ PRIORITY 2 FAILED: No provider with seller-related title');
          }
        }

        if (!sellerProvider) {
          console.log('🔧 PRIORITY 3: Looking for any provider with valid shipping cost');

          // PRIORITY 3: Find any provider that has a valid shipping cost (not null)
          sellerProvider = shipmentMethods.providers.find(p =>
            (p.price?.value && p.price.value > 0) || p.is_free
          );
          if (sellerProvider) {
            console.log('✅ PRIORITY 3 SUCCESS: Found provider with valid cost:', sellerProvider);
          } else {
            console.log('❌ PRIORITY 3 FAILED: No provider with valid shipping cost');
          }
        }

        if (!sellerProvider) {
          console.log('🔧 PRIORITY 4: Single provider fallback check');

          // PRIORITY 4: If it's single provider and marked as ship by seller, use it
          if (shipmentMethods.providers.length === 1) {
            sellerProvider = shipmentMethods.providers[0];
            console.log('⚠️ PRIORITY 4 SUCCESS: Using single provider for seller shipping (fallback):', sellerProvider);
          } else {
            console.log('❌ PRIORITY 4 FAILED: Multiple providers available, cannot use single fallback');
          }
        }

        if (!sellerProvider) {
          console.log('🔧 FINAL FALLBACK: Using first provider');

          // FINAL FALLBACK: Use first provider
          sellerProvider = shipmentMethods.providers[0];
          console.log('⚠️ FINAL FALLBACK: Using first provider as final fallback for seller shipping:', sellerProvider);
        }
      } else {
        console.log('🔧 NON-SELLER SHIPPING: Looking for providers with actual costs');

        // If not marked as seller shipping, prefer providers with actual costs
        sellerProvider = shipmentMethods.providers.find(p =>
          (p.price?.value && p.price.value > 0) || p.is_free
        );

        if (sellerProvider) {
          console.log('✅ NON-SELLER SUCCESS: Found provider with cost:', sellerProvider);
        } else {
          console.log('❌ NON-SELLER FAILED: No provider with cost, using first provider');
          sellerProvider = shipmentMethods.providers[0];
        }
      }

      console.log('🎯 FINAL SELECTED PROVIDER:', sellerProvider);

      if (!sellerProvider) {
        console.log('❌ No suitable seller shipping provider found');
        return null;
      }

      console.log('✅ Found seller shipping provider:', {
        is_free: sellerProvider.is_free,
        has_price: !!sellerProvider.price?.value,
        price_value: sellerProvider.price?.value
      });
      
      // Check if shipping is free (check both provider level and price level)
      if (sellerProvider.is_free || sellerProvider.price?.is_free) {
        const result = {
          is_free: true,
          cost: 0,
          display_text: 'ارسال رایگان'
        };
        console.log(`[ShippingCost:Parse] ===== FINAL RESULT (FREE) =====`);
        console.log(`[ShippingCost:Parse] Returning free shipping:`, result);
        return result;
      }

      // Get shipping cost with robust parsing - handle null values better
      let shippingCost = sellerProvider.price?.value;

      // [ShippingCost:Parse] Critical shipping cost extraction point
      console.log(`[ShippingCost:Parse] ===== CRITICAL EXTRACTION POINT =====`);
      console.log(`[ShippingCost:Parse] provider.price?.value extraction:`, {
        raw_value: shippingCost,
        value_type: typeof shippingCost,
        is_null: shippingCost === null,
        is_undefined: shippingCost === undefined,
        is_zero: shippingCost === 0,
        is_nan: Number.isNaN(shippingCost),
        price_object: sellerProvider.price,
        price_object_type: typeof sellerProvider.price,
        price_is_null: sellerProvider.price === null,
        has_price_key: 'price' in sellerProvider,
        price_object_keys: sellerProvider.price ? Object.keys(sellerProvider.price) : null
      });

      // [ShippingCost:Parse] FULL PROVIDER STRUCTURE DEBUG
      console.log(`[ShippingCost:Parse] 🚨 COMPLETE PROVIDER STRUCTURE:`, sellerProvider);
      console.log(`[ShippingCost:Parse] 🚨 PROVIDER KEYS:`, Object.keys(sellerProvider));
      if (sellerProvider.price) {
        console.log(`[ShippingCost:Parse] 🚨 PRICE OBJECT COMPLETE:`, sellerProvider.price);
        console.log(`[ShippingCost:Parse] 🚨 PRICE OBJECT KEYS:`, Object.keys(sellerProvider.price));
      }

      console.log('🔍 Shipping cost extraction debug:', {
        raw_value: shippingCost,
        value_type: typeof shippingCost,
        is_null: shippingCost === null,
        is_undefined: shippingCost === undefined,
        price_object: sellerProvider.price,
        price_object_type: typeof sellerProvider.price,
        price_is_null: sellerProvider.price === null,
        has_price_key: 'price' in sellerProvider
      });

      if (typeof shippingCost === 'string') {
        shippingCost = parseInt(shippingCost.replace(/[^\d]/g, '')) || 0;
      }

      // Check if we have a valid numeric shipping cost
      if (typeof shippingCost === 'number' && shippingCost > 0) {
        console.log('✅ Found valid shipping cost:', shippingCost);
        const result = {
          is_free: false,
          cost: shippingCost,
          display_text: `هزینه ارسال: ${this.formatPrice(shippingCost)}`
        };
        console.log('🎯 FINAL SHIPPING RESULT (direct value):', result);
        console.log(`[ShippingCost:Parse] ===== FINAL RESULT (DIRECT VALUE) =====`);
        console.log(`[ShippingCost:Parse] Returning direct value result:`, result);
        return result;
      }

      // If price object exists and is not null, check for alternative price fields
      if (sellerProvider.price && typeof sellerProvider.price === 'object' && sellerProvider.price !== null) {
        console.log(`[ShippingCost:Parse] ===== ALTERNATIVE PRICE FIELDS CHECK =====`);
        console.log(`[ShippingCost:Parse] price.value was null/undefined, checking alternatives:`, {
          price_keys: Object.keys(sellerProvider.price),
          all_price_values: sellerProvider.price,
          amount: sellerProvider.price.amount,
          cost: sellerProvider.price.cost,
          price: sellerProvider.price.price,
          shipping_cost: sellerProvider.price.shipping_cost,
          delivery_cost: sellerProvider.price.delivery_cost
        });

        console.log('🔍 price.value is null/undefined, checking alternative price fields:', {
          price_keys: Object.keys(sellerProvider.price),
          all_price_values: sellerProvider.price
        });

        // Check for other possible value fields in price object
        const alternativeValue = sellerProvider.price.amount || sellerProvider.price.cost ||
                                sellerProvider.price.price || sellerProvider.price.shipping_cost ||
                                sellerProvider.price.delivery_cost;

        if (alternativeValue) {
          let parsedValue = alternativeValue;
          if (typeof parsedValue === 'string') {
            parsedValue = parseInt(parsedValue.replace(/[^\d]/g, '')) || 0;
          }

          if (typeof parsedValue === 'number' && parsedValue > 0) {
            console.log('✅ Found alternative shipping value in price object:', parsedValue);
            const result = {
              is_free: false,
              cost: parsedValue,
              display_text: `هزینه ارسال: ${this.formatPrice(parsedValue)}`
            };
            console.log('🎯 FINAL SHIPPING RESULT (alternative price field):', result);
            console.log(`[ShippingCost:Parse] ===== FINAL RESULT (ALTERNATIVE PRICE FIELD) =====`);
            console.log(`[ShippingCost:Parse] Returning alternative price field result:`, result);
            return result;
          }
        }
      }

      // NEW: Check for direct cost fields on the provider when price is null/missing
      console.log('🔍 price object is null/missing, checking direct provider cost fields');
      const directCostFields = {
        cost: sellerProvider.cost,
        amount: sellerProvider.amount,
        value: sellerProvider.value,
        shipping_cost: sellerProvider.shipping_cost,
        delivery_cost: sellerProvider.delivery_cost,
        fee: sellerProvider.fee,
        price_value: sellerProvider.price_value
      };
      console.log('🔍 Direct provider cost fields:', directCostFields);

      // Try to find a cost in direct provider fields
      const directCost = sellerProvider.cost || sellerProvider.amount || sellerProvider.value ||
                        sellerProvider.shipping_cost || sellerProvider.delivery_cost ||
                        sellerProvider.fee || sellerProvider.price_value;

      if (directCost) {
        let parsedCost = directCost;
        if (typeof parsedCost === 'string') {
          parsedCost = parseInt(parsedCost.replace(/[^\d]/g, '')) || 0;
        }

        if (typeof parsedCost === 'number' && parsedCost > 0) {
          console.log('✅ Found direct provider cost field:', parsedCost);
          const result = {
            is_free: false,
            cost: parsedCost,
            display_text: `هزینه ارسال: ${this.formatPrice(parsedCost)}`
          };
          console.log('🎯 FINAL SHIPPING RESULT (direct provider field):', result);
          console.log(`[ShippingCost:Parse] ===== FINAL RESULT (DIRECT PROVIDER FIELD) =====`);
          console.log(`[ShippingCost:Parse] Returning direct provider field result:`, result);
          return result;
        }
      }

      // Enhanced fallback: check for provider-level shipping costs
      console.log('🔍 Checking main provider level shipping fields:', {
        provider_cost: sellerProvider.cost,
        provider_amount: sellerProvider.amount,
        provider_fee: sellerProvider.fee,
        provider_shipping_cost: sellerProvider.shipping_cost,
        provider_delivery_cost: sellerProvider.delivery_cost
      });

      const providerLevelCost = sellerProvider.cost || sellerProvider.amount || sellerProvider.fee ||
                               sellerProvider.shipping_cost || sellerProvider.delivery_cost;

      if (providerLevelCost) {
        let parsedCost = providerLevelCost;
        if (typeof parsedCost === 'string') {
          parsedCost = parseInt(parsedCost.replace(/[^\d]/g, '')) || 0;
        }

        if (typeof parsedCost === 'number' && parsedCost > 0) {
          console.log('✅ Found main provider-level shipping cost:', parsedCost);
          const result = {
            is_free: false,
            cost: parsedCost,
            display_text: `هزینه ارسال: ${this.formatPrice(parsedCost)}`
          };
          console.log('🎯 FINAL SHIPPING RESULT (provider-level cost):', result);
          console.log(`[ShippingCost:Parse] ===== FINAL RESULT (PROVIDER-LEVEL COST) =====`);
          console.log(`[ShippingCost:Parse] Returning provider-level cost result:`, result);
          return result;
        }
      }

      // Final fallback: if provider exists but no clear cost info, check if it's seller shipping
      if (sellerProvider.type === 'seller' || sellerProvider.shipping_mode === 'seller' ||
          sellerProvider.title?.includes('فروشنده') || sellerProvider.title?.includes('seller')) {
        console.log('✅ Found main seller shipping without explicit cost');
        const result = {
          is_free: false,
          cost: null,
          display_text: 'ارسال توسط فروشنده'
        };
        console.log('🎯 FINAL SHIPPING RESULT (seller without cost):', result);
        console.log(`[ShippingCost:Parse] ===== FINAL RESULT (SELLER WITHOUT COST) =====`);
        console.log(`[ShippingCost:Parse] Returning seller without cost result:`, result);
        return result;
      }

      // If we get here, we should have triggered the enhanced fallback logic above
      console.log('🚨 ERROR: Reached final fallback without triggering enhanced logic!');
      console.log('🚨 This should not happen - check enhanced fallback conditions');
      console.log('⚠️ Provider found but no clear cost information');
      console.log('🎯 FINAL SHIPPING RESULT (error fallback): null');
      console.log(`[ShippingCost:Parse] ===== FINAL RESULT (NULL - NO COST FOUND) =====`);
      console.log(`[ShippingCost:Parse] All extraction methods failed, returning null`);
      return null;
    } catch (error) {
      console.warn('Error extracting seller shipping cost:', error);
      return null;
    }
  }

  shouldRetryError(errorMessage) {
    if (!errorMessage) return false;
    
    const retryableErrors = [
      'network error',
      'network',
      'timeout',
      'request timeout',
      'connection refused',
      'connection',
      'fetch',
      'rate limit',
      'http 429',
      '429',
      'http 500',
      '500',
      'http 502', 
      '502',
      'http 503',
      '503',
      'http 504',
      '504'
    ];
    
    const lowerError = errorMessage.toLowerCase();
    return retryableErrors.some(error => lowerError.includes(error));
  }

  calculateDiscountPercent(originalPrice, sellingPrice) {
    if (!originalPrice || !sellingPrice || originalPrice <= sellingPrice) {
      return 0;
    }
    return Math.round(((originalPrice - sellingPrice) / originalPrice) * 100);
  }

  parsePrice(priceText) {
    if (!priceText) return 0;
    const cleanPrice = priceText.replace(/[^\d]/g, '');
    return parseInt(cleanPrice) || 0;
  }

  formatPrice(priceInRials) {
    if (!priceInRials || priceInRials <= 0) return '';
    // Convert Rials to Tomans by dividing by 10
    const priceInTomans = Math.round(priceInRials / 10);
    return priceInTomans.toLocaleString('fa-IR') + ' تومان';
  }

  markAsProcessed(productId, type = 'product') {
    if (type === 'cart') {
      this.processedCartItems.add(productId);
    } else {
      this.processedProducts.add(productId);
    }
  }

  isProcessed(productId, type = 'product') {
    if (type === 'cart') {
      return this.processedCartItems.has(productId);
    }
    return this.processedProducts.has(productId);
  }

  clearProcessedItems(type = null) {
    if (type === 'cart' || type === null) {
      this.processedCartItems.clear();
    }
    if (type === 'product' || type === null) {
      this.processedProducts.clear();
    }
  }

  getProcessedCount(type = 'product') {
    if (type === 'cart') {
      return this.processedCartItems.size;
    }
    return this.processedProducts.size;
  }

}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.DataManager = DataManager;
}