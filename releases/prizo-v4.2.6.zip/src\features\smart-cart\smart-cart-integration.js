/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-18
 * Smart Cart Integration - Main integration manager that ties all optimized services together
 */
class SmartCartIntegration {
  constructor(eventBus, storageService) {
    this.eventBus = eventBus;
    this.storageService = storageService;

    // Initialize optimized services
    this.cacheService = null;
    this.apiService = null;
    this.batchProcessor = null;
    this.smartCartManager = null;

    // Service status tracking
    this.servicesInitialized = false;
    this.initializationPromise = null;

    // Duplicate request prevention
    this.activeRequests = new Map();
    this.requestDeduplication = true;

    // Integration settings
    this.settings = {
      enableCaching: true,
      enableBatching: true,
      enableAutoRefresh: true,
      cacheRetention: 2 * 60 * 1000, // 2 minutes
      batchDelay: 1000, // 1 second
      maxConcurrentRequests: 3
    };

    console.log('🔧 Smart Cart Integration initialized');
  }

  async initialize() {
    if (this.initializationPromise) {
      return this.initializationPromise;
    }

    this.initializationPromise = this._performInitialization();
    return this.initializationPromise;
  }

  async _performInitialization() {
    try {
      console.log('🚀 Initializing Smart Cart Integration services...');

      // Initialize cache service
      if (this.settings.enableCaching) {
        this.cacheService = new ProductCacheService(this.storageService, this.eventBus);
        await this.cacheService.initialize();
        console.log('✅ Product Cache Service initialized');
      }

      // Initialize optimized API service
      this.apiService = new OptimizedAPIService(this.eventBus, this.cacheService);
      console.log('✅ Optimized API Service initialized');

      // Initialize batch processor
      if (this.settings.enableBatching) {
        this.batchProcessor = new BatchProcessor(this.apiService, this.eventBus);
        console.log('✅ Batch Processor initialized');
      }

      // Initialize enhanced Smart Cart Manager
      this.smartCartManager = new SmartCartManager(
        this.eventBus,
        this.storageService,
        this.apiService,
        this.cacheService
      );
      await this.smartCartManager.initialize();
      console.log('✅ Enhanced Smart Cart Manager initialized');

      // Setup integration event listeners
      this.setupIntegrationEventListeners();

      this.servicesInitialized = true;
      console.log('🎉 Smart Cart Integration fully initialized');

      // Emit initialization complete event
      this.eventBus.emit('smart-cart-integration:initialized', {
        services: {
          cache: !!this.cacheService,
          api: !!this.apiService,
          batch: !!this.batchProcessor,
          manager: !!this.smartCartManager
        }
      });

      return true;

    } catch (error) {
      console.error('❌ Smart Cart Integration initialization failed:', error);
      this.eventBus.emit('smart-cart-integration:init-error', { error: error.message });
      throw error;
    }
  }

  setupIntegrationEventListeners() {
    // Handle cart opened event with optimized data refresh
    this.eventBus.on('smart-cart:cart-opened', this.handleCartOpened.bind(this));

    // Handle product addition with variation-aware caching
    this.eventBus.on('smart-cart:add-item', this.handleAddItemIntegrated.bind(this));

    // Handle batch refresh requests
    this.eventBus.on('smart-cart:refresh-data', this.handleRefreshData.bind(this));

    // Handle preload requests
    this.eventBus.on('smart-cart:preload-products', this.handlePreloadProducts.bind(this));

    // Listen for API optimization events
    this.eventBus.on('api:rate-limited', this.handleRateLimited.bind(this));
    this.eventBus.on('api:batch-completed', this.handleBatchCompleted.bind(this));

    console.log('📡 Integration event listeners setup complete');
  }

  async handleCartOpened() {
    console.log('📂 Smart Cart opened - checking for optimized data refresh');

    if (!this.servicesInitialized) {
      console.warn('⚠️ Services not initialized, skipping cart opened handling');
      return;
    }

    try {
      // Get current cart items
      const cartItems = this.smartCartManager.getCartItems();

      if (cartItems.length === 0) {
        console.log('📭 Cart is empty, no refresh needed');
        return;
      }

      // Check if any items need refresh
      const itemsNeedingRefresh = cartItems.filter(item => {
        return this.smartCartManager.shouldRefreshData() ||
               this.getDataAge(item) > this.settings.cacheRetention;
      });

      if (itemsNeedingRefresh.length === 0) {
        console.log('✅ All cart items have fresh data');
        return;
      }

      console.log(`🔄 Refreshing ${itemsNeedingRefresh.length} items with stale data`);

      // Extract product requests for refreshing
      const refreshRequests = itemsNeedingRefresh.map(item => ({
        productId: item.productId,
        variantId: item.variantId,
        includeVariant: !!item.variantId,
        priority: 'high'
      }));

      // Use batch processor for efficient refresh
      if (this.batchProcessor) {
        await this.batchProcessor.processMultipleProducts(refreshRequests, {
          priority: 'high',
          immediate: false
        });
      } else {
        // Fallback to direct API calls
        await this.apiService.fetchMultipleProducts(refreshRequests, {
          priority: 'high',
          freshData: true
        });
      }

      console.log('✅ Cart data refresh completed');

    } catch (error) {
      console.error('❌ Error handling cart opened:', error);
      this.eventBus.emit('smart-cart:refresh-error', { error: error.message });
    }
  }

  async handleAddItemIntegrated(data) {
    console.log('➕ Handling Smart Cart item addition with integration');

    try {
      const { productInfo, selectedVariant } = data;

      // First, try to get fresh product data with current price
      const enhancedProductInfo = await this.fetchProductWithCurrentData(
        productInfo.productId,
        selectedVariant
      );

      // Merge enhanced data with original product info
      const finalProductInfo = {
        ...productInfo,
        ...enhancedProductInfo,
        extractedAt: Date.now()
      };

      // Let the Smart Cart Manager handle the actual addition
      await this.smartCartManager.addItem(finalProductInfo, selectedVariant);

      console.log('✅ Smart Cart item added with enhanced data');

    } catch (error) {
      console.error('❌ Error in integrated add item:', error);
      // Fallback to original data if enhancement fails
      await this.smartCartManager.addItem(data.productInfo, data.selectedVariant);
    }
  }

  async fetchProductWithCurrentData(productId, selectedVariant = null) {
    const requestKey = this.generateRequestKey(productId, selectedVariant);

    // Check for duplicate requests
    if (this.requestDeduplication && this.activeRequests.has(requestKey)) {
      console.log(`🔄 Reusing pending request for ${requestKey}`);
      return await this.activeRequests.get(requestKey);
    }

    // Create new request
    const requestPromise = this._fetchProductDataInternal(productId, selectedVariant);

    if (this.requestDeduplication) {
      this.activeRequests.set(requestKey, requestPromise);
    }

    try {
      const result = await requestPromise;
      return result;
    } finally {
      if (this.requestDeduplication) {
        this.activeRequests.delete(requestKey);
      }
    }
  }

  async _fetchProductDataInternal(productId, selectedVariant) {
    try {
      // Use optimized API service for fetching
      const result = await this.apiService.fetchProductData(productId, {
        includeVariant: !!selectedVariant,
        variantId: selectedVariant?.id,
        priority: 'high',
        freshData: false // Allow cache hits for recent data
      });

      if (result.success && result.data) {
        return this.extractEnhancedProductInfo(result.data);
      } else {
        console.warn('⚠️ Failed to fetch enhanced product data:', result.error);
        return {};
      }
    } catch (error) {
      console.error('❌ Error fetching product data:', error);
      return {};
    }
  }

  extractEnhancedProductInfo(apiData) {
    // Extract key information from API response
    const extracted = {};

    // Extract current price
    if (apiData.default_variant?.price?.selling_price) {
      extracted.currentPrice = apiData.default_variant.price.selling_price;
    } else if (apiData.price?.selling_price) {
      extracted.currentPrice = apiData.price.selling_price;
    }

    // Extract title
    if (apiData.title_fa) {
      extracted.productTitle = apiData.title_fa;
    } else if (apiData.title) {
      extracted.productTitle = apiData.title;
    }

    // Extract image
    if (apiData.images?.main?.url?.[0]) {
      extracted.productImage = apiData.images.main.url[0];
    }

    // Extract availability info
    extracted.availability = {
      isAvailable: apiData.is_active && apiData.has_stock,
      stockCount: apiData.stock?.count || 0,
      maxCartCount: apiData.max_order_count || 10
    };

    return extracted;
  }

  async handleRefreshData(data) {
    console.log('🔄 Handling data refresh request:', data);

    if (!this.servicesInitialized) {
      console.warn('⚠️ Services not initialized, skipping refresh');
      return;
    }

    const { productIds = null, force = false } = data;

    try {
      if (productIds && productIds.length > 0) {
        // Refresh specific products
        await this.refreshSpecificProducts(productIds, { force });
      } else {
        // Refresh all cart products
        await this.refreshAllCartProducts({ force });
      }
    } catch (error) {
      console.error('❌ Error handling refresh data:', error);
      this.eventBus.emit('smart-cart:refresh-error', { error: error.message });
    }
  }

  async refreshSpecificProducts(productIds, options = {}) {
    console.log(`🔄 Refreshing specific products: ${productIds.join(', ')}`);

    const { force = false } = options;

    // Get cart items for these products
    const cartItems = this.smartCartManager.getCartItems();
    const itemsToRefresh = cartItems.filter(item => productIds.includes(item.productId));

    if (itemsToRefresh.length === 0) {
      console.log('ℹ️ No cart items found for specified product IDs');
      return;
    }

    // Create refresh requests
    const refreshRequests = itemsToRefresh.map(item => ({
      productId: item.productId,
      variantId: item.variantId,
      includeVariant: !!item.variantId,
      priority: 'high'
    }));

    // Process with batch processor or API service
    let results;
    if (this.batchProcessor) {
      results = await this.batchProcessor.processMultipleProducts(refreshRequests, {
        priority: 'high',
        immediate: false
      });
    } else {
      results = await this.apiService.fetchMultipleProducts(refreshRequests, {
        priority: 'high',
        freshData: force
      });
    }

    // Emit refresh completed event
    this.eventBus.emit('smart-cart:refresh-completed', {
      productIds,
      results,
      refreshedCount: Object.keys(results).length
    });

    console.log(`✅ Refreshed ${Object.keys(results).length} products`);
  }

  async refreshAllCartProducts(options = {}) {
    console.log('🔄 Refreshing all cart products');

    const cartItems = this.smartCartManager.getCartItems();
    if (cartItems.length === 0) {
      console.log('📭 Cart is empty, nothing to refresh');
      return;
    }

    const productIds = [...new Set(cartItems.map(item => item.productId))];
    await this.refreshSpecificProducts(productIds, options);
  }

  async handlePreloadProducts(data) {
    console.log('🚀 Handling product preload request:', data);

    if (!this.servicesInitialized || !this.apiService) {
      console.warn('⚠️ Services not available for preloading');
      return;
    }

    const { productIds } = data;

    try {
      await this.apiService.preloadProducts(productIds, { priority: 'low' });
      console.log(`✅ Preloaded ${productIds.length} products`);
    } catch (error) {
      console.warn('⚠️ Error preloading products:', error);
    }
  }

  handleRateLimited(data) {
    console.log('⏳ API rate limited, adjusting request strategy:', data);

    // Could implement backoff strategies here
    // For now, just log the event
  }

  handleBatchCompleted(data) {
    console.log('📦 Batch processing completed:', data);

    // Update last refresh time
    if (this.smartCartManager) {
      this.smartCartManager.lastRefreshTime = Date.now();
    }
  }

  // Utility methods
  generateRequestKey(productId, selectedVariant) {
    const variantId = selectedVariant?.id || 'default';
    return `${productId}_${variantId}`;
  }

  getDataAge(item) {
    const now = Date.now();
    const lastRefreshed = item.lastRefreshed || item.updatedAt || item.addedAt;
    return now - lastRefreshed;
  }

  // Configuration and monitoring
  updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    console.log('🔧 Integration settings updated:', this.settings);

    // Propagate settings to services
    if (this.smartCartManager) {
      this.smartCartManager.refreshSettings = {
        ...this.smartCartManager.refreshSettings,
        autoRefreshOnOpen: this.settings.enableAutoRefresh
      };
    }

    if (this.batchProcessor) {
      this.batchProcessor.updateConfig({
        batchTimeout: this.settings.batchDelay,
        concurrency: this.settings.maxConcurrentRequests
      });
    }
  }

  getIntegrationStats() {
    const stats = {
      servicesInitialized: this.servicesInitialized,
      settings: this.settings,
      activeRequests: this.activeRequests.size,
      services: {}
    };

    if (this.cacheService) {
      stats.services.cache = this.cacheService.getCacheStats();
    }

    if (this.apiService) {
      stats.services.api = this.apiService.getStats();
    }

    if (this.batchProcessor) {
      stats.services.batch = this.batchProcessor.getStats();
    }

    if (this.smartCartManager) {
      stats.services.smartCart = this.smartCartManager.getServiceStats();
    }

    return stats;
  }

  // Testing and debugging
  async testIntegration() {
    console.log('🧪 Testing Smart Cart Integration...');

    if (!this.servicesInitialized) {
      console.error('❌ Services not initialized');
      return false;
    }

    try {
      // Test cache service
      if (this.cacheService) {
        await this.cacheService.set('test-product', { test: 'data' });
        const cached = await this.cacheService.get('test-product');
        console.log('✅ Cache service test passed:', !!cached);
      }

      // Test API service
      if (this.apiService) {
        const stats = this.apiService.getStats();
        console.log('✅ API service test passed:', stats);
      }

      // Test batch processor
      if (this.batchProcessor) {
        const batchStats = this.batchProcessor.getStats();
        console.log('✅ Batch processor test passed:', batchStats);
      }

      console.log('🎉 Integration test completed successfully');
      return true;

    } catch (error) {
      console.error('❌ Integration test failed:', error);
      return false;
    }
  }

  destroy() {
    // Clean up all services
    if (this.smartCartManager) {
      this.smartCartManager.cleanup();
    }

    if (this.batchProcessor) {
      this.batchProcessor.destroy();
    }

    if (this.apiService) {
      this.apiService.destroy();
    }

    if (this.cacheService) {
      this.cacheService.destroy();
    }

    // Clear active requests
    this.activeRequests.clear();

    // Remove event listeners
    this.eventBus.off('smart-cart:cart-opened', this.handleCartOpened.bind(this));
    this.eventBus.off('smart-cart:add-item', this.handleAddItemIntegrated.bind(this));
    this.eventBus.off('smart-cart:refresh-data', this.handleRefreshData.bind(this));
    this.eventBus.off('smart-cart:preload-products', this.handlePreloadProducts.bind(this));

    console.log('🧹 Smart Cart Integration destroyed');
  }
}

window.SmartCartIntegration = SmartCartIntegration;