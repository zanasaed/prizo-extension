/**
 * @Author: Smart Cart System
 * @Date: 2025-01-18
 * Main Basket Optimizer - Coordinates different optimization strategies
 */

class BasketOptimizer {
  constructor() {
    this.validator = new (window.BasketValidator || BasketValidator)();
    this.costCalculator = new (window.CostCalculator || CostCalculator)();
    this.exhaustiveOptimizer = new (window.ExhaustiveSearchOptimizer || ExhaustiveSearchOptimizer)(this.costCalculator);
    this.greedyOptimizer = new (window.GreedyLocalSearchOptimizer || GreedyLocalSearchOptimizer)(this.costCalculator);
  }

  /**
   * Main optimization entry point
   * @param {Object} basketData - Input data structure
   * @returns {Object|null} Optimized basket solution or null if no solution exists
   */
  async optimizeBasket(basketData) {
    try {
      // Validate input data
      const validation = this.validator.validateInput(basketData);
      if (!validation.isValid) {
        throw new Error(`Invalid input: ${validation.errors.join(', ')}`);
      }

      // Normalize and prepare data
      const normalizedData = this.normalizeData(basketData);

      // Check if any solution exists
      if (!this.hasFeasibleSolution(normalizedData)) {
        return {
          success: false,
          error: 'No feasible solution exists - some products have no available sellers',
          assignments: [],
          totalProductCost: 0,
          totalShippingCost: 0,
          totalCost: 0,
          sellersUsed: []
        };
      }

      // Choose optimization strategy based on problem size
      const strategy = this.selectOptimizationStrategy(normalizedData);
      console.log(`🎯 Using ${strategy} optimization strategy for ${normalizedData.products.length} products`);

      let result;
      switch (strategy) {
        case 'exhaustive':
          result = await this.exhaustiveOptimizer.optimize(normalizedData);
          break;
        case 'greedy':
          result = await this.greedyOptimizer.optimize(normalizedData);
          break;
        default:
          throw new Error(`Unknown optimization strategy: ${strategy}`);
      }

      // Validate result
      if (result && this.validator.validateSolution(result, normalizedData)) {
        result.success = true;
        result.strategy = strategy;
        console.log(`✅ Optimization completed using ${strategy} strategy`);
        console.log(`💰 Total cost: ${result.totalCost} (${result.totalProductCost} + ${result.totalShippingCost})`);
        console.log(`🏪 Sellers used: ${result.sellersUsed.length}`);
        return result;
      } else {
        throw new Error('Generated solution is invalid');
      }

    } catch (error) {
      console.error('❌ Basket optimization failed:', error);
      return {
        success: false,
        error: error.message,
        assignments: [],
        totalProductCost: 0,
        totalShippingCost: 0,
        totalCost: 0,
        sellersUsed: []
      };
    }
  }

  /**
   * Select the best optimization strategy based on problem characteristics
   */
  selectOptimizationStrategy(data) {
    const productCount = data.products.length;
    const avgSellersPerProduct = data.products.reduce((sum, p) => sum + p.sellers.length, 0) / productCount;

    // For small problems with few sellers per product, use exhaustive search
    if (productCount <= 8 || (productCount <= 12 && avgSellersPerProduct <= 3)) {
      return 'exhaustive';
    }

    // For larger problems, use greedy + local search
    return 'greedy';
  }

  /**
   * Normalize input data for consistent processing
   */
  normalizeData(basketData) {
    const normalized = {
      ...basketData,
      products: basketData.products.map(product => ({
        ...product,
        sellers: product.sellers.filter(seller =>
          seller.inventory > 0 &&
          seller.price > 0 &&
          basketData.sellers[seller.sellerId]
        )
      }))
    };

    // Set default values
    normalized.optimizationMode = normalized.optimizationMode || 'COST';
    normalized.maxSellers = normalized.maxSellers || Infinity;
    normalized.marketplaceShipping = normalized.marketplaceShipping || 0;

    return normalized;
  }

  /**
   * Check if a feasible solution exists
   */
  hasFeasibleSolution(data) {
    // Check if every product has at least one available seller
    for (const product of data.products) {
      if (product.preferredSeller) {
        // If preferred seller is specified, it must be available
        const preferredAvailable = product.sellers.some(s => s.sellerId === product.preferredSeller);
        if (!preferredAvailable) {
          console.warn(`❌ Preferred seller ${product.preferredSeller} not available for product ${product.id}`);
          return false;
        }
      } else if (product.sellers.length === 0) {
        console.warn(`❌ No available sellers for product ${product.id}`);
        return false;
      }
    }
    return true;
  }

  /**
   * Get optimization statistics for debugging
   */
  getOptimizationStats(data) {
    const productCount = data.products.length;
    const totalSellers = Object.keys(data.sellers).length;
    const avgSellersPerProduct = data.products.reduce((sum, p) => sum + p.sellers.length, 0) / productCount;
    const maxSellersPerProduct = Math.max(...data.products.map(p => p.sellers.length));
    const productsWithPreference = data.products.filter(p => p.preferredSeller).length;

    return {
      productCount,
      totalSellers,
      avgSellersPerProduct: Math.round(avgSellersPerProduct * 100) / 100,
      maxSellersPerProduct,
      productsWithPreference,
      optimizationMode: data.optimizationMode,
      maxSellers: data.maxSellers
    };
  }
}

// Browser extension compatibility
if (typeof window !== 'undefined') {
  window.BasketOptimizer = BasketOptimizer;
}