/**
 * Robust Dropdown Component
 * Handles click events properly with stopPropagation and focus management
 */
class SmartDropdown {
  constructor(options = {}) {
    this.options = {
      placeholder: 'انتخاب کنید',
      maxHeight: '200px',
      searchable: false,
      allowClear: false,
      ...options
    };

    this.isOpen = false;
    this.selectedValue = null;
    this.selectedText = '';
    this.items = [];
    this.filteredItems = [];
    this.onSelect = null;
    this.element = null;

    // Focus management
    this.lastFocusedElement = null;

    this.create();
  }

  /**
   * Create dropdown HTML
   */
  create() {
    this.element = document.createElement('div');
    this.element.className = 'smart-dropdown';
    this.element.innerHTML = `
      <div class="dropdown-trigger" tabindex="0" role="button" aria-haspopup="listbox">
        <span class="dropdown-text">${this.options.placeholder}</span>
        <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
          <path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/>
        </svg>
      </div>
      <div class="dropdown-menu" role="listbox" style="display: none;">
        ${this.options.searchable ? `
          <div class="dropdown-search">
            <input type="text" placeholder="جستجو..." class="search-input">
          </div>
        ` : ''}
        <div class="dropdown-items"></div>
      </div>
    `;

    this.addStyles();
    this.bindEvents();
  }

  /**
   * Add component styles
   */
  addStyles() {
    if (document.querySelector('#smart-dropdown-styles')) return;

    const styles = document.createElement('style');
    styles.id = 'smart-dropdown-styles';
    styles.textContent = `
      .smart-dropdown {
        position: relative;
        display: inline-block;
        width: 100%;
        font-family: IRANSans, Tahoma, sans-serif;
        direction: rtl;
      }

      .dropdown-trigger {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 8px 12px;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        background: white;
        cursor: pointer;
        transition: all 0.2s ease;
        outline: none;
      }

      .dropdown-trigger:hover {
        border-color: #cbd5e1;
        background: #f8fafc;
      }

      .dropdown-trigger:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
      }

      .dropdown-trigger.open {
        border-color: #3b82f6;
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
      }

      .dropdown-text {
        flex: 1;
        font-size: 14px;
        color: #374151;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .dropdown-text.placeholder {
        color: #9ca3af;
      }

      .dropdown-arrow {
        color: #6b7280;
        transition: transform 0.2s ease;
        flex-shrink: 0;
      }

      .dropdown-trigger.open .dropdown-arrow {
        transform: rotate(180deg);
      }

      .dropdown-menu {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 1px solid #3b82f6;
        border-top: none;
        border-radius: 0 0 6px 6px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        max-height: ${this.options.maxHeight};
        overflow: hidden;
      }

      .dropdown-search {
        padding: 8px;
        border-bottom: 1px solid #e2e8f0;
      }

      .search-input {
        width: 100%;
        padding: 6px 8px;
        border: 1px solid #e2e8f0;
        border-radius: 4px;
        font-size: 14px;
        outline: none;
      }

      .search-input:focus {
        border-color: #3b82f6;
      }

      .dropdown-items {
        max-height: calc(${this.options.maxHeight} - ${this.options.searchable ? '48px' : '0px'});
        overflow-y: auto;
      }

      .dropdown-item {
        display: flex;
        align-items: center;
        padding: 8px 12px;
        cursor: pointer;
        font-size: 14px;
        color: #374151;
        transition: background-color 0.15s ease;
        border: none;
        background: none;
        width: 100%;
        text-align: right;
      }

      .dropdown-item:hover {
        background: #f3f4f6;
      }

      .dropdown-item:focus {
        background: #e5e7eb;
        outline: none;
      }

      .dropdown-item.selected {
        background: #eff6ff;
        color: #1d4ed8;
        font-weight: 500;
      }

      .dropdown-item.disabled {
        color: #9ca3af;
        cursor: not-allowed;
      }

      .dropdown-item.disabled:hover {
        background: none;
      }

      .item-icon {
        margin-left: 8px;
        width: 16px;
        height: 16px;
        flex-shrink: 0;
      }

      .item-text {
        flex: 1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .item-badge {
        margin-right: 8px;
        padding: 2px 6px;
        background: #e5e7eb;
        border-radius: 10px;
        font-size: 12px;
        color: #6b7280;
      }

      /* Scrollbar styling */
      .dropdown-items::-webkit-scrollbar {
        width: 6px;
      }

      .dropdown-items::-webkit-scrollbar-track {
        background: #f1f5f9;
      }

      .dropdown-items::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 3px;
      }

      .dropdown-items::-webkit-scrollbar-thumb:hover {
        background: #94a3b8;
      }

      /* Animation */
      .dropdown-menu {
        opacity: 0;
        transform: translateY(-10px);
        transition: all 0.15s ease;
      }

      .dropdown-menu.show {
        opacity: 1;
        transform: translateY(0);
      }
    `;
    document.head.appendChild(styles);
  }

  /**
   * Bind event listeners
   */
  bindEvents() {
    const trigger = this.element.querySelector('.dropdown-trigger');
    const menu = this.element.querySelector('.dropdown-menu');
    const searchInput = this.element.querySelector('.search-input');

    // Trigger click
    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      this.toggle();
    });

    // Keyboard navigation
    trigger.addEventListener('keydown', (e) => {
      e.stopPropagation();

      switch (e.key) {
        case 'Enter':
        case ' ':
          e.preventDefault();
          this.toggle();
          break;
        case 'ArrowDown':
          e.preventDefault();
          if (!this.isOpen) {
            this.open();
          } else {
            this.focusNextItem();
          }
          break;
        case 'ArrowUp':
          e.preventDefault();
          if (this.isOpen) {
            this.focusPreviousItem();
          }
          break;
        case 'Escape':
          e.preventDefault();
          this.close();
          break;
      }
    });

    // Search input
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        e.stopPropagation();
        this.handleSearch(e.target.value);
      });

      searchInput.addEventListener('keydown', (e) => {
        e.stopPropagation();

        if (e.key === 'ArrowDown') {
          e.preventDefault();
          this.focusFirstItem();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          this.close();
        }
      });
    }

    // Click outside to close
    document.addEventListener('click', (e) => {
      if (!this.element.contains(e.target)) {
        this.close();
      }
    });

    // Prevent menu clicks from closing dropdown
    menu.addEventListener('click', (e) => {
      e.stopPropagation();
    });
  }

  /**
   * Set dropdown items
   */
  setItems(items) {
    this.items = items.map(item => ({
      value: item.value,
      text: item.text,
      disabled: item.disabled || false,
      icon: item.icon || null,
      badge: item.badge || null,
      data: item.data || {}
    }));

    this.filteredItems = [...this.items];
    this.renderItems();
  }

  /**
   * Render dropdown items
   */
  renderItems() {
    const container = this.element.querySelector('.dropdown-items');
    container.innerHTML = '';

    if (this.filteredItems.length === 0) {
      container.innerHTML = '<div class="dropdown-item disabled">موردی یافت نشد</div>';
      return;
    }

    this.filteredItems.forEach((item, index) => {
      const itemElement = document.createElement('button');
      itemElement.className = `dropdown-item ${item.disabled ? 'disabled' : ''} ${item.value === this.selectedValue ? 'selected' : ''}`;
      itemElement.disabled = item.disabled;
      itemElement.setAttribute('data-value', item.value);
      itemElement.setAttribute('data-index', index);

      itemElement.innerHTML = `
        ${item.icon ? `<span class="item-icon">${item.icon}</span>` : ''}
        <span class="item-text">${item.text}</span>
        ${item.badge ? `<span class="item-badge">${item.badge}</span>` : ''}
      `;

      // Item click handler
      itemElement.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!item.disabled) {
          this.selectItem(item);
        }
      });

      // Item keyboard handler
      itemElement.addEventListener('keydown', (e) => {
        e.stopPropagation();

        switch (e.key) {
          case 'Enter':
          case ' ':
            e.preventDefault();
            if (!item.disabled) {
              this.selectItem(item);
            }
            break;
          case 'ArrowDown':
            e.preventDefault();
            this.focusNextItem();
            break;
          case 'ArrowUp':
            e.preventDefault();
            this.focusPreviousItem();
            break;
          case 'Escape':
            e.preventDefault();
            this.close();
            break;
        }
      });

      container.appendChild(itemElement);
    });
  }

  /**
   * Handle search
   */
  handleSearch(query) {
    if (!query.trim()) {
      this.filteredItems = [...this.items];
    } else {
      const searchTerm = query.toLowerCase();
      this.filteredItems = this.items.filter(item =>
        item.text.toLowerCase().includes(searchTerm)
      );
    }

    this.renderItems();
  }

  /**
   * Select an item
   */
  selectItem(item) {
    console.log(`🎯 [SmartDropdown] Selected: ${item.text} (${item.value})`);

    this.selectedValue = item.value;
    this.selectedText = item.text;

    // Update trigger text
    const triggerText = this.element.querySelector('.dropdown-text');
    triggerText.textContent = item.text;
    triggerText.classList.remove('placeholder');

    // Trigger selection callback
    if (this.onSelect) {
      this.onSelect(item);
    }

    this.close();
  }

  /**
   * Open dropdown
   */
  open() {
    if (this.isOpen) return;

    console.log('📂 [SmartDropdown] Opening dropdown');

    this.isOpen = true;
    this.lastFocusedElement = document.activeElement;

    const trigger = this.element.querySelector('.dropdown-trigger');
    const menu = this.element.querySelector('.dropdown-menu');

    trigger.classList.add('open');
    menu.style.display = 'block';

    // Force reflow for animation
    menu.offsetHeight;
    menu.classList.add('show');

    // Focus search input if available, otherwise first item
    const searchInput = this.element.querySelector('.search-input');
    if (searchInput) {
      searchInput.focus();
    } else {
      this.focusFirstItem();
    }
  }

  /**
   * Close dropdown
   */
  close() {
    if (!this.isOpen) return;

    console.log('📁 [SmartDropdown] Closing dropdown');

    this.isOpen = false;

    const trigger = this.element.querySelector('.dropdown-trigger');
    const menu = this.element.querySelector('.dropdown-menu');

    trigger.classList.remove('open');
    menu.classList.remove('show');

    setTimeout(() => {
      menu.style.display = 'none';
    }, 150);

    // Restore focus
    if (this.lastFocusedElement) {
      this.lastFocusedElement.focus();
    }
  }

  /**
   * Toggle dropdown
   */
  toggle() {
    if (this.isOpen) {
      this.close();
    } else {
      this.open();
    }
  }

  /**
   * Focus first item
   */
  focusFirstItem() {
    const firstItem = this.element.querySelector('.dropdown-item:not(.disabled)');
    if (firstItem) {
      firstItem.focus();
    }
  }

  /**
   * Focus next item
   */
  focusNextItem() {
    const items = this.element.querySelectorAll('.dropdown-item:not(.disabled)');
    const currentIndex = Array.from(items).findIndex(item => item === document.activeElement);

    if (currentIndex < items.length - 1) {
      items[currentIndex + 1].focus();
    }
  }

  /**
   * Focus previous item
   */
  focusPreviousItem() {
    const items = this.element.querySelectorAll('.dropdown-item:not(.disabled)');
    const currentIndex = Array.from(items).findIndex(item => item === document.activeElement);

    if (currentIndex > 0) {
      items[currentIndex - 1].focus();
    } else {
      // Focus search input if available
      const searchInput = this.element.querySelector('.search-input');
      if (searchInput) {
        searchInput.focus();
      }
    }
  }

  /**
   * Set selected value
   */
  setValue(value) {
    const item = this.items.find(item => item.value === value);
    if (item) {
      this.selectItem(item);
    }
  }

  /**
   * Get selected value
   */
  getValue() {
    return this.selectedValue;
  }

  /**
   * Clear selection
   */
  clear() {
    this.selectedValue = null;
    this.selectedText = '';

    const triggerText = this.element.querySelector('.dropdown-text');
    triggerText.textContent = this.options.placeholder;
    triggerText.classList.add('placeholder');

    this.renderItems();
  }

  /**
   * Set selection callback
   */
  onSelectionChange(callback) {
    this.onSelect = callback;
  }

  /**
   * Destroy dropdown
   */
  destroy() {
    if (this.element && this.element.parentNode) {
      this.element.parentNode.removeChild(this.element);
    }
  }
}

// Export for use
window.SmartDropdown = SmartDropdown;