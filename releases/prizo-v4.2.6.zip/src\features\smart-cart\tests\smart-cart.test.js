/**
 * Smart Cart Test Suite
 * Comprehensive tests for core functionality
 */

// Mock Chrome APIs
global.chrome = {
  storage: {
    local: {
      get: jest.fn(),
      set: jest.fn(),
      remove: jest.fn()
    },
    onChanged: {
      addListener: jest.fn()
    }
  },
  runtime: {
    sendMessage: jest.fn()
  }
};

// Import components (in real environment, these would be loaded)
const SmartCartState = require('../core/smart-cart-state.js');
const UnifiedSmartCartAPI = require('../core/smart-cart-api.js');

describe('SmartCartState', () => {
  let cartState;

  beforeEach(() => {
    cartState = new SmartCartState();
    jest.clearAllMocks();
  });

  describe('addItem', () => {
    test('should add new item to empty cart', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();
      const result = await cartState.addItem('12345', null, 1);

      expect(result.pId).toBe('12345');
      expect(result.qty).toBe(1);
      expect(cartState.cart).toHaveLength(1);
    });

    test('should update quantity for existing item', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();
      await cartState.addItem('12345', null, 1);
      const result = await cartState.addItem('12345', null, 2);

      expect(result.qty).toBe(3);
      expect(cartState.cart).toHaveLength(1);
    });

    test('should handle different variants separately', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();
      await cartState.addItem('12345', 'variant1', 1);
      await cartState.addItem('12345', 'variant2', 1);

      expect(cartState.cart).toHaveLength(2);
    });
  });

  describe('updateQuantity', () => {
    test('should update item quantity', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();
      const item = await cartState.addItem('12345', null, 1);
      const updated = await cartState.updateQuantity(item.id, 5);

      expect(updated.qty).toBe(5);
    });

    test('should remove item when quantity is 0', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();
      const item = await cartState.addItem('12345', null, 1);
      await cartState.updateQuantity(item.id, 0);

      expect(cartState.cart).toHaveLength(0);
    });

    test('should throw error for non-existent item', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();

      await expect(cartState.updateQuantity('non-existent', 5))
        .rejects.toThrow('Item non-existent not found');
    });
  });

  describe('removeItem', () => {
    test('should remove item from cart', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();
      const item = await cartState.addItem('12345', null, 1);
      const removed = await cartState.removeItem(item.id);

      expect(removed).toBe(true);
      expect(cartState.cart).toHaveLength(0);
    });

    test('should return false for non-existent item', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();
      const removed = await cartState.removeItem('non-existent');

      expect(removed).toBe(false);
    });
  });

  describe('storage optimization', () => {
    test('should optimize cart when approaching size limit', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();

      // Add items to approach size limit
      for (let i = 0; i < 50; i++) {
        await cartState.addItem(`product_${i}`, null, 1);
      }

      // Verify optimization was triggered
      const cartSize = JSON.stringify(cartState.cart).length;
      expect(cartSize).toBeLessThan(8000);
    });

    test('should handle storage overflow gracefully', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set
        .mockRejectedValueOnce(new Error('Value too large'))
        .mockResolvedValueOnce();

      await cartState.loadCart();
      await cartState.addItem('12345', null, 1);

      // Should not throw error, should handle overflow
      expect(cartState.cart.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe('getSummary', () => {
    test('should calculate cart summary correctly', async () => {
      chrome.storage.local.get.mockResolvedValue({});
      chrome.storage.local.set.mockResolvedValue();

      await cartState.loadCart();
      await cartState.addItem('12345', null, 2);
      await cartState.addItem('67890', null, 3);

      const summary = cartState.getSummary();

      expect(summary.totalItems).toBe(5);
      expect(summary.uniqueProducts).toBe(2);
      expect(summary.itemCount).toBe(2);
    });
  });
});

describe('UnifiedSmartCartAPI', () => {
  let api;
  let mockState;

  beforeEach(() => {
    mockState = {
      addItem: jest.fn(),
      removeItem: jest.fn(),
      updateQuantity: jest.fn(),
      getCart: jest.fn(),
      getSummary: jest.fn(),
      clearCart: jest.fn(),
      loadCart: jest.fn(),
      subscribe: jest.fn()
    };

    window.smartCartState = mockState;
    api = new UnifiedSmartCartAPI('test');
  });

  describe('buildUniqueVariants', () => {
    test('should build unique variants list', () => {
      const productData = {
        variants: [
          { id: 'v1', attributes: { color: 'red' }, stock: 5 },
          { id: 'v1', attributes: { color: 'red' }, stock: 3 }, // Duplicate
          { id: 'v2', attributes: { color: 'blue' }, stock: 0 }
        ]
      };

      const variants = api.buildUniqueVariants(productData);

      expect(variants).toHaveLength(2);
      expect(variants[0].id).toBe('v1');
      expect(variants[0].isAvailable).toBe(true);
      expect(variants[1].id).toBe('v2');
      expect(variants[1].isAvailable).toBe(false);
    });

    test('should handle empty variants array', () => {
      const productData = { variants: [] };
      const variants = api.buildUniqueVariants(productData);

      expect(variants).toHaveLength(0);
    });
  });

  describe('buildUniqueSellers', () => {
    test('should build unique sellers list', () => {
      const productData = {
        default_variant: {
          seller: { id: 's1', title: 'Seller 1', rating: { total_rate: 90 } },
          price: { selling_price: 100 }
        },
        variants: [
          {
            id: 'v1',
            seller: { id: 's2', title: 'Seller 2', rating: { total_rate: 85 } },
            price: { selling_price: 95 }
          },
          {
            id: 'v2',
            seller: { id: 's1', title: 'Seller 1' }, // Duplicate
            price: { selling_price: 105 }
          }
        ]
      };

      const sellers = api.buildUniqueSellers(productData);

      expect(sellers).toHaveLength(2);
      expect(sellers[0].price).toBe(95); // Should be sorted by price
      expect(sellers[1].price).toBe(100);
    });

    test('should filter by selected variant', () => {
      const productData = {
        variants: [
          {
            id: 'v1',
            seller: { id: 's1', title: 'Seller 1' },
            price: { selling_price: 100 }
          },
          {
            id: 'v2',
            seller: { id: 's2', title: 'Seller 2' },
            price: { selling_price: 95 }
          }
        ]
      };

      const sellers = api.buildUniqueSellers(productData, 'v1');

      expect(sellers).toHaveLength(1);
      expect(sellers[0].id).toBe('s1');
    });
  });

  describe('getDisplayedPrice', () => {
    const mockProductData = {
      default_variant: {
        price: { selling_price: 100 }
      },
      variants: [
        {
          id: 'v1',
          seller: { id: 's1' },
          price: { selling_price: 95 }
        },
        {
          id: 'v1',
          seller: { id: 's2' },
          price: { selling_price: 90 }
        },
        {
          id: 'v2',
          seller: { id: 's1' },
          price: { selling_price: 110 }
        }
      ]
    };

    test('should return specific price for variant + seller', () => {
      const price = api.getDisplayedPrice(mockProductData, 'v1', 's1');
      expect(price).toBe(95);
    });

    test('should return lowest price for variant only', () => {
      const price = api.getDisplayedPrice(mockProductData, 'v1');
      expect(price).toBe(90); // Lowest price for v1
    });

    test('should return lowest price for no selection', () => {
      const price = api.getDisplayedPrice(mockProductData);
      expect(price).toBe(90); // Lowest across all
    });

    test('should return 0 for invalid data', () => {
      const price = api.getDisplayedPrice({});
      expect(price).toBe(0);
    });
  });

  describe('updateQuantity', () => {
    test('should validate quantity range', async () => {
      const result1 = await api.updateQuantity('item1', -1);
      expect(result1.success).toBe(false);
      expect(result1.error).toBe('Invalid quantity');

      const result2 = await api.updateQuantity('item1', 100);
      expect(result2.success).toBe(false);
      expect(result2.error).toBe('Maximum quantity is 99');
    });

    test('should accept valid quantities', async () => {
      mockState.updateQuantity.mockResolvedValue({ id: 'item1', qty: 5 });

      const result = await api.updateQuantity('item1', 5);
      expect(result.success).toBe(true);
      expect(mockState.updateQuantity).toHaveBeenCalledWith('item1', 5);
    });
  });
});

describe('Request Deduplication', () => {
  let api;

  beforeEach(() => {
    window.smartCartState = { subscribe: jest.fn(), loadCart: jest.fn() };
    api = new UnifiedSmartCartAPI('test');
  });

  test('should deduplicate concurrent requests', async () => {
    const mockApiService = {
      fetchProduct: jest.fn().mockResolvedValue({
        success: true,
        data: { id: '12345', title: 'Test Product' }
      })
    };

    api.apiService = mockApiService;

    // Make multiple concurrent requests for same product
    const promises = [
      api.fetchProductData('12345'),
      api.fetchProductData('12345'),
      api.fetchProductData('12345')
    ];

    await Promise.all(promises);

    // Should only make one actual API call
    expect(mockApiService.fetchProduct).toHaveBeenCalledTimes(1);
  });

  test('should respect rate limiting', async () => {
    const mockApiService = {
      fetchProduct: jest.fn().mockResolvedValue({ success: true, data: {} })
    };

    api.apiService = mockApiService;

    // Exhaust rate limit
    for (let i = 0; i < 15; i++) {
      await api.fetchProductData(`product_${i}`);
    }

    // Should not exceed rate limit
    expect(mockApiService.fetchProduct).toHaveBeenCalledTimes(10);
  });
});

// Integration Tests
describe('Smart Cart Integration', () => {
  test('add item workflow', async () => {
    chrome.storage.local.get.mockResolvedValue({});
    chrome.storage.local.set.mockResolvedValue();

    const cartState = new SmartCartState();
    const api = new UnifiedSmartCartAPI('test');

    await cartState.loadCart();

    // Add item
    const result = await api.addItem('12345', 'variant1', 2);

    expect(result.success).toBe(true);
    expect(result.item.pId).toBe('12345');
    expect(result.item.qty).toBe(2);

    // Verify cart state
    const cart = cartState.getCart();
    expect(cart).toHaveLength(1);

    const summary = cartState.getSummary();
    expect(summary.totalItems).toBe(2);
    expect(summary.uniqueProducts).toBe(1);
  });

  test('quantity update workflow', async () => {
    chrome.storage.local.get.mockResolvedValue({});
    chrome.storage.local.set.mockResolvedValue();

    const cartState = new SmartCartState();
    const api = new UnifiedSmartCartAPI('test');

    await cartState.loadCart();

    // Add item and update quantity
    const addResult = await api.addItem('12345', null, 1);
    const updateResult = await api.updateQuantity(addResult.item.id, 5);

    expect(updateResult.success).toBe(true);
    expect(updateResult.item.qty).toBe(5);

    const summary = cartState.getSummary();
    expect(summary.totalItems).toBe(5);
  });
});

// Performance Tests
describe('Performance', () => {
  test('should handle large cart efficiently', async () => {
    chrome.storage.local.get.mockResolvedValue({});
    chrome.storage.local.set.mockResolvedValue();

    const cartState = new SmartCartState();
    await cartState.loadCart();

    const startTime = Date.now();

    // Add 100 items
    for (let i = 0; i < 100; i++) {
      await cartState.addItem(`product_${i}`, null, 1);
    }

    const endTime = Date.now();
    const duration = endTime - startTime;

    // Should complete within reasonable time (adjust threshold as needed)
    expect(duration).toBeLessThan(5000); // 5 seconds

    const summary = cartState.getSummary();
    expect(summary.uniqueProducts).toBe(100);
  });
});

module.exports = {
  SmartCartState,
  UnifiedSmartCartAPI
};