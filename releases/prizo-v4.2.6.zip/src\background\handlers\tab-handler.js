/**
 * Tab Handler Module
 * Manages tab-related events and state persistence
 */

import { BackgroundLogger } from '../utils/logger.js';

class TabHandler {
  constructor(backgroundService) {
    this.backgroundService = backgroundService;
  }

  async handleTabUpdate(tabId, changeInfo, tab) {
    if (changeInfo.status !== 'complete' || !tab.url) {
      return;
    }

    if (!this.backgroundService.isDigikalaSellerPage(tab.url)) {
      return;
    }

    try {
      const storageKey = `seller_prices_active_${tabId}`;
      const result = await chrome.storage.local.get([storageKey]);
      const wasActive = result[storageKey] || false;

      if (wasActive) {
        BackgroundLogger.info(`Tab ${tabId} was previously active, attempting to reactivate`);

        setTimeout(async () => {
          await this.reactivateTab(tabId);
        }, 1500);
      }
    } catch (error) {
      console.error('Error handling tab update:', error);
    }
  }

  async reactivateTab(tabId) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, {
        action: 'toggleStatus'
      });

      if (response && response.active) {
        BackgroundLogger.info(`Successfully reactivated extension on tab ${tabId}`);
        // Update icon to active state
        await this.backgroundService.updateExtensionIcon(tabId, true);
      } else {
        BackgroundLogger.info(`Failed to reactivate extension on tab ${tabId}`);
        const storageKey = `seller_prices_active_${tabId}`;
        await chrome.storage.local.remove([storageKey]);
        // Update icon to inactive state
        await this.backgroundService.updateExtensionIcon(tabId, false);
      }
    } catch (error) {
      console.error(`Error reactivating tab ${tabId}:`, error);
      // Update icon to inactive state on error
      await this.backgroundService.updateExtensionIcon(tabId, false);
    }
  }

  async cleanupTabStorage(tabId) {
    try {
      const storageKey = `seller_prices_active_${tabId}`;
      await chrome.storage.local.remove([storageKey]);
      BackgroundLogger.info(`Cleaned up storage for closed tab ${tabId}`);
    } catch (error) {
      console.error('Error cleaning up tab storage:', error);
    }
  }

  async updateExtensionIcon(tabId, isActive) {
    try {
      const iconPaths = {
        16: chrome.runtime.getURL(`icons/${isActive ? 'active' : 'deactive'}_16.png`),
        32: chrome.runtime.getURL(`icons/${isActive ? 'active' : 'deactive'}_32.png`),
        48: chrome.runtime.getURL(`icons/${isActive ? 'active' : 'deactive'}_48.png`),
        128: chrome.runtime.getURL(`icons/${isActive ? 'active' : 'deactive'}_128.png`)
      };

      await chrome.action.setIcon({
        path: iconPaths,
        tabId: tabId
      });

      BackgroundLogger.info(`🎨 Icon updated for tab ${tabId}: ${isActive ? 'active' : 'inactive'}`);
    } catch (error) {
      console.error('Error updating extension icon:', error);
    }
  }
}

export { TabHandler };