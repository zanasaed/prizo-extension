/**
 * Production Logger - Minimal logging for production environment
 */
class ProductionLogger {
  static isProduction = true; // Set to false for development
  static logLevel = 'error'; // error, warn, none

  static log(...args) {
    if (!this.isProduction && this.logLevel !== 'none') {
      console.log(...args);
    }
  }

  static warn(...args) {
    if (this.logLevel === 'warn' || (!this.isProduction && this.logLevel !== 'none')) {
      console.warn(...args);
    }
  }

  static error(...args) {
    if (this.logLevel !== 'none') {
      console.error(...args);
    }
  }

  static info(...args) {
    if (!this.isProduction && this.logLevel !== 'none') {
      console.info(...args);
    }
  }

  static debug(...args) {
    if (!this.isProduction && this.logLevel !== 'none') {
      console.debug(...args);
    }
  }

  static setProductionMode(isProduction, logLevel = 'error') {
    this.isProduction = isProduction;
    this.logLevel = logLevel;
  }
}

// Export for global use
window.ProductionLogger = ProductionLogger;