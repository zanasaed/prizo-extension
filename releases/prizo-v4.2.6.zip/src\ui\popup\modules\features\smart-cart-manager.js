/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-18
 * Smart Cart Manager for Popup - Manages Smart Cart display and interaction in popup
 */
class SmartCartManager extends BaseModule {
  constructor(eventBus, domManager) {
    super('SmartCartManager', eventBus, domManager);
    this.cartItems = [];
    this.isModalOpen = false;

    // Bind handlers to avoid losing event listeners on button updates
    this.boundShowModalHandler = null;

    // Loading states and data refresh
    this.loadingStates = new Map();
    this.refreshInProgress = false;
    this.lastRefreshTime = null;
    this.refreshSettings = {
      autoRefreshOnOpen: true,
      refreshInterval: 2 * 60 * 1000, // 2 minutes
      showLoadingStates: true
    };

    // Data age tracking
    this.dataAgeThreshold = 5 * 60 * 1000; // 5 minutes

    // Smart Cart optimization
    this.smartCartOptimizer = null;
    this.isOptimizing = false;
    this.optimizationResults = null;
  }

  async initializeElements() {
    // Elements are already in the HTML, no need to create them
    this.elements = {
      showCartBtn: document.getElementById('showSmartCartBtn'),
      clearCartBtn: document.getElementById('clearSmartCartBtn'),
      modal: document.getElementById('smartCartModal'),
      closeModalBtn: document.getElementById('closeSmartCartModal'),
      clearAllModalBtn: document.getElementById('clearAllSmartCartBtn'),
      cartItemsContainer: document.getElementById('smartCartItems'),
      cartSummary: {
        itemsCount: document.getElementById('cartItemsCount'),
        totalValue: document.getElementById('cartTotalValue'),
        uniqueProducts: document.getElementById('cartUniqueProducts')
      },
      modalSummary: {
        itemsCount: document.getElementById('modalCartItemsCount'),
        totalValue: document.getElementById('modalCartTotalValue'),
        uniqueProducts: document.getElementById('modalCartUniqueProducts')
      }
    };
  }

  async setupEventListeners() {
    this.setupSmartCartEventListeners();
    this.setupStorageListener();
  }

  setupStorageListener() {
    // Listen for storage changes to keep data in sync
    if (chrome.storage && chrome.storage.onChanged) {
      this.storageChangeListener = (changes, namespace) => {
        if (namespace === 'local' && changes.digikala_extension_smart_cart_items) {
          console.log('📦 Smart Cart storage changed:', changes.digikala_extension_smart_cart_items);
          console.log('📦 Old value:', changes.digikala_extension_smart_cart_items.oldValue);
          console.log('📦 New value:', changes.digikala_extension_smart_cart_items.newValue);

          const newItems = changes.digikala_extension_smart_cart_items.newValue || [];
          console.log(`🔄 Updating manager with ${newItems.length} items from storage`);

          this.cartItems = newItems;
          this.updateUI();

          if (this.isModalOpen) {
            console.log('📋 Modal is open, updating modal state...');
            this.updateModalState();
          }

          console.log('✅ Smart Cart manager synced with storage');
        }
      };

      chrome.storage.onChanged.addListener(this.storageChangeListener);
      console.log('✅ Storage change listener registered');
    }
  }

  async loadInitialData() {
    await this.loadCartData();
    this.updateUI();

    // Test with sample data if no real data exists
    if (this.cartItems.length === 0) {
      console.log('📝 No cart items found, testing with sample data...');
      await this.testWithSampleData();
    }

    // Initialize Smart Cart optimizer
    await this.initializeOptimizer();
  }

  /**
   * Initialize Smart Cart optimizer for popup
   */
  async initializeOptimizer() {
    if (!window.EnhancedSmartCartOptimizer) {
      console.warn('⚠️ EnhancedSmartCartOptimizer not available in popup');
      return false;
    }

    try {
      console.log('🚀 Initializing Smart Cart Optimizer for popup...');

      // Create a mock storage service and smart cart manager for the optimizer
      const mockStorage = {
        getItem: async (key) => {
          if (key === 'digikala_extension_smart_cart_items') {
            return this.cartItems;
          }
          return null;
        },
        setItem: async (key, value) => {
          if (key === 'digikala_extension_smart_cart_items') {
            this.cartItems = value;
            this.updateUI();
          }
        }
      };

      const mockSmartCartManager = {
        getCartItems: () => this.cartItems,
        updateCartItem: (id, updates) => {
          const index = this.cartItems.findIndex(item => item.id === id);
          if (index !== -1) {
            this.cartItems[index] = { ...this.cartItems[index], ...updates };
            this.updateUI();
          }
        },
        eventBus: this.eventBus
      };

      const mockApiService = {
        fetchMultipleProducts: async (productIds) => {
          console.log('🌐 Mock API: fetching product data for', productIds);
          // Return mock product data for testing
          return productIds.map(id => ({
            id: id,
            name: `Product ${id}`,
            price: Math.floor(Math.random() * 1000000) + 100000,
            sellers: [
              {
                id: 1,
                name: 'دیجی‌کالا',
                price: Math.floor(Math.random() * 1000000) + 100000,
                hasStock: true
              }
            ]
          }));
        }
      };

      // Initialize the optimizer
      this.smartCartOptimizer = new window.EnhancedSmartCartOptimizer(mockSmartCartManager, mockApiService, mockStorage);
      const success = await this.smartCartOptimizer.initialize();

      if (success) {
        console.log('✅ Smart Cart Optimizer initialized successfully in popup');

        // Setup optimization display UI
        this.setupOptimizationDisplay();

        // Setup event listeners for optimization
        this.setupOptimizationEventListeners();

        // Trigger initial optimization if cart has items and data is loaded
        // Delay to ensure cart data is fully loaded
        setTimeout(async () => {
          if (this.cartItems.length > 0) {
            await this.triggerCartOptimization('popup_init');
          }
        }, 500);

        return true;
      } else {
        console.warn('⚠️ Smart Cart Optimizer initialization failed in popup');
        return false;
      }

    } catch (error) {
      console.error('❌ Error initializing Smart Cart Optimizer in popup:', error);
      return false;
    }
  }

  async testWithSampleData() {
    // Add sample data for testing
    this.cartItems = [
      {
        id: 'test_item_1',
        productId: 'dkp-12345',
        productTitle: 'گوشی موبایل سامسونگ Galaxy S23 Ultra - ظرفیت 256 گیگابایت',
        productUrl: 'https://www.digikala.com/product/dkp-12345/',
        productImage: 'https://dkstatics-public.digikala.com/digikala-products/120x120_dir/12345.jpg',
        price: 450000000, // 45 million rials
        quantity: 1,
        variantId: 'variant_black_256gb',
        variantDetails: {
          color: { title: 'مشکی' },
          size: { title: '256 گیگابایت' }
        },
        addedAt: Date.now() - 3600000, // 1 hour ago
        updatedAt: Date.now() - 3600000
      },
      {
        id: 'test_item_2',
        productId: 'dkp-67890',
        productTitle: 'هدفون بی‌سیم اپل AirPods Pro',
        productUrl: 'https://www.digikala.com/product/dkp-67890/',
        productImage: null,
        price: 120000000, // 12 million rials
        quantity: 2,
        variantId: null,
        variantDetails: null,
        addedAt: Date.now() - 7200000, // 2 hours ago
        updatedAt: Date.now() - 7200000
      }
    ];

    console.log('🧪 Added sample cart data:', this.cartItems);
    this.updateUI();
  }

  setupSmartCartEventListeners() {
    // Smart Cart button event listeners
    const showCartBtn = document.getElementById('showSmartCartBtn');
    const clearCartBtn = document.getElementById('clearSmartCartBtn');
    const closeModalBtn = document.getElementById('closeSmartCartModal');
    const clearAllModalBtn = document.getElementById('clearAllSmartCartBtn');

    console.log('🔍 Setting up Smart Cart event listeners...');
    console.log('🔍 showCartBtn element:', showCartBtn);

    if (showCartBtn) {
      console.log('✅ Smart Cart show button found and event listener added');

      // Remove any existing event listeners first
      const oldHandler = showCartBtn.onclick;
      if (oldHandler) {
        console.log('⚠️ Found existing onclick handler, removing...');
        showCartBtn.onclick = null;
      }

      // Create bound handler if not exists
      if (!this.boundShowModalHandler) {
        this.boundShowModalHandler = (e) => {
          console.log('🔍 Smart Cart show button clicked!');
          console.log('🔍 Event details:', {
            target: e.target,
            currentTarget: e.currentTarget,
            bubbles: e.bubbles,
            cancelable: e.cancelable
          });

          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();

          this.showSmartCartModal();
        };
      }

      // Add our event listener with high priority (capture phase)
      showCartBtn.addEventListener('click', this.boundShowModalHandler, true);
    } else {
      console.warn('❌ showSmartCartBtn not found!');
    }

    if (clearCartBtn) {
      clearCartBtn.addEventListener('click', () => this.clearSmartCart());
    }

    if (closeModalBtn) {
      closeModalBtn.addEventListener('click', () => this.hideSmartCartModal());
    }

    if (clearAllModalBtn) {
      clearAllModalBtn.addEventListener('click', () => this.clearSmartCart());
    }

    // Listen for messages from content script about cart updates
    this.eventBus.on('smart-cart:updated', (data) => {
      this.handleCartUpdate(data);
    });

    // Listen for Smart Cart events from extension bridge
    this.eventBus.on('extension:smart-cart-items-received', (data) => {
      console.log('📬 Received Smart Cart items from extension bridge:', data);

      if (data && data.success && data.items) {
        console.log('✅ Processing received items:', data.items);
        console.log('🔍 First item detail:', data.items[0]);
        this.cartItems = data.items;
        this.updateUI();
        if (this.isModalOpen) {
          this.updateModalState();
        }
      } else if (data && data.items) {
        // Handle case where data.success might not be set
        console.log('✅ Processing received items (no success flag):', data.items);
        console.log('🔍 First item detail:', data.items[0]);
        this.cartItems = data.items;
        this.updateUI();
        if (this.isModalOpen) {
          this.updateModalState();
        }
      } else {
        console.warn('❌ Invalid data received:', data);
      }
    });

    this.eventBus.on('extension:smart-cart-cleared', () => {
      console.log('🧹 Received Smart Cart cleared event');
      this.cartItems = [];
      this.updateUI();
      this.renderCartItems();
    });

    this.eventBus.on('extension:smart-cart-item-removed', (data) => {
      console.log('🗑️ Received Smart Cart item removed event:', data);
      // Cart items are already updated locally, just refresh if needed
      this.updateUI();
      if (this.isModalOpen) {
        this.renderCartItems();
      }
    });

    // Close modal when clicking outside
    const modal = document.getElementById('smartCartModal');
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          this.hideSmartCartModal();
        }
      });
    }

    // Event delegation for cart item actions
    const smartCartItems = document.getElementById('smartCartItems');
    if (smartCartItems) {
      smartCartItems.addEventListener('click', (e) => {
        this.handleCartItemClick(e);
      });

      // Handle change events for dropdowns
      smartCartItems.addEventListener('change', (e) => {
        this.handleCartItemChange(e);
      });
    }
  }

  async loadCartData() {
    try {
      console.log('🔄 Loading Smart Cart data with API-first approach...');

      // First try to get from storage directly
      const result = await chrome.storage.local.get(['digikala_extension_smart_cart_items']);
      this.cartItems = result.digikala_extension_smart_cart_items || [];
      console.log(`📦 Loaded ${this.cartItems.length} items from storage`);

      // Update UI with current data (may show cached data temporarily)
      this.updateUI();

      // Request fresh API data for all items
      console.log('🌐 Requesting fresh API data for cart items...');
      this.eventBus.emit('extension:refresh-smart-cart-api-data');

      // Show message if items need API refresh
      const itemsNeedingRefresh = this.cartItems.filter(item =>
        item._cached?.needsRefresh || (!item.price && !item.productTitle)
      ).length;

      if (itemsNeedingRefresh > 0) {
        console.log(`⚠️ ${itemsNeedingRefresh} items need API data refresh`);
      }

      // Also get fresh data from extension bridge
      this.eventBus.emit('extension:get-smart-cart-items');

      // Force load after a delay to ensure we have the latest data
      setTimeout(async () => {
        await this.forceLoadFromExtension();
      }, 500);

    } catch (error) {
      console.error('❌ Error loading Smart Cart data:', error);
      this.cartItems = [];
    }
  }

  async forceLoadFromExtension() {
    try {
      // Get the extension bridge module
      const extensionBridge = window.popupExtensionBridge;
      if (extensionBridge) {
        console.log('🔄 Forcing fresh load from extension bridge...');
        const response = await extensionBridge.getSmartCartItems();
        if (response && response.success && response.items) {
          console.log('✅ Got fresh data from extension bridge:', response.items);
          this.cartItems = response.items;
          this.updateUI();
          if (this.isModalOpen) {
            this.renderCartItems();
          }
        }
      }
    } catch (error) {
      console.error('❌ Error forcing load from extension:', error);
    }
  }

  updateUI() {
    this.updateSummary();
    this.updateButtons();
  }

  updateSummary() {
    const summary = this.getCartSummary();
    console.log('📊 Updating Smart Cart summary:', summary);

    // Update main summary
    const itemsCountEl = document.getElementById('cartItemsCount');
    const totalValueEl = document.getElementById('cartTotalValue');
    const uniqueProductsEl = document.getElementById('cartUniqueProducts');

    if (itemsCountEl) {
      itemsCountEl.textContent = summary.totalItems;
      console.log('Updated items count:', summary.totalItems);
    } else {
      console.warn('❌ cartItemsCount element not found');
    }

    if (totalValueEl) {
      totalValueEl.textContent = this.formatPrice(summary.totalValue);
      console.log('Updated total value:', this.formatPrice(summary.totalValue));
    } else {
      console.warn('❌ cartTotalValue element not found');
    }

    if (uniqueProductsEl) {
      uniqueProductsEl.textContent = summary.uniqueProducts;
      console.log('Updated unique products:', summary.uniqueProducts);
    } else {
      console.warn('❌ cartUniqueProducts element not found');
    }

    // Update modal summary
    const modalItemsCountEl = document.getElementById('modalCartItemsCount');
    const modalTotalValueEl = document.getElementById('modalCartTotalValue');
    const modalUniqueProductsEl = document.getElementById('modalCartUniqueProducts');

    if (modalItemsCountEl) modalItemsCountEl.textContent = summary.totalItems;
    if (modalTotalValueEl) modalTotalValueEl.textContent = this.formatPrice(summary.totalValue);
    if (modalUniqueProductsEl) modalUniqueProductsEl.textContent = summary.uniqueProducts;
  }

  updateButtons() {
    const showCartBtn = document.getElementById('showSmartCartBtn');
    if (showCartBtn) {
      // Clear existing content and set new content properly
      showCartBtn.innerHTML = `<span>🛒</span> مشاهده سبد (${this.cartItems.length})`;
      console.log('Updated button text:', `مشاهده سبد (${this.cartItems.length})`);

      // Re-add event listener since innerHTML clears it
      showCartBtn.removeEventListener('click', this.boundShowModalHandler);
      this.boundShowModalHandler = (e) => {
        console.log('🔍 Smart Cart show button clicked!');
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        this.showSmartCartModal();
      };
      showCartBtn.addEventListener('click', this.boundShowModalHandler, true);
    } else {
      console.warn('❌ showSmartCartBtn element not found');
    }
  }

  getCartSummary() {
    const totalItems = this.cartItems.reduce((sum, item) => sum + (item.quantity || 0), 0);

    // Debug price calculation
    console.log('🔍 Cart items for price calculation:', this.cartItems.map(item => ({
      id: item.id,
      title: item.productTitle,
      price: item.price,
      quantity: item.quantity,
      calculatedPrice: (item.price || 0) * (item.quantity || 0)
    })));

    const totalValue = this.cartItems.reduce((sum, item) => {
      const itemPrice = parseFloat(item.price || 0);
      const itemQuantity = parseInt(item.quantity) || 0;
      const itemTotal = itemPrice * itemQuantity;
      const productTitle = item.productTitle || item._cached?.productTitle || 'محصول';
      console.log(`💰 Item: ${productTitle} - Price: ${itemPrice}, Qty: ${itemQuantity}, Total: ${itemTotal}`);
      return sum + itemTotal;
    }, 0);

    const uniqueProducts = new Set(this.cartItems.map(item => item.productId)).size;

    console.log('📊 Final summary calculation:', {
      totalItems,
      totalValue,
      uniqueProducts,
      itemCount: this.cartItems.length
    });

    return {
      totalItems,
      totalValue,
      uniqueProducts,
      itemCount: this.cartItems.length
    };
  }

  formatPrice(price) {
    if (!price || price === 0) return '0 تومان';

    // Convert from rials to tomans (divide by 10)
    const tomans = Math.floor(price / 10);

    // Format with Persian numbers and thousand separators
    const formatted = tomans.toLocaleString('fa-IR');
    return `${formatted} تومان`;
  }

  async showSmartCartModal() {
    console.log('🔍 showSmartCartModal called');
    console.log('🔍 Current cart items:', this.cartItems);

    const modal = document.getElementById('smartCartModal');
    const loading = document.getElementById('smartCartLoading');
    const empty = document.getElementById('smartCartEmpty');
    const items = document.getElementById('smartCartItems');
    const summary = document.getElementById('smartCartModalSummary');

    console.log('🔍 Modal elements found:', {
      modal: !!modal,
      loading: !!loading,
      empty: !!empty,
      items: !!items,
      summary: !!summary
    });

    if (!modal) {
      console.error('❌ Smart Cart modal not found!');
      return;
    }

    // Show modal
    console.log('📱 Showing Smart Cart modal');
    modal.style.display = 'flex';
    modal.style.visibility = 'visible';
    modal.style.opacity = '1';
    this.isModalOpen = true;

    console.log('📱 Modal display style set to:', modal.style.display);

    // Emit cart opened event for data refresh
    this.eventBus.emit('extension:smart-cart-opened');

    // Show loading state
    if (loading) loading.style.display = 'flex';
    if (empty) empty.style.display = 'none';
    if (items) items.style.display = 'none';
    if (summary) summary.style.display = 'none';

    try {
      // Reload cart data
      await this.loadCartData();

      // Check if data needs refresh
      const needsRefresh = this.shouldRefreshData();
      if (needsRefresh && this.refreshSettings.autoRefreshOnOpen) {
        console.log('🔄 Data needs refresh, requesting fresh data...');
        this.requestDataRefresh();
      }

      // Hide loading
      if (loading) loading.style.display = 'none';

      console.log(`📊 Cart has ${this.cartItems.length} items`);

      if (this.cartItems.length === 0) {
        // Show empty state
        console.log('📭 Showing empty state');
        if (empty) empty.style.display = 'block';
      } else {
        // Show items
        console.log('📋 Showing cart items');
        if (items) {
          items.style.display = 'block';
          console.log('🔄 Rendering cart items...');
          this.renderCartItems();
        }
        if (summary) {
          summary.style.display = 'block';
          console.log('📊 Updating modal summary...');
          this.updateSummary();
        }
      }
    } catch (error) {
      console.error('❌ Error loading Smart Cart items:', error);
      if (loading) loading.style.display = 'none';
      if (empty) empty.style.display = 'block';
    }
  }

  hideSmartCartModal() {
    const modal = document.getElementById('smartCartModal');
    if (modal) {
      modal.style.display = 'none';
      this.isModalOpen = false;
    }
  }

  updateModalState() {
    if (!this.isModalOpen) return;

    console.log('🔄 Updating modal state...');

    const loading = document.getElementById('smartCartLoading');
    const empty = document.getElementById('smartCartEmpty');
    const items = document.getElementById('smartCartItems');
    const summary = document.getElementById('smartCartModalSummary');

    // Hide loading first
    if (loading) loading.style.display = 'none';

    console.log(`📊 Modal state check: ${this.cartItems.length} items`);

    if (this.cartItems.length === 0) {
      // Show empty state
      console.log('📭 Switching to empty state');
      if (empty) empty.style.display = 'block';
      if (items) items.style.display = 'none';
      if (summary) summary.style.display = 'none';
    } else {
      // Show items
      console.log('📋 Switching to items state');
      if (empty) empty.style.display = 'none';
      if (items) {
        items.style.display = 'block';
        console.log('🔄 Rendering cart items...');
        this.renderCartItems();
      }
      if (summary) {
        summary.style.display = 'block';
        console.log('📊 Updating modal summary...');
        this.updateSummary();
      }
    }

    console.log('✅ Modal state updated');
  }

  renderCartItems() {
    console.log('🔄 renderCartItems called');
    const container = document.getElementById('smartCartItems');
    console.log('🔍 smartCartItems container:', container);

    if (!container) {
      console.error('❌ smartCartItems container not found!');
      return;
    }

    console.log(`📊 Rendering ${this.cartItems.length} cart items`);

    if (this.cartItems.length === 0) {
      console.log('📭 No items, showing empty message');
      container.innerHTML = '<div class="no-items">سبد خالی است</div>';
      return;
    }

    const renderedHTML = this.cartItems.map(item => this.renderCartItem(item)).join('');
    console.log('🎨 Generated HTML length:', renderedHTML.length);
    console.log('🎨 Generated HTML preview:', renderedHTML.substring(0, 200) + '...');

    container.innerHTML = renderedHTML;
    console.log('✅ Cart items rendered to container');
  }

  renderCartItem(item) {
    // Handle new API-first data structure
    const productTitle = item.productTitle || item._cached?.productTitle || 'در حال بارگذاری...';
    const productImage = item.productImage || null;
    const productPrice = item.price || 0;

    // Check if we need to show API refresh warning
    const needsApiRefresh = item._cached?.needsRefresh || (!item.price && !item.productTitle);
    const hasApiData = !!item._cached?.lastFetched;

    const itemPrice = this.formatPrice(productPrice);
    const totalPrice = this.formatPrice(productPrice * item.quantity);

    // Get variant display text - simplified for popup
    const variantText = this.getVariantDisplayText(item.variantDetails);

    // Check if item is loading or needs refresh
    const isLoading = this.loadingStates.get(item.id) || false;
    const needsRefresh = item._cached?.needsRefresh || false;

    // Check data age and freshness
    const dataAge = this.getDataAge(item);
    const isStale = dataAge > this.dataAgeThreshold || needsRefresh;

    // Log enhanced price-variation relationship for verification
    console.log('🔍 Rendering Smart Cart item with enhanced data:', {
      productId: item.productId,
      price: productPrice,
      formattedPrice: itemPrice,
      variantId: item.variantId,
      variantDetails: item.variantDetails,
      variantText: variantText,
      isLoading,
      needsRefresh,
      dataAge,
      isStale,
      hasApiData: !!item._cached?.lastFetched
    });

    // Truncate product title for better display
    const truncatedTitle = this.truncateProductTitle(productTitle);

    // Calculate discount info if available
    const originalPrice = item.originalPrice || item._cached?.originalPrice;
    const hasDiscount = originalPrice && originalPrice > productPrice;
    const discountAmount = hasDiscount ? originalPrice - productPrice : 0;

    return `
      <div class="br-list-vertical-0 mx-3 py-4" data-testid="cart-item" data-item-id="${item.id}">
        <div class="styles_CartItem__grid__rZXPE" style="display: grid; grid-template-columns: auto 1fr auto auto; gap: 12px; align-items: flex-start;">
          <!-- Product Image Section -->
          <div class="flex flex-col items-center">
            <a class="relative" href="${item.productUrl || item._cached?.productUrl || `https://www.digikala.com/product/dkp-${item.productId}/`}" target="_blank">
              <div style="width: 114px; height: 114px; line-height: 0;">
                ${productImage ?
                  `<img class="w-full inline-block" src="${productImage}" width="114" height="114" alt="${productTitle}" title="${productTitle}" style="object-fit: contain; border-radius: 4px;">` :
                  `<div class="w-full inline-block" style="width: 114px; height: 114px; background: #f8fafc; display: flex; align-items: center; justify-content: center; color: #64748b; border: 1px solid #e2e8f0; border-radius: 4px; font-size: 32px;">📦</div>`
                }
              </div>
              ${item.quantity > 1 ? `<div class="bg-neutral-000 absolute bottom-0 left-0 rounded-small text-center text-neutral-900 text-caption-strong" style="background: white; padding: 2px 6px; border-radius: 4px; font-size: 12px; font-weight: 600;">${item.quantity}</div>` : ''}
            </a>
            ${hasDiscount ? `
            <div class="mr-2">
              <div class="flex items-center text-h5 py-2 mt-2 flex-col">
                <div class="ml-2 flex items-center justify-center" style="width: 64px; height: 14px; line-height: 0;">
                  <div style="background: #ef4444; color: white; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 600;">تخفیف</div>
                </div>
              </div>
            </div>` : ''}
          </div>

          <!-- Product Info Section -->
          <div class="overflow-x-hidden">
            <div>
              <h3 class="text-neutral-800 text-body1-strong mb-2" style="color: #1e293b; font-weight: 600; font-size: 14px; line-height: 1.4; margin-bottom: 8px;">
                <a href="${item.productUrl || item._cached?.productUrl || `https://www.digikala.com/product/dkp-${item.productId}/`}" target="_blank" style="color: inherit; text-decoration: none;" title="${productTitle}">
                  ${truncatedTitle}
                  ${isStale ? ' <span style="color: #f59e0b; font-size: 11px;">⚠</span>' : ''}
                </a>
              </h3>

              ${variantText ? `
              <div class="flex" style="margin-bottom: 8px;">
                <div class="flex mt-1">
                  <svg style="width: 18px; height: 18px; fill: rgb(156, 39, 177);">
                    <circle cx="9" cy="9" r="8" fill="currentColor"/>
                  </svg>
                </div>
                <p class="text-body-2 text-neutral-600 mr-2" style="color: #64748b; font-size: 12px; margin-right: 8px;">${variantText}</p>
              </div>` : ''}

              <div class="flex flex-col w-full relative">
                <ul class="flex flex-col">
                  <li class="flex ml-3 items-center" style="margin-left: 12px;">
                    <div class="flex">
                      <svg style="width: 14px; height: 14px; fill: var(--color-icon-high-emphasis);">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                      </svg>
                    </div>
                    <p class="text-body-2 text-neutral-500 mr-2 ellipsis" style="color: #64748b; font-size: 11px; margin-right: 8px;">
                      ${hasApiData ? 'قیمت بروز' : 'نیاز به بروزرسانی قیمت'}
                      ${isStale ? ' • قیمت قدیمی' : ''}
                    </p>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <!-- Quantity Controls Section -->
          <div class="flex flex-col items-center">
            <div class="flex items-center justify-between user-select-none px-2 rounded-medium border-complete-200 item-quantity_ItemQuantity__box__5r4FJ" style="border: 1px solid #d1d5db; border-radius: 6px; padding: 4px;">
              <div class="flex cursor-pointer" ${item.quantity >= 10 ? 'style="opacity: 0.5; pointer-events: none;"' : ''}>
                <svg class="quantity-increase" data-item-id="${item.id}" data-testid="quantity-increase" data-cro-id="cart-add-quantity" style="width: 18px; height: 18px; fill: var(--color-icon-primary); cursor: pointer;" title="افزایش تعداد">
                  <path d="M12 5v14m7-7H5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
              </div>
              <span class="flex flex-col items-center justify-between text-primary-500" style="color: #3b82f6;">
                <span class="relative flex items-center justify-center text-h5" style="font-size: 14px; font-weight: 600; min-width: 20px; text-align: center;">${item.quantity}</span>
                ${item.quantity >= 10 ? '<small class="text-caption text-neutral-300" style="font-size: 10px; color: #9ca3af;">حداکثر</small>' : ''}
              </span>
              <div class="flex cursor-pointer" ${item.quantity <= 1 ? 'style="opacity: 0.5;"' : ''}>
                <svg class="quantity-decrease" data-item-id="${item.id}" data-testid="quantity-decrease" data-cro-id="cart-delete-item-right" style="width: 18px; height: 18px; fill: var(--color-icon-primary); cursor: pointer;" title="${item.quantity <= 1 ? 'حذف از سبد' : 'کاهش تعداد'}">
                  ${item.quantity <= 1 ?
                    '<path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2M10 11v6M14 11v6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>' :
                    '<path d="M5 12h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>'
                  }
                </svg>
              </div>
            </div>
          </div>

          <!-- Price Section -->
          <div class="h-[40px]">
            ${hasDiscount ? `
            <div class="flex items-center text-primary-700" style="color: #dc2626;">
              <span class="text-caption-strong" style="font-size: 12px; font-weight: 600;">${this.formatPrice(discountAmount)}</span>
              <div class="flex relative styles_CartItem__discountIcon__Vw7DV">
                <svg style="width: 14px; height: 14px; fill: var(--color-icon-primary);">
                  <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                </svg>
              </div>
              <span class="text-caption mr-1" style="font-size: 11px; margin-right: 4px;">تخفیف</span>
            </div>` : ''}

            <div class="flex items-center justify-between">
              <div>
                <div class="flex items-center justify-start ml-4">
                  <div class="flex justify-start items-center gap-1">
                    <span class="text-h4 text-neutral-800" style="font-size: 16px; font-weight: 600; color: #1e293b;">
                      ${itemPrice.replace(' تومان', '')}
                    </span>
                  </div>
                  <div class="flex items-center justify-between">
                    <div class="flex items-center">
                      <div class="flex">
                        <svg style="width: 18px; height: 18px; fill: var(--color-icon-high-emphasis);">
                          <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="flex a-center flex-row-reverse ml-4">
                <button class="remove-cart-item" data-item-id="${item.id}" title="حذف از سبد" style="
                  background: transparent;
                  border: none;
                  color: #dc2626;
                  cursor: pointer;
                  padding: 4px;
                  border-radius: 4px;
                  transition: background 0.2s ease;
                " onmouseover="this.style.background='#fee2e2'" onmouseout="this.style.background='transparent'">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3,6 5,6 21,6"></polyline>
                    <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"></path>
                    <line x1="10" y1="11" x2="10" y2="17"></line>
                    <line x1="14" y1="11" x2="14" y2="17"></line>
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>

        ${isLoading ? `<div class="loading-overlay" style="
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(255,255,255,0.8);
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1;
        ">
          <div class="loading-spinner" style="
            width: 20px;
            height: 20px;
            border: 2px solid #e2e8f0;
            border-top: 2px solid #3b82f6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
          "></div>
        </div>` : ''}
      </div>
    `;
  }

  getVariantDisplayText(variantDetails) {
    if (!variantDetails) return null;

    const parts = [];

    if (variantDetails.color) {
      parts.push(`رنگ: ${variantDetails.color.title}`);
    }

    if (variantDetails.size) {
      parts.push(`سایز: ${variantDetails.size.title}`);
    }

    if (variantDetails.warranty) {
      parts.push(`گارانتی: ${variantDetails.warranty.title}`);
    }

    if (variantDetails.themes && variantDetails.themes.length > 0) {
      variantDetails.themes.forEach(theme => {
        parts.push(theme.title);
      });
    }

    return parts.length > 0 ? parts.join(', ') : null;
  }

  truncateProductTitle(title) {
    if (!title) return '';

    // For popup, limit to approximately 80 characters for 2 lines
    const maxLength = 80;

    if (title.length <= maxLength) {
      return title;
    }

    // Find a good breaking point near the limit
    let truncated = title.substring(0, maxLength);

    // Try to break at word boundary
    const lastSpace = truncated.lastIndexOf(' ');
    if (lastSpace > maxLength * 0.8) { // If we have a good word break
      truncated = title.substring(0, lastSpace);
    }

    return truncated + '...';
  }

  getAvailableVariations(item) {
    // Get available variations from API data
    if (item.variantData || item.variations) {
      const variations = item.variations || (item.variantData ? [item.variantData] : []);

      // Add the "All Variations (Best Price)" option
      const variationOptions = [{
        id: 'all_best_price',
        title: 'همه تنوع‌ها (بهترین قیمت)',
        isSpecial: true
      }];

      // Add actual variations
      variations.forEach(variation => {
        const title = this.formatVariationTitle(variation);
        variationOptions.push({
          id: variation.id,
          title: title,
          price: variation.price?.selling_price,
          isSelected: variation.id === item.variantId
        });
      });

      return variationOptions;
    }

    return [];
  }

  formatVariationTitle(variation) {
    const parts = [];

    if (variation.color) {
      parts.push(variation.color.title || variation.color.name);
    }

    if (variation.size) {
      parts.push(variation.size.title || variation.size.name);
    }

    if (variation.warranty) {
      parts.push(variation.warranty.title_fa || variation.warranty.title);
    }

    return parts.length > 0 ? parts.join(' - ') : `گزینه ${variation.id}`;
  }

  getSellerOptions(item) {
    // Get seller options for the selected variation
    if (item.sellers && Array.isArray(item.sellers)) {
      return item.sellers.map(seller => ({
        id: seller.id,
        name: seller.name,
        price: seller.price,
        inventory: seller.inventory,
        rating: seller.rating,
        shipsDirectly: seller.shipsDirectly
      }));
    }

    // Fallback: create default seller option
    return [{
      id: 'digikala',
      name: 'دیجی‌کالا',
      price: item.price || 0,
      inventory: 5,
      rating: 100,
      shipsDirectly: true
    }];
  }

  renderVariationSelection(item, availableVariations, variantText) {
    if (availableVariations.length <= 1) {
      // Only show simple variant text if no multiple variations
      return variantText ? `<div class="cart-item-variant" style="
        font-size: 11px;
        color: #64748b;
        background: #f1f5f9;
        padding: 2px 6px;
        border-radius: 4px;
        display: inline-block;
        margin-bottom: 6px;
      ">${variantText}</div>` : '';
    }

    // Show variation dropdown
    const currentVariationTitle = availableVariations.find(v => v.isSelected)?.title ||
                                 availableVariations.find(v => v.id === item.variantId)?.title ||
                                 variantText || 'انتخاب تنوع';

    const variationOptions = availableVariations.map(variation =>
      `<option value="${variation.id}" ${variation.isSelected ? 'selected' : ''}>
        ${variation.title}${variation.price ? ` - ${this.formatPrice(variation.price)}` : ''}
      </option>`
    ).join('');

    return `
      <div class="cart-item-variation-section" style="margin-bottom: 6px;">
        <div class="variation-selector" style="
          display: flex;
          align-items: center;
          gap: 6px;
          flex-wrap: wrap;
        ">
          <label style="
            font-size: 10px;
            color: #6b7280;
            font-weight: 500;
          ">تنوع:</label>
          <select class="variation-select" data-item-id="${item.id}" style="
            font-size: 10px;
            padding: 2px 4px;
            border: 1px solid #d1d5db;
            border-radius: 4px;
            background: white;
            color: #374151;
            min-width: 120px;
            max-width: 200px;
          ">
            ${variationOptions}
          </select>
        </div>
      </div>
    `;
  }

  renderSellerInfo(item, sellerOptions) {
    if (!sellerOptions || sellerOptions.length === 0) {
      return '';
    }

    const currentSeller = sellerOptions[0]; // For now, show the first/selected seller
    const hasMultipleSellers = sellerOptions.length > 1;

    if (!hasMultipleSellers) {
      // Show simple seller info
      return `
        <div class="seller-info" style="
          font-size: 10px;
          color: #6b7280;
          display: flex;
          align-items: center;
          gap: 4px;
        ">
          <span>فروشنده:</span>
          <span style="color: #059669; font-weight: 500;">${currentSeller.name}</span>
          ${currentSeller.shipsDirectly ? '<span style="color: #059669;">📦</span>' : ''}
        </div>
      `;
    }

    // Show seller dropdown
    const sellerOptions_html = sellerOptions.map(seller =>
      `<option value="${seller.id}">
        ${seller.name} - ${this.formatPrice(seller.price)}
        ${seller.shipsDirectly ? ' 📦' : ''}
      </option>`
    ).join('');

    return `
      <div class="seller-selector" style="
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: wrap;
      ">
        <label style="
          font-size: 10px;
          color: #6b7280;
          font-weight: 500;
        ">فروشنده:</label>
        <select class="seller-select" data-item-id="${item.id}" style="
          font-size: 10px;
          padding: 2px 4px;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          background: white;
          color: #374151;
          min-width: 100px;
          max-width: 150px;
        ">
          ${sellerOptions_html}
        </select>
      </div>
    `;
  }

  async clearSmartCart() {
    const confirmed = confirm('آیا مطمئن هستید که می‌خواهید تمام محصولات را از سبد هوشمند حذف کنید؟');

    if (!confirmed) return;

    try {
      // Send clear command to content script via event bus
      this.eventBus.emit('extension:clear-smart-cart');

      // Update local state immediately for better UX
      this.cartItems = [];
      this.updateUI();
      this.renderCartItems();

      // Hide modal if open
      if (this.isModalOpen) {
        this.hideSmartCartModal();
      }
    } catch (error) {
      console.error('❌ Error clearing Smart Cart:', error);
    }
  }

  async removeCartItem(itemId) {
    try {
      // Send remove command to content script via event bus
      this.eventBus.emit('extension:remove-smart-cart-item', { itemId });

      // Update local data immediately for better UX
      this.cartItems = this.cartItems.filter(item => item.id !== itemId);
      this.updateUI();
      this.renderCartItems();
    } catch (error) {
      console.error('❌ Error removing item from Smart Cart:', error);
    }
  }

  async increaseQuantity(itemId) {
    try {
      console.log('📈 Increasing quantity for item:', itemId);

      // Update local data immediately for better UX
      const item = this.cartItems.find(item => item.id === itemId);
      if (item) {
        item.quantity += 1;
        item.updatedAt = Date.now();

        // Send update to content script
        this.eventBus.emit('extension:update-smart-cart-quantity', {
          itemId,
          quantity: item.quantity,
          action: 'increase'
        });

        this.updateUI();
        this.renderCartItems();
        console.log(`✅ Increased quantity to ${item.quantity} for item ${itemId}`);
      }
    } catch (error) {
      console.error('❌ Error increasing quantity:', error);
    }
  }

  async decreaseQuantity(itemId) {
    try {
      console.log('📉 Decreasing quantity for item:', itemId);

      // Update local data immediately for better UX
      const item = this.cartItems.find(item => item.id === itemId);
      if (item && item.quantity > 1) {
        item.quantity -= 1;
        item.updatedAt = Date.now();

        // Send update to content script
        this.eventBus.emit('extension:update-smart-cart-quantity', {
          itemId,
          quantity: item.quantity,
          action: 'decrease'
        });

        this.updateUI();
        this.renderCartItems();
        console.log(`✅ Decreased quantity to ${item.quantity} for item ${itemId}`);
      } else if (item && item.quantity === 1) {
        // If quantity is 1, remove the item instead
        console.log('🗑️ Quantity is 1, removing item instead');
        await this.removeCartItem(itemId);
      }
    } catch (error) {
      console.error('❌ Error decreasing quantity:', error);
    }
  }

  handleCartUpdate(data) {
    console.log('🔄 Smart Cart updated:', data);

    // Reload cart data and update UI
    this.loadCartData().then(() => {
      this.updateUI();
      if (this.isModalOpen) {
        this.renderCartItems();
      }
    });
  }

  // Event delegation for cart item actions
  async handleCartItemClick(event) {
    const removeBtn = event.target.closest('.remove-cart-item');
    const increaseBtn = event.target.closest('.quantity-increase');
    const decreaseBtn = event.target.closest('.quantity-decrease');

    let targetBtn = removeBtn || increaseBtn || decreaseBtn;
    if (!targetBtn) return;

    // Prevent multiple rapid clicks by disabling button during processing
    if (targetBtn.disabled) return;
    targetBtn.disabled = true;

    try {
      if (removeBtn) {
        const itemId = removeBtn.dataset.itemId;
        if (itemId) {
          await this.removeCartItem(itemId);
        }
      } else if (increaseBtn) {
        const itemId = increaseBtn.dataset.itemId;
        if (itemId) {
          await this.increaseQuantity(itemId);
        }
      } else if (decreaseBtn) {
        const itemId = decreaseBtn.dataset.itemId;
        if (itemId) {
          await this.decreaseQuantity(itemId);
        }
      }
    } catch (error) {
      console.error('❌ Error handling cart item click:', error);
    } finally {
      // Re-enable button after processing
      targetBtn.disabled = false;
    }
  }

  // Handle change events for dropdowns
  async handleCartItemChange(event) {
    const variationSelect = event.target.closest('.variation-select');
    const sellerSelect = event.target.closest('.seller-select');

    const target = variationSelect || sellerSelect;
    if (!target) return;

    // Disable dropdown during processing
    if (target.disabled) return;
    target.disabled = true;

    try {
      if (variationSelect) {
        const itemId = variationSelect.dataset.itemId;
        const newVariationId = variationSelect.value;
        if (itemId && newVariationId) {
          await this.changeItemVariation(itemId, newVariationId);
        }
      } else if (sellerSelect) {
        const itemId = sellerSelect.dataset.itemId;
        const newSellerId = sellerSelect.value;
        if (itemId && newSellerId) {
          await this.changeItemSeller(itemId, newSellerId);
        }
      }
    } catch (error) {
      console.error('❌ Error handling dropdown change:', error);
    } finally {
      // Re-enable dropdown
      target.disabled = false;
    }
  }

  async changeItemVariation(itemId, newVariationId) {
    try {
      console.log(`🔄 Changing variation for item ${itemId} to ${newVariationId}`);

      const item = this.cartItems.find(item => item.id === itemId);
      if (!item) {
        console.error('❌ Item not found:', itemId);
        return;
      }

      if (newVariationId === 'all_best_price') {
        // Handle "All Variations (Best Price)" option
        item.variantId = null;
        item.variantDetails = null;
        item.optimizeForBestPrice = true;
        console.log('🎯 Set item to auto-optimize for best price');
      } else {
        // Handle specific variation selection
        item.variantId = newVariationId;
        item.optimizeForBestPrice = false;

        // Find the variation details from available variations
        const availableVariations = this.getAvailableVariations(item);
        const selectedVariation = availableVariations.find(v => v.id === newVariationId);

        if (selectedVariation && selectedVariation.price) {
          item.price = selectedVariation.price;
        }
      }

      item.updatedAt = Date.now();

      // Send update to content script for backend processing
      this.eventBus.emit('extension:update-smart-cart-variation', {
        itemId,
        variationId: newVariationId,
        optimizeForBestPrice: item.optimizeForBestPrice || false
      });

      // Update UI
      this.updateUI();
      this.renderCartItems();

      console.log(`✅ Changed variation for item ${itemId} to ${newVariationId}`);
    } catch (error) {
      console.error('❌ Error changing item variation:', error);
    }
  }

  async changeItemSeller(itemId, newSellerId) {
    try {
      console.log(`🔄 Changing seller for item ${itemId} to ${newSellerId}`);

      const item = this.cartItems.find(item => item.id === itemId);
      if (!item) {
        console.error('❌ Item not found:', itemId);
        return;
      }

      // Find the seller and update price if available
      const sellerOptions = this.getSellerOptions(item);
      const selectedSeller = sellerOptions.find(s => s.id === newSellerId);

      if (selectedSeller) {
        item.selectedSeller = newSellerId;
        item.price = selectedSeller.price;
        item.updatedAt = Date.now();

        // Send update to content script
        this.eventBus.emit('extension:update-smart-cart-seller', {
          itemId,
          sellerId: newSellerId,
          price: selectedSeller.price
        });

        // Update UI
        this.updateUI();
        this.renderCartItems();

        console.log(`✅ Changed seller for item ${itemId} to ${selectedSeller.name}`);
      }
    } catch (error) {
      console.error('❌ Error changing item seller:', error);
    }
  }

  // Manual test function for debugging
  async testSmartCartDisplay() {
    console.log('🧪 Testing Smart Cart display...');

    // Add test data
    this.cartItems = [
      {
        id: 'test_debug_1',
        productId: 'dkp-debug-1',
        productTitle: 'محصول تست - دیباگ Smart Cart',
        productUrl: 'https://www.digikala.com/product/dkp-debug-1/',
        productImage: null,
        price: 100000000, // 10 million rials = 1 million tomans
        quantity: 1,
        variantId: null,
        variantDetails: { color: { title: 'قرمز' } },
        addedAt: Date.now(),
        updatedAt: Date.now()
      },
      {
        id: 'test_debug_2',
        productId: 'dkp-debug-2',
        productTitle: 'محصول تست دوم - گوشی هوشمند',
        productUrl: 'https://www.digikala.com/product/dkp-debug-2/',
        productImage: 'https://dkstatics-public.digikala.com/digikala-products/120x120_dir/test.jpg',
        price: 250000000, // 25 million rials = 2.5 million tomans
        quantity: 2,
        variantId: 'variant_blue_128gb',
        variantDetails: {
          color: { title: 'آبی' },
          size: { title: '128 گیگابایت' }
        },
        addedAt: Date.now() - 3600000, // 1 hour ago
        updatedAt: Date.now() - 3600000
      }
    ];

    console.log('🧪 Test data added:', this.cartItems);

    // Update storage with test data
    await chrome.storage.local.set({ digikala_extension_smart_cart_items: this.cartItems });

    // Update UI
    this.updateUI();

    // Also open modal to test display
    this.showSmartCartModal();

    return this.cartItems;
  }

  // Debug method to check current state
  debugCurrentState() {
    console.log('🔍 Smart Cart Manager Debug Info:');
    console.log('- Cart Items:', this.cartItems);
    console.log('- Is Modal Open:', this.isModalOpen);
    console.log('- Elements:', {
      showBtn: !!this.elements?.showCartBtn,
      modal: !!this.elements?.modal,
      container: !!this.elements?.cartItemsContainer
    });

    // Check all DOM elements
    console.log('- DOM Elements Check:', {
      showCartBtn: document.getElementById('showSmartCartBtn'),
      modal: document.getElementById('smartCartModal'),
      items: document.getElementById('smartCartItems'),
      itemsCount: document.getElementById('cartItemsCount'),
      totalValue: document.getElementById('cartTotalValue')
    });

    // Check storage
    chrome.storage.local.get(['digikala_extension_smart_cart_items']).then(result => {
      console.log('- Storage Data:', result.digikala_extension_smart_cart_items);
    });

    return {
      cartItems: this.cartItems,
      isModalOpen: this.isModalOpen,
      elements: this.elements
    };
  }

  // Force show modal for testing
  forceShowModal() {
    console.log('🔧 Force showing modal...');
    const modal = document.getElementById('smartCartModal');
    if (modal) {
      modal.style.display = 'flex';
      modal.style.visibility = 'visible';
      modal.style.opacity = '1';
      this.isModalOpen = true;
      console.log('✅ Modal display set to flex');

      // Update modal state properly
      this.updateModalState();
      console.log('✅ Modal state updated');
    } else {
      console.error('❌ Modal element not found!');
    }
  }

  // Data refresh and loading state methods
  shouldRefreshData() {
    if (!this.lastRefreshTime) return true;

    const timeSinceRefresh = Date.now() - this.lastRefreshTime;
    return timeSinceRefresh > this.refreshSettings.refreshInterval;
  }

  getDataAge(item) {
    const now = Date.now();
    const lastRefreshed = item.lastRefreshed || item.updatedAt || item.addedAt;
    return now - lastRefreshed;
  }

  formatLastRefresh(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;

    if (diff < 60000) {
      return 'همین الان';
    } else if (diff < 3600000) {
      const minutes = Math.floor(diff / 60000);
      return `${minutes} دقیقه پیش`;
    } else {
      const hours = Math.floor(diff / 3600000);
      return `${hours} ساعت پیش`;
    }
  }

  requestDataRefresh() {
    if (this.refreshInProgress) {
      console.log('⏳ Refresh already in progress');
      return;
    }

    console.log('🔄 Requesting Smart Cart data refresh...');
    this.refreshInProgress = true;

    // Set loading states for all items
    if (this.refreshSettings.showLoadingStates) {
      this.cartItems.forEach(item => {
        this.loadingStates.set(item.id, true);
      });

      // Re-render items to show loading states
      if (this.isModalOpen) {
        this.renderCartItems();
      }
    }

    // Emit refresh request
    this.eventBus.emit('extension:smart-cart-refresh-data', {
      productIds: this.cartItems.map(item => item.productId),
      force: false
    });

    // Set timeout to clear loading states if refresh takes too long
    setTimeout(() => {
      if (this.refreshInProgress) {
        console.warn('⚠️ Data refresh timeout, clearing loading states');
        this.clearLoadingStates();
        this.refreshInProgress = false;
      }
    }, 10000); // 10 second timeout
  }

  handleDataRefreshed(data) {
    console.log('✅ Data refresh completed:', data);
    this.refreshInProgress = false;
    this.lastRefreshTime = Date.now();

    // Clear all loading states
    this.clearLoadingStates();

    // Update UI
    this.updateUI();
    if (this.isModalOpen) {
      this.renderCartItems();
    }
  }

  handleDataRefreshError(error) {
    console.error('❌ Data refresh failed:', error);
    this.refreshInProgress = false;

    // Clear loading states
    this.clearLoadingStates();

    // Show error indicator if needed
    // Could add a toast notification here
  }

  clearLoadingStates() {
    this.loadingStates.clear();
    if (this.isModalOpen) {
      this.renderCartItems();
    }
  }

  setItemLoading(itemId, isLoading) {
    if (isLoading) {
      this.loadingStates.set(itemId, true);
    } else {
      this.loadingStates.delete(itemId);
    }

    // Update item display if modal is open
    if (this.isModalOpen) {
      this.renderCartItems();
    }
  }

  // Enhanced summary with loading info
  getCartSummary() {
    const totalItems = this.cartItems.reduce((sum, item) => sum + (item.quantity || 0), 0);

    // Debug price calculation
    console.log('🔍 Cart items for price calculation:', this.cartItems.map(item => ({
      id: item.id,
      title: item.productTitle,
      price: item.price,
      quantity: item.quantity,
      calculatedPrice: (item.price || 0) * (item.quantity || 0)
    })));

    const totalValue = this.cartItems.reduce((sum, item) => {
      const itemPrice = parseFloat(item.price || 0);
      const itemQuantity = parseInt(item.quantity) || 0;
      const itemTotal = itemPrice * itemQuantity;
      const productTitle = item.productTitle || item._cached?.productTitle || 'محصول';
      console.log(`💰 Item: ${productTitle} - Price: ${itemPrice}, Qty: ${itemQuantity}, Total: ${itemTotal}`);
      return sum + itemTotal;
    }, 0);

    const uniqueProducts = new Set(this.cartItems.map(item => item.productId)).size;
    const loadingItems = this.loadingStates.size;
    const staleItems = this.cartItems.filter(item => this.getDataAge(item) > this.dataAgeThreshold).length;

    console.log('📊 Final summary calculation:', {
      totalItems,
      totalValue,
      uniqueProducts,
      itemCount: this.cartItems.length,
      loadingItems,
      staleItems,
      needsRefresh: this.shouldRefreshData()
    });

    return {
      totalItems,
      totalValue,
      uniqueProducts,
      itemCount: this.cartItems.length,
      loadingItems,
      staleItems,
      needsRefresh: this.shouldRefreshData(),
      lastRefreshed: this.lastRefreshTime
    };
  }

  cleanup() {
    // Remove event listeners and clean up
    this.eventBus.off('smart-cart:updated');
    this.eventBus.off('extension:smart-cart-items-received');
    this.eventBus.off('extension:smart-cart-cleared');
    this.eventBus.off('extension:smart-cart-item-removed');
    this.eventBus.off('extension:smart-cart-data-refreshed');
    this.eventBus.off('extension:smart-cart-refresh-error');

    // Clear loading states
    this.loadingStates.clear();
    this.refreshInProgress = false;

    this.isModalOpen = false;
    this.cartItems = [];
  }

  /**
   * Setup optimization display UI for popup
   */
  setupOptimizationDisplay() {
    console.log('🎨 Setting up optimization display UI for popup');

    // Find the modal content area where we'll add optimization results
    const modalBody = document.querySelector('#smartCartModal .modal-content');
    if (!modalBody) {
      console.warn('⚠️ Modal body not found for optimization display');
      return;
    }

    // Check if optimization container already exists
    let optimizationContainer = modalBody.querySelector('.optimization-results-container');
    if (!optimizationContainer) {
      optimizationContainer = document.createElement('div');
      optimizationContainer.className = 'optimization-results-container';
      optimizationContainer.style.display = 'none';
      optimizationContainer.innerHTML = `
        <div class="optimization-section">
          <div class="optimization-header">
            <h4>🧮 Cart Optimization</h4>
            <div class="optimization-loading" style="display: none;">
              <div class="loading-spinner"></div>
              <span>Calculating...</span>
            </div>
          </div>
          <div class="optimization-content">
            <div class="optimization-summary"></div>
            <div class="optimization-recommendations"></div>
          </div>
        </div>
      `;

      // Insert after the cart summary
      const cartSummary = modalBody.querySelector('.cart-summary');
      if (cartSummary) {
        cartSummary.insertAdjacentElement('afterend', optimizationContainer);
      } else {
        modalBody.appendChild(optimizationContainer);
      }
    }

    this.optimizationContainer = optimizationContainer;
    console.log('✅ Optimization display UI setup complete for popup');
  }

  /**
   * Setup optimization event listeners
   */
  setupOptimizationEventListeners() {
    if (!this.smartCartOptimizer) {
      return;
    }

    // Listen for optimization events
    this.smartCartOptimizer.on('optimization-started', () => {
      this.isOptimizing = true;
      this.showOptimizationLoading();
    });

    this.smartCartOptimizer.on('optimization-completed', (result) => {
      this.isOptimizing = false;
      this.optimizationResults = result;
      this.displayOptimizationResults(result);
    });

    this.smartCartOptimizer.on('optimization-error', (error) => {
      this.isOptimizing = false;
      this.hideOptimizationLoading();
      console.error('❌ Optimization error in popup:', error);
    });

    console.log('✅ Optimization event listeners setup for popup');
  }

  /**
   * Trigger cart optimization
   */
  async triggerCartOptimization(reason = 'popup_manual') {
    if (!this.smartCartOptimizer) {
      console.log('⚠️ Smart Cart Optimizer not available in popup');
      return;
    }

    try {
      console.log(`🧮 Triggering cart optimization in popup: ${reason}`);
      const result = await this.smartCartOptimizer.optimizeCurrentCart({
        reason,
        enableAPIRefresh: false // Disable API in popup for now
      });

      return result;
    } catch (error) {
      console.error('❌ Error triggering optimization in popup:', error);
      return null;
    }
  }

  /**
   * Display optimization results in popup
   */
  displayOptimizationResults(result) {
    console.log('📊 Displaying optimization results in popup:', result);

    if (!this.optimizationContainer) {
      console.warn('⚠️ Optimization container not found, setting up...');
      this.setupOptimizationDisplay();
    }

    this.hideOptimizationLoading();

    if (!result || !result.success) {
      // Don't show optimization error if cart is empty or during initialization
      if (this.cartItems.length === 0) {
        console.log('ℹ️ Skipping optimization error display - cart is empty');
        this.hideOptimizationContainer();
        return;
      }
      this.displayOptimizationError(result?.error || 'Unknown optimization error');
      return;
    }

    const summaryContainer = this.optimizationContainer.querySelector('.optimization-summary');
    const recommendationsContainer = this.optimizationContainer.querySelector('.optimization-recommendations');

    // Display compact optimization summary for popup
    if (summaryContainer) {
      summaryContainer.innerHTML = this.generatePopupOptimizationSummary(result);
    }

    // Display key recommendations
    if (recommendationsContainer) {
      recommendationsContainer.innerHTML = this.generatePopupOptimizationRecommendations(result);
    }

    // Show the optimization results
    this.optimizationContainer.style.display = 'block';
    console.log('✅ Optimization results displayed in popup');
  }

  /**
   * Generate compact optimization summary for popup
   */
  generatePopupOptimizationSummary(result) {
    const { optimization, originalCart } = result;
    const savingsAmount = optimization?.totalSavings || 0;
    const savingsPercent = originalCart?.totalCost ?
      ((savingsAmount / originalCart.totalCost) * 100).toFixed(1) : 0;

    return `
      <div class="optimization-summary-compact">
        <div class="savings-highlight">
          <span class="savings-amount">${this.formatPrice(savingsAmount)}</span>
          <span class="savings-label">savings (${savingsPercent}%)</span>
        </div>
        <div class="optimization-stats">
          <span class="stat-item">
            <span class="stat-value">${optimization?.sellersUsed?.length || 0}</span>
            <span class="stat-label">sellers</span>
          </span>
          <span class="stat-item">
            <span class="stat-value">${optimization?.strategy || 'auto'}</span>
            <span class="stat-label">algorithm</span>
          </span>
        </div>
      </div>
    `;
  }

  /**
   * Generate compact recommendations for popup
   */
  generatePopupOptimizationRecommendations(result) {
    if (!result.recommendations || result.recommendations.length === 0) {
      return '<div class="no-recommendations">✅ Cart is already optimized</div>';
    }

    // Show only top 2 recommendations in popup
    const topRecommendations = result.recommendations.slice(0, 2);

    const recommendationsHTML = topRecommendations.map(rec => `
      <div class="recommendation-item-compact ${rec.type}">
        <div class="recommendation-text">
          <span class="recommendation-title">${rec.title}</span>
          <span class="recommendation-impact">+${this.formatPrice(rec.impact)}</span>
        </div>
        ${rec.action ? `<button class="recommendation-action-small" data-action="${rec.action}">${rec.actionText}</button>` : ''}
      </div>
    `).join('');

    return `
      <div class="recommendations-compact">
        <h5>💡 Optimization Tips</h5>
        ${recommendationsHTML}
        ${result.recommendations.length > 2 ? `<div class="more-recommendations">+${result.recommendations.length - 2} more suggestions</div>` : ''}
      </div>
    `;
  }

  /**
   * Display optimization error in popup
   */
  displayOptimizationError(error) {
    if (!this.optimizationContainer) {
      return;
    }

    const summaryContainer = this.optimizationContainer.querySelector('.optimization-summary');
    if (summaryContainer) {
      summaryContainer.innerHTML = `
        <div class="optimization-error-compact">
          <span class="error-icon">⚠️</span>
          <span class="error-text">Optimization failed: ${error}</span>
        </div>
      `;
    }

    // Clear recommendations
    const recommendationsContainer = this.optimizationContainer.querySelector('.optimization-recommendations');
    if (recommendationsContainer) {
      recommendationsContainer.innerHTML = '';
    }

    this.optimizationContainer.style.display = 'block';
  }

  /**
   * Show optimization loading state for popup
   */
  showOptimizationLoading() {
    if (this.optimizationContainer) {
      const loadingElement = this.optimizationContainer.querySelector('.optimization-loading');
      if (loadingElement) {
        loadingElement.style.display = 'flex';
      }

      // Show optimization container
      this.optimizationContainer.style.display = 'block';
    }
  }

  /**
   * Hide optimization loading state for popup
   */
  hideOptimizationLoading() {
    if (this.optimizationContainer) {
      const loadingElement = this.optimizationContainer.querySelector('.optimization-loading');
      if (loadingElement) {
        loadingElement.style.display = 'none';
      }
    }
  }

  hideOptimizationContainer() {
    if (this.optimizationContainer) {
      this.optimizationContainer.style.display = 'none';
    }
  }
}

// Register the module
window.SmartCartManager = SmartCartManager;

// Global test functions for debugging
window.testSmartCartModal = function() {
  console.log('🧪 Global test function called');
  const manager = window.popupSmartCartManager;
  if (manager) {
    console.log('✅ Found Smart Cart manager');
    manager.forceShowModal();
  } else {
    console.error('❌ Smart Cart manager not found');
  }
};

window.testSmartCartData = function() {
  console.log('🧪 Testing Smart Cart data...');
  const manager = window.popupSmartCartManager;
  if (manager) {
    manager.testSmartCartDisplay();
  } else {
    console.error('❌ Smart Cart manager not found');
  }
};

// Complete flow test
window.testCompleteSmartCartFlow = function() {
  console.log('🧪 Testing complete Smart Cart flow...');

  // 1. Check manager
  const manager = window.popupSmartCartManager;
  if (!manager) {
    console.error('❌ Smart Cart manager not found');
    return;
  }

  // 2. Add test data
  console.log('📝 Adding test data...');
  manager.testSmartCartDisplay().then(() => {

    // 3. Check DOM elements
    console.log('🔍 Checking DOM elements...');
    const elements = {
      button: document.getElementById('showSmartCartBtn'),
      modal: document.getElementById('smartCartModal'),
      container: document.getElementById('smartCartItems'),
      summary: document.getElementById('cartItemsCount')
    };
    console.log('DOM elements:', elements);

    // 4. Try to show modal
    console.log('📱 Attempting to show modal...');
    manager.forceShowModal();

    // 5. Check if modal is visible
    setTimeout(() => {
      const modal = document.getElementById('smartCartModal');
      const isVisible = modal && window.getComputedStyle(modal).display !== 'none';
      console.log('Modal visible:', isVisible);

      if (isVisible) {
        console.log('✅ Smart Cart modal is working!');
      } else {
        console.log('❌ Smart Cart modal is not visible');
      }
    }, 100);
  });
};

// Test extension bridge fallback
window.testExtensionBridgeFallback = function() {
  console.log('🧪 Testing extension bridge fallback...');

  const bridge = window.popupExtensionBridge;
  if (!bridge) {
    console.error('❌ Extension bridge not found');
    return;
  }

  // Test getting Smart Cart items with fallback
  console.log('📡 Testing getSmartCartItems fallback...');
  bridge.getSmartCartItems().then(response => {
    console.log('✅ Extension bridge response:', response);

    if (response.success) {
      console.log(`📦 Got ${response.items.length} items from ${response.source || 'content script'}`);
    } else {
      console.log('❌ Extension bridge failed:', response.error);
    }
  }).catch(error => {
    console.error('❌ Extension bridge error:', error);
  });
};

// Simple direct test - bypass all complexity
window.directSmartCartTest = function() {
  console.log('🧪 Direct Smart Cart test...');

  const manager = window.popupSmartCartManager;
  if (!manager) {
    console.error('❌ Smart Cart manager not found');
    return;
  }

  // Set test data directly
  manager.cartItems = [
    {
      id: 'direct_test_1',
      productId: 'dkp-direct-1',
      productTitle: 'تست مستقیم - محصول آزمایشی',
      productUrl: 'https://example.com',
      productImage: null,
      price: 50000000, // 5 million tomans
      quantity: 1,
      variantId: null,
      variantDetails: null,
      addedAt: Date.now(),
      updatedAt: Date.now()
    }
  ];

  console.log('📝 Set test data directly:', manager.cartItems);

  // Update UI
  manager.updateUI();

  // Force show modal
  manager.forceShowModal();

  console.log('✅ Direct test complete');
};

// Check what's actually in storage vs what manager thinks
window.checkSmartCartStorage = function() {
  console.log('🔍 Checking Smart Cart storage vs manager state...');

  const manager = window.popupSmartCartManager;
  if (!manager) {
    console.error('❌ Smart Cart manager not found');
    return;
  }

  console.log('📊 Manager state:');
  console.log('- Cart Items:', manager.cartItems);
  console.log('- Items Count:', manager.cartItems.length);

  // Check storage
  chrome.storage.local.get(['digikala_extension_smart_cart_items']).then(result => {
    console.log('📦 Storage state:');
    console.log('- Storage Items:', result.digikala_extension_smart_cart_items);
    console.log('- Storage Count:', result.digikala_extension_smart_cart_items?.length || 0);

    // Compare
    const managerCount = manager.cartItems.length;
    const storageCount = result.digikala_extension_smart_cart_items?.length || 0;

    if (managerCount !== storageCount) {
      console.warn('⚠️ Mismatch detected!');
      console.log('Manager has', managerCount, 'items but storage has', storageCount, 'items');

      // Try to sync from storage
      console.log('🔄 Syncing from storage...');
      manager.cartItems = result.digikala_extension_smart_cart_items || [];
      manager.updateUI();
      console.log('✅ Synced manager with storage');
    } else {
      console.log('✅ Manager and storage are in sync');
    }
  }).catch(error => {
    console.error('❌ Error checking storage:', error);
  });
};

// Simulate adding an item to test data sync
window.simulateAddToSmartCart = function() {
  console.log('🧪 Simulating adding item to Smart Cart...');

  const testItem = {
    id: 'simulated_' + Date.now(),
    productId: 'dkp-simulated-' + Date.now(),
    productTitle: 'شبیه‌سازی افزودن محصول جدید',
    productUrl: 'https://example.com/simulated',
    productImage: null,
    price: 75000000, // 7.5 million tomans
    quantity: 1,
    variantId: null,
    variantDetails: {
      color: { title: 'قرمز' }
    },
    addedAt: Date.now(),
    updatedAt: Date.now()
  };

  // First check what's currently in storage
  chrome.storage.local.get(['digikala_extension_smart_cart_items']).then(result => {
    const currentItems = result.digikala_extension_smart_cart_items || [];
    console.log('📦 Current items in storage:', currentItems.length);

    // Add the new item
    const updatedItems = [...currentItems, testItem];
    console.log('📝 Adding new item to storage:', testItem);

    // Update storage (this should trigger the storage change listener)
    return chrome.storage.local.set({ digikala_extension_smart_cart_items: updatedItems });
  }).then(() => {
    console.log('✅ Item added to storage, should trigger sync...');

    // Give the storage listener time to react
    setTimeout(() => {
      const manager = window.popupSmartCartManager;
      if (manager) {
        console.log('📊 Manager now has:', manager.cartItems.length, 'items');
        manager.updateUI();
      }
    }, 200);
  }).catch(error => {
    console.error('❌ Error simulating add to cart:', error);
  });
};