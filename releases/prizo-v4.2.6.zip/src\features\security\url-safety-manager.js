/**
 * @Author: Zana Saedpanah
 * @Date:   2025-07-20
 * URL safety and validation utilities
 */

class URLSafetyManager {
  constructor() {
    this.allowedSortValues = new Set([
      '22', '4', '1', '7', '20', '21', '25', '27', '29', '26'
    ]);

    this.allowedHostPatterns = [
      /^(www\.)?digikala\.com$/,
      /^(www\.)?digikala\.ir$/,
      // Allow any HTTPS domain for general e-commerce support
      /^[\w\.-]+$/
    ];

    this.allowedParameters = new Set([
      'sort', 'page', 'category', 'brand', 'price_range', 'search'
    ]);
  }

  validateSortValue(value) {
    if (value === null || value === undefined || value === '') {
      return null;
    }

    const stringValue = String(value).trim();

    if (!this.allowedSortValues.has(stringValue)) {
      console.warn(`⚠️ Invalid sort value: ${stringValue}`);
      return null;
    }

    return stringValue;
  }

  getCurrentSortValue() {
    try {
      if (!this.isValidURL(window.location.href)) {
        console.warn('⚠️ Invalid URL for sort parameter extraction');
        return null;
      }

      const urlParams = new URLSearchParams(window.location.search);
      const sortValue = urlParams.get('sort');

      const validatedValue = this.validateSortValue(sortValue);
      console.log('🎯 Current sort value from URL:', validatedValue);

      return validatedValue;
    } catch (error) {
      console.error('❌ Error getting current sort value:', error);
      return null;
    }
  }

  isValidURL(urlString) {
    try {
      const url = new URL(urlString);

      if (!['http:', 'https:'].includes(url.protocol)) {
        return false;
      }

      return this.allowedHostPatterns.some(pattern => pattern.test(url.hostname));
    } catch (error) {
      console.error('❌ Invalid URL format:', error);
      return false;
    }
  }

  // Keep backward compatibility for Digikala-specific checks
  isValidDigikalaURL(urlString) {
    try {
      const url = new URL(urlString);
      return url.hostname.includes('digikala.com') || url.hostname.includes('digikala.ir');
    } catch (error) {
      return false;
    }
  }

  createSortURL(currentURL, sortValue) {
    try {
      if (!this.isValidURL(currentURL)) {
        throw new Error('Invalid base URL');
      }

      const validatedSortValue = this.validateSortValue(sortValue);
      if (validatedSortValue === null) {
        throw new Error('Invalid sort value');
      }

      const newUrl = new URL(currentURL);

      const currentParams = new URLSearchParams(newUrl.search);

      const cleanParams = new URLSearchParams();
      for (const [key, value] of currentParams) {
        if (this.allowedParameters.has(key)) {
          cleanParams.set(key, value);
        }
      }

      cleanParams.set('sort', validatedSortValue);

      newUrl.search = cleanParams.toString();

      return newUrl.toString();
    } catch (error) {
      console.error('❌ Error creating sort URL:', error);
      throw new Error('Failed to create safe sort URL');
    }
  }

  navigateToSortURL(currentURL, sortValue) {
    try {
      const safeURL = this.createSortURL(currentURL, sortValue);

      if (!this.isValidURL(safeURL)) {
        throw new Error('Generated URL failed safety validation');
      }

      console.log('🎯 Navigating to safe sort URL:', safeURL);
      window.location.href = safeURL;

      return true;
    } catch (error) {
      console.error('❌ Error navigating to sort URL:', error);
      return false;
    }
  }
}

// Make available globally
window.URLSafetyManager = URLSafetyManager;