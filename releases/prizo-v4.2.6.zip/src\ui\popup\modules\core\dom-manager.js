/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * DOM Manager - Centralized DOM element management and utilities
 */

class DOMManager {
  constructor() {
    this.elementCache = new Map();
    this.observedElements = new Map();
    this.mutationObserver = null;
    this.debugMode = false;

    this.initMutationObserver();
  }

  // Enable debug mode
  setDebugMode(enabled) {
    this.debugMode = enabled;
  }

  // Basic DOM selection methods
  getElementById(id) {
    if (this.elementCache.has(id)) {
      const element = this.elementCache.get(id);
      if (element && document.contains(element)) {
        return element;
      } else {
        this.elementCache.delete(id);
      }
    }

    const element = document.getElementById(id);
    if (element) {
      this.elementCache.set(id, element);
    }

    if (this.debugMode && !element) {
      console.warn(`🔍 DOMManager: Element with ID '${id}' not found`);
    }

    return element;
  }

  getElementsByClassName(className) {
    return document.getElementsByClassName(className);
  }

  querySelector(selector) {
    return document.querySelector(selector);
  }

  querySelectorAll(selector) {
    return document.querySelectorAll(selector);
  }

  // Enhanced element management
  getElements(selectors) {
    const elements = {};

    for (const [key, selector] of Object.entries(selectors)) {
      if (selector.startsWith('#')) {
        elements[key] = this.getElementById(selector.substring(1));
      } else {
        elements[key] = this.querySelector(selector);
      }
    }

    return elements;
  }

  validateElements(elements, requiredElements = []) {
    const missing = [];
    const results = {};

    for (const [key, element] of Object.entries(elements)) {
      if (!element) {
        if (requiredElements.includes(key)) {
          missing.push(key);
        }
        results[key] = false;
      } else {
        results[key] = true;
      }
    }

    if (missing.length > 0) {
      console.error(`🚫 DOMManager: Required elements missing:`, missing);
      return { valid: false, missing, results };
    }

    return { valid: true, missing: [], results };
  }

  // Element manipulation utilities
  show(element, display = 'block') {
    if (!element) return false;

    element.style.display = display;
    element.classList.remove('hidden');
    return true;
  }

  hide(element) {
    if (!element) return false;

    element.style.display = 'none';
    element.classList.add('hidden');
    return true;
  }

  toggle(element, show = null) {
    if (!element) return false;

    const isVisible = element.style.display !== 'none' && !element.classList.contains('hidden');
    const shouldShow = show !== null ? show : !isVisible;

    if (shouldShow) {
      this.show(element);
    } else {
      this.hide(element);
    }

    return shouldShow;
  }

  addClass(element, ...classes) {
    if (!element) return false;
    element.classList.add(...classes);
    return true;
  }

  removeClass(element, ...classes) {
    if (!element) return false;
    element.classList.remove(...classes);
    return true;
  }

  toggleClass(element, className, force = null) {
    if (!element) return false;
    return element.classList.toggle(className, force);
  }

  hasClass(element, className) {
    return element && element.classList.contains(className);
  }

  // Text and HTML manipulation
  setText(element, text) {
    if (!element) return false;
    element.textContent = text;
    return true;
  }

  setHTML(element, html) {
    if (!element) return false;
    element.innerHTML = html;
    return true;
  }

  appendHTML(element, html) {
    if (!element) return false;
    element.insertAdjacentHTML('beforeend', html);
    return true;
  }

  prependHTML(element, html) {
    if (!element) return false;
    element.insertAdjacentHTML('afterbegin', html);
    return true;
  }

  // Attribute manipulation
  setAttribute(element, name, value) {
    if (!element) return false;
    element.setAttribute(name, value);
    return true;
  }

  getAttribute(element, name) {
    return element ? element.getAttribute(name) : null;
  }

  removeAttribute(element, name) {
    if (!element) return false;
    element.removeAttribute(name);
    return true;
  }

  // Style manipulation
  setStyle(element, styles) {
    if (!element || typeof styles !== 'object') return false;

    for (const [property, value] of Object.entries(styles)) {
      element.style[property] = value;
    }
    return true;
  }

  getStyle(element, property) {
    if (!element) return null;
    return window.getComputedStyle(element)[property];
  }

  // Event handling utilities
  addEventListener(element, event, handler, options = {}) {
    if (!element) return null;

    const wrappedHandler = (e) => {
      try {
        return handler(e);
      } catch (error) {
        console.error('🚫 DOMManager: Event handler error:', error);
      }
    };

    element.addEventListener(event, wrappedHandler, options);

    // Return removal function
    return () => element.removeEventListener(event, wrappedHandler, options);
  }

  removeEventListener(element, event, handler, options = {}) {
    if (!element) return false;
    element.removeEventListener(event, handler, options);
    return true;
  }

  // Form utilities
  getFormData(form) {
    if (!form) return null;

    const formData = new FormData(form);
    const data = {};

    for (const [key, value] of formData.entries()) {
      data[key] = value;
    }

    return data;
  }

  setFormData(form, data) {
    if (!form || typeof data !== 'object') return false;

    for (const [key, value] of Object.entries(data)) {
      const field = form.querySelector(`[name="${key}"]`);
      if (field) {
        if (field.type === 'checkbox' || field.type === 'radio') {
          field.checked = Boolean(value);
        } else {
          field.value = value;
        }
      }
    }
    return true;
  }

  validateForm(form, validators = {}) {
    if (!form) return { valid: false, errors: ['Form not found'] };

    const errors = [];
    const formData = this.getFormData(form);

    for (const [field, validator] of Object.entries(validators)) {
      const value = formData[field];

      if (typeof validator === 'function') {
        const result = validator(value, formData);
        if (result !== true) {
          errors.push(result || `Field ${field} is invalid`);
        }
      }
    }

    return { valid: errors.length === 0, errors };
  }

  // Element creation utilities
  createElement(tag, options = {}) {
    const element = document.createElement(tag);

    if (options.id) element.id = options.id;
    if (options.className) element.className = options.className;
    if (options.text) element.textContent = options.text;
    if (options.html) element.innerHTML = options.html;

    if (options.attributes) {
      for (const [name, value] of Object.entries(options.attributes)) {
        element.setAttribute(name, value);
      }
    }

    if (options.styles) {
      this.setStyle(element, options.styles);
    }

    if (options.parent) {
      options.parent.appendChild(element);
    }

    return element;
  }

  // Element observation utilities
  observeElement(element, callback, options = {}) {
    if (!element) return null;

    const observerId = this.generateObserverId();

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => callback(entry, element));
    }, options);

    observer.observe(element);
    this.observedElements.set(observerId, { observer, element, callback });

    return observerId;
  }

  unobserveElement(observerId) {
    const observed = this.observedElements.get(observerId);
    if (observed) {
      observed.observer.disconnect();
      this.observedElements.delete(observerId);
      return true;
    }
    return false;
  }

  // Wait for element to exist
  waitForElement(selector, timeout = 5000) {
    return new Promise((resolve, reject) => {
      const element = this.querySelector(selector);
      if (element) {
        resolve(element);
        return;
      }

      const startTime = Date.now();
      const checkInterval = setInterval(() => {
        const element = this.querySelector(selector);
        if (element) {
          clearInterval(checkInterval);
          resolve(element);
        } else if (Date.now() - startTime > timeout) {
          clearInterval(checkInterval);
          reject(new Error(`Element ${selector} not found within ${timeout}ms`));
        }
      }, 100);
    });
  }

  // Mutation observer setup
  initMutationObserver() {
    this.mutationObserver = new MutationObserver((mutations) => {
      mutations.forEach(mutation => {
        // Clear cache for removed elements
        if (mutation.type === 'childList') {
          mutation.removedNodes.forEach(node => {
            if (node.nodeType === Node.ELEMENT_NODE) {
              this.clearCacheForElement(node);
            }
          });
        }
      });
    });

    // Start observing
    this.mutationObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  clearCacheForElement(element) {
    if (element.id) {
      this.elementCache.delete(element.id);
    }
  }

  // Cache management
  clearCache() {
    this.elementCache.clear();
  }

  getCacheSize() {
    return this.elementCache.size;
  }

  // Utility methods
  generateObserverId() {
    return `observer_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Cleanup
  destroy() {
    if (this.mutationObserver) {
      this.mutationObserver.disconnect();
    }

    // Cleanup all observers
    for (const [id, observed] of this.observedElements) {
      observed.observer.disconnect();
    }

    this.observedElements.clear();
    this.elementCache.clear();
  }

  // Debug utilities
  logCacheStats() {
    console.log('🔍 DOMManager Cache Statistics:');
    console.log(`- Cached elements: ${this.elementCache.size}`);
    console.log(`- Active observers: ${this.observedElements.size}`);
  }
}

// Create global instance
window.DOMManager = DOMManager;