/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-25
 * Order Controller - Handles order detail pages
 */
class OrderController extends BaseController {
  constructor(services) {
    super(services, 'order');
    this.orderItems = [];
    this.orderObserver = null;
    this.lastOrderHash = null;
  }

  async initialize() {
    console.log('🔄 Initializing order controller');
    
    // Check if we're on an order detail page
    if (!this.isOrderDetailPage()) {
      console.log('❌ Not an order detail page, skipping initialization');
      return;
    }

    console.log('✅ Order detail page detected');
    
    // Set up periodic order checking
    this.setupOrderMonitoring();
  }

  isOrderDetailPage() {
    const url = window.location.href;
    const path = window.location.pathname;
    
    console.log(`🔍 Checking order page - URL: ${url}, Path: ${path}`);
    
    // Check for order detail page patterns
    const orderPagePatterns = [
      /\/profile\/orders\/\d+/,
      /\/order-detail/,
      /\/orders\/detail/,
      /\/profile\/order\//
    ];

    const isOrderPage = orderPagePatterns.some(pattern => {
      const matches = pattern.test(url) || pattern.test(path);
      if (matches) {
        console.log(`✅ URL pattern matched: ${pattern}`);
      }
      return matches;
    });
    
    // Also check for DOM elements that indicate order detail page
    const hasOrderElements = document.querySelector('[data-testid="cart-item"]') && 
                            (document.querySelector('.Parcel_Parcel__') || 
                             document.querySelector('[class*="Parcel"]') ||
                             document.querySelector('[class*="OrderDetail"]') ||
                             document.querySelector('[class*="shipping"]') ||
                             path.includes('/profile/orders/'));

    console.log(`🔍 Order page detection - URL match: ${isOrderPage}, DOM match: ${hasOrderElements}`);
    
    return isOrderPage || hasOrderElements;
  }

  setupOrderMonitoring() {
    // Find order container to observe
    const orderContainer = this.findOrderContainer();
    
    if (!orderContainer) {
      console.log('⚠️ Order container not found, falling back to document observation');
      // Fall back to observing document body if specific order container not found
      this.observeOrderChanges(document.body);
      return;
    }
    
    console.log('🔍 Setting up order mutation observer on container:', orderContainer);
    this.observeOrderChanges(orderContainer);
  }

  findOrderContainer() {
    // Try to find the most specific order container first, using similar selectors to waitForOrderItems
    const selectors = [
      '[data-testid="cart"]', // Main container for order items
      '.cart-container',
      '[class*="order-items"]',
      '[class*="OrderDetail"]',
      '[class*="Parcel"]',
      '.Parcel_Parcel__',
      // Fallback to broader containers that might contain order items
      'main[role="main"]',
      'main',
      '[role="main"]'
    ];

    for (const selector of selectors) {
      const container = document.querySelector(selector);
      if (container) {
        // Verify this container actually contains or can contain order items
        const hasOrderItems = container.querySelector('[data-testid="cart-item"]') ||
                            container.querySelector('.cart-item') ||
                            container.querySelector('a[href*="/product/"]') ||
                            container.querySelector('[data-product-id]');
        
        if (hasOrderItems || selector.includes('order') || selector.includes('cart') || 
            selector.includes('main') || selector.includes('Parcel')) {
          return container;
        }
      }
    }
    
    return null;
  }

  observeOrderChanges(container) {
    // Disconnect existing observer if any
    if (this.orderObserver) {
      this.orderObserver.disconnect();
    }

    // Create new mutation observer
    this.orderObserver = new MutationObserver((mutations) => {
      // Only process if controller is active
      if (!this.isActive) {
        return;
      }

      // Check if any mutations are relevant to order items
      let hasRelevantChanges = false;
      
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          // Check if added or removed nodes include order items
          const allNodes = [...mutation.addedNodes, ...mutation.removedNodes];
          for (const node of allNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              if (this.isOrderItemOrContainer(node)) {
                hasRelevantChanges = true;
                break;
              }
            }
          }
        }
        
        if (hasRelevantChanges) break;
      }

      // Debounce the order changes check to avoid excessive processing
      if (hasRelevantChanges) {
        this.debouncedOrderCheck();
      }
    });

    // Start observing with childList and subtree options
    this.orderObserver.observe(container, {
      childList: true,
      subtree: true
    });

    console.log('✅ Order mutation observer started');
  }

  isOrderItemOrContainer(element) {
    // Check if element is an order item or contains order items
    const orderItemSelectors = [
      '[data-testid="cart-item"]',
      '.cart-item',
      '[data-product-id]',
      'a[href*="/product/"]',
      '[class*="cart-item"]',
      '[class*="order-item"]',
      '[class*="product-item"]'
    ];

    return orderItemSelectors.some(selector => 
      element.matches && element.matches(selector) || 
      (element.querySelector && element.querySelector(selector))
    );
  }

  debouncedOrderCheck() {
    // Clear existing timeout
    if (this.orderCheckTimeout) {
      clearTimeout(this.orderCheckTimeout);
    }

    // Debounce order changes check to avoid excessive calls
    this.orderCheckTimeout = setTimeout(() => {
      this.checkForOrderChanges();
    }, 800); // Slightly longer debounce for order pages (less frequent changes expected)
  }

  setupEventListeners() {
    // Listen for order item changes
    this.orderChangeHandler = this.debounce(() => {
      if (this.isActive) {
        this.processOrderItems();
      }
    }, 1500);

    // Listen for DOM changes
    document.addEventListener('click', this.orderChangeHandler);
    document.addEventListener('change', this.orderChangeHandler);
  }

  removeEventListeners() {
    if (this.orderChangeHandler) {
      document.removeEventListener('click', this.orderChangeHandler);
      document.removeEventListener('change', this.orderChangeHandler);
      this.orderChangeHandler = null;
    }

    // Disconnect mutation observer
    if (this.orderObserver) {
      this.orderObserver.disconnect();
      this.orderObserver = null;
      console.log('🔌 Order mutation observer disconnected');
    }

    // Clear any pending timeouts
    if (this.orderCheckTimeout) {
      clearTimeout(this.orderCheckTimeout);
      this.orderCheckTimeout = null;
    }
  }

  cleanup() {
    this.orderItems = [];
    this.lastOrderHash = null;
    
    // Ensure observer is disconnected during cleanup
    if (this.orderObserver) {
      this.orderObserver.disconnect();
      this.orderObserver = null;
    }

    // Clear any pending timeouts
    if (this.orderCheckTimeout) {
      clearTimeout(this.orderCheckTimeout);
      this.orderCheckTimeout = null;
    }
  }

  async processInitialElements() {
    if (!this.isFeatureEnabled('showOrderPrices')) {
      console.log('ℹ️ Order price features disabled, skipping processing');
      return;
    }

    console.log('📦 Processing initial order items');
    await this.processOrderItems();
  }

  async processOrderItems() {
    try {
      console.log('🔄 Processing order items');

      // Wait for order items to load
      const orderItems = await this.waitForOrderItems();
      
      if (orderItems.length === 0) {
        console.log('ℹ️ No order items found');
        return;
      }

      console.log(`📦 Found ${orderItems.length} order items`);
      this.orderItems = orderItems;

      // Process each order item
      const promises = orderItems.map(item => this.processOrderItem(item));
      await Promise.allSettled(promises);

      this.services.eventBus.emit('order:processed', { 
        itemCount: orderItems.length 
      });

      console.log(`✅ Successfully processed ${orderItems.length} order items`);

    } catch (error) {
      console.error('❌ Error processing order items:', error);
      this.showNotification({
        type: 'warning',
        title: 'خطا در بارگذاری اطلاعات سفارش',
        message: 'امکان نمایش قیمت فعلی برای برخی محصولات وجود ندارد',
        autoHide: true,
        duration: 5000
      });
    }
  }

  async waitForOrderItems() {
    // Try to find order items using various selectors
    const selectors = [
      '[data-testid="cart-item"]', // Main cart item selector from the HTML
      '.cart-item',
      '[data-product-id]',
      'a[href*="/product/dkp-"]', // Product links
      'a[href*="/product/"]'
    ];

    // Wait for elements to appear
    for (const selector of selectors) {
      const items = await this.waitForElements(selector, 15, 1000);
      if (items.length > 0) {
        console.log(`✅ Found ${items.length} potential order items with selector: ${selector}`);
        
        // Filter for valid order items
        const validItems = items.filter(item => this.isValidOrderItem(item));
        console.log(`✅ Filtered to ${validItems.length} valid order items`);
        
        if (validItems.length > 0) {
          return validItems;
        }
      }
    }

    return [];
  }

  isValidOrderItem(item) {
    // Check if the item is actually an order item (has product info)
    const hasProductLink = item.querySelector('a[href*="/product/"]') || 
                          item.matches('a[href*="/product/"]');
    
    const hasProductTitle = item.querySelector('h3') || 
                           item.querySelector('[class*="title"]') ||
                           item.querySelector('[class*="name"]');
    
    const hasPrice = item.querySelector('[class*="text-h4"]') ||
                    item.querySelector('[class*="price"]') ||
                    item.textContent.includes('تومان');

    const isVisible = this.isElementVisible(item);
    
    const isValid = (hasProductLink || hasProductTitle) && hasPrice && isVisible;
    
    if (!isValid) {
      console.debug('❌ Invalid order item:', {
        hasProductLink,
        hasProductTitle, 
        hasPrice,
        isVisible,
        element: item
      });
    }
    
    return isValid;
  }

  async processOrderItem(orderItem) {
    try {
      // Extract product ID
      const productId = this.extractOrderItemProductId(orderItem);
      if (!productId) {
        console.log('⚠️ Could not extract product ID from order item');
        return;
      }

      if (this.processedElements.has(orderItem)) {
        console.log(`⏭️ Order item for product ${productId} already processed`);
        return;
      }

      console.log(`🔄 Processing order item for product ${productId}`);

      // Fetch order item data
      const dataResult = await this.fetchOrderItemData(productId);
      if (!dataResult) {
        console.log(`⚠️ No data found for product ${productId}`);
        return;
      }

      // Extract order item details
      const orderItemDetails = await this.extractOrderItemDetails(dataResult, productId, orderItem);

      // Update order item UI
      this.updateOrderItemUI(orderItem, orderItemDetails);

      this.processedElements.add(orderItem);
      console.log(`✅ Successfully processed order item for product ${productId}`);

    } catch (error) {
      console.error('❌ Error processing order item:', error);
    }
  }

  extractOrderItemProductId(orderItem) {
    // Try DOM manager first
    if (this.services.domManager && this.services.domManager.extractProductIdFromOrderItem) {
      return this.services.domManager.extractProductIdFromOrderItem(orderItem);
    }

    // Fallback extraction (similar to cart but for order items)
    console.log('🔍 Using fallback product ID extraction for order item');

    // 1. Check if the item itself is a product link
    if (orderItem.matches('a[href*="/product/"]')) {
      const href = orderItem.getAttribute('href');
      const productId = this.extractProductIdFromUrl(href);
      if (productId) {
        console.log('✅ Found product ID from order item href:', productId);
        return productId;
      }
    }

    // 2. Look for product links within the item
    const productLinks = orderItem.querySelectorAll('a[href*="/product/"]');
    for (const link of productLinks) {
      const href = link.getAttribute('href');
      const productId = this.extractProductIdFromUrl(href);
      if (productId) {
        console.log('✅ Found product ID from order item link:', productId);
        return productId;
      }
    }

    // 3. Check data attributes
    if (orderItem.dataset.productId) {
      return orderItem.dataset.productId;
    }

    // 4. Look in parent containers
    let parent = orderItem.parentElement;
    while (parent && parent !== document.body) {
      const parentLink = parent.querySelector('a[href*="/product/"]');
      if (parentLink) {
        const productId = this.extractProductIdFromUrl(parentLink.getAttribute('href'));
        if (productId) {
          console.log('✅ Found product ID from parent element:', productId);
          return productId;
        }
      }
      parent = parent.parentElement;
    }

    console.log('❌ Fallback product ID extraction failed for order item');
    return null;
  }

  extractProductIdFromUrl(href) {
    if (!href) return null;
    
    const patterns = [
      /\/product\/dkp-(\d+)\//,
      /\/product\/(\d+)\//,
      /dkp-(\d+)/,
      /\/dp\/(\d+)\//,
      /product-id[=:](\d+)/,
      /\/(\d{6,})\//,
      /[?&]id=(\d+)/
    ];
    
    for (const pattern of patterns) {
      const match = href.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }
    
    return null;
  }

  /**
   * Fetch order item data using the product ID
   * @param {string} productId - The product ID to fetch data for
   * @returns {Promise<Object|null>} - The fetched product data or null if failed
   */
  async fetchOrderItemData(productId) {
    console.log(`📡 Fetching current price data for order item: ${productId}`);
    const dataResult = await this.services.dataManager.fetchProductDataForProductPage(productId);
    console.log(`📊 Data result for product ${productId}:`, dataResult);
    return dataResult;
  }

  /**
   * Extract order item details from data result and order DOM
   * @param {Object} dataResult - The fetched product data
   * @param {string} productId - The product ID
   * @param {HTMLElement} orderItem - The order item DOM element
   * @returns {Promise<Object>} - The order-specific price comparison data
   */
  async extractOrderItemDetails(dataResult, productId, orderItem) {
    console.log(`💰 Extracting order-specific price data for product ${productId}`);
    
    // Get current lowest price from API
    const currentLowestPrice = await this.services.dataManager.extractCurrentLowestPrice(dataResult, productId);
    console.log(`💰 Current lowest price for product ${productId}:`, currentLowestPrice);
    
    // Extract original order price from DOM
    const orderPrice = this.extractOrderPriceFromDOM(orderItem);
    console.log(`📦 Original order price for product ${productId}:`, orderPrice);
    
    return {
      currentLowestPrice,
      orderPrice,
      productId
    };
  }

  /**
   * Extract order price from order item DOM
   * @param {HTMLElement} orderItem - The order item DOM element
   * @returns {Object|null} - Object with price information or null if not found
   */
  extractOrderPriceFromDOM(orderItem) {
    try {
      console.log('🔍 Extracting order price from DOM');
      
      // Common price selectors for order pages
      const priceSelectors = [
        '[class*="text-h4"]', // Main price text
        '[class*="price"]',
        '.price',
        '[data-testid="price"]'
      ];
      
      for (const selector of priceSelectors) {
        const priceElements = orderItem.querySelectorAll(selector);
        
        for (const element of priceElements) {
          const text = element.textContent || '';
          
          // Look for price patterns (Persian/Farsi numbers with تومان)
          const priceMatch = text.match(/[\d,۰-۹]+.*?تومان|[\d,۰-۹]+\s*تومان/);
          if (priceMatch) {
            const priceText = priceMatch[0].replace(/تومان/g, '').trim();
            
            // Convert Persian/Arabic numerals to English
            const englishPrice = this.convertPersianToEnglish(priceText);
            const numericPrice = parseFloat(englishPrice.replace(/,/g, ''));
            
            if (!isNaN(numericPrice) && numericPrice > 0) {
              console.log(`✅ Found order price: ${numericPrice} from text: "${text}"`);
              return {
                price: numericPrice * 10, // Convert to rials (API format)
                displayText: priceText,
                source: 'dom'
              };
            }
          }
        }
      }
      
      console.log('⚠️ Could not extract order price from DOM');
      return null;
    } catch (error) {
      console.error('❌ Error extracting order price from DOM:', error);
      return null;
    }
  }

  /**
   * Convert Persian/Arabic numerals to English numerals
   * @param {string} text - Text containing Persian/Arabic numerals
   * @returns {string} - Text with English numerals
   */
  convertPersianToEnglish(text) {
    const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    
    let result = text;
    
    for (let i = 0; i < persianNumbers.length; i++) {
      result = result.replace(new RegExp(persianNumbers[i], 'g'), englishNumbers[i]);
      result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
    }
    
    return result;
  }

  /**
   * Update order item UI with enhanced price information
   * @param {HTMLElement} orderItem - The order item DOM element
   * @param {Object} priceData - Object containing currentLowestPrice and productId
   */
  updateOrderItemUI(orderItem, priceData) {
    // Use DOM manager if available
    if (this.services.domManager && typeof this.services.domManager.addOrderPriceInfo === 'function') {
      this.services.domManager.addOrderPriceInfo(orderItem, priceData);
    } else {
      // Fallback: Add simple price info directly
      this.addSimpleOrderPriceInfo(orderItem, priceData);
    }
  }

  addOrderPriceInfo(orderItem, priceData) {
    // Use DOM manager if available
    if (this.services.domManager && typeof this.services.domManager.addOrderPriceInfo === 'function') {
      this.services.domManager.addOrderPriceInfo(orderItem, priceData);
    } else {
      // Fallback: Add simple price info directly
      this.addSimpleOrderPriceInfo(orderItem, priceData);
    }
  }

  addSimpleOrderPriceInfo(orderItem, priceData) {
    try {
      const { currentLowestPrice, orderPrice, productId } = priceData;
      
      // Remove existing price info
      this.removeExistingPriceInfo(orderItem);

      if (!this.validatePriceData(currentLowestPrice)) {
        return;
      }

      // Create and style price info element
      const priceInfoElement = this.createOrderPriceElement(currentLowestPrice, orderPrice);

      // Insert price info into DOM
      this.insertPriceInfo(orderItem, priceInfoElement);

      // Add entrance animation
      this.animatePriceInfo(priceInfoElement);

      console.log(`✅ Added order price comparison info to order item for product ${productId}`);

    } catch (error) {
      console.error('❌ Error adding simple order price info:', error);
    }
  }

  /**
   * Remove existing price info from order item
   * @param {HTMLElement} orderItem - The order item element
   */
  removeExistingPriceInfo(orderItem) {
    const existingPriceInfo = orderItem.querySelector('.order-current-price-info');
    if (existingPriceInfo) {
      existingPriceInfo.remove();
    }
  }

  /**
   * Validate price data before processing
   * @param {Object} currentLowestPrice - The price data to validate
   * @returns {boolean} - Whether the price data is valid
   */
  validatePriceData(currentLowestPrice) {
    if (!currentLowestPrice || !currentLowestPrice.price) {
      console.log('⚠️ No current lowest price data available');
      return false;
    }
    return true;
  }

  /**
   * Create and style the order price info element
   * @param {Object} currentLowestPrice - The current price data from API
   * @param {Object|null} orderPrice - The original order price data from DOM
   * @returns {HTMLElement} - The created price info element
   */
  createOrderPriceElement(currentLowestPrice, orderPrice = null) {
    const priceInfoElement = document.createElement('div');
    priceInfoElement.className = 'order-current-price-info';
    
    // Calculate price difference and styling
    let backgroundColor, borderColor, textColor, icon, title, subtitle;
    const currentPriceFormatted = Math.round(currentLowestPrice.price / 10).toLocaleString('fa-IR');
    
    if (orderPrice && orderPrice.price) {
      const orderPriceFormatted = Math.round(orderPrice.price / 10).toLocaleString('fa-IR');
      const difference = currentLowestPrice.price - orderPrice.price;
      const differenceFormatted = Math.round(Math.abs(difference) / 10).toLocaleString('fa-IR');
      
      if (difference < 0) {
        // Current price is lower - good news for customer
        backgroundColor = 'linear-gradient(135deg, #10b981, #059669)';
        borderColor = '#10b981';
        textColor = 'white';
        icon = '📈';
        title = `قیمت کمتر شده: ${differenceFormatted} تومان`;
        subtitle = `خرید شما: ${orderPriceFormatted} | فعلی: ${currentPriceFormatted}`;
      } else if (difference > 0) {
        // Current price is higher - neutral info
        backgroundColor = 'linear-gradient(135deg, #f59e0b, #d97706)';
        borderColor = '#f59e0b';
        textColor = 'white';
        icon = '📊';
        title = `قیمت بالاتر شده: ${differenceFormatted} تومان`;
        subtitle = `خرید شما: ${orderPriceFormatted} | فعلی: ${currentPriceFormatted}`;
      } else {
        // Same price
        backgroundColor = 'linear-gradient(135deg, #6366f1, #4f46e5)';
        borderColor = '#6366f1';
        textColor = 'white';
        icon = '✅';
        title = 'قیمت تغییر نکرده';
        subtitle = `قیمت: ${currentPriceFormatted} تومان`;
      }
    } else {
      // Fallback when order price couldn't be extracted
      backgroundColor = 'linear-gradient(135deg, #6366f1, #4f46e5)';
      borderColor = '#6366f1';
      textColor = 'white';
      icon = '💰';
      title = 'قیمت فعلی کمترین';
      subtitle = `${currentPriceFormatted} تومان`;
    }
    
    priceInfoElement.style.cssText = `
      background: ${backgroundColor};
      border-radius: 6px;
      padding: 8px 10px;
      margin-top: 8px;
      color: ${textColor};
      font-size: 10px;
      box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
      border: 1px solid ${borderColor};
    `;
    
    priceInfoElement.innerHTML = `
      <div style="display: flex; align-items: center; gap: 6px;">
        <span style="font-size: 11px;">${icon}</span>
        <div style="flex: 1;">
          <div style="font-weight: 600; font-size: 10px; margin-bottom: 2px;">${title}</div>
          <div style="font-weight: 500; font-size: 9px; opacity: 0.95;">${subtitle}</div>
        </div>
      </div>
    `;

    return priceInfoElement;
  }

  /**
   * Insert price info element into the order item DOM
   * @param {HTMLElement} orderItem - The order item element
   * @param {HTMLElement} priceInfoElement - The price info element to insert
   */
  insertPriceInfo(orderItem, priceInfoElement) {
    // Find the best place to insert the price info
    const priceContainer = orderItem.querySelector('.h-[40px]') || 
                          orderItem.querySelector('[class*="price"]') ||
                          orderItem.querySelector('.overflow-x-hidden') ||
                          orderItem.querySelector('[class*="CartItem"]');
    
    if (priceContainer) {
      priceContainer.appendChild(priceInfoElement);
    } else {
      orderItem.appendChild(priceInfoElement);
    }
  }

  /**
   * Add entrance animation to price info element
   * @param {HTMLElement} priceInfoElement - The price info element to animate
   */
  animatePriceInfo(priceInfoElement) {
    if (priceInfoElement.animate) {
      priceInfoElement.animate([
        { opacity: 0, transform: 'translateY(5px)' },
        { opacity: 1, transform: 'translateY(0)' }
      ], {
        duration: 200,
        easing: 'ease-out'
      });
    }
  }

  checkForOrderChanges() {
    const currentOrderItems = this.getCurrentOrderItems();
    const currentHash = this.generateOrderHash(currentOrderItems);

    if (currentHash !== this.lastOrderHash) {
      console.log('🔄 Order changes detected');
      this.lastOrderHash = currentHash;
      this.processOrderItems();
    }
  }

  getCurrentOrderItems() {
    const selectors = [
      '[data-testid="cart-item"]',
      '.cart-item'
    ];

    for (const selector of selectors) {
      const items = Array.from(document.querySelectorAll(selector));
      if (items.length > 0) {
        return items.filter(item => this.isValidOrderItem(item));
      }
    }

    return [];
  }

  generateOrderHash(items) {
    return items.map(item => {
      const productId = this.extractOrderItemProductId(item);
      const title = item.querySelector('h3')?.textContent || '';
      return `${productId}-${title.slice(0, 20)}`;
    }).join('|');
  }

  async processNewElements() {
    // Check for new order items
    const currentItems = this.getCurrentOrderItems();
    const newItems = currentItems.filter(item => 
      !this.processedElements.has(item)
    );

    if (newItems.length > 0) {
      console.log(`📦 Found ${newItems.length} new order items`);
      const promises = newItems.map(item => this.processOrderItem(item));
      await Promise.allSettled(promises);
    }
  }

  isElementRelevant(element) {
    const selectors = [
      '[data-testid="cart-item"]',
      '.cart-item',
      '[data-product-id]',
      'a[href*="/product/"]'
    ];

    return selectors.some(selector => 
      element.matches(selector) || element.querySelector(selector)
    );
  }

  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  isElementVisible(element) {
    // Use DOM manager if available
    if (this.services.domManager && this.services.domManager.isElementVisible) {
      return this.services.domManager.isElementVisible(element);
    }
    
    // Fallback implementation
    if (!element) return false;

    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    
    return rect.width > 0 && 
           rect.height > 0 && 
           style.display !== 'none' && 
           style.visibility !== 'hidden';
  }

  async clearOrderPriceInfo() {
    console.log('🧹 Clearing order price information');
    
    const priceInfoElements = document.querySelectorAll('.order-current-price-info');
    priceInfoElements.forEach(element => element.remove());
    
    console.log('🧹 Order price information cleared');
  }
}

window.OrderController = OrderController;