/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-18
 * Product Cache Service - Manages cached product data with TTL for Smart Cart
 */
class ProductCacheService {
  constructor(storageService, eventBus) {
    this.storageService = storageService;
    this.eventBus = eventBus;
    this.cache = new Map();
    this.storageKey = 'smart_cart_product_cache';

    // Cache configuration
    this.defaultTTL = 2 * 60 * 1000; // 2 minutes
    this.maxCacheSize = 50; // Max 50 products in cache
    this.cleanupInterval = 5 * 60 * 1000; // Cleanup every 5 minutes

    // Track access times for LRU eviction
    this.accessTimes = new Map();

    // Start cleanup timer
    this.startCleanupTimer();
  }

  async initialize() {
    try {
      await this.loadCacheFromStorage();
      console.log('✅ Product Cache Service initialized');
    } catch (error) {
      console.error('❌ Failed to initialize Product Cache Service:', error);
    }
  }

  async loadCacheFromStorage() {
    try {
      const cacheData = await this.storageService.get(this.storageKey, {});

      // Convert storage data back to Map and validate TTL
      const now = Date.now();
      for (const [key, entry] of Object.entries(cacheData)) {
        if (entry.expiresAt > now) {
          this.cache.set(key, entry);
          this.accessTimes.set(key, entry.lastAccessed || entry.cachedAt);
        }
      }

      console.log(`📦 Loaded ${this.cache.size} valid cache entries`);
    } catch (error) {
      console.error('❌ Failed to load cache from storage:', error);
      this.cache.clear();
    }
  }

  async saveCacheToStorage() {
    try {
      // Convert Map to plain object for storage
      const cacheObject = {};
      for (const [key, entry] of this.cache.entries()) {
        cacheObject[key] = entry;
      }

      await this.storageService.set({ [this.storageKey]: cacheObject });
    } catch (error) {
      console.error('❌ Failed to save cache to storage:', error);
    }
  }

  generateCacheKey(productId, includeVariant = false, variantId = null) {
    return includeVariant && variantId
      ? `product_${productId}_variant_${variantId}`
      : `product_${productId}`;
  }

  async get(productId, variantId = null, includeVariant = false) {
    const key = this.generateCacheKey(productId, includeVariant, variantId);
    const entry = this.cache.get(key);

    if (!entry) {
      return null;
    }

    const now = Date.now();

    // Check if entry has expired
    if (entry.expiresAt <= now) {
      this.cache.delete(key);
      this.accessTimes.delete(key);
      this.saveCacheToStorage(); // Async save
      return null;
    }

    // Update access time
    this.accessTimes.set(key, now);
    entry.lastAccessed = now;

    console.log(`📋 Cache hit for product ${productId}${variantId ? ` variant ${variantId}` : ''}`);

    return {
      ...entry.data,
      _cacheInfo: {
        cachedAt: entry.cachedAt,
        expiresAt: entry.expiresAt,
        age: now - entry.cachedAt
      }
    };
  }

  async set(productId, data, options = {}) {
    const {
      variantId = null,
      includeVariant = false,
      ttl = this.defaultTTL,
      priority = 'normal'
    } = options;

    const key = this.generateCacheKey(productId, includeVariant, variantId);
    const now = Date.now();

    // Check cache size and evict if necessary
    await this.ensureCacheSpace();

    const entry = {
      data: data,
      cachedAt: now,
      expiresAt: now + ttl,
      lastAccessed: now,
      productId: productId,
      variantId: variantId,
      priority: priority
    };

    this.cache.set(key, entry);
    this.accessTimes.set(key, now);

    console.log(`💾 Cached product ${productId}${variantId ? ` variant ${variantId}` : ''} for ${ttl}ms`);

    // Save to storage asynchronously
    this.saveCacheToStorage();

    // Emit cache update event
    this.eventBus?.emit('product-cache:updated', {
      productId,
      variantId,
      cacheSize: this.cache.size
    });
  }

  async ensureCacheSpace() {
    if (this.cache.size < this.maxCacheSize) {
      return;
    }

    // Evict least recently used entries
    const entries = Array.from(this.accessTimes.entries())
      .sort((a, b) => a[1] - b[1]); // Sort by access time

    const toEvict = Math.ceil(this.maxCacheSize * 0.2); // Evict 20% of cache

    for (let i = 0; i < toEvict && i < entries.length; i++) {
      const keyToEvict = entries[i][0];
      this.cache.delete(keyToEvict);
      this.accessTimes.delete(keyToEvict);
      console.log(`🗑️ Evicted cache entry: ${keyToEvict}`);
    }
  }

  has(productId, variantId = null, includeVariant = false) {
    const key = this.generateCacheKey(productId, includeVariant, variantId);
    const entry = this.cache.get(key);

    if (!entry) return false;

    // Check if expired
    if (entry.expiresAt <= Date.now()) {
      this.cache.delete(key);
      this.accessTimes.delete(key);
      return false;
    }

    return true;
  }

  delete(productId, variantId = null, includeVariant = false) {
    const key = this.generateCacheKey(productId, includeVariant, variantId);
    const deleted = this.cache.delete(key);
    this.accessTimes.delete(key);

    if (deleted) {
      console.log(`🗑️ Deleted cache entry for product ${productId}`);
      this.saveCacheToStorage();
    }

    return deleted;
  }

  clear() {
    const size = this.cache.size;
    this.cache.clear();
    this.accessTimes.clear();
    this.saveCacheToStorage();

    console.log(`🧹 Cleared ${size} cache entries`);

    this.eventBus?.emit('product-cache:cleared', { clearedCount: size });
  }

  getCacheStats() {
    const now = Date.now();
    const entries = Array.from(this.cache.values());

    const stats = {
      totalEntries: this.cache.size,
      maxSize: this.maxCacheSize,
      utilizationPercent: Math.round((this.cache.size / this.maxCacheSize) * 100),
      oldestEntry: null,
      newestEntry: null,
      expiredEntries: 0,
      averageAge: 0
    };

    if (entries.length > 0) {
      const ages = entries.map(e => now - e.cachedAt);
      const expiredCount = entries.filter(e => e.expiresAt <= now).length;

      stats.oldestEntry = Math.max(...ages);
      stats.newestEntry = Math.min(...ages);
      stats.expiredEntries = expiredCount;
      stats.averageAge = ages.reduce((sum, age) => sum + age, 0) / ages.length;
    }

    return stats;
  }

  startCleanupTimer() {
    setInterval(() => {
      this.cleanup();
    }, this.cleanupInterval);
  }

  cleanup() {
    const now = Date.now();
    let cleanedCount = 0;

    for (const [key, entry] of this.cache.entries()) {
      if (entry.expiresAt <= now) {
        this.cache.delete(key);
        this.accessTimes.delete(key);
        cleanedCount++;
      }
    }

    if (cleanedCount > 0) {
      console.log(`🧹 Cleaned up ${cleanedCount} expired cache entries`);
      this.saveCacheToStorage();

      this.eventBus?.emit('product-cache:cleaned', {
        cleanedCount,
        remainingCount: this.cache.size
      });
    }
  }

  // Batch operations
  async setMultiple(products, options = {}) {
    const promises = products.map(({ productId, data, variantId, productOptions }) =>
      this.set(productId, data, { ...options, ...productOptions, variantId })
    );

    await Promise.all(promises);
    console.log(`📦 Cached ${products.length} products in batch`);
  }

  async getMultiple(productRequests) {
    const results = {};

    for (const { productId, variantId, includeVariant } of productRequests) {
      const data = await this.get(productId, variantId, includeVariant);
      if (data) {
        results[productId + (variantId ? `_${variantId}` : '')] = data;
      }
    }

    return results;
  }

  // Preload products that are likely to be accessed soon
  async preloadProducts(productIds, options = {}) {
    const { apiService } = options;

    if (!apiService) {
      console.warn('⚠️ Cannot preload without API service');
      return;
    }

    const uncachedProducts = productIds.filter(id => !this.has(id));

    if (uncachedProducts.length === 0) {
      console.log('✅ All requested products already cached');
      return;
    }

    console.log(`🔄 Preloading ${uncachedProducts.length} products...`);

    // Load products in small batches to avoid overwhelming the API
    const batchSize = 3;
    for (let i = 0; i < uncachedProducts.length; i += batchSize) {
      const batch = uncachedProducts.slice(i, i + batchSize);

      const promises = batch.map(async (productId) => {
        try {
          const data = await apiService.fetchProductData(productId);
          if (data) {
            await this.set(productId, data, { ttl: this.defaultTTL });
          }
        } catch (error) {
          console.warn(`⚠️ Failed to preload product ${productId}:`, error);
        }
      });

      await Promise.all(promises);

      // Add delay between batches
      if (i + batchSize < uncachedProducts.length) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }

    console.log(`✅ Completed preloading products`);
  }

  destroy() {
    this.cache.clear();
    this.accessTimes.clear();
    console.log('🧹 Product Cache Service destroyed');
  }
}

window.ProductCacheService = ProductCacheService;