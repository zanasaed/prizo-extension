# Popup Modular Architecture

This directory contains the new modular architecture for the popup interface, designed to replace the monolithic 3,221-line `popup.js` file with maintainable, focused modules.

## Architecture Overview

```
src/ui/popup/modules/
├── core/                    # Core infrastructure
│   ├── base-module.js      # Base class for all modules
│   ├── event-bus.js        # Inter-module communication
│   ├── dom-manager.js      # DOM utilities and caching
│   └── popup-core.js       # Core initialization and management
├── ui/                     # UI-related modules
│   ├── tab-manager.js      # Tab navigation (planned)
│   ├── modal-manager.js    # Modal dialogs (planned)
│   └── notification-manager.js # Success/error messages
├── features/               # Feature-specific modules
│   ├── watchlist-manager.js    # Watchlist CRUD (planned)
│   ├── feature-toggles.js      # Sort/Cart/Comparison (planned)
│   └── settings-manager.js     # Settings & storage (planned)
├── communication/          # Extension communication
│   ├── extension-bridge.js     # Chrome API calls (planned)
│   └── message-handler.js      # System messages (planned)
└── utils/                  # Utility modules
    ├── page-detector.js        # Page type detection (planned)
    └── ui-helpers.js           # Common UI utilities (planned)
```

## Core Components

### BaseModule
All modules extend `BaseModule` which provides:
- Standardized initialization lifecycle
- Event system integration
- DOM management helpers
- Storage utilities
- Chrome extension API helpers
- Logging and debugging tools

### EventBus
Central communication hub that enables:
- Decoupled inter-module communication
- Event history tracking
- Priority-based event listeners
- Async event handling
- Debug mode for development

### DOMManager
Centralized DOM manipulation with:
- Element caching for performance
- Utility methods for common operations
- Form handling helpers
- Element observation capabilities
- Mutation tracking

### PopupCore
Core orchestrator that:
- Initializes the infrastructure
- Manages module lifecycle
- Handles global UI state
- Provides cleanup on page unload

## Usage Example

```javascript
// Create a new module
class MyModule extends BaseModule {
  constructor(eventBus, domManager) {
    super('MyModule', eventBus, domManager);
  }

  async initializeElements() {
    this.elements = this.domManager.getElements({
      button: '#myButton',
      container: '#myContainer'
    });
  }

  async setupEventListeners() {
    this.on('some:event', this.handleEvent);

    const button = this.getElement('myButton');
    this.domManager.addEventListener(button, 'click', this.handleClick);
  }

  handleEvent(data) {
    this.log('Received event:', data);
  }

  handleClick() {
    this.emit('button:clicked', { module: this.name });
  }
}

// Initialize the module
const myModule = new MyModule(window.popupEventBus, window.popupDOMManager);
await myModule.init();
```

## Integration with Existing Code

The new architecture is designed for **progressive migration**:

1. **Phase 1** ✅ - Core infrastructure implemented
2. **Phase 2** - Extract high-impact modules (Watchlist, Tabs, Settings)
3. **Phase 3** - Extract remaining modules (Features, Messages, Modals)
4. **Phase 4** - Final refactoring and cleanup

### Current Integration

- `popup-integration.js` initializes and coordinates all modules
- `PopupIntegration` class manages the entire modular system
- Legacy `PopupController` methods are bridged to use new modules
- No breaking changes to existing functionality
- Full backward compatibility maintained

### Phase 2 Complete ✅

**Successfully Extracted:**
- **WatchlistManager** (~800 lines) - Complete watchlist CRUD and UI
- **TabManager** (~300 lines) - Tab navigation and switching
- **SettingsManager** (~400 lines) - All extension settings and configuration
- **ExtensionBridge** (~500 lines) - Chrome extension API communication
- **PopupIntegration** - Coordination layer for all modules

**Reduced Original File:** From 3,221 lines to ~1,200 lines remaining

### Phase 3 Complete ✅

**Successfully Extracted:**
- **MessageHandler** (~200 lines) - System messages and notifications
- **ModalManager** (~200 lines) - Generic modal management system
- **ComparisonManager** (~300 lines) - Price comparison features and site management
- **UIHelpers** (~200 lines) - Common UI utilities and helper functions

**Final Result:** Original file reduced from **3,221 lines to ~300 lines remaining**

### Complete Modular Architecture ✅

```
src/ui/popup/modules/
├── core/                    # Phase 1 ✅
│   ├── base-module.js       # Foundation for all modules
│   ├── event-bus.js         # Inter-module communication
│   ├── dom-manager.js       # DOM utilities and caching
│   └── popup-core.js        # Core initialization and management
├── ui/                      # UI Components
│   ├── notification-manager.js # Success/error notifications ✅
│   ├── tab-manager.js          # Tab navigation ✅
│   └── modal-manager.js        # Generic modal system ✅
├── features/                # Business Logic
│   ├── watchlist-manager.js    # Watchlist CRUD operations ✅
│   ├── settings-manager.js     # Extension configuration ✅
│   └── comparison-manager.js   # Price comparison features ✅
├── communication/           # External Communication
│   ├── extension-bridge.js     # Chrome API integration ✅
│   └── message-handler.js      # System messaging ✅
├── utils/                   # Utilities
│   └── ui-helpers.js           # Common UI helpers ✅
└── popup-integration.js        # Module coordination ✅
```

## Benefits

### For Developers
- **Single Responsibility**: Each module has a focused purpose
- **Easy Testing**: Modules can be unit tested independently
- **Better Debugging**: Clear separation of concerns
- **Reusable Components**: Modules can be used elsewhere in the extension

### For Maintenance
- **Reduced Complexity**: 300-line focused files vs 3,221-line monolith
- **Faster Navigation**: Find specific functionality quickly
- **Safer Changes**: Modify one area without affecting others
- **Clear Dependencies**: Explicit module interactions via events

### For Performance
- **Element Caching**: DOM lookups are cached automatically
- **Event Optimization**: Efficient event system with priority handling
- **Lazy Loading**: Modules can be loaded on demand (future)
- **Memory Management**: Proper cleanup prevents memory leaks

## Development Guidelines

### Creating New Modules

1. Extend `BaseModule`
2. Implement required lifecycle methods:
   - `initializeElements()`
   - `setupEventListeners()`
   - `loadInitialData()` (optional)
   - `cleanup()` (optional)

3. Use the event system for communication:
   ```javascript
   this.on('event', handler);     // Listen
   this.emit('event', data);      // Emit
   ```

4. Use DOM manager for element operations:
   ```javascript
   this.getElement('elementId');
   this.domManager.show(element);
   ```

### Event Naming Convention

- `module:*` - Module lifecycle events
- `ui:*` - UI state changes
- `data:*` - Data operations
- `user:*` - User interactions
- `system:*` - System events

### Error Handling

- Use module logging methods: `this.log()`, `this.warn()`, `this.error()`
- Emit error events: `this.emit('ui:error', { message })`
- Handle async errors gracefully in lifecycle methods

## Migration Strategy

### Extracting Functionality from popup.js

1. **Identify** a cohesive set of functionality (e.g., watchlist management)
2. **Create** a new module extending BaseModule
3. **Move** the functionality to the module
4. **Update** popup.js to use the module via events
5. **Test** thoroughly to ensure no regressions
6. **Remove** the old code once confirmed working

### Testing Migration

- Use browser developer tools to monitor events
- Enable debug mode: `window.popupEventBus.setDebugMode(true)`
- Check module stats: `window.popupCore.logStats()`
- Verify all UI interactions still work

## Debugging

### Debug Mode
```javascript
// Enable debug logging
window.popupEventBus.setDebugMode(true);
window.popupDOMManager.setDebugMode(true);
```

### Inspection Tools
```javascript
// View all events
window.popupEventBus.getEventHistory();

// View registered modules
window.popupCore.getAllModules();

// View DOM cache stats
window.popupDOMManager.logCacheStats();
```

## Next Steps

1. **Phase 2**: Extract WatchlistManager (~800 lines)
2. **Phase 2**: Extract TabManager (~300 lines)
3. **Phase 2**: Extract SettingsManager (~400 lines)
4. **Phase 2**: Extract ExtensionBridge (~500 lines)

Each phase should be implemented incrementally with thorough testing to ensure stability and backward compatibility.