/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Notification Manager - Handles success/error messages and notifications
 */

class NotificationManager extends BaseModule {
  constructor(eventBus, domManager) {
    super('NotificationManager', eventBus, domManager);

    this.notifications = [];
    this.maxNotifications = 5;
    this.defaultDuration = 5000;
  }

  async initializeElements() {
    this.elements = this.domManager.getElements({
      status: '#status',
      error: '#error',
      loading: '#loading'
    });

    const validation = this.domManager.validateElements(this.elements, ['status']);
    if (!validation.valid) {
      this.warn('Some notification elements are missing:', validation.missing);
    }
  }

  async setupEventListeners() {
    // Listen for UI events
    this.on('ui:loading', (data) => this.handleLoading(data));
    this.on('ui:error', (data) => this.handleError(data));
    this.on('ui:success', (data) => this.handleSuccess(data));
    this.on('ui:hideError', (data) => this.hideError(data));

    // Listen for notification events
    this.on('notification:show', (data) => this.showNotification(data));
    this.on('notification:hide', (data) => this.hideNotification(data));
    this.on('notification:clear', () => this.clearAllNotifications());
  }

  handleLoading(data) {
    const { loading } = this.elements;
    if (!loading) return;

    if (data.show) {
      this.domManager.show(loading);
      this.domManager.setText(loading, data.message || 'در حال بارگذاری...');
    } else {
      this.domManager.hide(loading);
    }
  }

  handleError(data) {
    const { error, status } = this.elements;

    // Hide loading if showing error
    this.handleLoading({ show: false });

    // Show in error element if available
    if (error) {
      this.domManager.setText(error, data.message);
      this.domManager.show(error);
    }

    // Also show in status with error styling
    if (status) {
      this.domManager.setText(status, data.message);
      this.domManager.removeClass(status, 'success');
      this.domManager.addClass(status, 'error');
      this.domManager.show(status);
    }

    this.log('Error displayed:', data.message);
  }

  handleSuccess(data) {
    const { status, error } = this.elements;

    // Hide loading and error if showing success
    this.handleLoading({ show: false });
    this.hideError();

    if (status) {
      this.domManager.setText(status, data.message);
      this.domManager.removeClass(status, 'error');
      this.domManager.addClass(status, 'success');
      this.domManager.show(status);

      // Auto-hide success messages after delay
      if (data.autoHide !== false) {
        setTimeout(() => {
          this.domManager.hide(status);
        }, data.duration || this.defaultDuration);
      }
    }

    this.log('Success displayed:', data.message);
  }

  hideError() {
    const { error } = this.elements;
    if (error) {
      this.domManager.hide(error);
    }
  }

  // Advanced notification system
  showNotification(data) {
    const notification = {
      id: this.generateNotificationId(),
      type: data.type || 'info',
      title: data.title,
      message: data.message,
      duration: data.duration || this.defaultDuration,
      actions: data.actions || [],
      timestamp: Date.now()
    };

    this.notifications.push(notification);

    // Keep only latest notifications
    if (this.notifications.length > this.maxNotifications) {
      this.notifications = this.notifications.slice(-this.maxNotifications);
    }

    this.renderNotification(notification);

    // Auto-hide if duration is set
    if (notification.duration > 0) {
      setTimeout(() => {
        this.hideNotification({ id: notification.id });
      }, notification.duration);
    }

    this.emit('notification:created', { notification });
    return notification.id;
  }

  hideNotification(data) {
    const notificationElement = this.domManager.getElementById(`notification-${data.id}`);
    if (notificationElement) {
      notificationElement.remove();
    }

    this.notifications = this.notifications.filter(n => n.id !== data.id);
    this.emit('notification:hidden', { id: data.id });
  }

  clearAllNotifications() {
    this.notifications.forEach(notification => {
      this.hideNotification({ id: notification.id });
    });

    this.notifications = [];
    this.emit('notification:cleared');
  }

  renderNotification(notification) {
    // Create notification container if it doesn't exist
    let container = this.domManager.getElementById('notifications-container');
    if (!container) {
      container = this.domManager.createElement('div', {
        id: 'notifications-container',
        className: 'notifications-container',
        parent: document.body
      });
    }

    const notificationElement = this.domManager.createElement('div', {
      id: `notification-${notification.id}`,
      className: `notification notification-${notification.type}`,
      html: this.getNotificationHTML(notification)
    });

    container.appendChild(notificationElement);

    // Add event listeners for actions
    notification.actions.forEach((action, index) => {
      const button = notificationElement.querySelector(`[data-action="${index}"]`);
      if (button) {
        this.domManager.addEventListener(button, 'click', () => {
          if (typeof action.handler === 'function') {
            action.handler(notification);
          }
          if (action.closeOnClick !== false) {
            this.hideNotification({ id: notification.id });
          }
        });
      }
    });

    // Add close button handler
    const closeButton = notificationElement.querySelector('.notification-close');
    if (closeButton) {
      this.domManager.addEventListener(closeButton, 'click', () => {
        this.hideNotification({ id: notification.id });
      });
    }
  }

  getNotificationHTML(notification) {
    const actionsHTML = notification.actions.map((action, index) =>
      `<button class="notification-action" data-action="${index}">${action.text}</button>`
    ).join('');

    return `
      <div class="notification-header">
        ${notification.title ? `<div class="notification-title">${notification.title}</div>` : ''}
        <button class="notification-close" aria-label="بستن">×</button>
      </div>
      <div class="notification-body">
        <div class="notification-message">${notification.message}</div>
        ${actionsHTML ? `<div class="notification-actions">${actionsHTML}</div>` : ''}
      </div>
    `;
  }

  generateNotificationId() {
    return `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Public API methods
  success(message, options = {}) {
    return this.showNotification({
      type: 'success',
      message,
      ...options
    });
  }

  error(message, options = {}) {
    return this.showNotification({
      type: 'error',
      message,
      duration: 0, // Don't auto-hide errors
      ...options
    });
  }

  warning(message, options = {}) {
    return this.showNotification({
      type: 'warning',
      message,
      ...options
    });
  }

  info(message, options = {}) {
    return this.showNotification({
      type: 'info',
      message,
      ...options
    });
  }

  // Cleanup
  async cleanup() {
    this.clearAllNotifications();

    const container = this.domManager.getElementById('notifications-container');
    if (container) {
      container.remove();
    }
  }
}

// Make available globally
window.NotificationManager = NotificationManager;