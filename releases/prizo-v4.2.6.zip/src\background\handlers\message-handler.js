/**
 * Message Handler Module
 * Handles communication between content scripts, popup, and background service
 */

class MessageHandler {
  constructor(backgroundService) {
    this.backgroundService = backgroundService;
  }

  async handleMessage(request, sender, sendResponse) {
    let responseAlreadySent = false;

    // Safe sendResponse wrapper to prevent double-sending
    const safeSendResponse = (response) => {
      if (!responseAlreadySent) {
        responseAlreadySent = true;
        try {
          sendResponse(response);
        } catch (error) {
          console.error('Failed to send response:', error);
        }
      }
    };

    try {
      if (request.action === 'fetchProductData') {
        await this.handleFetchProductData(request, sender, safeSendResponse);
      } else if (request.action === 'fetchPriceChart') {
        await this.handleFetchPriceChart(request, safeSendResponse);
      } else if (request.action === 'batchFetchProducts') {
        await this.handleBatchFetchProducts(request, sender, safeSendResponse);
      } else if (request.action === 'checkStatus') {
        await this.handleCheckStatus(request, sender, safeSendResponse);
      } else if (request.action === 'setActive' || request.action === 'setInactive') {
        await this.handleSetActiveStatus(request, sender, safeSendResponse);
      } else if (request.action === 'getSellerTabs') {
        await this.handleGetSellerTabs(safeSendResponse);
      } else if (request.action === 'getCurrentTabId') {
        await this.handleGetCurrentTabId(sender, safeSendResponse);
      } else if (request.action === 'refreshWatchlist' || request.action === 'refreshWatchlistItem') {
        await this.handleRefreshWatchlist(request, sender, safeSendResponse);
      } else if (request.action === 'fetchSellerVouchers') {
        await this.handleFetchSellerVouchers(request, sender, safeSendResponse);
      } else if (request.action === 'clearCache') {
        await this.handleClearCache(safeSendResponse);
      } else if (request.action === 'checkTabStatus') {
        await this.handleCheckTabStatus(request, sender, safeSendResponse);
      } else if (request.action === 'saveTabStatus') {
        await this.handleSaveTabStatus(request, sender, safeSendResponse);
      } else if (request.action === 'updateIcon') {
        await this.handleUpdateIcon(request, sender, safeSendResponse);
      } else if (request.action === 'getSellerPageTabs') {
        await this.handleGetSellerPageTabs(safeSendResponse);
      } else if (request.action === 'getTabId') {
        await this.handleGetTabId(sender, safeSendResponse);
      } else if (request.action === 'requestNotificationPermission') {
        await this.handleRequestNotificationPermission(safeSendResponse);
      } else if (request.action === 'testNotification') {
        await this.handleTestNotification(safeSendResponse);
      } else if (request.action === 'triggerRecovery') {
        await this.handleTriggerRecovery(safeSendResponse);
      } else if (request.action === 'restartWatchlistMonitoring') {
        await this.handleRestartWatchlistMonitoring(safeSendResponse);
      } else if (request.action === 'refreshAllWatchlist') {
        await this.handleRefreshAllWatchlist(safeSendResponse);
      } else if (request.action === 'updateWatchlistItem') {
        await this.handleUpdateWatchlistItem(request, safeSendResponse);
      } else if (request.action === 'refreshWatchlistBatch') {
        await this.handleRefreshWatchlistBatch(request, safeSendResponse);
      } else if (request.action?.startsWith('smartCart:')) {
        await this.handleSmartCartMessage(request, sender, safeSendResponse);
      } else if (request.type === 'WATCH_FORCE_CHECK' && request.productId) {
        await this.handleWatchForceCheck(request, safeSendResponse);
      } else {
        safeSendResponse({ success: false, error: 'Unknown action' });
      }
    } catch (error) {
      console.error('Error in message handler:', error);

      // Sanitize error message for security
      let sanitizedMessage = error.message || 'Unknown error occurred';
      if (sanitizedMessage.length > 200) {
        sanitizedMessage = sanitizedMessage.substring(0, 197) + '...';
      }

      // Remove potentially sensitive information and URLs
      sanitizedMessage = sanitizedMessage.replace(/key|token|password|secret|api[_-]?key|authorization|bearer/gi, '[REDACTED]');
      sanitizedMessage = sanitizedMessage.replace(/https?:\/\/[^\s]+/gi, '[URL]');

      safeSendResponse({
        success: false,
        error: sanitizedMessage,
        errorType: this.classifyError(error)
      });
    }
  }

  async handleFetchProductData(request, sender, safeSendResponse) {
    // Support timeout parameter from content script
    const timeout = request.timeout || 30000; // Default 30 seconds

    // Create timeout wrapper
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('BACKGROUND_TIMEOUT')), timeout);
    });

    // Get current tab URL to determine endpoint type
    const currentUrl = sender.tab?.url || request.currentUrl;
    const fetchPromise = this.backgroundService.fetchProductData(
      request.productId,
      request.pageType || 'seller',
      safeSendResponse,
      currentUrl
    );

    // Race between fetch and timeout
    await Promise.race([fetchPromise, timeoutPromise]);
  }

  async handleFetchPriceChart(request, safeSendResponse) {
    const timeout = request.timeout || 15000; // Default 15 seconds for price chart

    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('PRICE_CHART_TIMEOUT')), timeout);
    });

    const fetchPromise = this.backgroundService.fetchPriceChart(request.productId, safeSendResponse);

    // Race between fetch and timeout
    await Promise.race([fetchPromise, timeoutPromise]);
  }

  async handleBatchFetchProducts(request, sender, safeSendResponse) {
    const results = await this.backgroundService.batchFetchProducts(
      request.requests || [],
      sender.tab?.url || request.currentUrl
    );
    safeSendResponse({ success: true, results });
  }

  async handleCheckStatus(request, sender, safeSendResponse) {
    const tabId = sender.tab?.id;
    if (tabId) {
      const storageKey = `seller_prices_active_${tabId}`;
      const result = await chrome.storage.local.get([storageKey]);
      safeSendResponse({ active: result[storageKey] || false });
    } else {
      safeSendResponse({ active: false });
    }
  }

  async handleSetActiveStatus(request, sender, safeSendResponse) {
    const tabId = sender.tab?.id;
    const isSetActive = request.action === 'setActive';

    if (tabId && typeof request.active === 'boolean') {
      const storageKey = `seller_prices_active_${tabId}`;

      if (isSetActive) {
        await chrome.storage.local.set({ [storageKey]: request.active });
        await this.backgroundService.updateExtensionIcon(tabId, request.active);
        safeSendResponse({ success: true });
      } else {
        safeSendResponse({ success: false, error: 'Invalid parameters' });
      }
    } else if (tabId && typeof request.active === 'boolean') {
      const storageKey = `seller_prices_active_${tabId}`;
      await chrome.storage.local.set({ [storageKey]: request.active });
      await this.backgroundService.updateExtensionIcon(tabId, request.active);
      safeSendResponse({ success: true });
    } else {
      safeSendResponse({ success: false, error: 'Invalid parameters' });
    }
  }

  async handleGetSellerTabs(safeSendResponse) {
    const tabs = await chrome.tabs.query({});
    const sellerTabs = tabs.filter(tab =>
      tab.url && this.backgroundService.isDigikalaSellerPage(tab.url)
    );
    safeSendResponse({ tabs: sellerTabs });
  }

  async handleGetCurrentTabId(sender, safeSendResponse) {
    safeSendResponse({ tabId: sender.tab?.id || null });
  }

  async handleRefreshWatchlist(request, sender, safeSendResponse) {
    try {
      const productId = request.productId;
      if (!productId) {
        safeSendResponse({ success: false, error: 'Product ID is required' });
        return;
      }

      // Check if sender is an extension page (like fullpage) or a content script
      const isExtensionPage = sender.url && sender.url.startsWith('chrome-extension://');

      if (isExtensionPage) {
        // Direct refresh from extension page (like fullpage)
        await this.handleForceCheck(productId, safeSendResponse);
      } else {
        // Forward to content script on Digikala page
        const response = await chrome.tabs.sendMessage(sender.tab?.id, {
          action: 'refreshWatchlistItem',
          productId: productId
        });

        if (response && typeof response.ok === 'boolean') {
          safeSendResponse({
            success: true,
            refreshed: response.ok,
            data: response.data || null
          });
        } else {
          safeSendResponse(response);
        }
      }
    } catch (error) {
      console.error('Error refreshing watchlist:', error);
      safeSendResponse({
        success: false,
        error: error.message || 'Failed to refresh watchlist'
      });
    }
  }

  async handleFetchSellerVouchers(request, sender, safeSendResponse) {
    try {
      const productId = request.productId;
      if (!productId) {
        safeSendResponse({ success: false, error: 'Product ID is required' });
        return;
      }

      // Support timeout parameter from content script
      const timeout = request.timeout || 8000; // Default 8 seconds for vouchers

      console.log(`🎟️ Background: Fetching seller vouchers for product ${productId}`);

      // Use the request manager to fetch voucher data
      const voucherData = await this.backgroundService.requestManager.fetchSellerVouchers(productId, timeout);

      if (voucherData) {
        console.log('✅ Background: Successfully fetched voucher data');
        safeSendResponse({
          success: true,
          data: voucherData
        });
      } else {
        safeSendResponse({
          success: false,
          error: 'No voucher data available'
        });
      }
    } catch (error) {
      console.error('❌ Background: Error fetching seller vouchers:', error);
      safeSendResponse({
        success: false,
        error: error.message || 'Failed to fetch voucher data'
      });
    }
  }

  async handleSmartCartMessage(request, sender, safeSendResponse) {
    try {
      if (!this.backgroundService.smartCartStateManager) {
        safeSendResponse({ success: false, error: 'Smart Cart not available' });
        return;
      }

      const action = request.action.replace('smartCart:', '');
      console.log(`🛒 DBG:smartCart:${action}`, {
        action,
        hasProductInfo: !!request.productInfo,
        hasVariant: !!request.selectedVariant,
        hasSeller: !!request.selectedSeller,
        itemId: request.itemId,
        tabId: sender.tab?.id
      });

      switch (action) {
        case 'addItem':
          {
            const { productInfo, selectedVariant, selectedSeller } = request;
            const item = await this.backgroundService.smartCartStateManager.addItem(productInfo, selectedVariant, selectedSeller);
            safeSendResponse({ success: true, item });
          }
          break;

        case 'removeItem':
          {
            const { itemId } = request;
            const success = await this.backgroundService.smartCartStateManager.removeItem(itemId);
            safeSendResponse({ success });
          }
          break;

        case 'updateQuantity':
          {
            const { itemId, quantity } = request;
            const item = await this.backgroundService.smartCartStateManager.updateQuantity(itemId, quantity);
            safeSendResponse({ success: true, item });
          }
          break;

        case 'changeVariant':
          {
            const { itemId, variantId, variantDetails } = request;
            const item = await this.backgroundService.smartCartStateManager.changeVariant(itemId, variantId, variantDetails);
            safeSendResponse({ success: true, item });
          }
          break;

        case 'changeSeller':
          {
            const { itemId, sellerId, sellerDetails } = request;
            console.log(`🔧 DBG:calc:shipping - Seller change triggered`, {
              itemId,
              sellerId,
              hasSellerDetails: !!sellerDetails,
              shippingCost: sellerDetails?.shippingCost
            });

            const item = await this.backgroundService.smartCartStateManager.changeSeller(itemId, sellerId, sellerDetails);
            console.log(`✅ DBG:calc:shipping - Seller changed successfully`, { item });
            safeSendResponse({ success: true, item });
          }
          break;

        case 'clearCart':
          await this.backgroundService.smartCartStateManager.clearCart();
          safeSendResponse({ success: true });
          break;

        case 'getState':
          {
            const state = this.backgroundService.smartCartStateManager.getCartState();
            safeSendResponse({ success: true, state });
          }
          break;

        case 'getItems':
          {
            const items = await this.backgroundService.smartCartStateManager.getCartItems();
            safeSendResponse({ success: true, items });
          }
          break;

        case 'refreshItems':
          await this.backgroundService.smartCartStateManager.refreshAllItems();
          safeSendResponse({ success: true });
          break;

        case 'subscribe':
          {
            const { contextId } = request;
            const tabId = sender.tab?.id;

            if (tabId && contextId) {
              // Create message forwarder for this context
              const messageForwarder = (update) => {
                chrome.tabs.sendMessage(tabId, {
                  action: 'smartCart:stateUpdate',
                  update
                }).catch(error => {
                  console.warn(`Failed to forward update to ${contextId}:`, error);
                  // Unsubscribe if tab is closed or content script not available
                  this.backgroundService.smartCartStateManager.unsubscribe(`${contextId}_${tabId}`);
                });
              };

              this.backgroundService.smartCartStateManager.subscribe(`${contextId}_${tabId}`, messageForwarder);
              safeSendResponse({ success: true });
            } else {
              safeSendResponse({ success: false, error: 'Invalid context or tab' });
            }
          }
          break;

        case 'unsubscribe':
          {
            const { contextId } = request;
            const tabId = sender.tab?.id;

            if (tabId && contextId) {
              this.backgroundService.smartCartStateManager.unsubscribe(`${contextId}_${tabId}`);
              safeSendResponse({ success: true });
            } else {
              safeSendResponse({ success: false, error: 'Invalid context or tab' });
            }
          }
          break;

        default:
          console.warn(`Unknown Smart Cart action: ${action}`);
          safeSendResponse({
            success: false,
            error: 'Unknown Smart Cart action',
            errorType: 'UNKNOWN_ACTION'
          });
      }

    } catch (error) {
      console.error('Error handling Smart Cart message:', error);
      safeSendResponse({
        success: false,
        error: error.message || 'Smart Cart operation failed',
        errorType: 'SMART_CART_ERROR'
      });
    }
  }

  async handleClearCache(safeSendResponse) {
    try {
      this.backgroundService.requestManager.clearCache();
      safeSendResponse({ success: true });
    } catch (error) {
      console.error('Error clearing cache:', error);
      safeSendResponse({ success: false, error: 'Failed to clear cache' });
    }
  }

  async handleCheckTabStatus(request, sender, safeSendResponse) {
    const tabId = sender.tab?.id;
    if (tabId) {
      const storageKey = `seller_prices_active_${tabId}`;
      const result = await chrome.storage.local.get([storageKey]);
      safeSendResponse({ active: result[storageKey] || false });
    } else {
      safeSendResponse({ active: false });
    }
  }

  async handleSaveTabStatus(request, sender, safeSendResponse) {
    const tabId = sender.tab?.id || request.tabId;
    if (tabId && typeof request.active === 'boolean') {
      const storageKey = `seller_prices_active_${tabId}`;
      await chrome.storage.local.set({
        [storageKey]: request.active
      });

      // Update icon based on active state
      await this.backgroundService.updateExtensionIcon(tabId, request.active);

      safeSendResponse({ success: true });
    } else {
      safeSendResponse({ success: false, error: 'Invalid parameters' });
    }
  }

  async handleUpdateIcon(request, sender, safeSendResponse) {
    const tabId = sender.tab?.id || request.tabId;
    if (tabId && typeof request.active === 'boolean') {
      await this.backgroundService.updateExtensionIcon(tabId, request.active);
      safeSendResponse({ success: true });
    } else {
      safeSendResponse({ success: false, error: 'Invalid parameters' });
    }
  }

  async handleGetSellerPageTabs(safeSendResponse) {
    const tabs = await chrome.tabs.query({});
    const sellerTabs = tabs.filter(tab =>
      tab.url && this.backgroundService.isDigikalaSellerPage(tab.url)
    );
    safeSendResponse({ tabs: sellerTabs });
  }

  async handleGetTabId(sender, safeSendResponse) {
    safeSendResponse({ tabId: sender.tab?.id || null });
  }

  async handleRequestNotificationPermission(safeSendResponse) {
    try {
      if (!chrome.permissions || !chrome.permissions.request) {
        safeSendResponse({ success: false, error: 'Permissions API not available' });
        return;
      }

      const granted = await chrome.permissions.request({
        permissions: ['notifications']
      });

      if (granted) {
        console.log('✅ Notification permission granted');
        safeSendResponse({ success: true, granted: true });
      } else {
        console.log('❌ Notification permission denied');
        safeSendResponse({ success: true, granted: false });
      }
    } catch (error) {
      console.error('❌ Error requesting notification permission:', error);
      safeSendResponse({ success: false, error: error.message });
    }
  }

  async handleTestNotification(safeSendResponse) {
    try {
      console.log('🧪 Sending test notification...');

      // First check if notifications API is available
      if (!chrome.notifications || !chrome.notifications.create) {
        console.warn('⚠️ Notifications API not available');
        safeSendResponse({
          success: false,
          error: 'Notifications API not available. Please ensure the extension has notification permissions.'
        });
        return;
      }

      // Check permission status
      try {
        if (chrome.permissions && chrome.permissions.contains) {
          const hasPermission = await chrome.permissions.contains({
            permissions: ['notifications']
          });

          if (!hasPermission) {
            console.warn('⚠️ No notification permission granted');
            safeSendResponse({
              success: false,
              error: 'Notification permission not granted. Please enable notifications for this extension in your browser settings.'
            });
            return;
          }
        }
      } catch (permError) {
        console.warn('⚠️ Could not check notification permissions:', permError);
        // Continue anyway - permission check might fail but notification might still work
      }

      // Create test notification
      const notificationId = `test_notification_${Date.now()}`;
      const notificationOptions = {
        type: 'basic',
        iconUrl: chrome.runtime.getURL('icons/active_128.png'),
        title: 'تست اطلاع‌رسانی پریزو 🎯',
        message: 'این یک پیام تست است. اگر این پیام را مشاهده می‌کنید، اطلاع‌رسانی‌ها به درستی کار می‌کنند!',
        contextMessage: 'کلیک کنید تا پنجره پریزو باز شود',
        requireInteraction: true,
        buttons: [
          { title: '✅ عالی!' },
          { title: '📋 متوجه شدم' }
        ]
      };

      // Create the notification
      await new Promise((resolve, reject) => {
        chrome.notifications.create(notificationId, notificationOptions, (createdId) => {
          if (chrome.runtime.lastError) {
            console.error('❌ Failed to create test notification:', chrome.runtime.lastError);
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            console.log('✅ Test notification created successfully with ID:', createdId);
            resolve(createdId);
          }
        });
      });

      // Store test notification context for cleanup
      await chrome.storage.local.set({
        [`notification_context_${notificationId}`]: {
          type: 'test',
          createdAt: Date.now(),
          productId: 'test',
          productTitle: 'تست اطلاع‌رسانی'
        }
      });

      // Auto-clear test notification after 10 seconds
      setTimeout(async () => {
        try {
          await chrome.notifications.clear(notificationId);
          await chrome.storage.local.remove([`notification_context_${notificationId}`]);
          console.log('🧹 Test notification auto-cleared');
        } catch (clearError) {
          console.warn('⚠️ Failed to auto-clear test notification:', clearError);
        }
      }, 10000);

      safeSendResponse({
        success: true,
        message: 'Test notification sent successfully!',
        notificationId: notificationId
      });

    } catch (error) {
      console.error('❌ Error sending test notification:', error);
      safeSendResponse({
        success: false,
        error: `Failed to send test notification: ${error.message}`
      });
    }
  }

  async handleTriggerRecovery(safeSendResponse) {
    console.log('🔄 Manual recovery triggered from test page');
    try {
      await this.performRecoveryCheck();
      safeSendResponse({ success: true, message: 'Recovery check completed' });
    } catch (error) {
      console.error('❌ Recovery check failed:', error);
      safeSendResponse({ success: false, error: 'Recovery check failed' });
    }
  }

  async handleRestartWatchlistMonitoring(safeSendResponse) {
    console.log('🔄 Manual watchlist monitoring restart triggered');
    try {
      await this.backgroundService.watchlistMonitor.startWatchlistMonitoring();
      safeSendResponse({ success: true, message: 'Watchlist monitoring restarted' });
    } catch (error) {
      console.error('❌ Failed to restart watchlist monitoring:', error);
      safeSendResponse({ success: false, error: 'Failed to restart watchlist monitoring' });
    }
  }

  async handleRefreshAllWatchlist(safeSendResponse) {
    console.log('🔄 Refresh all watchlist triggered');
    try {
      await this.refreshAllWatchlistItems(safeSendResponse);
    } catch (error) {
      console.error('❌ Failed to refresh all watchlist items:', error);
      safeSendResponse({ success: false, error: 'Failed to refresh watchlist items' });
    }
  }

  async handleWatchForceCheck(request, safeSendResponse) {
    try {
      const productId = request.productId;
      console.log(`🔄 Force checking product ${productId}`);
      await this.handleForceCheck(productId, safeSendResponse);
    } catch (error) {
      console.error('Error in force check:', error);
      safeSendResponse({ success: false, error: 'Force check failed' });
    }
  }

  async performRecoveryCheck() {
    console.log('🔄 Performing recovery check for missed updates');

    try {
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];
      const now = Date.now();
      let recoveredCount = 0;

      for (const item of watchlist) {
        if (!item.isActive) continue;

        const checkInterval = item.checkInterval || this.backgroundService.watchlistMonitor.monitoringInterval;
        const lastChecked = item.lastCheckedAt || 0;
        const timeSinceLastCheck = now - lastChecked;

        // If it's been more than 1.5x the check interval, it's likely missed
        if (timeSinceLastCheck > (checkInterval * 1.5)) {
          console.log(`🚨 Detected missed update for ${item.productTitle}, recovering...`);

          // Ensure alarm exists for this product
          const alarmName = `watchlist-${item.productId}`;
          try {
            const existingAlarm = await chrome.alarms.get(alarmName);

            if (!existingAlarm) {
              console.log(`⚡ Re-creating missing alarm for ${item.productTitle}`);
              // Schedule new alarm
              await chrome.alarms.create(alarmName, { delayInMinutes: 1 });
              recoveredCount++;
            }
          } catch (alarmError) {
            console.warn('Failed to check/create alarm:', alarmError);
          }
        }
      }

      console.log(`✅ Recovery check completed. Recovered ${recoveredCount} items.`);
      return recoveredCount;
    } catch (error) {
      console.error('❌ Recovery check failed:', error);
      throw error;
    }
  }

  async handleForceCheck(productId, sendResponse) {
    try {
      console.log(`🔄 Force checking product ${productId}`);

      // Verify product exists in watchlist
      const storageResult = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = storageResult['digikala_extension_watchlist'] || [];
      const itemExists = watchlist.some(item => item.id === productId || item.productId === productId);

      if (!itemExists) {
        sendResponse({
          success: false,
          shouldRemoveFromUI: true,
          error: 'Product not found in watchlist'
        });
        return;
      }

      // Check throttling - prevent too frequent force checks
      const now = Date.now();
      const lastForceCheck = this.backgroundService.watchlistMonitor.forceCheckThrottles?.get(productId);

      if (lastForceCheck && (now - lastForceCheck) < this.backgroundService.watchlistMonitor.forceCheckCooldown) {
        const waitTime = Math.ceil((this.backgroundService.watchlistMonitor.forceCheckCooldown - (now - lastForceCheck)) / 1000);
        sendResponse({
          success: false,
          error: 'throttled',
          retryAfter: waitTime
        });
        return;
      }

      // Update throttle timestamp
      if (this.backgroundService.watchlistMonitor.forceCheckThrottles) {
        this.backgroundService.watchlistMonitor.forceCheckThrottles.set(productId, now);
      }

      // Get product data using the request manager
      const result = await this.backgroundService.requestManager.fetchWithDeduplication(
        productId,
        'product-detail'
      );

      if (result.success) {
        // Extract price from the correct location in the response
        const price = this.extractPriceFromResponse(result.data);

        console.log(`💾 [PRICE UPDATE] Product ${productId} price: ${price}`);

        // Update watchlist entry
        await this.updateWatchlistEntry(productId, {
          lastCheckedAt: now,
          lastKnownPrice: price || 0
        });

        sendResponse({
          success: true,
          lastKnownPrice: price,
          lastCheckedAt: now
        });
      } else {
        sendResponse({
          success: false,
          error: result.error || 'Failed to fetch product data'
        });
      }

    } catch (error) {
      console.error(`❌ Force check failed for product ${productId}:`, error);
      sendResponse({
        success: false,
        error: error.message || 'Force check failed'
      });
    }
  }

  async refreshAllWatchlistItems(sendResponse) {
    try {
      console.log('🔄 Starting refresh all watchlist items');

      // Get current watchlist
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];

      if (watchlist.length === 0) {
        console.log('📋 No items in watchlist to refresh');
        sendResponse({ success: true, message: 'No items to refresh' });
        return;
      }

      console.log(`📋 Refreshing ${watchlist.length} watchlist items`);

      // Process only active items
      const activeItems = watchlist.filter(item => item.isActive);
      console.log(`📋 Found ${activeItems.length} active items to refresh`);

      if (activeItems.length === 0) {
        console.log('📋 No active items to refresh');
        sendResponse({ success: true, message: 'No active items to refresh' });
        return;
      }

      let successCount = 0;
      let errorCount = 0;

      // Process items with delay to avoid overwhelming the API
      for (const item of activeItems) {
        try {
          const result = await this.backgroundService.requestManager.fetchWithDeduplication(
            item.productId,
            'product-detail'
          );

          if (result.success) {
            const price = this.extractPriceFromResponse(result.data);
            console.log(`💾 [BATCH REFRESH] Product ${item.productId} price: ${price}`);

            await this.updateWatchlistEntry(item.id, {
              lastCheckedAt: Date.now(),
              lastKnownPrice: price || item.lastKnownPrice
            });
            successCount++;
          } else {
            errorCount++;
          }
        } catch (error) {
          console.error(`❌ Failed to refresh item ${item.productId}:`, error);
          errorCount++;
        }

        // Add delay between requests
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      console.log(`✅ Refresh completed: ${successCount} success, ${errorCount} errors`);
      sendResponse({
        success: true,
        message: `Refreshed ${successCount} items, ${errorCount} errors`
      });

    } catch (error) {
      console.error('❌ Failed to refresh all watchlist items:', error);
      sendResponse({
        success: false,
        error: error.message || 'Failed to refresh watchlist items'
      });
    }
  }

  async updateWatchlistEntry(entryId, updates) {
    try {
      console.log(`💾 [WATCHLIST UPDATE] Updating entry ID: ${entryId}`);
      console.log(`💾 [WATCHLIST UPDATE] Updates:`, updates);

      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];

      // Search by id first, then by productId
      const entryIndex = watchlist.findIndex(item => item.id === entryId || item.productId === entryId);
      if (entryIndex !== -1) {
        const oldEntry = watchlist[entryIndex];
        console.log(`💾 [WATCHLIST UPDATE] Found entry at index ${entryIndex}`);
        console.log(`💾 [WATCHLIST UPDATE] Old data:`, {
          id: oldEntry.id,
          productId: oldEntry.productId,
          title: oldEntry.title,
          lastKnownPrice: oldEntry.lastKnownPrice
        });

        watchlist[entryIndex] = { ...watchlist[entryIndex], ...updates };

        console.log(`💾 [WATCHLIST UPDATE] New data:`, {
          id: watchlist[entryIndex].id,
          productId: watchlist[entryIndex].productId,
          title: watchlist[entryIndex].title,
          lastKnownPrice: watchlist[entryIndex].lastKnownPrice
        });

        await chrome.storage.local.set({ 'digikala_extension_watchlist': watchlist });
        console.log(`✅ [WATCHLIST UPDATE] Successfully updated entry ${entryId}`);
        return true;
      }

      console.log(`❌ [WATCHLIST UPDATE] Entry ${entryId} not found in watchlist`);
      return false;
    } catch (error) {
      console.error('Error updating watchlist entry:', error);
      return false;
    }
  }

  async handleUpdateWatchlistItem(request, safeSendResponse) {
    try {
      console.log('🔄 Updating watchlist item:', request.data?.id);

      const updatedItem = request.data;
      if (!updatedItem || !updatedItem.id) {
        safeSendResponse({ success: false, error: 'Invalid item data' });
        return;
      }

      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];

      const itemIndex = watchlist.findIndex(item => item.id === updatedItem.id);
      if (itemIndex === -1) {
        safeSendResponse({ success: false, error: 'Item not found' });
        return;
      }

      // Update the item with new data, preserving existing fields
      watchlist[itemIndex] = {
        ...watchlist[itemIndex],
        ...updatedItem,
        updatedAt: Date.now()
      };

      await chrome.storage.local.set({ 'digikala_extension_watchlist': watchlist });

      // If check interval changed, update the alarm
      if (updatedItem.checkInterval && updatedItem.checkInterval !== watchlist[itemIndex].checkInterval) {
        const alarmName = `watchlist-${updatedItem.id}`;
        await chrome.alarms.clear(alarmName);
        if (updatedItem.isActive) {
          await chrome.alarms.create(alarmName, {
            delayInMinutes: updatedItem.checkInterval / 60000,
            periodInMinutes: updatedItem.checkInterval / 60000
          });
          console.log(`⏰ Updated alarm for ${updatedItem.productTitle} with new interval`);
        }
      }

      console.log('✅ Watchlist item updated successfully');
      safeSendResponse({ success: true, item: watchlist[itemIndex] });
    } catch (error) {
      console.error('❌ Failed to update watchlist item:', error);
      safeSendResponse({ success: false, error: error.message || 'Failed to update item' });
    }
  }

  /**
   * Handle batch refresh of multiple watchlist items
   * Uses OptimizedAPIService for rate limiting and caching
   */
  async handleRefreshWatchlistBatch(request, safeSendResponse) {
    try {
      const productIds = request.productIds || [];

      if (!Array.isArray(productIds) || productIds.length === 0) {
        safeSendResponse({
          success: false,
          message: 'لیست محصولات معتبر نیست'
        });
        return;
      }

      console.log(`🔄 Starting batch refresh for ${productIds.length} products`);

      // Get current watchlist to verify products exist
      const storageResult = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = storageResult['digikala_extension_watchlist'] || [];

      let successCount = 0;
      let errorCount = 0;
      const now = Date.now();

      // Process items with batching and rate limiting
      // Use a delay between requests to respect rate limits
      const BATCH_DELAY = 800; // 800ms between requests

      for (const productId of productIds) {
        try {
          // Find the item in watchlist
          const item = watchlist.find(i => i.id === productId || i.productId === productId);

          if (!item) {
            console.warn(`⚠️ Product ${productId} not found in watchlist, skipping`);
            errorCount++;
            continue;
          }

          // Fetch product data using request manager with deduplication and caching
          const result = await this.backgroundService.requestManager.fetchWithDeduplication(
            item.productId,
            'product-detail'
          );

          if (result.success && result.data) {
            const price = this.extractPriceFromResponse(result.data);
            console.log(`💾 [BATCH UPDATE] Product ${item.productId} price: ${price}`);

            // Update the watchlist entry
            const itemIndex = watchlist.findIndex(i => i.id === productId);
            if (itemIndex !== -1) {
              watchlist[itemIndex] = {
                ...watchlist[itemIndex],
                lastCheckedAt: now,
                lastKnownPrice: price || watchlist[itemIndex].lastKnownPrice,
                updatedAt: now
              };
              successCount++;
            }
          } else {
            console.warn(`⚠️ Failed to fetch data for ${productId}:`, result.error);
            errorCount++;
          }

          // Add delay between requests to respect rate limits
          await new Promise(resolve => setTimeout(resolve, BATCH_DELAY));

        } catch (error) {
          console.error(`❌ Error refreshing product ${productId}:`, error);
          errorCount++;
        }
      }

      // Save updated watchlist
      if (successCount > 0) {
        await chrome.storage.local.set({ 'digikala_extension_watchlist': watchlist });
      }

      console.log(`✅ Batch refresh completed: ${successCount} success, ${errorCount} errors`);

      safeSendResponse({
        success: true,
        refreshedCount: successCount,
        errorCount: errorCount,
        message: `${successCount} محصول به‌روزرسانی شد${errorCount > 0 ? `، ${errorCount} محصول با خطا مواجه شد` : ''}`
      });

    } catch (error) {
      console.error('❌ Batch refresh failed:', error);
      safeSendResponse({
        success: false,
        message: `خطا در به‌روزرسانی: ${error.message}`
      });
    }
  }

  /**
   * Extract price from API response data structure
   * Handles multiple possible data structures from different API endpoints
   */
  extractPriceFromResponse(data) {
    if (!data) return null;

    // Try multiple possible locations for the price
    // 1. product.default_variant.price.selling_price (most common)
    if (data.product?.default_variant?.price?.selling_price) {
      return data.product.default_variant.price.selling_price;
    }

    // 2. default_variant.price.selling_price (direct access)
    if (data.default_variant?.price?.selling_price) {
      return data.default_variant.price.selling_price;
    }

    // 3. product.price.selling_price (alternative structure)
    if (data.product?.price?.selling_price) {
      return data.product.price.selling_price;
    }

    // 4. price.selling_price (direct price object)
    if (data.price?.selling_price) {
      return data.price.selling_price;
    }

    // 5. Direct price field (legacy or simplified response)
    if (data.price && typeof data.price === 'number') {
      return data.price;
    }

    console.warn('⚠️ Could not extract price from response data structure:', Object.keys(data));
    return null;
  }

  classifyError(error) {
    if (!error) return 'UNKNOWN_ERROR';

    const message = error.message || error.toString();
    const lowerMessage = message.toLowerCase();

    if (lowerMessage.includes('fetch') || lowerMessage.includes('network')) {
      return 'NETWORK_ERROR';
    }
    if (lowerMessage.includes('storage') || lowerMessage.includes('quota')) {
      return 'STORAGE_ERROR';
    }
    if (lowerMessage.includes('rate limit') || lowerMessage.includes('429')) {
      return 'RATE_LIMITED';
    }

    return 'API_ERROR';
  }
}

export { MessageHandler };