/**
 * @Author: Zana Saedpanah
 * @Date:   2025-07-20
 * Error recovery and handling system
 */

class ErrorRecoveryManager {
  constructor(extension) {
    this.extension = extension;
    this.errorCounts = new Map();
    this.maxRetries = 3;
    this.retryDelay = 2000;
    this.criticalErrors = new Set([
      'STOPPED_BY_USER',
      'EXTENSION_DISABLED',
      'STORAGE_QUOTA_EXCEEDED',
      'NETWORK_BLOCKED'
    ]);
    this.transientErrors = new Set([
      'NETWORK_ERROR',
      'RATE_LIMITED',
      'TIMEOUT',
      'API_TEMPORARILY_UNAVAILABLE'
    ]);
  }

  classifyError(error) {
    const message = error.message || error.toString();

    if (this.criticalErrors.has(message)) {
      return 'critical';
    }

    if (this.transientErrors.has(message)) {
      return 'transient';
    }

    if (message.includes('Failed to fetch') || message.includes('NetworkError')) {
      return 'network';
    }

    if (message.includes('Storage') || message.includes('quota')) {
      return 'storage';
    }

    if (message.includes('Rate limit') || message.includes('429')) {
      return 'rate_limit';
    }

    return 'unknown';
  }

  generateUserMessage(error, context) {
    const errorType = this.classifyError(error);

    const messages = {
      network: {
        title: 'مشکل در اتصال',
        message: 'اتصال اینترنت خود را بررسی کنید و دوباره تلاش کنید.',
        actions: ['retry', 'refresh']
      },
      storage: {
        title: 'مشکل در ذخیره‌سازی',
        message: 'فضای ذخیره‌سازی مرورگر پر است. لطفاً فضای آزاد ایجاد کنید.',
        actions: ['clear_cache', 'refresh']
      },
      rate_limit: {
        title: 'درخواست‌های زیاد',
        message: 'لطفاً کمی صبر کنید و دوباره تلاش کنید.',
        actions: ['wait_retry']
      },
      critical: {
        title: 'خطای جدی',
        message: 'عملیات متوقف شد. لطفاً صفحه را تازه‌سازی کنید.',
        actions: ['refresh']
      },
      transient: {
        title: 'خطای موقت',
        message: 'خطای موقت رخ داد. در حال تلاش مجدد...',
        actions: ['auto_retry']
      },
      unknown: {
        title: 'خطای نامشخص',
        message: 'مشکلی پیش آمده است. اگر مشکل ادامه داشت، افزونه را غیرفعال و فعال کنید.',
        actions: ['retry', 'refresh', 'reset']
      }
    };

    return messages[errorType] || messages.unknown;
  }

  async handleError(error, context, retryFunction = null) {
    const errorKey = `${context}_${error.message}`;
    const errorCount = this.errorCounts.get(errorKey) || 0;

    console.error(`❌ Error in ${context}:`, error);

    if (this.classifyError(error) === 'critical') {
      this.showCriticalError(error, context);
      return { recovered: false, shouldStop: true };
    }

    if (errorCount >= this.maxRetries) {
      console.log(`⚠️ Max retries exceeded for ${context}`);
      this.showMaxRetriesError(error, context);
      return { recovered: false, shouldStop: true };
    }

    this.errorCounts.set(errorKey, errorCount + 1);

    const userMessage = this.generateUserMessage(error, context);

    const errorType = this.classifyError(error);

    if (errorType === 'transient' && retryFunction) {
      return await this.handleTransientError(error, context, retryFunction, userMessage);
    }

    if (errorType === 'network' && retryFunction) {
      return await this.handleNetworkError(error, context, retryFunction, userMessage);
    }

    if (errorType === 'rate_limit' && retryFunction) {
      return await this.handleRateLimitError(error, context, retryFunction, userMessage);
    }

    this.showRecoverableError(error, context, userMessage);
    return { recovered: false, shouldStop: false };
  }

  async handleTransientError(error, context, retryFunction, userMessage) {
    this.showAutoRetryNotification(userMessage);

    await new Promise(resolve => setTimeout(resolve, this.retryDelay));

    try {
      console.log(`🔄 Auto-retrying ${context}`);
      await retryFunction();

      const errorKey = `${context}_${error.message}`;
      this.errorCounts.delete(errorKey);

      this.showRecoverySuccess(context);
      return { recovered: true, shouldStop: false };
    } catch (retryError) {
      console.error(`❌ Retry failed for ${context}:`, retryError);
      return { recovered: false, shouldStop: false };
    }
  }

  async handleNetworkError(error, context, retryFunction, userMessage) {
    return new Promise((resolve) => {
      this.showNetworkErrorDialog(userMessage, {
        onRetry: async () => {
          try {
            await retryFunction();
            const errorKey = `${context}_${error.message}`;
            this.errorCounts.delete(errorKey);
            this.showRecoverySuccess(context);
            resolve({ recovered: true, shouldStop: false });
          } catch (retryError) {
            resolve({ recovered: false, shouldStop: false });
          }
        },
        onSkip: () => {
          resolve({ recovered: false, shouldStop: false });
        },
        onStop: () => {
          resolve({ recovered: false, shouldStop: true });
        }
      });
    });
  }

  async handleRateLimitError(error, context, retryFunction, userMessage) {
    const waitTime = this.extractWaitTime(error) || 5000;

    this.showRateLimitNotification(userMessage, waitTime);

    await new Promise(resolve => setTimeout(resolve, waitTime));

    try {
      console.log(`🔄 Retrying after rate limit for ${context}`);
      await retryFunction();

      const errorKey = `${context}_${error.message}`;
      this.errorCounts.delete(errorKey);

      this.showRecoverySuccess(context);
      return { recovered: true, shouldStop: false };
    } catch (retryError) {
      return { recovered: false, shouldStop: false };
    }
  }

  extractWaitTime(error) {
    const message = error.message || error.toString();
    const match = message.match(/retry after (\d+) seconds/i);
    return match ? parseInt(match[1]) * 1000 : null;
  }

  showAutoRetryNotification(userMessage) {
    this.extension.showNotification({
      type: 'info',
      title: userMessage.title,
      message: userMessage.message,
      autoHide: true,
      duration: 3000
    });
  }

  showNetworkErrorDialog(userMessage, callbacks) {
    this.extension.showErrorDialog({
      title: userMessage.title,
      message: userMessage.message,
      actions: [
        { text: 'تلاش مجدد', action: callbacks.onRetry, primary: true },
        { text: 'ادامه بدون این مورد', action: callbacks.onSkip },
        { text: 'توقف', action: callbacks.onStop, danger: true }
      ]
    });
  }

  showRateLimitNotification(userMessage, waitTime) {
    const waitSeconds = Math.ceil(waitTime / 1000);
    this.extension.showNotification({
      type: 'warning',
      title: userMessage.title,
      message: `${userMessage.message} (${waitSeconds} ثانیه)`,
      autoHide: true,
      duration: waitTime
    });
  }

  showCriticalError(error, context) {
    const userMessage = this.generateUserMessage(error, context);
    this.extension.showNotification({
      type: 'error',
      title: userMessage.title,
      message: userMessage.message,
      autoHide: false,
      actions: [
        { text: 'تازه‌سازی صفحه', action: () => window.location.reload() }
      ]
    });
  }

  showMaxRetriesError(error, context) {
    this.extension.showNotification({
      type: 'error',
      title: 'حداکثر تلاش',
      message: 'حداکثر تعداد تلاش انجام شد. لطفاً صفحه را تازه‌سازی کنید.',
      autoHide: false,
      actions: [
        { text: 'تازه‌سازی', action: () => window.location.reload() },
        { text: 'ریست افزونه', action: () => this.extension.clearAllData() }
      ]
    });
  }

  showRecoverableError(error, context, userMessage) {
    this.extension.showNotification({
      type: 'warning',
      title: userMessage.title,
      message: userMessage.message,
      autoHide: true,
      duration: 5000
    });
  }

  showRecoverySuccess(context) {
    this.extension.showNotification({
      type: 'success',
      title: 'بازیابی موفق',
      message: 'مشکل برطرف شد و عملیات ادامه یافت.',
      autoHide: true,
      duration: 2000
    });
  }

  clearErrorCounts() {
    this.errorCounts.clear();
  }
}

// Make available globally
window.ErrorRecoveryManager = ErrorRecoveryManager;