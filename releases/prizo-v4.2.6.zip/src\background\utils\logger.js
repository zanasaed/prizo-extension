/**
 * Background Logger Utility
 * Simple inline logger for background script monitoring logs
 */

const BackgroundLogger = {
  info: (message, productId = null) => {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const logMessage = productId
      ? `[${timestamp}] [INFO] ${message} | Product: ${productId}`
      : `[${timestamp}] [INFO] ${message}`;
    console.log(logMessage);
  }
};

export { BackgroundLogger };