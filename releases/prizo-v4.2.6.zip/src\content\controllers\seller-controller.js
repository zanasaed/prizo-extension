/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Seller Controller - Handles seller dashboard and seller-specific pages
 */
class SellerController extends BaseController {
  constructor(services) {
    super(services, 'seller');
    this.sellerId = null;
  }

  async initialize() {
    console.log('🔄 Initializing seller controller');
    
    if (!this.isSellerPage()) {
      console.log('❌ Not a seller page, skipping initialization');
      return;
    }

    this.sellerId = this.extractSellerIdFromURL();
    console.log(`🏪 Current seller ID: ${this.sellerId}`);
  }

  isSellerPage() {
    const url = window.location.href;
    const path = window.location.pathname;
    
    const sellerPagePatterns = [
      /\/seller\//,
      /\/shop\//,
      /\/store\//
    ];

    return sellerPagePatterns.some(pattern => pattern.test(url) || pattern.test(path)) ||
           document.querySelector('[data-testid="seller-page"]') ||
           document.querySelector('.seller-dashboard');
  }

  extractSellerIdFromURL() {
    const url = window.location.href;
    console.log('🔍 Extracting seller ID from URL:', url);
    
    // Try different patterns for seller ID extraction
    const patterns = [
      /\/seller\/(\d+)/,           // /seller/123456
      /\/seller\/([^\/\?]+)/,      // /seller/seller-name
      /seller[_-]?id[=:](\d+)/i,   // seller_id=123 or sellerid:123
      /\/shop\/(\d+)/,             // /shop/123456
      /\/store\/(\d+)/             // /store/123456
    ];
    
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        console.log(`✅ Found seller ID: ${match[1]} using pattern: ${pattern}`);
        return match[1];
      }
    }
    
    // Try extracting from page data
    const sellerIdFromPage = this.extractSellerIdFromPage();
    if (sellerIdFromPage) {
      console.log(`✅ Found seller ID from page data: ${sellerIdFromPage}`);
      return sellerIdFromPage;
    }
    
    console.log('❌ Could not extract seller ID from URL');
    return null;
  }
  
  extractSellerIdFromPage() {
    try {
      // Look for seller ID in page elements
      const selectors = [
        '[data-seller-id]',
        '[data-seller-code]', 
        '[class*="seller"][data-id]',
        '.seller-info [data-id]'
      ];
      
      for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) {
          const sellerId = element.getAttribute('data-seller-id') || 
                          element.getAttribute('data-seller-code') ||
                          element.getAttribute('data-id');
          if (sellerId) {
            return sellerId;
          }
        }
      }
      
      // Look for seller ID in script tags or window objects
      if (window.pageData && window.pageData.seller) {
        return window.pageData.seller.id || window.pageData.seller.code;
      }
      
      return null;
    } catch (error) {
      console.error('❌ Error extracting seller ID from page:', error);
      return null;
    }
  }

  async processInitialElements() {
    console.log('🏪 Processing seller page elements');
    
    if (!this.sellerId) {
      console.log('❌ No seller ID found, cannot process seller prices');
      return;
    }
    
    // Get products using DOM manager
    const productElements = this.services.domManager.getProductElements();
    console.log(`📦 Found ${productElements.length} product elements on seller page`);

    if (productElements.length === 0) {
      console.log('⚠️ No product elements found on seller page');
      return;
    }

    // Process products to show seller-specific prices
    await this.updateSellerPrices(Array.from(productElements));
  }

  async updateSellerPrices(products) {
    console.log(`🔄 Processing ${products.length} products for seller prices`);

    for (let i = 0; i < products.length; i++) {
      if (this.shouldStop) {
        console.log('⏹️ Processing stopped by user');
        throw new Error('STOPPED_BY_USER');
      }

      const productElement = products[i];
      console.log(`\n--- Processing product ${i + 1}/${products.length} for seller price ---`);

      try {
        const productId = this.services.domManager.extractProductId(productElement);
        console.log('🆔 Product ID:', productId);

        if (!productId) {
          console.log('❌ No product ID found, skipping');
          continue;
        }

        if (this.processedElements.has(productId)) {
          console.log('⏭️ Product already processed, skipping');
          continue;
        }

        this.processedElements.add(productId);
        await this.updateSingleProductSellerPrice(productElement, productId);

        // Check for stop again after processing
        if (this.shouldStop) {
          throw new Error('STOPPED_BY_USER');
        }

        // Reasonable delay between requests
        await new Promise(resolve => setTimeout(resolve, 800));

      } catch (error) {
        if (error.message === 'STOPPED_BY_USER') {
          throw error;
        }
        console.error('❌ Error updating product seller price:', error);
        // Continue with next product instead of failing completely
      }
    }
  }

  async updateSingleProductSellerPrice(productElement, productId) {
    try {
      console.log(`🔄 Updating seller price for product: ${productId}`);

      const productData = await this.services.dataManager.fetchProductDataForProductPage(productId);
      if (!productData) {
        console.log('❌ No product data received');
        this.services.domManager.markProductAsUnavailable(productElement);
        return;
      }

      // Find seller-specific variant (to ensure this seller has the product)
      const sellerVariant = await this.services.dataManager.findSellerVariant(productData, this.sellerId, productId);
      
      if (!sellerVariant) {
        console.log('❌ No seller variant found for this seller');
        this.services.domManager.markProductAsUnavailable(productElement);
        return;
      }

      // Extract current lowest price among all sellers instead of selected seller's price
      const currentLowestPriceData = await this.services.dataManager.extractCurrentLowestPrice(productData, productId);
      if (!currentLowestPriceData || currentLowestPriceData.price <= 0) {
        console.log('❌ No current lowest price found');
        this.services.domManager.markProductAsUnavailable(productElement);
        return;
      }

      const currentLowestPrice = currentLowestPriceData.price;
      const monthlyLowPrice = sellerVariant.monthly_low_price || 0;

      // Calculate discount based on current lowest price vs monthly low price
      const discountPercent = this.calculateCurrentPriceDiscount(currentLowestPrice, monthlyLowPrice);

      console.log(`💰 Current lowest price: ${currentLowestPrice}, Monthly low: ${monthlyLowPrice}, Discount: ${discountPercent}%`);

      // Add seller price section to product element (now showing current lowest price)
      this.services.domManager.addSellerPriceSection(
        productElement, 
        currentLowestPrice, 
        discountPercent, 
        monthlyLowPrice
      );

      this.services.domManager.addUpdatedIndicator(productElement);
      console.log('✅ Seller price update completed');
      
    } catch (error) {
      console.error(`❌ Error updating seller price for product ${productId}:`, error);
      this.services.domManager.markProductAsError(productElement);
    }
  }

  extractSellerPrice(sellerVariant) {
    if (!sellerVariant) return 0;
    
    // Try different price fields
    const priceFields = ['selling_price', 'price', 'amount', 'value'];
    
    for (const field of priceFields) {
      if (sellerVariant[field] && typeof sellerVariant[field] === 'number') {
        return sellerVariant[field];
      }
      
      // Handle nested price objects
      if (sellerVariant.price && typeof sellerVariant.price === 'object') {
        if (sellerVariant.price[field] && typeof sellerVariant.price[field] === 'number') {
          return sellerVariant.price[field];
        }
      }
    }
    
    return 0;
  }

  calculateCurrentPriceDiscount(currentLowestPrice, monthlyLowPrice) {
    try {
      // Calculate discount based on current lowest price vs monthly low price
      if (monthlyLowPrice > currentLowestPrice && currentLowestPrice > 0 && monthlyLowPrice > 0) {
        return Math.round(((monthlyLowPrice - currentLowestPrice) / monthlyLowPrice) * 100);
      }
      
      return 0;
    } catch (error) {
      console.error('❌ Error calculating current price discount:', error);
      return 0;
    }
  }

  calculateSellerDiscount(productData, sellerVariant, sellerPrice) {
    try {
      // Find other variants to compare prices
      const otherVariants = productData.variants ? 
        productData.variants.filter(v => v.id !== sellerVariant.id) : [];
      
      if (otherVariants.length === 0) return 0;
      
      // Find the highest price among other sellers
      let maxPrice = 0;
      for (const variant of otherVariants) {
        const variantPrice = this.extractSellerPrice(variant);
        if (variantPrice > maxPrice) {
          maxPrice = variantPrice;
        }
      }
      
      // Calculate discount percentage
      if (maxPrice > sellerPrice && sellerPrice > 0) {
        return Math.round(((maxPrice - sellerPrice) / maxPrice) * 100);
      }
      
      return 0;
    } catch (error) {
      console.error('❌ Error calculating seller discount:', error);
      return 0;
    }
  }

  async processNewElements() {
    if (!this.isActive || !this.sellerId) return;
    
    const newProductElements = this.services.domManager.getProductElements().filter(element => {
      const productId = this.services.domManager.extractProductId(element);
      return productId && !this.processedElements.has(productId);
    });

    if (newProductElements.length > 0) {
      console.log(`📦 Found ${newProductElements.length} new product elements on seller page`);
      await this.updateSellerPrices(newProductElements);
    }
  }

  isElementRelevant(element) {
    // Check if element is a product card on seller page
    const selectors = [
      'article[data-product-id]',
      '[data-testid="product-card"]',
      '.c-product-box',
      '.product-list__item'
    ];

    return selectors.some(selector => 
      element.matches(selector) || element.querySelector(selector)
    );
  }
}

window.SellerController = SellerController;