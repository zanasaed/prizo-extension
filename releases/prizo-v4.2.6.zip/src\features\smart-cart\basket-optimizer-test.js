/**
 * @Author: Smart Cart System
 * @Date: 2025-01-18
 * Comprehensive Test Suite for Basket Optimizer
 * Demonstrates all optimization modes with various scenarios
 */

// Test data scenarios
const testScenarios = {
  // Small scenario for exhaustive search testing
  smallBasket: {
    products: [
      {
        id: "laptop",
        sellers: [
          { sellerId: "techStore", price: 75000, inventory: 3, shipsDirectly: true },
          { sellerId: "megaMarket", price: 72000, inventory: 5, shipsDirectly: false },
          { sellerId: "digitalShop", price: 78000, inventory: 2, shipsDirectly: true }
        ]
      },
      {
        id: "mouse",
        sellers: [
          { sellerId: "techStore", price: 2500, inventory: 10, shipsDirectly: true },
          { sellerId: "megaMarket", price: 2200, inventory: 8, shipsDirectly: false }
        ]
      },
      {
        id: "keyboard",
        sellers: [
          { sellerId: "digitalShop", price: 4500, inventory: 6, shipsDirectly: true },
          { sellerId: "megaMarket", price: 4200, inventory: 4, shipsDirectly: false }
        ]
      }
    ],
    sellers: {
      "techStore": { shippingCost: 1500 },
      "megaMarket": { shippingCost: 2000 },
      "digitalShop": { shippingCost: 1200 }
    },
    marketplaceShipping: 800,
    optimizationMode: "COST"
  },

  // Medium scenario for greedy algorithm testing
  mediumBasket: {
    products: [
      {
        id: "phone",
        sellers: [
          { sellerId: "mobileWorld", price: 120000, inventory: 2, shipsDirectly: true },
          { sellerId: "techGiant", price: 118000, inventory: 5, shipsDirectly: false },
          { sellerId: "gadgetHub", price: 125000, inventory: 3, shipsDirectly: true }
        ]
      },
      {
        id: "case",
        sellers: [
          { sellerId: "mobileWorld", price: 1200, inventory: 20, shipsDirectly: true },
          { sellerId: "accessoryShop", price: 1000, inventory: 15, shipsDirectly: false }
        ]
      },
      {
        id: "charger",
        sellers: [
          { sellerId: "techGiant", price: 1800, inventory: 10, shipsDirectly: false },
          { sellerId: "gadgetHub", price: 2000, inventory: 8, shipsDirectly: true }
        ]
      },
      {
        id: "headphones",
        sellers: [
          { sellerId: "audioStore", price: 8500, inventory: 4, shipsDirectly: true },
          { sellerId: "techGiant", price: 8200, inventory: 6, shipsDirectly: false }
        ]
      },
      {
        id: "powerBank",
        sellers: [
          { sellerId: "accessoryShop", price: 3500, inventory: 12, shipsDirectly: false },
          { sellerId: "gadgetHub", price: 3800, inventory: 7, shipsDirectly: true }
        ]
      }
    ],
    sellers: {
      "mobileWorld": { shippingCost: 2500 },
      "techGiant": { shippingCost: 1800 },
      "gadgetHub": { shippingCost: 2200 },
      "audioStore": { shippingCost: 1500 },
      "accessoryShop": { shippingCost: 1000 }
    },
    marketplaceShipping: 1200,
    optimizationMode: "COST"
  },

  // Scenario with preferred sellers
  preferredSellersBasket: {
    products: [
      {
        id: "smartWatch",
        preferredSeller: "premiumStore",
        sellers: [
          { sellerId: "premiumStore", price: 45000, inventory: 3, shipsDirectly: true },
          { sellerId: "bargainShop", price: 42000, inventory: 5, shipsDirectly: false }
        ]
      },
      {
        id: "smartBand",
        sellers: [
          { sellerId: "premiumStore", price: 8500, inventory: 4, shipsDirectly: true },
          { sellerId: "bargainShop", price: 8000, inventory: 6, shipsDirectly: false },
          { sellerId: "fitnessStore", price: 8200, inventory: 8, shipsDirectly: true }
        ]
      }
    ],
    sellers: {
      "premiumStore": { shippingCost: 2000 },
      "bargainShop": { shippingCost: 1500 },
      "fitnessStore": { shippingCost: 1800 }
    },
    marketplaceShipping: 1000,
    optimizationMode: "COST"
  }
};

/**
 * Test suite runner
 */
class BasketOptimizerTestSuite {
  constructor() {
    this.results = [];
  }

  async runAllTests() {
    console.log('🧪 Starting Basket Optimizer Test Suite');
    console.log('=====================================');

    // Test different optimization modes with small basket
    await this.testOptimizationModes();

    // Test algorithm selection
    await this.testAlgorithmSelection();

    // Test edge cases
    await this.testEdgeCases();

    // Test constraint handling
    await this.testConstraints();

    // Print summary
    this.printSummary();

    return this.results;
  }

  async testOptimizationModes() {
    console.log('\n📊 Testing Optimization Modes');
    console.log('------------------------------');

    const modes = ['COST', 'SELLERS_FIRST', 'MAX_SELLERS'];

    for (const mode of modes) {
      const basketData = {
        ...testScenarios.smallBasket,
        optimizationMode: mode,
        maxSellers: mode === 'MAX_SELLERS' ? 2 : undefined
      };

      await this.runSingleTest(`${mode} Mode`, basketData);
    }
  }

  async testAlgorithmSelection() {
    console.log('\n🔀 Testing Algorithm Selection');
    console.log('------------------------------');

    // Small basket should use exhaustive search
    await this.runSingleTest('Small Basket (Exhaustive)', testScenarios.smallBasket);

    // Medium basket should use greedy + local search
    await this.runSingleTest('Medium Basket (Greedy)', testScenarios.mediumBasket);
  }

  async testEdgeCases() {
    console.log('\n⚠️ Testing Edge Cases');
    console.log('----------------------');

    // Test with preferred sellers
    await this.runSingleTest('Preferred Sellers', testScenarios.preferredSellersBasket);

    // Test with no marketplace shipping
    const noMarketplaceBasket = {
      ...testScenarios.smallBasket,
      marketplaceShipping: 0
    };
    await this.runSingleTest('No Marketplace Shipping', noMarketplaceBasket);

    // Test with single seller per product
    const singleSellerBasket = {
      products: [
        {
          id: "uniqueProduct1",
          sellers: [{ sellerId: "onlyStore1", price: 10000, inventory: 1, shipsDirectly: true }]
        },
        {
          id: "uniqueProduct2",
          sellers: [{ sellerId: "onlyStore2", price: 15000, inventory: 1, shipsDirectly: false }]
        }
      ],
      sellers: {
        "onlyStore1": { shippingCost: 500 },
        "onlyStore2": { shippingCost: 700 }
      },
      marketplaceShipping: 300,
      optimizationMode: "COST"
    };
    await this.runSingleTest('Single Seller Per Product', singleSellerBasket);
  }

  async testConstraints() {
    console.log('\n🔒 Testing Constraints');
    console.log('----------------------');

    // Test max sellers constraint
    const maxSellersBasket = {
      ...testScenarios.mediumBasket,
      optimizationMode: 'MAX_SELLERS',
      maxSellers: 2
    };
    await this.runSingleTest('Max Sellers Constraint', maxSellersBasket);

    // Test sellers first optimization
    const sellersFirstBasket = {
      ...testScenarios.mediumBasket,
      optimizationMode: 'SELLERS_FIRST'
    };
    await this.runSingleTest('Sellers First Optimization', sellersFirstBasket);
  }

  async runSingleTest(testName, basketData) {
    console.log(`\n🔬 Testing: ${testName}`);

    try {
      // Import the optimizer (in browser environment)
      const optimizer = new BasketOptimizer();

      const startTime = Date.now();
      const result = await optimizer.optimizeBasket(basketData);
      const duration = Date.now() - startTime;

      if (result && result.success) {
        console.log(`✅ ${testName} - SUCCESS (${duration}ms)`);
        console.log(`   💰 Total Cost: ${result.totalCost}`);
        console.log(`   🏪 Sellers Used: ${result.sellersUsed.length} (${result.sellersUsed.join(', ')})`);
        console.log(`   📦 Product Cost: ${result.totalProductCost}`);
        console.log(`   🚚 Shipping Cost: ${result.totalShippingCost}`);
        if (result.strategy) {
          console.log(`   🎯 Strategy: ${result.strategy}`);
        }

        this.results.push({
          testName,
          success: true,
          duration,
          result,
          basketData
        });
      } else {
        console.log(`❌ ${testName} - FAILED`);
        console.log(`   Error: ${result ? result.error : 'Unknown error'}`);

        this.results.push({
          testName,
          success: false,
          error: result ? result.error : 'Unknown error',
          basketData
        });
      }

    } catch (error) {
      console.log(`💥 ${testName} - EXCEPTION`);
      console.log(`   Exception: ${error.message}`);

      this.results.push({
        testName,
        success: false,
        error: error.message,
        basketData
      });
    }
  }

  printSummary() {
    console.log('\n📈 Test Summary');
    console.log('===============');

    const totalTests = this.results.length;
    const successfulTests = this.results.filter(r => r.success).length;
    const failedTests = totalTests - successfulTests;

    console.log(`Total Tests: ${totalTests}`);
    console.log(`✅ Successful: ${successfulTests}`);
    console.log(`❌ Failed: ${failedTests}`);

    if (successfulTests > 0) {
      const avgDuration = this.results
        .filter(r => r.success && r.duration)
        .reduce((sum, r) => sum + r.duration, 0) / successfulTests;
      console.log(`⏱️ Average Duration: ${Math.round(avgDuration)}ms`);
    }

    if (failedTests > 0) {
      console.log('\n❌ Failed Tests:');
      this.results
        .filter(r => !r.success)
        .forEach(r => console.log(`   - ${r.testName}: ${r.error}`));
    }

    console.log('\n🎯 Performance Analysis:');
    this.analyzePerformance();
  }

  analyzePerformance() {
    const successfulResults = this.results.filter(r => r.success);

    // Group by optimization strategy
    const strategyPerformance = {};
    successfulResults.forEach(result => {
      const strategy = result.result.strategy || 'unknown';
      if (!strategyPerformance[strategy]) {
        strategyPerformance[strategy] = [];
      }
      strategyPerformance[strategy].push(result);
    });

    Object.entries(strategyPerformance).forEach(([strategy, results]) => {
      const avgDuration = results.reduce((sum, r) => sum + r.duration, 0) / results.length;
      const avgProducts = results.reduce((sum, r) => sum + r.basketData.products.length, 0) / results.length;

      console.log(`   ${strategy}: ${results.length} tests, avg ${Math.round(avgDuration)}ms, avg ${Math.round(avgProducts)} products`);
    });
  }

  // Utility method to manually test a custom basket
  async testCustomBasket(basketData, testName = 'Custom Test') {
    console.log(`\n🔬 Custom Test: ${testName}`);
    await this.runSingleTest(testName, basketData);
    return this.results[this.results.length - 1];
  }
}

/**
 * Simple test runner for browser console
 */
async function runBasketOptimizerTests() {
  const testSuite = new BasketOptimizerTestSuite();
  return await testSuite.runAllTests();
}

/**
 * Quick test function for development
 */
async function quickTest() {
  console.log('🚀 Running Quick Test');
  const optimizer = new BasketOptimizer();
  const result = await optimizer.optimizeBasket(testScenarios.smallBasket);
  console.log('Result:', result);
  return result;
}

// Browser extension compatibility
if (typeof window !== 'undefined') {
  window.BasketOptimizerTestSuite = BasketOptimizerTestSuite;
  window.runBasketOptimizerTests = runBasketOptimizerTests;
  window.quickTest = quickTest;
  window.testScenarios = testScenarios;
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    BasketOptimizerTestSuite,
    runBasketOptimizerTests,
    quickTest,
    testScenarios
  };
}