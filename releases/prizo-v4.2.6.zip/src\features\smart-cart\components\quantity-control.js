/**
 * Robust Quantity Control Component
 * Handles quantity updates with debouncing, validation, and proper state management
 */
class QuantityControl {
  constructor(cartAPI, itemId, initialQuantity = 1) {
    this.cartAPI = cartAPI;
    this.itemId = itemId;
    this.currentQuantity = initialQuantity;
    this.element = null;
    this.isUpdating = false;

    // Debouncing
    this.updateTimeout = null;
    this.debounceMs = 300;

    // Validation
    this.minQuantity = 1;
    this.maxQuantity = 99;

    this.create();
  }

  /**
   * Create quantity control HTML element
   */
  create() {
    this.element = document.createElement('div');
    this.element.className = 'quantity-control';
    this.element.innerHTML = `
      <button class="qty-btn qty-decrease" ${this.currentQuantity <= this.minQuantity ? 'disabled' : ''}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
          <path d="M19 13H5v-2h14v2z"/>
        </svg>
      </button>
      <input class="qty-input" type="number"
             value="${this.currentQuantity}"
             min="${this.minQuantity}"
             max="${this.maxQuantity}">
      <button class="qty-btn qty-increase" ${this.currentQuantity >= this.maxQuantity ? 'disabled' : ''}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
          <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
        </svg>
      </button>
      <div class="qty-loading" style="display: none;">
        <div class="spinner"></div>
      </div>
    `;

    this.addStyles();
    this.bindEvents();
  }

  /**
   * Add component styles
   */
  addStyles() {
    if (document.querySelector('#quantity-control-styles')) return;

    const styles = document.createElement('style');
    styles.id = 'quantity-control-styles';
    styles.textContent = `
      .quantity-control {
        display: flex;
        align-items: center;
        gap: 0;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        overflow: hidden;
        background: white;
        direction: ltr;
      }

      .qty-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border: none;
        background: #f8fafc;
        color: #64748b;
        cursor: pointer;
        transition: all 0.2s ease;
        border-radius: 0;
      }

      .qty-btn:hover:not(:disabled) {
        background: #e2e8f0;
        color: #334155;
      }

      .qty-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .qty-input {
        width: 50px;
        height: 32px;
        border: none;
        text-align: center;
        font-size: 14px;
        font-weight: 500;
        color: #1e293b;
        background: white;
        outline: none;
        border-left: 1px solid #e2e8f0;
        border-right: 1px solid #e2e8f0;
      }

      .qty-input:focus {
        background: #f8fafc;
      }

      /* Remove number input arrows */
      .qty-input::-webkit-outer-spin-button,
      .qty-input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      .qty-input[type=number] {
        -moz-appearance: textfield;
      }

      .qty-loading {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255, 255, 255, 0.9);
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .spinner {
        width: 16px;
        height: 16px;
        border: 2px solid #e2e8f0;
        border-top: 2px solid #3b82f6;
        border-radius: 50%;
        animation: spin 1s linear infinite;
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }

      .quantity-control.updating {
        position: relative;
      }

      .quantity-control.updating .qty-loading {
        display: flex;
      }

      .quantity-control.error {
        border-color: #ef4444;
      }

      .quantity-control.error .qty-input {
        color: #ef4444;
      }
    `;
    document.head.appendChild(styles);
  }

  /**
   * Bind event listeners
   */
  bindEvents() {
    const decreaseBtn = this.element.querySelector('.qty-decrease');
    const increaseBtn = this.element.querySelector('.qty-increase');
    const input = this.element.querySelector('.qty-input');

    // Decrease button
    decreaseBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      this.changeQuantity(-1);
    });

    // Increase button
    increaseBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      this.changeQuantity(1);
    });

    // Input field
    input.addEventListener('input', (e) => {
      e.stopPropagation();
      this.handleInputChange();
    });

    input.addEventListener('blur', () => {
      this.validateAndUpdate();
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        input.blur();
      }
    });

    // Prevent form submission on Enter
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
      }
    });
  }

  /**
   * Change quantity by delta
   */
  async changeQuantity(delta) {
    if (this.isUpdating) return;

    const newQuantity = this.currentQuantity + delta;

    // Validate bounds
    if (newQuantity < this.minQuantity || newQuantity > this.maxQuantity) {
      return;
    }

    console.log(`🔄 [QuantityControl] Change quantity: ${this.currentQuantity} + ${delta} = ${newQuantity}`);

    await this.updateQuantity(newQuantity);
  }

  /**
   * Handle input change with debouncing
   */
  handleInputChange() {
    if (this.updateTimeout) {
      clearTimeout(this.updateTimeout);
    }

    this.updateTimeout = setTimeout(() => {
      this.validateAndUpdate();
    }, this.debounceMs);
  }

  /**
   * Validate input and update if valid
   */
  async validateAndUpdate() {
    const input = this.element.querySelector('.qty-input');
    const rawValue = input.value;
    const newQuantity = parseInt(rawValue, 10);

    console.log(`🔍 [QuantityControl] Validating input: "${rawValue}" → ${newQuantity}`);

    // Validation
    if (isNaN(newQuantity) || newQuantity < this.minQuantity) {
      console.warn(`⚠️ [QuantityControl] Invalid quantity, resetting to ${this.minQuantity}`);
      this.setInputValue(this.minQuantity);
      await this.updateQuantity(this.minQuantity);
      return;
    }

    if (newQuantity > this.maxQuantity) {
      console.warn(`⚠️ [QuantityControl] Quantity too high, clamping to ${this.maxQuantity}`);
      this.setInputValue(this.maxQuantity);
      await this.updateQuantity(this.maxQuantity);
      return;
    }

    // If quantity unchanged, just update UI
    if (newQuantity === this.currentQuantity) {
      this.updateButtonStates();
      return;
    }

    await this.updateQuantity(newQuantity);
  }

  /**
   * Update quantity via API
   */
  async updateQuantity(newQuantity) {
    if (this.isUpdating) return;

    console.log(`💾 [QuantityControl] Updating quantity: ${this.currentQuantity} → ${newQuantity}`);

    this.setLoadingState(true);

    try {
      const result = await this.cartAPI.updateQuantity(this.itemId, newQuantity);

      if (result.success) {
        this.currentQuantity = newQuantity;
        this.setInputValue(newQuantity);
        this.updateButtonStates();
        this.clearError();

        console.log(`✅ [QuantityControl] Quantity updated successfully`);
      } else {
        this.showError(result.error);
        this.revertToCurrentQuantity();
        console.error(`❌ [QuantityControl] Update failed: ${result.error}`);
      }
    } catch (error) {
      this.showError('Network error');
      this.revertToCurrentQuantity();
      console.error(`❌ [QuantityControl] Update error:`, error);
    } finally {
      this.setLoadingState(false);
    }
  }

  /**
   * Set input value without triggering events
   */
  setInputValue(value) {
    const input = this.element.querySelector('.qty-input');
    input.value = value;
  }

  /**
   * Update button enabled/disabled states
   */
  updateButtonStates() {
    const decreaseBtn = this.element.querySelector('.qty-decrease');
    const increaseBtn = this.element.querySelector('.qty-increase');

    decreaseBtn.disabled = this.currentQuantity <= this.minQuantity;
    increaseBtn.disabled = this.currentQuantity >= this.maxQuantity;
  }

  /**
   * Set loading state
   */
  setLoadingState(loading) {
    this.isUpdating = loading;

    if (loading) {
      this.element.classList.add('updating');
    } else {
      this.element.classList.remove('updating');
    }

    // Disable all controls during update
    const buttons = this.element.querySelectorAll('.qty-btn');
    const input = this.element.querySelector('.qty-input');

    buttons.forEach(btn => btn.disabled = loading ||
      (btn.classList.contains('qty-decrease') && this.currentQuantity <= this.minQuantity) ||
      (btn.classList.contains('qty-increase') && this.currentQuantity >= this.maxQuantity)
    );

    input.disabled = loading;
  }

  /**
   * Show error state
   */
  showError(message) {
    this.element.classList.add('error');
    this.element.title = `Error: ${message}`;

    // Clear error after 3 seconds
    setTimeout(() => {
      this.clearError();
    }, 3000);
  }

  /**
   * Clear error state
   */
  clearError() {
    this.element.classList.remove('error');
    this.element.title = '';
  }

  /**
   * Revert input to current quantity
   */
  revertToCurrentQuantity() {
    this.setInputValue(this.currentQuantity);
    this.updateButtonStates();
  }

  /**
   * Update quantity from external source
   */
  setQuantity(newQuantity) {
    this.currentQuantity = newQuantity;
    this.setInputValue(newQuantity);
    this.updateButtonStates();
  }

  /**
   * Get current quantity
   */
  getQuantity() {
    return this.currentQuantity;
  }

  /**
   * Cleanup
   */
  destroy() {
    if (this.updateTimeout) {
      clearTimeout(this.updateTimeout);
    }

    if (this.element && this.element.parentNode) {
      this.element.parentNode.removeChild(this.element);
    }
  }
}

// Export for use
window.QuantityControl = QuantityControl;