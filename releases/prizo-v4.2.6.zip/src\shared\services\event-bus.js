/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Event Bus - Central communication system for services
 */
class EventBus {
  constructor() {
    this.listeners = new Map();
    this.debugMode = false;
  }

  on(event, callback, context = null) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    
    this.listeners.get(event).push({ callback, context });
    
    if (this.debugMode) {
      console.log(`📡 EventBus: Registered listener for '${event}'`);
    }
  }

  off(event, callback = null) {
    if (!this.listeners.has(event)) return;
    
    if (callback) {
      const eventListeners = this.listeners.get(event);
      const index = eventListeners.findIndex(listener => listener.callback === callback);
      if (index !== -1) {
        eventListeners.splice(index, 1);
      }
    } else {
      this.listeners.delete(event);
    }
    
    if (this.debugMode) {
      console.log(`📡 EventBus: Removed listener for '${event}'`);
    }
  }

  emit(event, data = null) {
    if (this.debugMode) {
      console.log(`📡 EventBus: Emitting '${event}'`, data);
    }
    
    if (!this.listeners.has(event)) return;
    
    const eventListeners = this.listeners.get(event);
    eventListeners.forEach(({ callback, context }) => {
      try {
        if (context) {
          callback.call(context, data);
        } else {
          callback(data);
        }
      } catch (error) {
        console.error(`❌ EventBus: Error in listener for '${event}':`, error);
      }
    });
  }

  once(event, callback, context = null) {
    const onceCallback = (data) => {
      callback.call(context, data);
      this.off(event, onceCallback);
    };
    
    this.on(event, onceCallback, context);
  }

  clear() {
    this.listeners.clear();
    if (this.debugMode) {
      console.log('📡 EventBus: Cleared all listeners');
    }
  }

  setDebugMode(enabled) {
    this.debugMode = enabled;
  }

  getListenerCount(event) {
    return this.listeners.has(event) ? this.listeners.get(event).length : 0;
  }
}

window.EventBus = EventBus;