/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * UI Helpers - Common UI utilities and helper functions
 */

class UIHelpers extends BaseModule {
  constructor(eventBus, domManager) {
    super('UIHelpers', eventBus, domManager);
  }

  async initializeElements() {
    this.elements = this.domManager.getElements({
      statusElement: '#status',
      errorElement: '#error',
      loadingElement: '#loading',
      pageTypeElement: '#pageType'
    });
  }

  async setupEventListeners() {
    // Listen for UI utility requests
    this.on('ui:show-loading', (data) => this.showLoading(data));
    this.on('ui:hide-loading', (data) => this.hideLoading(data));
    this.on('ui:show-error', (data) => this.showError(data));
    this.on('ui:show-success', (data) => this.showSuccess(data));
    this.on('ui:hide-error', (data) => this.hideError(data));
    this.on('ui:update-page-type', (data) => this.updatePageTypeDisplay(data));
    this.on('ui:resize-image', (data) => this.resizeDigikalaImage(data));

    // Listen for extension info requests
    this.on('extension:load-version', () => this.loadExtensionVersion());
  }

  async loadInitialData() {
    this.loadExtensionVersion();
  }

  // Loading states
  showLoading(data = {}) {
    const { loadingElement } = this.elements;
    const show = data.show !== undefined ? data.show : true;
    const message = data.message || 'در حال بارگذاری...';

    if (loadingElement) {
      if (show) {
        this.domManager.setText(loadingElement, message);
        this.domManager.show(loadingElement);
      } else {
        this.domManager.hide(loadingElement);
      }
    }

    this.emit('ui:loading-state-changed', { show, message });
  }

  hideLoading() {
    this.showLoading({ show: false });
  }

  // Error handling
  showError(data) {
    const { errorElement } = this.elements;
    const message = data.message || data;

    // Emit to message handler
    this.emit('messages:add', {
      type: 'error',
      message: message,
      options: { source: 'ui' }
    });

    // Show in legacy error element for backwards compatibility
    if (errorElement) {
      this.domManager.setHTML(errorElement, `<strong>⚠️ خطا:</strong> ${message}`);
      this.domManager.show(errorElement);

      // Auto-hide after 8 seconds
      setTimeout(() => this.hideError(), 8000);
    }

    this.emit('ui:error-displayed', { message });
  }

  hideError() {
    const { errorElement } = this.elements;
    if (errorElement) {
      this.domManager.hide(errorElement);
    }

    this.emit('ui:error-hidden');
  }

  // Success messages
  showSuccess(data) {
    const { statusElement } = this.elements;
    const message = data.message || data;

    // Emit to message handler
    this.emit('messages:add', {
      type: 'success',
      message: message,
      options: { source: 'ui' }
    });

    // Temporarily show success message in the status
    if (statusElement) {
      const originalHTML = statusElement.innerHTML;
      const originalClass = statusElement.className;

      this.domManager.setHTML(statusElement, `<span>${message}</span><div class="status-icon">✅</div>`);
      statusElement.className = 'status active';

      setTimeout(() => {
        statusElement.innerHTML = originalHTML;
        statusElement.className = originalClass;
      }, 3000);
    }

    this.emit('ui:success-displayed', { message });
  }

  // Page type display
  updatePageTypeDisplay(data) {
    const { pageTypeElement } = this.elements;
    const pageType = data.pageType || data.forcePageType;

    if (!pageTypeElement) return;

    const pageTypeNames = {
      'seller': '🏪 صفحه فروشنده',
      'search': '🔍 صفحه جستجو',
      'category': '📂 صفحه دسته‌بندی',
      'brand': '🏷️ صفحه برند',
      'offers': '🎯 پیشنهادات شگفت‌انگیز',
      'tags': '🏷️ صفحه برچسب‌ها',
      'product': '📦 صفحه محصول',
      'cart': '🛒 سبد خرید',
      'order': '📋 جزئیات سفارش',
      'home': '🏠 صفحه اصلی',
      'homepage': '🏠 صفحه اصلی',
      'fresh-homepage': '🥬 صفحه اصلی سوپرمارکت',
      'wishlist': '❤️ لیست علاقه‌مندی‌ها',
      'listing': '📋 فهرست محصولات',
      'unknown': '❓ صفحه نامشخص',
      'unsupported': '❌ صفحه پشتیبانی نشده'
    };

    const displayText = pageTypeNames[pageType] || '❓ صفحه نامشخص';
    this.domManager.setText(pageTypeElement, displayText);

    this.emit('ui:page-type-updated', { pageType, displayText });

    // Show contextual sections based on page type
    this.updatePageSections(pageType);
  }

  updatePageSections(pageType) {
    const sellerSections = document.querySelectorAll('.seller-only');
    const monthlySections = document.querySelectorAll('.monthly-only');
    const cartSections = document.querySelectorAll('.cart-only');

    // Hide all sections first
    sellerSections.forEach(el => this.domManager.hide(el));
    monthlySections.forEach(el => this.domManager.hide(el));
    cartSections.forEach(el => this.domManager.hide(el));

    // Show relevant sections based on page type
    if (pageType === 'seller') {
      // Seller pages: Show both seller features and monthly features
      sellerSections.forEach(el => this.domManager.show(el));
      monthlySections.forEach(el => this.domManager.show(el));
    } else if (['search', 'category', 'brand', 'offers', 'tags', 'product', 'listing', 'wishlist'].includes(pageType)) {
      // Monthly-only pages: Show only monthly features
      monthlySections.forEach(el => this.domManager.show(el));
    } else if (['cart', 'order'].includes(pageType)) {
      // Cart pages: Show cart features and monthly features
      cartSections.forEach(el => this.domManager.show(el));
      monthlySections.forEach(el => this.domManager.show(el));
    } else if (['homepage', 'fresh-homepage', 'home'].includes(pageType)) {
      // Homepage or Fresh Homepage: Show helpful information and all settings
      monthlySections.forEach(el => this.domManager.show(el));
      cartSections.forEach(el => this.domManager.show(el));

      // Add contextual messages
      if (pageType === 'fresh-homepage') {
        this.emit('messages:add', {
          type: 'info',
          message: 'این صفحه اصلی فروشگاه است. افزونه در صفحات محصول فعال می‌شود.',
          options: { source: 'page-detection' }
        });
      } else {
        this.emit('messages:add', {
          type: 'info',
          message: 'این صفحه اصلی فروشگاه است. افزونه در صفحات محصول و لیست‌ها فعال می‌شود.',
          options: { source: 'page-detection' }
        });
      }
    } else if (pageType === 'unsupported') {
      this.showError('این صفحه توسط افزونه پشتیبانی نمی‌شود. برای مشاهده راهنمای کامل، به بخش "چگونه از افزونه استفاده کنم؟" در پیش روی مراجعه کنید.');
    } else {
      // Unknown or other page types: Show helpful information and settings
      monthlySections.forEach(el => this.domManager.show(el));

      this.emit('messages:add', {
        type: 'info',
        message: 'افزونه آماده استفاده است. ویژگی‌های نظارت قیمت و مقایسه قیمت در دسترس هستند.',
        options: { source: 'page-detection' }
      });
    }
  }

  // Extension version management
  loadExtensionVersion() {
    try {
      const manifest = chrome.runtime.getManifest();
      const versionElement = document.getElementById('extensionVersion');
      const sourceElement = document.getElementById('sourceLink');

      if (versionElement) {
        this.domManager.setText(versionElement, `v${manifest.version}`);
      }

      // Set up source link - you can modify this URL as needed
      if (sourceElement) {
        sourceElement.href = 'https://github.com/zanadeveloper/prizo-extension';
        sourceElement.target = '_blank';
        sourceElement.rel = 'noopener noreferrer';
      }

      this.emit('extension:version-loaded', {
        version: manifest.version,
        name: manifest.name
      });
    } catch (error) {
      this.error('Failed to load extension version:', error);

      const versionElement = document.getElementById('extensionVersion');
      if (versionElement) {
        this.domManager.setText(versionElement, 'نامشخص');
      }
    }
  }

  // Image utilities
  resizeDigikalaImage(data) {
    const { imageUrl, width = 100, height = 100 } = data;

    if (!imageUrl) {
      return '';
    }

    // Check if this is a Digikala image URL with size parameters
    if (imageUrl.includes('dkstatics-public.digikala.com') && imageUrl.includes('x-oss-process=image/resize')) {
      // Replace existing size parameters with new ones
      const resizedUrl = imageUrl.replace(
        /h_\d+,w_\d+/g,
        `h_${height},w_${width}`
      );
      return resizedUrl;
    }

    // If it doesn't have size parameters but is a Digikala image, add them
    if (imageUrl.includes('dkstatics-public.digikala.com')) {
      const separator = imageUrl.includes('?') ? '&' : '?';
      return `${imageUrl}${separator}x-oss-process=image/resize,m_lfit,h_${height},w_${width}/quality,q_90`;
    }

    // Return original URL if not a Digikala image
    return imageUrl;
  }

  // Time utilities
  getTimeAgo(date) {
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);

    if (diffInSeconds < 60) {
      return 'همین حالا';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} دقیقه پیش`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} ساعت پیش`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} روز پیش`;
    }
  }

  // Format utilities
  formatPrice(price, currency = 'تومان') {
    // Handle null, undefined, or non-numeric values
    if (price === null || price === undefined || isNaN(price)) return 'نامشخص';

    // Convert to number if it's a string
    const numericPrice = typeof price === 'string' ? parseFloat(price) : price;

    // Only return 'نامشخص' if price is explicitly 0 or negative
    if (numericPrice <= 0) return 'نامشخص';

    // Convert from rials to tomans if needed
    const tomans = Math.round(numericPrice / 10);
    return `${tomans.toLocaleString('fa-IR')} ${currency}`;
  }

  formatNumber(number, locale = 'fa-IR') {
    if (!number || isNaN(number)) return '0';
    return number.toLocaleString(locale);
  }

  // URL utilities
  extractDomain(url) {
    try {
      return new URL(url).hostname;
    } catch (error) {
      return url;
    }
  }

  isValidUrl(url) {
    try {
      new URL(url);
      return true;
    } catch (error) {
      return false;
    }
  }

  // Storage utilities (complementary to BaseModule)
  async clearAllStorage() {
    try {
      await chrome.storage.local.clear();
      this.showSuccess('تمام داده‌ها پاک شدند');
      this.emit('storage:cleared');
      return true;
    } catch (error) {
      this.error('Error clearing storage:', error);
      this.showError('خطا در پاک کردن داده‌ها');
      return false;
    }
  }

  async exportAllData() {
    try {
      const allData = await chrome.storage.local.get(null);
      const exportData = {
        data: allData,
        timestamp: new Date().toISOString(),
        version: chrome.runtime.getManifest().version
      };

      const dataJSON = JSON.stringify(exportData, null, 2);
      const blob = new Blob([dataJSON], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = this.domManager.createElement('a', {
        attributes: {
          href: url,
          download: `prizo-backup-${Date.now()}.json`
        }
      });

      a.click();
      URL.revokeObjectURL(url);

      this.showSuccess('داده‌ها با موفقیت صادر شدند');
      this.emit('data:exported', { size: Object.keys(allData).length });
      return true;
    } catch (error) {
      this.error('Error exporting data:', error);
      this.showError('خطا در صادرات داده‌ها');
      return false;
    }
  }

  // Animation utilities
  fadeIn(element, duration = 300) {
    if (!element) return;

    element.style.opacity = '0';
    element.style.display = 'block';

    let start = null;
    const animate = (timestamp) => {
      if (!start) start = timestamp;
      const progress = (timestamp - start) / duration;

      element.style.opacity = Math.min(progress, 1);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }

  fadeOut(element, duration = 300) {
    if (!element) return;

    const startOpacity = parseFloat(element.style.opacity) || 1;
    let start = null;

    const animate = (timestamp) => {
      if (!start) start = timestamp;
      const progress = (timestamp - start) / duration;

      element.style.opacity = startOpacity * (1 - Math.min(progress, 1));

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        element.style.display = 'none';
      }
    };

    requestAnimationFrame(animate);
  }

  slideDown(element, duration = 300) {
    if (!element) return;

    element.style.height = '0px';
    element.style.overflow = 'hidden';
    element.style.display = 'block';

    const targetHeight = element.scrollHeight;
    let start = null;

    const animate = (timestamp) => {
      if (!start) start = timestamp;
      const progress = (timestamp - start) / duration;

      element.style.height = (targetHeight * Math.min(progress, 1)) + 'px';

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        element.style.height = '';
        element.style.overflow = '';
      }
    };

    requestAnimationFrame(animate);
  }

  slideUp(element, duration = 300) {
    if (!element) return;

    const startHeight = element.offsetHeight;
    element.style.height = startHeight + 'px';
    element.style.overflow = 'hidden';

    let start = null;
    const animate = (timestamp) => {
      if (!start) start = timestamp;
      const progress = (timestamp - start) / duration;

      element.style.height = (startHeight * (1 - Math.min(progress, 1))) + 'px';

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        element.style.display = 'none';
        element.style.height = '';
        element.style.overflow = '';
      }
    };

    requestAnimationFrame(animate);
  }

  // Accessibility utilities
  announceToScreenReader(message) {
    const announcement = this.domManager.createElement('div', {
      attributes: {
        'aria-live': 'polite',
        'aria-atomic': 'true'
      },
      styles: {
        position: 'absolute',
        left: '-10000px',
        width: '1px',
        height: '1px',
        overflow: 'hidden'
      }
    });

    document.body.appendChild(announcement);
    announcement.textContent = message;

    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 1000);
  }

  // Public API methods
  showLoading(show = true, message = 'در حال بارگذاری...') {
    this.emit('ui:show-loading', { show, message });
  }

  showError(message) {
    this.emit('ui:show-error', { message });
  }

  showSuccess(message) {
    this.emit('ui:show-success', { message });
  }

  updatePageType(pageType) {
    this.emit('ui:update-page-type', { pageType });
  }

  resizeImage(imageUrl, width, height) {
    return this.resizeDigikalaImage({ imageUrl, width, height });
  }

  // Cleanup
  async cleanup() {
    // UIHelpers doesn't need specific cleanup
  }
}

// Make available globally
window.UIHelpers = UIHelpers;