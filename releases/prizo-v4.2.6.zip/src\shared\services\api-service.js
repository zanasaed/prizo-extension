/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * API Service - Handles all external API communications
 * Uses background script's RequestManager instead of duplicating functionality
 * Now optimized to use network interception when possible
 */
class APIService {
  constructor(eventBus) {
    this.eventBus = eventBus;
    this.maxRetries = 3;
    this.retryDelay = 1000;

    // Initialize the optimized API service
    this.initializeOptimizedService();
  }

  /**
   * Initialize the optimized API service with network interception
   */
  initializeOptimizedService() {
    // Check if optimized services are available
    if (typeof OptimizedAPIService !== 'undefined') {
      console.log('🚀 Initializing optimized API service with network interception');
      this.optimizedService = new OptimizedAPIService(this.eventBus);
      this.optimizedService.setFallbackService(this);
      this.isOptimized = true;
    } else {
      console.log('⚠️ Optimized API service not available, using standard API service');
      this.isOptimized = false;
    }
  }

  async fetchProductData(productId, options = {}) {
    try {
      // Use optimized service if available
      if (this.isOptimized && this.optimizedService) {
        console.log(`⚡ Using optimized API service for product ${productId}`);
        return await this.optimizedService.fetchProductData(productId, options);
      }

      // Fallback to original implementation
      console.log(`🔄 Using standard API service for product ${productId}`);
      const data = await this._performProductRequest(productId, options);
      this.eventBus.emit('product:data-fetched', { productId, data });
      return data;
    } catch (error) {
      this.eventBus.emit('product:fetch-error', { productId, error });
      throw error;
    }
  }

  async _performProductRequest(productId, options) {
    try {
      console.log(`📡 Fetching product data for: ${productId}`);

      // Use the same method as the original extension - messaging to background script
      const response = await ExtensionCore.BrowserCompat.safeSendMessage({
        action: 'fetchProductData',
        productId: productId,
        pageType: options.pageType || 'product',
        timeout: options.timeout || 8000,
        currentUrl: window.location?.href || options.currentUrl
      });

      if (response && response.success) {
        console.log('✅ Successfully fetched product data');
        return response.data.product || response.data;
      } else {
        const errorMsg = response?.error || 'Failed to fetch product data';
        console.log('❌ API call failed:', errorMsg);
        throw new Error(errorMsg);
      }
    } catch (error) {
      console.error(`❌ Failed to fetch product data for ${productId}:`, error);
      
      // Don't retry messaging failures to prevent infinite loops
      if (error.message.includes('Messaging API unavailable') ||
          error.message.includes('Extension messaging not supported')) {
        console.log('📱 Messaging unavailable');
        return null;
      }
      
      throw error;
    }
  }

  async fetchSellerData(sellerId, options = {}) {
    try {
      // Use optimized service if available
      if (this.isOptimized && this.optimizedService) {
        console.log(`⚡ Using optimized API service for seller ${sellerId}`);
        return await this.optimizedService.fetchSellerData(sellerId, options);
      }

      // Fallback to original implementation
      console.log(`🔄 Using standard API service for seller ${sellerId}`);
      // Use background script messaging for consistency
      const response = await ExtensionCore.BrowserCompat.safeSendMessage({
        action: 'fetchProductData',
        productId: sellerId,
        pageType: 'seller',
        timeout: options.timeout || 8000
      });

      if (response && response.success) {
        const data = response.data;
        this.eventBus.emit('seller:data-fetched', { sellerId, data });
        return data;
      } else {
        throw new Error(response?.error || 'Failed to fetch seller data');
      }
    } catch (error) {
      this.eventBus.emit('seller:fetch-error', { sellerId, error });
      throw error;
    }
  }

  async fetchWithRetry(fetchFunction, maxRetries = this.maxRetries) {
    let lastError;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await fetchFunction();
      } catch (error) {
        lastError = error;
        
        if (attempt < maxRetries) {
          const delay = this.retryDelay * Math.pow(2, attempt - 1);
          console.log(`🔄 Retry attempt ${attempt}/${maxRetries} after ${delay}ms`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
    
    throw lastError;
  }

  async clearCache() {
    try {
      // Clear optimized service cache if available
      if (this.isOptimized && this.optimizedService) {
        await this.optimizedService.clearCache();
      }

      // Delegate to background script's cache management
      await ExtensionCore.BrowserCompat.safeSendMessage({
        action: 'clearCache'
      });
      console.log('🧹 API cache cleared via background script');
    } catch (error) {
      console.warn('Failed to clear cache:', error);
    }
  }

  getCacheStats() {
    if (this.isOptimized && this.optimizedService) {
      return {
        optimization: this.optimizedService.getPerformanceStats(),
        interceptor: this.optimizedService.getInterceptorStatus(),
        note: 'Using optimized API service with network interception'
      };
    }

    // Cache stats are managed by background script
    return {
      note: 'Cache managed by background script RequestManager'
    };
  }

  /**
   * Get performance statistics from the optimized service
   */
  getPerformanceStats() {
    if (this.isOptimized && this.optimizedService) {
      return this.optimizedService.getPerformanceStats();
    }
    return {
      message: 'Performance stats not available - using standard API service'
    };
  }

  /**
   * Check if network interception is active
   */
  isNetworkInterceptionActive() {
    if (this.isOptimized && this.optimizedService) {
      return this.optimizedService.isOptimizationActive();
    }
    return false;
  }

  /**
   * Fetch seller vouchers for a product
   * @param {string} productId - The product ID to fetch vouchers for
   * @param {Object} options - Optional parameters
   * @returns {Promise<Object>} - Voucher data from Digikala API
   */
  async fetchSellerVouchers(productId, options = {}) {
    try {
      console.log(`🎟️ Fetching seller vouchers for product: ${productId}`);

      // Use background script messaging for API call
      const response = await ExtensionCore.BrowserCompat.safeSendMessage({
        action: 'fetchSellerVouchers',
        productId: productId,
        timeout: options.timeout || 8000,
        currentUrl: window.location?.href || options.currentUrl
      });

      if (response && response.success) {
        console.log('✅ Successfully fetched voucher data');
        this.eventBus.emit('vouchers:data-fetched', { productId, data: response.data });
        return response.data;
      } else {
        const errorMsg = response?.error || 'Failed to fetch voucher data';
        console.log('❌ Voucher API call failed:', errorMsg);
        throw new Error(errorMsg);
      }
    } catch (error) {
      console.error(`❌ Failed to fetch vouchers for product ${productId}:`, error);
      this.eventBus.emit('vouchers:fetch-error', { productId, error });

      // Don't retry messaging failures to prevent infinite loops
      if (error.message.includes('Messaging API unavailable') ||
          error.message.includes('Extension messaging not supported')) {
        console.log('📱 Messaging unavailable for vouchers');
        return null;
      }

      throw error;
    }
  }
}

window.APIService = APIService;