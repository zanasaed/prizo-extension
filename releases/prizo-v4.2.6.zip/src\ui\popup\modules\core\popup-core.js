/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Popup Core - Initialize core infrastructure for popup modules
 */

class PopupCore {
  constructor() {
    this.eventBus = null;
    this.domManager = null;
    this.modules = new Map();
    this.initialized = false;
  }

  async init() {
    if (this.initialized) {
      console.warn('PopupCore already initialized');
      return;
    }

    try {
      // Initialize core components
      this.eventBus = new EventBus();
      this.domManager = new DOMManager();

      // Enable debug mode in development
      if (this.isDevelopment()) {
        this.eventBus.setDebugMode(true);
        this.domManager.setDebugMode(true);
      }

      // Make instances globally available
      window.popupEventBus = this.eventBus;
      window.popupDOMManager = this.domManager;

      // Set up core event listeners
      this.setupCoreEventListeners();

      this.initialized = true;
      console.log('✅ PopupCore initialized successfully');

      // Emit initialization complete event
      this.eventBus.emit('core:initialized', {
        eventBus: this.eventBus,
        domManager: this.domManager
      });

    } catch (error) {
      console.error('❌ Failed to initialize PopupCore:', error);
      throw error;
    }
  }

  setupCoreEventListeners() {
    // Handle module registration
    this.eventBus.on('module:register', (data) => {
      this.registerModule(data.name, data.module);
    });

    // Handle module deregistration
    this.eventBus.on('module:unregister', (data) => {
      this.unregisterModule(data.name);
    });

    // Handle global loading states
    this.eventBus.on('ui:loading', (data) => {
      this.handleGlobalLoading(data);
    });

    // Handle global errors
    this.eventBus.on('ui:error', (data) => {
      this.handleGlobalError(data);
    });

    // Handle global success messages
    this.eventBus.on('ui:success', (data) => {
      this.handleGlobalSuccess(data);
    });

    // Handle hiding errors
    this.eventBus.on('ui:hideError', () => {
      this.hideGlobalError();
    });

    // Handle cleanup on page unload
    window.addEventListener('beforeunload', () => {
      this.cleanup();
    });
  }

  registerModule(name, module) {
    if (this.modules.has(name)) {
      console.warn(`Module ${name} is already registered`);
      return;
    }

    this.modules.set(name, module);
    console.log(`📦 Module ${name} registered`);
  }

  unregisterModule(name) {
    if (!this.modules.has(name)) {
      console.warn(`Module ${name} is not registered`);
      return;
    }

    const module = this.modules.get(name);
    if (module && typeof module.destroy === 'function') {
      module.destroy();
    }

    this.modules.delete(name);
    console.log(`📦 Module ${name} unregistered`);
  }

  getModule(name) {
    return this.modules.get(name);
  }

  getAllModules() {
    return Array.from(this.modules.values());
  }

  // Global UI state handlers
  handleGlobalLoading(data) {
    const loadingElement = this.domManager.getElementById('loading');
    if (loadingElement) {
      this.domManager.toggle(loadingElement, data.show);
    }
  }

  handleGlobalError(data) {
    const errorElement = this.domManager.getElementById('error');
    if (errorElement) {
      this.domManager.setText(errorElement, data.message);
      this.domManager.show(errorElement);
    }
  }

  handleGlobalSuccess(data) {
    const statusElement = this.domManager.getElementById('status');
    if (statusElement) {
      this.domManager.setText(statusElement, data.message);
      this.domManager.removeClass(statusElement, 'error');
      this.domManager.addClass(statusElement, 'success');
      this.domManager.show(statusElement);
    }
  }

  hideGlobalError() {
    const errorElement = this.domManager.getElementById('error');
    if (errorElement) {
      this.domManager.hide(errorElement);
    }
  }

  // Utility methods
  isDevelopment() {
    return !('update_url' in chrome.runtime.getManifest());
  }

  async cleanup() {
    console.log('🧹 PopupCore cleanup started');

    // Destroy all modules
    for (const [name, module] of this.modules) {
      try {
        if (module && typeof module.destroy === 'function') {
          await module.destroy();
        }
      } catch (error) {
        console.error(`Error destroying module ${name}:`, error);
      }
    }

    this.modules.clear();

    // Cleanup core components
    if (this.domManager) {
      this.domManager.destroy();
    }

    if (this.eventBus) {
      this.eventBus.removeAllListeners();
    }

    this.initialized = false;
    console.log('✅ PopupCore cleanup completed');
  }

  // Debug utilities
  logStats() {
    console.log('📊 PopupCore Statistics:');
    console.log(`- Initialized: ${this.initialized}`);
    console.log(`- Registered modules: ${this.modules.size}`);

    if (this.modules.size > 0) {
      console.log('- Modules:');
      for (const [name, module] of this.modules) {
        console.log(`  - ${name}: ${module.constructor.name}`);
      }
    }

    if (this.eventBus) {
      this.eventBus.logStats();
    }

    if (this.domManager) {
      this.domManager.logCacheStats();
    }
  }
}

// Create and initialize global instance
window.PopupCore = PopupCore;

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', async () => {
    const core = new PopupCore();
    await core.init();
    window.popupCore = core;
  });
} else {
  // DOM already ready
  (async () => {
    const core = new PopupCore();
    await core.init();
    window.popupCore = core;
  })();
}