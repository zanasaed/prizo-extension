/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-05
 * Constants - Centralized configuration values
 */
class ExtensionConstants {
  static get TIMING() {
    return {
      CACHE_EXPIRATION: 5 * 60 * 1000, // 5 minutes
      RETRY_DELAY: 1000, // 1 second
      DEFAULT_DELAY: 800, // Default processing delay
      REQUEST_TIMEOUT: 10000, // 10 seconds
      DEBOUNCE_DELAY: 300, // 300ms debounce
      ANIMATION_DURATION: 250 // Animation duration
    };
  }

  static get API() {
    return {
      BASE_URL: 'https://api.digikala.com',
      ENDPOINTS: {
        PRODUCT_V2: '/v2/product/{productId}/',
        PRODUCT_V1: '/v1/product/{productId}/',
        SELLER: '/v1/seller/{sellerId}/',
        SEARCH: '/v1/search/',
        // Fresh/Supermarket endpoints
        FRESH_PRODUCT: '/fresh/v1/product/{productId}/?_whid=1',
        FRESH_CATEGORY: '/fresh/v1/categories/{categorySlug}/search/?_whid=1&seo_url=&page=1',
        FRESH_SEARCH: '/fresh/v1/search/?_whid=1&q={query}&seo_url=&page=1'
      },
      MAX_RETRIES: 3,
      MAX_TOKENS: 10,
      TIMEOUT: 10000
    };
  }

  static get CACHE() {
    return {
      MAX_SIZE: 100,
      EXPIRATION: 5 * 60 * 1000, // 5 minutes
      KEYS: {
        PRODUCT_DATA: 'product_data_',
        SELLER_DATA: 'seller_data_',
        MONTHLY_PRICES: 'monthly_prices_',
        USER_SETTINGS: 'user_settings'
      }
    };
  }

  static get SELECTORS() {
    return {
      PRODUCT: {
        PRICE_CONTAINER: '.c-price, .ProductPrice, .c-ProductPrice',
        PRODUCT_CARD: '.c-product-box, .ProductCard, .product-card',
        PRODUCT_ID: '[data-product-id], [data-dkp]',
        PRICE_ELEMENT: '.c-price__value, .price-value, .price',
        DISCOUNT_PERCENT: '.c-price__discount-percent, .discount-percent'
      },
      CART: {
        ITEM: '.c-cart-item, .cart-item',
        PRICE: '.c-cart-item-price, .cart-item-price',
        QUANTITY: '.c-cart-item-quantity, .cart-item-quantity'
      },
      SELLER: {
        PRICE_CONTAINER: '.seller-price-container',
        INFO: '.seller-info, .seller-details'
      },
      SORT: {
        HEADER_SORT: '.styles_HeaderSort__SortList__OPEV3',
        SORT_OPTIONS: '.sort-options, .sorting-dropdown'
      }
    };
  }

  static get REGEX() {
    return {
      PRODUCT_ID: {
        DKP: /\/product\/dkp-(\d+)\//,
        DP: /\/dp\/(\d+)\//,
        GENERIC: /dkp-(\d+)/
      },
      PRICE: {
        NUMBERS_ONLY: /\d+/g,
        PRICE_FORMAT: /[^\d]/g
      },
      URL: {
        SELLER_PAGE: /\/seller\//,
        PRODUCT_PAGE: /\/product\//,
        CART_PAGE: /\/checkout\/cart/,
        WISHLIST_PAGE: /\/profile\/(lists|wishlist)/,
        FRESH_SECTION: /\/fresh\//
      }
    };
  }

  static get MESSAGES() {
    return {
      ERRORS: {
        PRODUCT_NOT_FOUND: 'محصول یافت نشد',
        NETWORK_ERROR: 'خطا در برقراری ارتباط',
        INVALID_DATA: 'داده‌های نامعتبر',
        STORAGE_ERROR: 'خطا در ذخیره‌سازی',
        PERMISSION_DENIED: 'دسترسی مجاز نیست'
      },
      SUCCESS: {
        DATA_LOADED: 'داده‌ها بارگذاری شد',
        SETTINGS_SAVED: 'تنظیمات ذخیره شد',
        CACHE_CLEARED: 'کش پاک شد'
      },
      STATUS: {
        LOADING: 'در حال بارگذاری...',
        PROCESSING: 'در حال پردازش...',
        READY: 'آماده',
        ERROR: 'خطا'
      }
    };
  }

  static get STYLING() {
    return {
      CLASSES: {
        PRICE_BADGE: 'digikala-price-badge',
        LOADING: 'loading-spinner',
        ERROR: 'error-state',
        SUCCESS: 'success-state',
        HIDDEN: 'hidden'
      },
      COLORS: {
        PRIMARY: '#ef394e',
        SUCCESS: '#00a046',
        WARNING: '#ff9500',
        ERROR: '#ee384e',
        GRAY: '#81858b'
      }
    };
  }

  static get FEATURES() {
    return {
      PERSISTENT_MODE: 'persistentMode',
      SORT_FEATURE: 'sortFeatureMode',
      CART_FEATURE: 'cartFeatureMode',
      NETWORK_STABILITY: 'networkStabilityCheck',
      GLOBAL_DELAY: 'globalDelayRange'
    };
  }

  static get PAGE_TYPES() {
    return {
      HOMEPAGE: 'homepage',
      PRODUCT_LIST: 'product-list',
      PRODUCT_DETAIL: 'product-detail',
      SELLER: 'seller',
      CART: 'cart',
      WISHLIST: 'wishlist',
      UNKNOWN: 'unknown'
    };
  }

  static get STORAGE_KEYS() {
    return {
      EXTENSION_SETTINGS: 'extensionSettings',
      CACHE_DATA: 'cacheData',
      USER_PREFERENCES: 'userPreferences',
      FEATURE_FLAGS: 'featureFlags'
    };
  }
}

if (typeof window !== 'undefined') {
  window.ExtensionConstants = ExtensionConstants;
}