/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Popup Integration - Initializes and coordinates all popup modules
 */

class PopupIntegration {
  constructor() {
    this.modules = new Map();
    this.initialized = false;
    this.eventBus = null;
    this.domManager = null;
  }

  async init() {
    if (this.initialized) {
      console.warn('PopupIntegration already initialized');
      return;
    }

    try {
      // Wait for core to be ready
      await this.waitForCore();

      this.eventBus = window.popupEventBus;
      this.domManager = window.popupDOMManager;

      // Initialize all modules
      await this.initializeModules();

      // Setup inter-module communication
      this.setupCommunication();

      // Setup legacy bridge
      this.setupLegacyBridge();

      this.initialized = true;
      console.log('✅ PopupIntegration initialized successfully');

      // Signal that the new system is ready
      this.eventBus.emit('popup:integration-ready', {
        modules: Array.from(this.modules.keys())
      });

    } catch (error) {
      console.error('❌ Failed to initialize PopupIntegration:', error);
      throw error;
    }
  }

  async waitForCore() {
    return new Promise((resolve) => {
      const checkCore = () => {
        if (window.popupCore && window.popupEventBus && window.popupDOMManager) {
          resolve();
        } else {
          setTimeout(checkCore, 10);
        }
      };
      checkCore();
    });
  }

  async initializeModules() {
    // Check if Smart Cart feature is enabled
    let smartCartEnabled = false;
    try {
      const result = await chrome.storage.sync.get(['smartCartEnabled']);
      smartCartEnabled = result.smartCartEnabled || false;
    } catch (error) {
      console.warn('⚠️ Could not check Smart Cart feature status in popup:', error);
    }

    // Initialize modules in dependency order
    const moduleConfigs = [
      // Core UI modules first
      {
        name: 'UIHelpers',
        class: UIHelpers,
        priority: 1
      },
      {
        name: 'ModalManager',
        class: ModalManager,
        priority: 2
      },
      {
        name: 'NotificationManager',
        class: NotificationManager,
        priority: 3
      },
      {
        name: 'TabManager',
        class: TabManager,
        priority: 4
      },
      {
        name: 'ButtonManager',
        class: ButtonManager,
        priority: 5
      },
      // Feature modules
      {
        name: 'SettingsManager',
        class: SettingsManager,
        priority: 6
      },
      {
        name: 'WatchlistManager',
        class: WatchlistManager,
        priority: 7
      },
      {
        name: 'ComparisonManager',
        class: ComparisonManager,
        priority: 8
      },
      // Communication modules last
      {
        name: 'MessageHandler',
        class: MessageHandler,
        priority: 9
      },
      {
        name: 'ExtensionBridge',
        class: ExtensionBridge,
        priority: 10
      }
    ];

    // Only add SmartCartManager if the feature is enabled
    if (smartCartEnabled) {
      console.log('✅ Smart Cart feature enabled - adding SmartCartManager to popup');
      moduleConfigs.push({
        name: 'SmartCartManager',
        class: SmartCartManager,
        priority: 8.5
      });
    } else {
      console.log('🚫 Smart Cart feature disabled - skipping SmartCartManager initialization in popup');

      // Hide Smart Cart section in the popup
      try {
        const smartCartSection = document.getElementById('smartCartSection');
        if (smartCartSection) {
          smartCartSection.style.display = 'none';
        }

        const smartCartModal = document.getElementById('smartCartModal');
        if (smartCartModal) {
          smartCartModal.style.display = 'none';
        }
      } catch (error) {
        console.warn('⚠️ Error hiding Smart Cart UI elements:', error);
      }
    }

    // Sort by priority
    moduleConfigs.sort((a, b) => a.priority - b.priority);

    // Initialize each module
    for (const config of moduleConfigs) {
      try {
        const module = new config.class(this.eventBus, this.domManager);
        await module.init();

        this.modules.set(config.name, module);
        console.log(`✅ ${config.name} initialized`);

        // Make modules globally accessible for debugging
        window[`popup${config.name}`] = module;

      } catch (error) {
        console.error(`❌ Failed to initialize ${config.name}:`, error);

        // Continue with other modules even if one fails
        this.modules.set(config.name, null);
      }
    }

    console.log(`📦 Initialized ${this.modules.size} modules`);
  }

  setupCommunication() {
    // Cross-module communication patterns

    // Tab switching affects multiple modules
    this.eventBus.on('tab:switched', (data) => {
      // Notify watchlist when switching to watchlist tab
      if (data.currentTab === 0) {
        this.eventBus.emit('watchlist:tab-activated');
      }

      // Notify other modules as needed
      this.eventBus.emit('tab:changed', data);
    });

    // Settings changes affect multiple modules
    this.eventBus.on('settings:setting-changed', (data) => {
      // Notify extension bridge of setting changes
      this.eventBus.emit('extension:setting-changed', data);
    });

    // Extension status changes affect UI
    this.eventBus.on('extension:status-received', (data) => {
      this.eventBus.emit('ui:extension-status-updated', data);
    });

    // Watchlist changes affect tabs (badge updates)
    this.eventBus.on('watchlist:summary-loaded', (data) => {
      const tabManager = this.modules.get('TabManager');
      if (tabManager) {
        tabManager.updateTabBadge(0, { count: data.activeCount, type: 'info' });
      }
    });

    console.log('🔗 Inter-module communication setup complete');
  }

  setupLegacyBridge() {
    // Bridge legacy PopupController with new modules
    this.eventBus.on('popup:controller-ready', (data) => {
      const popupController = data.controller;

      if (popupController) {
        this.bridgePopupController(popupController);
      }
    });

    // Wait for existing PopupController
    setTimeout(() => {
      if (window.popupController) {
        this.bridgePopupController(window.popupController);
      }
    }, 100);
  }

  bridgePopupController(popupController) {
    console.log('🔗 Bridging legacy PopupController with new modules');

    // Bridge success/error methods
    const originalShowSuccess = popupController.showSuccess?.bind(popupController);
    const originalShowError = popupController.showError?.bind(popupController);
    const originalShowLoading = popupController.showLoading?.bind(popupController);
    const originalHideError = popupController.hideError?.bind(popupController);

    // Override methods to emit events for new modules
    if (originalShowSuccess) {
      popupController.showSuccess = (message) => {
        originalShowSuccess(message);
        this.eventBus.emit('ui:success', { message, source: 'legacy' });
      };
    }

    if (originalShowError) {
      popupController.showError = (message) => {
        originalShowError(message);
        this.eventBus.emit('ui:error', { message, source: 'legacy' });
      };
    }

    if (originalShowLoading) {
      popupController.showLoading = (show) => {
        originalShowLoading(show);
        this.eventBus.emit('ui:loading', { show, source: 'legacy' });
      };
    }

    if (originalHideError) {
      popupController.hideError = () => {
        originalHideError();
        this.eventBus.emit('ui:hideError', { source: 'legacy' });
      };
    }

    // Bridge extension communication methods
    const extensionBridge = this.modules.get('ExtensionBridge');
    if (extensionBridge) {
      // Replace direct chrome API calls with module calls
      if (popupController.getExtensionStatus) {
        popupController.getExtensionStatus = () => {
          return extensionBridge.getExtensionStatus();
        };
      }

      if (popupController.handleToggle) {
        popupController.handleToggle = () => {
          return extensionBridge.handleToggle();
        };
      }

      if (popupController.handleUpdate) {
        popupController.handleUpdate = () => {
          return extensionBridge.handleUpdate();
        };
      }
    }

    // Bridge watchlist methods
    const watchlistManager = this.modules.get('WatchlistManager');
    if (watchlistManager) {
      if (popupController.loadWatchlistSummary) {
        popupController.loadWatchlistSummary = () => {
          return watchlistManager.loadWatchlistSummary();
        };
      }

      if (popupController.showWatchlistModal) {
        popupController.showWatchlistModal = () => {
          return watchlistManager.showWatchlistModal();
        };
      }

      if (popupController.refreshWatchlist) {
        popupController.refreshWatchlist = () => {
          return watchlistManager.refreshWatchlist();
        };
      }
    }

    // Bridge settings methods
    const settingsManager = this.modules.get('SettingsManager');
    if (settingsManager) {
      if (popupController.loadSettingsFromStorage) {
        popupController.loadSettingsFromStorage = () => {
          return settingsManager.loadAllSettings();
        };
      }
    }

    // Bridge tab methods
    const tabManager = this.modules.get('TabManager');
    if (tabManager) {
      if (popupController.switchToTab) {
        popupController.switchToTab = (index) => {
          return tabManager.switchToTab(index);
        };
      }

      if (popupController.initTabs) {
        popupController.initTabs = () => {
          // Already initialized by module, just signal ready
          this.eventBus.emit('tabs:legacy-init-requested');
        };
      }
    }

    console.log('✅ Legacy bridge setup complete');
  }

  // Public API for external access
  getModule(name) {
    return this.modules.get(name);
  }

  getAllModules() {
    return new Map(this.modules);
  }

  isInitialized() {
    return this.initialized;
  }

  async reinitializeModule(name) {
    const module = this.modules.get(name);
    if (module && typeof module.destroy === 'function') {
      await module.destroy();
    }

    // Find module config and reinitialize
    const moduleClasses = {
      NotificationManager,
      TabManager,
      SettingsManager,
      WatchlistManager,
      ExtensionBridge
    };

    // Only include SmartCartManager if the feature is enabled
    try {
      const result = await chrome.storage.sync.get(['smartCartEnabled']);
      const smartCartEnabled = result.smartCartEnabled || false;
      if (smartCartEnabled && typeof SmartCartManager !== 'undefined') {
        moduleClasses.SmartCartManager = SmartCartManager;
      }
    } catch (error) {
      console.warn('⚠️ Could not check Smart Cart feature status for reinitialize:', error);
    }

    if (moduleClasses[name]) {
      try {
        const newModule = new moduleClasses[name](this.eventBus, this.domManager);
        await newModule.init();

        this.modules.set(name, newModule);
        window[`popup${name}`] = newModule;

        console.log(`✅ ${name} reinitialized successfully`);
        return true;
      } catch (error) {
        console.error(`❌ Failed to reinitialize ${name}:`, error);
        return false;
      }
    }

    return false;
  }

  // Debug utilities
  logStatus() {
    console.log('📊 PopupIntegration Status:');
    console.log(`- Initialized: ${this.initialized}`);
    console.log(`- Modules: ${this.modules.size}`);

    for (const [name, module] of this.modules) {
      console.log(`  - ${name}: ${module ? '✅' : '❌'}`);
    }

    if (this.eventBus) {
      this.eventBus.logStats();
    }
  }

  // Cleanup
  async destroy() {
    console.log('🧹 PopupIntegration cleanup started');

    // Destroy all modules
    for (const [name, module] of this.modules) {
      if (module && typeof module.destroy === 'function') {
        try {
          await module.destroy();
          console.log(`✅ ${name} destroyed`);
        } catch (error) {
          console.error(`❌ Error destroying ${name}:`, error);
        }
      }
    }

    this.modules.clear();
    this.initialized = false;

    console.log('✅ PopupIntegration cleanup complete');
  }
}

// Initialize integration when DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
  try {
    const integration = new PopupIntegration();
    await integration.init();

    // Make globally accessible
    window.popupIntegration = integration;

  } catch (error) {
    console.error('Failed to initialize popup integration:', error);
  }
});

// Make class available globally for debugging
window.PopupIntegration = PopupIntegration;