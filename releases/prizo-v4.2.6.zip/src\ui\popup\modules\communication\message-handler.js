/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Message Handler - Manages system messages and notifications
 */

class MessageHandler extends BaseModule {
  constructor(eventBus, domManager) {
    super('MessageHandler', eventBus, domManager);

    this.systemMessages = [];
    this.maxMessages = 50;
  }

  async initializeElements() {
    this.elements = this.domManager.getElements({
      messagesBadge: '#messagesBadge',
      clearMessagesBtn: '#clearMessagesBtn',
      messagesContainer: '#messagesContainer'
    });

    const validation = this.domManager.validateElements(this.elements, ['messagesContainer']);
    if (!validation.valid) {
      this.warn('Some message elements are missing:', validation.missing);
    }
  }

  async setupEventListeners() {
    // Listen for external message events
    this.on('messages:add', (data) => this.handleAddMessage(data));
    this.on('messages:clear', () => this.clearSystemMessages());
    this.on('messages:clear-requested', () => this.clearSystemMessages());
    this.on('messages:tab-activated', (data) => this.handleTabActivated(data));

    // Listen for UI events that should generate messages
    this.on('ui:error', (data) => this.handleUIError(data));
    this.on('ui:success', (data) => this.handleUISuccess(data));
    this.on('ui:warning', (data) => this.handleUIWarning(data));
    this.on('ui:info', (data) => this.handleUIInfo(data));

    // Setup clear button
    const { clearMessagesBtn } = this.elements;
    if (clearMessagesBtn) {
      this.domManager.addEventListener(clearMessagesBtn, 'click', () => this.clearSystemMessages());
    }

    // Setup event delegation for message action buttons
    this.setupMessageActionListeners();
  }

  setupMessageActionListeners() {
    const { messagesContainer } = this.elements;
    if (!messagesContainer) return;

    // Use event delegation to handle dynamically created buttons
    this.domManager.addEventListener(messagesContainer, 'click', (event) => {
      const target = event.target;

      // Handle mark-read button clicks
      if (target.classList.contains('mark-read')) {
        event.preventDefault();
        event.stopPropagation();

        // Skip if button is disabled
        if (target.disabled) {
          return;
        }

        const messageItem = target.closest('.message-item');
        if (messageItem) {
          const messageId = parseInt(messageItem.dataset.messageId);
          if (messageId) {
            this.handleMarkAsRead(messageId);
          }
        }
      }

      // Handle delete-message button clicks
      else if (target.classList.contains('delete-message')) {
        event.preventDefault();
        event.stopPropagation();

        const messageItem = target.closest('.message-item');
        if (messageItem) {
          const messageId = parseInt(messageItem.dataset.messageId);
          if (messageId) {
            this.handleDeleteMessage(messageId);
          }
        }
      }
    });
  }

  handleMarkAsRead(messageId) {
    const message = this.systemMessages.find(msg => msg.id === messageId);
    if (message && !message.read) {
      this.log(`Marking message ${messageId} as read`);
      this.markAsRead(messageId);
    }
  }

  handleDeleteMessage(messageId) {
    const message = this.systemMessages.find(msg => msg.id === messageId);
    if (message) {
      this.log(`Deleting message ${messageId}`);
      this.deleteMessage(messageId);
    }
  }

  async loadInitialData() {
    await this.loadSystemMessages();
  }

  // Core message management
  async loadSystemMessages() {
    try {
      const systemMessages = await this.getStorage('systemMessages', []);
      this.systemMessages = systemMessages;

      this.updateMessagesBadge();
      this.renderSystemMessages();

      this.log(`Loaded ${this.systemMessages.length} system messages`);
      this.emit('messages:loaded', { count: this.systemMessages.length });
    } catch (error) {
      this.error('Error loading system messages:', error);
      this.systemMessages = [];
    }
  }

  async saveSystemMessages() {
    try {
      await this.setStorage('systemMessages', this.systemMessages);
      this.emit('messages:saved', { count: this.systemMessages.length });
    } catch (error) {
      this.error('Error saving system messages:', error);
    }
  }

  addSystemMessage(type, message, options = {}) {
    const timestamp = options.timestamp || new Date().toISOString();
    const messageObj = {
      id: options.id || Date.now(),
      type: type, // 'error', 'warning', 'info', 'success'
      message: message,
      timestamp: timestamp,
      source: options.source || 'system',
      read: false
    };

    this.systemMessages.unshift(messageObj);

    // Keep only last N messages
    if (this.systemMessages.length > this.maxMessages) {
      this.systemMessages = this.systemMessages.slice(0, this.maxMessages);
    }

    this.saveSystemMessages();
    this.updateMessagesBadge();
    this.renderSystemMessages();

    this.emit('messages:message-added', { message: messageObj });

    this.log(`Added ${type} message: ${message}`);
    return messageObj.id;
  }

  async clearSystemMessages() {
    this.systemMessages = [];
    await this.saveSystemMessages();
    this.updateMessagesBadge();
    this.renderSystemMessages();

    this.emit('messages:cleared');
    this.log('System messages cleared');
  }

  // UI update methods
  updateMessagesBadge() {
    const { messagesBadge } = this.elements;
    if (!messagesBadge) return;

    const unreadCount = this.systemMessages.filter(msg => !msg.read).length;

    if (unreadCount > 0) {
      const displayCount = unreadCount > 99 ? '99+' : unreadCount.toString();
      this.domManager.setText(messagesBadge, displayCount);
      this.domManager.removeClass(messagesBadge, 'hidden');
    } else {
      this.domManager.addClass(messagesBadge, 'hidden');
    }

    this.emit('messages:badge-updated', { count: unreadCount });
  }

  renderSystemMessages() {
    const { messagesContainer } = this.elements;
    if (!messagesContainer) return;

    if (this.systemMessages.length === 0) {
      this.domManager.setHTML(messagesContainer, this.getEmptyStateHTML());
      return;
    }

    const messagesHTML = this.systemMessages.map(msg => this.generateMessageHTML(msg)).join('');
    this.domManager.setHTML(messagesContainer, messagesHTML);

    this.emit('messages:rendered', { count: this.systemMessages.length });
  }

  getEmptyStateHTML() {
    return `
      <div class="empty-state">
        <div class="empty-icon">💬</div>
        <h4>بدون پیام</h4>
        <p>هیچ پیام سیستمی وجود ندارد</p>
      </div>
    `;
  }

  generateMessageHTML(msg) {
    const date = new Date(msg.timestamp);
    const timeAgo = this.getTimeAgo(date);

    const icons = {
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️',
      success: '✅'
    };

    const readClass = msg.read ? 'read' : 'unread';

    return `
      <div class="message-item ${msg.type} ${readClass}" data-message-id="${msg.id}">
        <div class="message-meta">
          <span>${icons[msg.type] || 'ℹ️'} ${this.getTypeLabel(msg.type)}</span>
          <span>${timeAgo}</span>
          ${msg.source !== 'system' ? `<span class="message-source">${msg.source}</span>` : ''}
        </div>
        <div class="message-text">${msg.message}</div>
        <div class="message-actions">
          <button class="message-action-btn mark-read" title="${msg.read ? 'پیام خوانده‌شده است' : 'علامت‌گذاری به‌عنوان خوانده‌شده'}" ${msg.read ? 'disabled' : ''}>
            📖
          </button>
          <button class="message-action-btn delete-message" title="حذف پیام">
            🗑️
          </button>
        </div>
      </div>
    `;
  }

  getTypeLabel(type) {
    const labels = {
      error: 'خطا',
      warning: 'هشدار',
      info: 'اطلاعات',
      success: 'موفقیت'
    };
    return labels[type] || 'پیام';
  }

  getTimeAgo(date) {
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);

    if (diffInSeconds < 60) {
      return 'همین حالا';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} دقیقه پیش`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} ساعت پیش`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} روز پیش`;
    }
  }

  // Event handlers
  handleAddMessage(data) {
    this.addSystemMessage(data.type, data.message, data.options);
  }

  handleUIError(data) {
    if (data.source !== 'MessageHandler') { // Prevent loops
      this.addSystemMessage('error', data.message, { source: data.source || 'ui' });
    }
  }

  handleUISuccess(data) {
    if (data.source !== 'MessageHandler') {
      this.addSystemMessage('success', data.message, { source: data.source || 'ui' });
    }
  }

  handleUIWarning(data) {
    if (data.source !== 'MessageHandler') {
      this.addSystemMessage('warning', data.message, { source: data.source || 'ui' });
    }
  }

  handleUIInfo(data) {
    if (data.source !== 'MessageHandler') {
      this.addSystemMessage('info', data.message, { source: data.source || 'ui' });
    }
  }

  handleTabActivated() {
    // Mark messages as read when messages tab is activated
    this.markAllAsRead();
  }

  // Message actions
  markAsRead(messageId) {
    const message = this.systemMessages.find(msg => msg.id === messageId);
    if (message) {
      message.read = true;
      this.saveSystemMessages();
      this.updateMessagesBadge();
      this.renderSystemMessages();

      this.emit('messages:message-read', { messageId });
    }
  }

  markAllAsRead() {
    let changed = false;
    this.systemMessages.forEach(msg => {
      if (!msg.read) {
        msg.read = true;
        changed = true;
      }
    });

    if (changed) {
      this.saveSystemMessages();
      this.updateMessagesBadge();
      this.renderSystemMessages();

      this.emit('messages:all-read');
    }
  }

  deleteMessage(messageId) {
    const index = this.systemMessages.findIndex(msg => msg.id === messageId);
    if (index !== -1) {
      const deletedMessage = this.systemMessages.splice(index, 1)[0];

      this.saveSystemMessages();
      this.updateMessagesBadge();
      this.renderSystemMessages();

      this.emit('messages:message-deleted', { messageId, message: deletedMessage });
    }
  }

  // Filter and search
  getMessagesByType(type) {
    return this.systemMessages.filter(msg => msg.type === type);
  }

  getUnreadMessages() {
    return this.systemMessages.filter(msg => !msg.read);
  }

  searchMessages(query) {
    const lowercaseQuery = query.toLowerCase();
    return this.systemMessages.filter(msg =>
      msg.message.toLowerCase().includes(lowercaseQuery) ||
      msg.type.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Statistics
  getMessageStats() {
    const stats = {
      total: this.systemMessages.length,
      unread: this.systemMessages.filter(msg => !msg.read).length,
      byType: {}
    };

    // Count by type
    this.systemMessages.forEach(msg => {
      if (!stats.byType[msg.type]) {
        stats.byType[msg.type] = 0;
      }
      stats.byType[msg.type]++;
    });

    return stats;
  }

  // Bulk operations
  deleteOldMessages(olderThanDays = 30) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - olderThanDays);

    const originalLength = this.systemMessages.length;
    this.systemMessages = this.systemMessages.filter(msg =>
      new Date(msg.timestamp) > cutoffDate
    );

    const deletedCount = originalLength - this.systemMessages.length;

    if (deletedCount > 0) {
      this.saveSystemMessages();
      this.updateMessagesBadge();
      this.renderSystemMessages();

      this.emit('messages:old-messages-deleted', {
        deletedCount,
        olderThanDays
      });

      this.log(`Deleted ${deletedCount} messages older than ${olderThanDays} days`);
    }

    return deletedCount;
  }

  deleteMessagesByType(type) {
    const originalLength = this.systemMessages.length;
    this.systemMessages = this.systemMessages.filter(msg => msg.type !== type);

    const deletedCount = originalLength - this.systemMessages.length;

    if (deletedCount > 0) {
      this.saveSystemMessages();
      this.updateMessagesBadge();
      this.renderSystemMessages();

      this.emit('messages:type-messages-deleted', {
        type,
        deletedCount
      });

      this.log(`Deleted ${deletedCount} messages of type '${type}'`);
    }

    return deletedCount;
  }

  // Export/Import functionality
  exportMessages() {
    try {
      const messagesJSON = JSON.stringify({
        messages: this.systemMessages,
        exportDate: new Date().toISOString(),
        version: '1.0'
      }, null, 2);

      const blob = new Blob([messagesJSON], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = this.domManager.createElement('a', {
        attributes: {
          href: url,
          download: 'prizo-messages.json'
        }
      });

      a.click();
      URL.revokeObjectURL(url);

      this.emit('messages:exported');
      this.log('Messages exported successfully');
      return true;
    } catch (error) {
      this.error('Error exporting messages:', error);
      return false;
    }
  }

  // Public API methods
  addError(message, options) {
    return this.addSystemMessage('error', message, options);
  }

  addWarning(message, options) {
    return this.addSystemMessage('warning', message, options);
  }

  addInfo(message, options) {
    return this.addSystemMessage('info', message, options);
  }

  addSuccess(message, options) {
    return this.addSystemMessage('success', message, options);
  }

  getMessages() {
    return [...this.systemMessages];
  }

  getMessageCount() {
    return this.systemMessages.length;
  }

  getUnreadCount() {
    return this.systemMessages.filter(msg => !msg.read).length;
  }

  // Cleanup
  async cleanup() {
    await this.saveSystemMessages();
    this.systemMessages = [];
  }
}

// Make available globally
window.MessageHandler = MessageHandler;