/**
 * @Author: Claude
 * @Date: 2025-09-27
 * Voucher Section Component - Displays seller discount vouchers with Digikala styling
 */

class VoucherSection {
  constructor(services) {
    this.services = services;
    this.copiedVouchers = new Set(); // Track copied voucher codes
  }

  /**
   * Create and display voucher section
   * @param {Object} voucherData - Voucher data from API
   * @param {string} productId - Product ID
   * @param {Element} insertAfterElement - Element to insert vouchers after
   * @returns {Element|null} - Created voucher section element
   */
  async createVoucherSection(voucherData, productId, insertAfterElement) {
    try {
      console.log('🎟️ Creating voucher section for product:', productId);

      // Remove existing voucher section
      this.removeExistingVoucherSection();

      // Validate voucher data
      if (!voucherData || !voucherData.data || !Array.isArray(voucherData.data) || voucherData.data.length === 0) {
        console.log('ℹ️ No vouchers available for this product');
        return null;
      }

      // Create main voucher container
      const voucherContainer = this.createVoucherContainer(voucherData);

      // Insert after the specified element
      if (insertAfterElement && insertAfterElement.parentNode) {
        insertAfterElement.parentNode.insertBefore(voucherContainer, insertAfterElement.nextSibling);
        console.log('✅ Voucher section added to product page');
        return voucherContainer;
      } else {
        console.warn('⚠️ Could not find insertion point for voucher section');
        return null;
      }

    } catch (error) {
      console.error('❌ Error creating voucher section:', error);
      return null;
    }
  }

  /**
   * Create the main voucher container element
   * @param {Object} voucherData - Voucher data
   * @returns {Element} - Voucher container element
   */
  createVoucherContainer(voucherData) {
    const container = document.createElement('div');
    container.className = 'digikala-extension-vouchers';
    container.style.cssText = `
      margin-top: 16px;
      margin-bottom: 8px;
      font-family: IRANSans, Tahoma, sans-serif;
    `;

    // Create info section (similar to Digikala's pattern)
    const infoSection = this.createInfoSection();
    container.appendChild(infoSection);

    // Create voucher title
    const titleSection = this.createTitleSection(voucherData.data);
    container.appendChild(titleSection);

    // Create voucher cards for each variant
    voucherData.data.forEach(variant => {
      if (variant.vouchers && variant.vouchers.length > 0) {
        variant.vouchers.forEach(voucher => {
          const voucherCard = this.createVoucherCard(voucher, variant.variant_id);
          container.appendChild(voucherCard);
        });
      }
    });

    return container;
  }

  /**
   * Create info section with instruction text
   * @returns {Element} - Info section element
   */
  createInfoSection() {
    const infoSection = document.createElement('div');
    infoSection.style.cssText = `
      display: flex;
      flex-col: gap-4;
      padding: 12px;
      margin-bottom: 8px;
      background-color: #f8f9fa;
      border: 1px solid #e9ecef;
      border-radius: 8px;
      color: #374151;
    `;

    infoSection.innerHTML = `
      <div style="display: flex; gap: 8px; align-items: flex-start;">
        <div style="flex-shrink: 0; margin-top: 1px;">
          <div style="width: 20px; height: 20px; color: #6366f1;">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
          </div>
        </div>
        <p style="margin: 0; font-size: 14px; line-height: 1.5; font-weight: 500;">
          بعد از کپی‌کردن کد تخفیف، هنگام پرداخت آن را در بخش کد تخفیف وارد کنید.
        </p>
      </div>
    `;

    return infoSection;
  }

  /**
   * Create title section showing voucher count
   * @param {Array} variants - Voucher variants
   * @returns {Element} - Title section element
   */
  createTitleSection(variants) {
    const titleSection = document.createElement('p');
    titleSection.style.cssText = `
      margin: 16px 0 12px 0;
      font-size: 18px;
      font-weight: 700;
      color: #1f2937;
    `;

    // Count total vouchers and sellers
    let totalVouchers = 0;
    const uniqueSellers = new Set();

    variants.forEach(variant => {
      if (variant.vouchers) {
        totalVouchers += variant.vouchers.length;
        variant.vouchers.forEach(voucher => {
          uniqueSellers.add(voucher.seller_id);
        });
      }
    });

    titleSection.textContent = `${totalVouchers} کد تخفیف از ${uniqueSellers.size} فروشنده`;

    return titleSection;
  }

  /**
   * Create individual voucher card
   * @param {Object} voucher - Voucher data
   * @param {number} variantId - Variant ID
   * @returns {Element} - Voucher card element
   */
  createVoucherCard(voucher, variantId) {
    const card = document.createElement('div');
    card.className = 'voucher-card';
    card.style.cssText = `
      position: relative;
      overflow: hidden;
      border-radius: 8px;
      border: 1px solid #e5e7eb;
      display: flex;
      color: #374151;
      margin-bottom: 12px;
      background: white;
    `;

    // Create voucher icon section
    const iconSection = this.createVoucherIcon();
    card.appendChild(iconSection);

    // Create main content section
    const contentSection = this.createVoucherContent(voucher, variantId);
    card.appendChild(contentSection);

    return card;
  }

  /**
   * Create voucher icon section
   * @returns {Element} - Icon section element
   */
  createVoucherIcon() {
    const iconSection = document.createElement('div');
    iconSection.style.cssText = `
      background: #f9fafb;
      width: 44px;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-shrink: 0;
    `;

    iconSection.innerHTML = `
       
        <div style="width: 32px; height: 32px; line-height: 0;"><picture><source type="image/webp" srcset="https://www.digikala.com/statics/img/png/voucher/discount-voucher.webp"><source type="image/jpeg" srcset="/statics/img/png/voucher/discount-voucher.png"><img class="w-full inline-block" src="/statics/img/png/voucher/discount-voucher.png" width="32" height="32" alt="تخفیف" title="" style="object-fit: contain;"></picture></div>
     
    `;

    return iconSection;
  }

  /**
   * Create voucher content section
   * @param {Object} voucher - Voucher data
   * @param {number} variantId - Variant ID
   * @returns {Element} - Content section element
   */
  createVoucherContent(voucher, variantId) {
    const contentSection = document.createElement('div');
    contentSection.style.cssText = `
      padding: 12px 16px;
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 8px;
    `;

    // Voucher title and seller
    const titleSection = this.createVoucherTitle(voucher);
    contentSection.appendChild(titleSection);

    // Price information
    const priceSection = this.createPriceSection(voucher);
    contentSection.appendChild(priceSection);

    // Voucher code section with copy button
    const codeSection = this.createCodeSection(voucher, variantId);
    contentSection.appendChild(codeSection);

    return contentSection;
  }

  /**
   * Create voucher title and seller section
   * @param {Object} voucher - Voucher data
   * @returns {Element} - Title section element
   */
  createVoucherTitle(voucher) {
    const titleContainer = document.createElement('div');
    titleContainer.innerHTML = `
      <h5 style="margin: 0 0 4px 0; font-size: 16px; font-weight: 600; color: #374151;">
        ${this.formatPrice(voucher.discount_amount)} تومان کد تخفیف
      </h5>
      <p style="margin: 0; font-size: 14px; color: #6b7280; font-weight: 400;">
        ${this.escapeHtml(voucher.seller_name)}
      </p>
    `;

    return titleContainer;
  }

  /**
   * Create price section showing final price
   * @param {Object} voucher - Voucher data
   * @returns {Element} - Price section element
   */
  createPriceSection(voucher) {
    const priceContainer = document.createElement('div');
    priceContainer.style.cssText = `
      display: flex;
      align-items: center;
      gap: 6px;
    `;

    priceContainer.innerHTML = `
      <p style="margin: 0; font-size: 14px; color: #6b7280;">قیمت بعد از اعمال تخفیف</p>
      <div style="display: flex; justify-content: space-between; align-items: center; gap: 4px; font-size: 14px; font-weight: 600; color: #374151;">
        <p style="margin: 0;">${this.formatPrice(voucher.final_price)}</p>
        <div style="display: flex;">
          <svg style="width: 16px; height: 16px; fill: #374151;">
            <use xlink:href="#toman"></use>
          </svg>
        </div>
      </div>
    `;

    return priceContainer;
  }

  /**
   * Create voucher code section with copy functionality
   * @param {Object} voucher - Voucher data
   * @param {number} variantId - Variant ID
   * @returns {Element} - Code section element
   */
  createCodeSection(voucher, variantId) {
    const codeContainer = document.createElement('div');
    codeContainer.style.cssText = `
      border-radius: 6px;
      padding: 8px;
      border: 1px solid #e5e7eb;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      background: #fafafa;
    `;

    const codeId = `${voucher.code}_${variantId}`;
    const isCopied = this.copiedVouchers.has(codeId);

    // Copy button
    const copyButton = document.createElement('div');
    copyButton.className = 'voucher-copy-button';
    copyButton.style.cssText = `
      padding: 6px 12px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 4px;
      transition: all 0.2s ease;
      ${isCopied
        ? 'background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0;'
        : 'background: #ddd6fe; color: #7c3aed; border: 1px solid #c4b5fd;'
      }
    `;

    copyButton.innerHTML = isCopied
      ? `<svg style="width: 14px; height: 14px; fill: currentColor;">
           <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
         </svg>
         <span>کپی شد</span>`
      : `<svg style="width: 14px; height: 14px; fill: currentColor;">
           <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
         </svg>
         <span>کپی</span>`;

    // Voucher code text
    const codeText = document.createElement('p');
    codeText.style.cssText = `
      margin: 0;
      font-size: 14px;
      font-weight: 500;
      font-family: 'Courier New', monospace;
      color: #374151;
      flex: 1;
      text-align: left;
      direction: ltr;
    `;
    codeText.textContent = voucher.code;

    // Add copy functionality
    copyButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.copyVoucherCode(voucher.code, codeId, copyButton);
    });

    codeContainer.appendChild(copyButton);
    codeContainer.appendChild(codeText);

    return codeContainer;
  }

  /**
   * Copy voucher code to clipboard
   * @param {string} code - Voucher code
   * @param {string} codeId - Unique code identifier
   * @param {Element} buttonElement - Copy button element
   */
  async copyVoucherCode(code, codeId, buttonElement) {
    try {
      // Copy to clipboard
      await navigator.clipboard.writeText(code);

      // Mark as copied
      this.copiedVouchers.add(codeId);

      // Update button appearance
      buttonElement.style.cssText = `
        padding: 6px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 4px;
        transition: all 0.2s ease;
        background: #dcfce7;
        color: #15803d;
        border: 1px solid #bbf7d0;
      `;

      buttonElement.innerHTML = `
        <svg style="width: 14px; height: 14px; fill: currentColor;">
          <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
        </svg>
        <span>کپی شد</span>
      `;

      // Show success notification
      if (this.services.notificationService) {
        this.services.notificationService.show({
          type: 'success',
          title: 'کد تخفیف کپی شد',
          message: `کد ${code} در کلیپ‌بورد ذخیره شد`,
          duration: 3000
        });
      }

      console.log(`✅ Voucher code copied: ${code}`);

      // Reset button after 3 seconds
      setTimeout(() => {
        this.copiedVouchers.delete(codeId);
        buttonElement.style.cssText = `
          padding: 6px 12px;
          border-radius: 4px;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 4px;
          transition: all 0.2s ease;
          background: #ddd6fe;
          color: #7c3aed;
          border: 1px solid #c4b5fd;
        `;

        buttonElement.innerHTML = `
          <svg style="width: 14px; height: 14px; fill: currentColor;">
            <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
          </svg>
          <span>کپی</span>
        `;
      }, 3000);

    } catch (error) {
      console.error('❌ Failed to copy voucher code:', error);

      // Show error notification
      if (this.services.notificationService) {
        this.services.notificationService.show({
          type: 'error',
          title: 'خطا در کپی',
          message: 'امکان کپی کد تخفیف وجود ندارد',
          duration: 3000
        });
      }
    }
  }

  /**
   * Remove existing voucher section
   */
  removeExistingVoucherSection() {
    const existingSection = document.querySelector('.digikala-extension-vouchers');
    if (existingSection) {
      existingSection.remove();
      console.log('🗑️ Removed existing voucher section');
    }
  }

  /**
   * Format price with thousand separators
   * @param {number} price - Price in rials or tomans
   * @returns {string} - Formatted price
   */
  formatPrice(price) {
    if (!price || price === 0) return '0';

    // Convert from Rials to Tomans (divide by 10)
    // All prices are stored in Rials throughout the app
    const displayPrice = Math.round(price / 10);

    return displayPrice.toLocaleString('fa-IR');
  }

  /**
   * Escape HTML to prevent XSS
   * @param {string} text - Text to escape
   * @returns {string} - Escaped text
   */
  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Cleanup method
   */
  cleanup() {
    this.removeExistingVoucherSection();
    this.copiedVouchers.clear();
  }
}

// Export for use in other modules
window.VoucherSection = VoucherSection;