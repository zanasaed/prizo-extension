/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Notification Service - Handles all user notifications and dialogs
 */
class NotificationService {
  constructor(eventBus) {
    this.eventBus = eventBus;
    this.notificationQueue = [];
    this.maxNotifications = 3;
    this.defaultDuration = 5000;
    this.notificationContainer = null;
    this.stackOffset = 80;
  }

  initialize() {
    this.createNotificationContainer();
    this.eventBus.on('notification:show', this.show.bind(this));
    this.eventBus.on('notification:clear-all', this.clearAll.bind(this));
    console.log('✅ Notification service initialized');
  }

  createNotificationContainer() {
    if (!this.notificationContainer) {
      this.notificationContainer = document.createElement('div');
      this.notificationContainer.id = 'extension-notifications';
      this.notificationContainer.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        pointer-events: none;
      `;
      document.body.appendChild(this.notificationContainer);
    }
  }

  show(options) {
    if (typeof options === 'string') {
      options = { message: options, type: 'info' };
    }

    const notification = this.createNotification(options);
    this.addToQueue(notification);
    this.updateNotificationPositions();

    if (options.autoHide !== false) {
      const duration = options.duration || this.defaultDuration;
      setTimeout(() => {
        this.remove(notification);
      }, duration);
    }

    this.eventBus.emit('notification:shown', options);
    return notification;
  }

  createNotification(options) {
    const notification = document.createElement('div');
    notification.className = `extension-notification notification-${options.type || 'info'}`;
    notification.style.pointerEvents = 'auto';

    const typeStyles = {
      info: 'background: rgba(59, 130, 246, 0.95); color: white;',
      success: 'background: rgba(34, 197, 94, 0.95); color: white;',
      warning: 'background: rgba(245, 158, 11, 0.95); color: white;',
      error: 'background: rgba(239, 68, 68, 0.95); color: white;'
    };

    const typeIcons = {
      info: 'ℹ️',
      success: '✅',
      warning: '⚠️',
      error: '❌'
    };

    notification.style.cssText = `
      ${typeStyles[options.type] || typeStyles.info}
      padding: 18px 22px;
      border-radius: 12px;
      font-size: 14px;
      max-width: 380px;
      min-width: 220px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15), 0 2px 8px rgba(0, 0, 0, 0.1);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.25);
      margin-bottom: 16px;
      transform: translateX(120%) scale(0.95);
      opacity: 0;
      transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      position: relative;
      overflow: hidden;
      font-family: 'Segoe UI', 'Vazir', system-ui, -apple-system, sans-serif;
    `;

    let notificationContent = `
      <div style="display: flex; align-items: flex-start; gap: 12px;">
        <div style="font-size: 18px; flex-shrink: 0;">
          ${typeIcons[options.type] || typeIcons.info}
        </div>
        <div style="flex: 1;">
    `;

    if (options.title) {
      notificationContent += `
        <div style="font-weight: bold; margin-bottom: 4px; font-size: 15px;">
          ${this.sanitizeHTML(options.title)}
        </div>
      `;
    }

    if (options.message) {
      notificationContent += `
        <div style="opacity: 0.9; line-height: 1.4;">
          ${this.sanitizeHTML(options.message)}
        </div>
      `;
    }

    notificationContent += `
        </div>
        <button style="
          background: none;
          border: none;
          color: rgba(255, 255, 255, 0.7);
          font-size: 18px;
          cursor: pointer;
          padding: 0;
          width: 20px;
          height: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          transition: all 0.2s;
          flex-shrink: 0;
        " onmouseover="this.style.background='rgba(255,255,255,0.2)'" 
           onmouseout="this.style.background='none'"
           onclick="this.closest('.extension-notification').dispatchEvent(new CustomEvent('close'))">
          ×
        </button>
      </div>
    `;

    // Add action buttons if provided
    if (options.actions && options.actions.length > 0) {
      notificationContent += `
        <div style="margin-top: 12px; display: flex; gap: 8px; flex-wrap: wrap;">
      `;

      options.actions.forEach(action => {
        notificationContent += `
          <button style="
            padding: 6px 12px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border-radius: 4px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
          " onmouseover="this.style.background='rgba(255,255,255,0.3)'"
             onmouseout="this.style.background='rgba(255,255,255,0.2)'"
             data-action="${action.action || 'dismiss'}">
            ${this.sanitizeHTML(action.text)}
          </button>
        `;
      });

      notificationContent += `</div>`;
    }

    notification.innerHTML = notificationContent;

    // Add event listeners
    notification.addEventListener('close', () => {
      this.remove(notification);
    });

    // Handle action buttons
    const actionButtons = notification.querySelectorAll('[data-action]');
    actionButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        const actionName = e.target.getAttribute('data-action');
        const action = options.actions?.find(a => a.action === actionName);
        
        if (action && typeof action.callback === 'function') {
          action.callback();
        }

        if (actionName === 'dismiss' || !action || action.dismiss !== false) {
          this.remove(notification);
        }
      });
    });

    return notification;
  }

  addToQueue(notification) {
    // Remove oldest notifications if queue is full
    while (this.notificationQueue.length >= this.maxNotifications) {
      const oldest = this.notificationQueue.shift();
      this.remove(oldest, false);
    }

    this.notificationQueue.push(notification);
    this.notificationContainer.appendChild(notification);

    // Trigger staggered entrance animation
    requestAnimationFrame(() => {
      setTimeout(() => {
        notification.style.transform = 'translateX(0) scale(1)';
        notification.style.opacity = '1';
      }, this.notificationQueue.length * 100); // Stagger animations
    });
  }

  remove(notification, updatePositions = true) {
    if (!notification || !notification.parentNode) return;

    // Enhanced exit animation
    notification.style.transform = 'translateX(120%) scale(0.9)';
    notification.style.opacity = '0';
    notification.style.filter = 'blur(2px)';

    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }

      const index = this.notificationQueue.indexOf(notification);
      if (index !== -1) {
        this.notificationQueue.splice(index, 1);
      }

      if (updatePositions) {
        this.updateNotificationPositions();
      }
    }, 400);
  }

  updateNotificationPositions() {
    this.notificationQueue.forEach((notification, index) => {
      const yOffset = index * this.stackOffset;
      notification.style.transform = `translateY(${yOffset}px)`;
    });
  }

  showSuccess(title, message, options = {}) {
    return this.show({
      type: 'success',
      title,
      message,
      ...options
    });
  }

  showError(title, message, options = {}) {
    return this.show({
      type: 'error',
      title,
      message,
      autoHide: false,
      ...options
    });
  }

  showWarning(title, message, options = {}) {
    return this.show({
      type: 'warning',
      title,
      message,
      ...options
    });
  }

  showInfo(title, message, options = {}) {
    return this.show({
      type: 'info',
      title,
      message,
      ...options
    });
  }

  showDialog(options) {
    const overlay = document.createElement('div');
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
      z-index: 10001;
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(5px);
    `;

    const dialog = document.createElement('div');
    dialog.style.cssText = `
      background: white;
      border-radius: 12px;
      padding: 24px;
      max-width: 450px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
      transform: scale(0.9);
      opacity: 0;
      transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    `;

    dialog.innerHTML = `
      <div style="font-size: 20px; font-weight: bold; margin-bottom: 16px; color: #333;">
        ${this.sanitizeHTML(options.title)}
      </div>
      <div style="font-size: 16px; line-height: 1.6; color: #666; margin-bottom: 24px;">
        ${this.sanitizeHTML(options.message)}
      </div>
    `;

    // Add action buttons
    if (options.actions && options.actions.length > 0) {
      const actionContainer = document.createElement('div');
      actionContainer.style.cssText = 'display: flex; gap: 12px; justify-content: flex-end; flex-wrap: wrap;';

      options.actions.forEach(action => {
        const button = document.createElement('button');
        button.textContent = action.text;
        button.style.cssText = `
          padding: 12px 24px;
          border: ${action.primary ? 'none' : '1px solid #d1d5db'};
          border-radius: 6px;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          ${action.primary ? 'background: #3b82f6; color: white;' : 'background: #f9fafb; color: #374151;'}
          ${action.danger ? 'background: #ef4444; color: white; border: none;' : ''}
        `;

        button.addEventListener('mouseover', () => {
          if (action.primary) {
            button.style.background = '#2563eb';
          } else if (action.danger) {
            button.style.background = '#dc2626';
          } else {
            button.style.background = '#f3f4f6';
          }
        });

        button.addEventListener('mouseout', () => {
          if (action.primary) {
            button.style.background = '#3b82f6';
          } else if (action.danger) {
            button.style.background = '#ef4444';
          } else {
            button.style.background = '#f9fafb';
          }
        });

        button.addEventListener('click', () => {
          if (action.callback && typeof action.callback === 'function') {
            action.callback();
          }
          overlay.remove();
        });

        actionContainer.appendChild(button);
      });

      dialog.appendChild(actionContainer);
    }

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    // Trigger animation
    requestAnimationFrame(() => {
      dialog.style.transform = 'scale(1)';
      dialog.style.opacity = '1';
    });

    // Close on overlay click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.remove();
      }
    });

    this.eventBus.emit('notification:dialog-shown', options);
    return overlay;
  }

  clearAll() {
    [...this.notificationQueue].forEach(notification => {
      this.remove(notification, false);
    });
    this.notificationQueue = [];
    console.log('🧹 All notifications cleared');
  }

  sanitizeHTML(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  getQueueSize() {
    return this.notificationQueue.length;
  }
}

window.NotificationService = NotificationService;