/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * DOM Manager - Handles DOM manipulation, element selection, and UI updates
 */
class DOMManager {
  constructor() {
    this.observer = null;
    this.scrollHandler = null;
    this.isObserving = false;
  }

  validateElement(element, context = 'unknown') {
    if (!element) {
      console.warn(`Element is null/undefined in context: ${context}`);
      return false;
    }
    if (!element.parentNode) {
      console.warn(`Element is detached from DOM in context: ${context}`);
      return false;
    }
    return true;
  }

  safeQuerySelector(parent, selector, context = 'unknown') {
    try {
      const element = parent.querySelector(selector);
      if (!element) {
        console.debug(`Element not found with selector "${selector}" in context: ${context}`);
      }
      return element;
    } catch (error) {
      console.error(`Invalid selector "${selector}" in context: ${context}`, error);
      return null;
    }
  }

  safeQuerySelectorAll(parent, selector, context = 'unknown') {
    try {
      return Array.from(parent.querySelectorAll(selector));
    } catch (error) {
      console.error(`Invalid selector "${selector}" in context: ${context}`, error);
      return [];
    }
  }

  createSafeElement(tagName, options = {}) {
    const element = document.createElement(tagName);

    if (options.text) {
      element.textContent = this.sanitizeText(options.text);
    }

    if (options.className) {
      element.className = options.className;
    }

    if (options.style) {
      this.setSafeCSSText(element, options.style);
    }

    if (options.attributes) {
      for (const [name, value] of Object.entries(options.attributes)) {
        if (this.isSafeAttribute(name)) {
          element.setAttribute(name, value);
        }
      }
    }

    return element;
  }

  setSafeCSSText(element, cssText) {
    try {
      const sanitizedCSS = cssText.replace(/javascript:|expression\s*\(|@import|behavior\s*:/gi, '');
      element.style.cssText = sanitizedCSS;
    } catch (error) {
      console.warn('Failed to set CSS text:', error);
    }
  }

  isSafeAttribute(attributeName) {
    const allowedAttributes = [
      'class', 'id', 'style', 'title', 'alt', 'src', 'href', 'data-*',
      'role', 'aria-*', 'tabindex', 'dir', 'lang'
    ];
    return allowedAttributes.some(attr =>
      attr === attributeName ||
      (attr.endsWith('*') && attributeName.startsWith(attr.slice(0, -1)))
    );
  }

  sanitizeText(text) {
    if (typeof text !== 'string') {
      return String(text || '');
    }
    return text.replace(/[<>]/g, match => match === '<' ? '&lt;' : '&gt;');
  }

  isElementVisible(element) {
    if (!element) return false;

    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);

    return rect.width > 0 &&
      rect.height > 0 &&
      style.display !== 'none' &&
      style.visibility !== 'hidden' &&
      style.opacity !== '0';
  }

  getProductElements() {
    // Use the original working selectors from the pre-refactor version - EXACTLY like the old working code
    const selectors = [
      // Primary selector that was working reliably in the original code
      '.product-list_ProductList__item__LiiNI',
      // Secondary selectors that were also working
      'article[data-product-id]',
      '[data-testid="product-card"]',
      // Legacy selectors that might still be used
      '.c-product-box',
      '.product-list__item',
      '.js-product-item'
    ];

    console.log('🔍 Searching for product elements using original working selectors...');

    // First try the proven working selectors - exactly like the original
    for (const selector of selectors) {
      const elements = this.safeQuerySelectorAll(document, selector, 'getProductElements');
      if (elements.length > 0) {
        const visibleElements = elements.filter(el => this.isElementVisible(el));
        console.log(`✅ Found ${visibleElements.length} visible product elements with selector: ${selector}`);
        return visibleElements;
      } else {
        console.log(`⚠️ No elements found with selector: ${selector}`);
      }
    }

    // Fallback: Exactly like the original code - look for specific Digikala patterns
    console.log('🔍 Using fallback method (like original working code)');
    const fallbackElements = [];

    // Look for product links using the exact patterns from the original working code
    const allProductLinks = document.querySelectorAll('a[href*="/product/"], a[href*="dkp-"], a[href*="/dp/"]');
    console.log(`🔍 Found ${allProductLinks.length} product links on page`);

    for (const link of allProductLinks) {
      // Find the closest container - using the same logic as the original
      let container = link.closest('article') ||
        link.closest('div[class*="ProductList"]') ||
        link.closest('div[class*="product-list"]') ||
        link.closest('div[class*="item"]') ||
        link.closest('div[class*="card"]');

      if (!container) {
        // Fallback to parent/grandparent like the original
        container = link.parentElement?.parentElement || link.parentElement;
      }

      if (container && this.isElementVisible(container) && !fallbackElements.includes(container)) {
        fallbackElements.push(container);
      }
    }

    console.log(`🔍 Found ${fallbackElements.length} product elements using fallback method`);
    return fallbackElements;
  }

  getWishlistProductElements() {
    const wishlistSelectors = [
      '[data-testid="product-card"]', // Standard Digikala product card selector
      '[data-testid="wishlist-item"]',
      '.wishlist-item',
      '[data-product-id]'
    ];

    for (const selector of wishlistSelectors) {
      const elements = this.safeQuerySelectorAll(document, selector, 'getWishlistProductElements');
      if (elements.length > 0) {
        return elements.filter(el => this.isElementVisible(el));
      }
    }
    return [];
  }

  extractProductId(productElement) {
    if (!this.validateElement(productElement, 'extractProductId')) {
      return null;
    }

    // Method 1: Check for data attributes (like the original working code)
    if (productElement.dataset.productId) {
      return productElement.dataset.productId;
    }

    // Method 2: Find product link (exactly like original working code)
    const link = this.safeQuerySelector(productElement, 'a[href*="/product/"], a[href*="dkp-"], a[href*="/dp/"]', 'extractProductId');
    if (!link) {
      console.log('⚠️ No product link found in element');
      return null;
    }

    const href = link.getAttribute('href');
    if (!href) {
      console.log('⚠️ Product link has no href');
      return null;
    }

    console.log('🔍 Extracting product ID from URL:', href);

    // Method 3: Use the exact same URL patterns that worked in the original code
    const patterns = [
      /\/product\/dkp-(\d+)\//,    // Standard Digikala format: /product/dkp-123456/
      /dkp-(\d+)/,                 // dkp-123456 anywhere in URL
      /\/dp\/(\d+)\//,             // /dp/123456/
      /\/product\/(\d+)\//,        // /product/123456/
      /\/(\d+)\/$/                 // /123456/ at end
    ];

    for (const pattern of patterns) {
      const match = href.match(pattern);
      if (match && match[1]) {
        const productId = match[1];
        console.log('✅ Extracted product ID:', productId, 'using pattern:', pattern.source);
        return productId;
      }
    }

    console.log('❌ Could not extract product ID from URL:', href);
    return null;
  }


  detectCartItems() {
    const cartItemSelectors = [
      '[data-testid="cart-item"]',
      '.cart-item',
      '[data-product-id]',
      '.basket-item',
      '.checkout-item',
      '[class*="cart"][class*="item"]',
      '[class*="basket"][class*="item"]',
      'article[data-product-id]',
      'div[data-product-id]',
      '.overflow-x-hidden', // Common Digikala cart item wrapper
      '[class*="ProductItem"]'
    ];

    console.log('🔍 Searching for cart items with multiple selectors...');

    for (const selector of cartItemSelectors) {
      const allCartItems = this.safeQuerySelectorAll(document, selector, 'detectCartItems');
      if (allCartItems.length === 0) {
        continue;
      }

      console.log(`🔍 Found ${allCartItems.length} potential cart items with selector: ${selector}`);

      const validCartItems = allCartItems.filter(item => {
        if (!this.isElementVisible(item)) {
          return false;
        }

        // More comprehensive check for product content
        const hasProductContent =
          this.safeQuerySelector(item, 'img', 'detectCartItems') ||
          this.safeQuerySelector(item, '[data-product-id]', 'detectCartItems') ||
          this.safeQuerySelector(item, 'a[href*="/dp/"]', 'detectCartItems') ||
          this.safeQuerySelector(item, 'a[href*="/product/"]', 'detectCartItems') ||
          this.safeQuerySelector(item, 'a[href*="dkp-"]', 'detectCartItems') ||
          this.safeQuerySelector(item, 'h3', 'detectCartItems') || // Product title
          this.safeQuerySelector(item, '[class*="title"]', 'detectCartItems') ||
          (item.textContent && item.textContent.includes('تومان')); // Has price in Tomans

        return !!hasProductContent;
      });

      if (validCartItems.length > 0) {
        console.log(`✅ Found ${validCartItems.length} valid cart items with selector: ${selector}`);
        return validCartItems;
      }
    }

    console.log('⚠️ No cart items found with any selector');
    return [];
  }

  extractProductIdFromCartItem(cartItem) {
    if (!this.validateElement(cartItem, 'extractProductIdFromCartItem')) {
      return null;
    }

    // Debug: Log cart item structure to understand what's available
    console.log('🔍 Debugging cart item structure:', {
      className: cartItem.className,
      dataset: cartItem.dataset,
      linksFound: cartItem.querySelectorAll('a').length,
      innerHTML: cartItem.innerHTML.substring(0, 500) + '...'
    });

    // Try multiple approaches to extract product ID

    // 1. Check for data attributes first
    if (cartItem.dataset.productId) {
      console.log('✅ Found product ID in dataset:', cartItem.dataset.productId);
      return cartItem.dataset.productId;
    }

    // 2. Look for various URL patterns in links
    const allLinks = this.safeQuerySelectorAll(cartItem, 'a[href]', 'extractProductIdFromCartItem');
    console.log(`🔍 Found ${allLinks.length} links in cart item`);

    if (allLinks.length > 0) {
      for (const link of allLinks) {
        const href = link.getAttribute('href');
        console.log('🔍 Checking link:', href);

        // Try different URL patterns that Digikala might use
        const patterns = [
          /\/dp\/(\d+)\//,           // /dp/123456/
          /\/product\/(\d+)\//,      // /product/123456/
          /\/dkp-(\d+)/,            // /dkp-123456
          /product-id[=:](\d+)/,     // product-id=123456 or product-id:123456
          /\/(\d{6,})\//,           // Any 6+ digit number in URL
          /[?&]id=(\d+)/,           // ?id=123456 or &id=123456
          /\/([0-9]+)$/,            // Ends with numbers
          /dkp(\d+)/,               // dkp123456 (without dash)
          /product\/dkp-(\d+)/      // product/dkp-123456
        ];

        for (const pattern of patterns) {
          const match = href.match(pattern);
          if (match && match[1]) {
            console.log('✅ Found product ID from URL pattern:', match[1]);
            return match[1];
          }
        }
      }
    }

    // 3. Look for product ID in text content or attributes
    const textContent = cartItem.textContent;
    const idPatterns = [
      /دیجی‌کالا-(\d+)/,  // دیجی‌کالا-123456
      /DKP-?(\d+)/i,      // DKP-123456 or DKP123456
      /کد[:\s]*(\d+)/,    // کد: 123456
      /شناسه[:\s]*(\d+)/  // شناسه: 123456
    ];

    for (const pattern of idPatterns) {
      const match = textContent.match(pattern);
      if (match && match[1]) {
        console.log('✅ Found product ID from text content:', match[1]);
        return match[1];
      }
    }

    // 4. Check for data-* attributes with different naming conventions
    const dataAttributes = Object.keys(cartItem.dataset);
    console.log('🔍 Available data attributes:', dataAttributes);

    for (const attr of dataAttributes) {
      if (attr.toLowerCase().includes('product') && cartItem.dataset[attr].match(/^\d+$/)) {
        console.log('✅ Found product ID in data attribute:', cartItem.dataset[attr]);
        return cartItem.dataset[attr];
      }
    }

    // 5. Look for hidden inputs or other elements with product ID
    const hiddenInputs = cartItem.querySelectorAll('input[type="hidden"]');
    for (const input of hiddenInputs) {
      if (input.name && input.name.toLowerCase().includes('product') && input.value.match(/^\d+$/)) {
        console.log('✅ Found product ID in hidden input:', input.value);
        return input.value;
      }
    }

    console.log('❌ Could not extract product ID from cart item');
    return null;
  }

  addSellerPriceSection(productElement, sellerPrice, discountPercent, monthlyLowPrice) {
    if (!this.validateElement(productElement, 'addSellerPriceSection')) {
      return;
    }

    const existingSection = this.safeQuerySelector(productElement, '.seller-price-info', 'addSellerPriceSection');
    if (existingSection) {
      existingSection.remove();
    }

    const articleElement = productElement.tagName === 'ARTICLE' ? productElement : this.safeQuerySelector(productElement, 'article', 'addSellerPriceSection');
    if (!articleElement) {
      return;
    }

    const sanitizedSellerPrice = this.sanitizeNumber(sellerPrice);
    const sanitizedDiscountPercent = this.sanitizeNumber(discountPercent);
    const sanitizedMonthlyLowPrice = this.sanitizeNumber(monthlyLowPrice);

    const sectionHTML = `
      <div class="seller-price-info" style="background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); border: 1px solid #dee2e6; border-radius: 8px; padding: 8px; margin: 4px 0; font-size: 12px; color: #495057; position: relative; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
        ${sanitizedDiscountPercent > 0 ? `
          <div style="display: flex; align-items: center; margin-bottom: 4px;">
            <span style="background: #28a745; color: white; padding: 2px 6px; border-radius: 4px; font-weight: bold; margin-right: 6px;">
              ${sanitizedDiscountPercent}% تخفیف
            </span>
            <span style="color: #28a745; font-weight: bold;">
              ${this.formatPrice(sanitizedSellerPrice)} (کمترین قیمت فعلی)
            </span>
          </div>
        ` : `
          <div style="display: flex; align-items: center; margin-bottom: 4px;">
            <span style="color: #007bff; font-weight: bold;">
              ${this.formatPrice(sanitizedSellerPrice)} (کمترین قیمت فعلی)
            </span>
          </div>
        `}
        ${sanitizedMonthlyLowPrice > 0 ? `
          <div style="display: flex; align-items: center; color: #6c757d;">
            <span style="margin-right: 4px;">📈</span>
            <span>کمترین قیمت ماه: ${this.formatPrice(sanitizedMonthlyLowPrice)}</span>
          </div>
        ` : ''}
      </div>
    `;

    articleElement.insertAdjacentHTML('beforeend', sectionHTML);
  }

  addMonthlyPriceSectionOnly(productElement, monthlyLowPrice, sellerShippingInfo = null) {
    if (!this.validateElement(productElement, 'addMonthlyPriceSectionOnly')) {
      return;
    }

    // Check if monthly price info already exists
    const existingSection = this.safeQuerySelector(productElement, '.monthly-price-info', 'addMonthlyPriceSectionOnly');
    if (existingSection) {
      // If we have new shipping info to add, check if shipping section exists
      if (sellerShippingInfo) {
        const existingShippingSection = this.safeQuerySelector(existingSection, '.shipping-cost-info', 'addMonthlyPriceSectionOnly');
        if (!existingShippingSection) {
          console.log('🚚 Adding shipping info to existing monthly price section');
          const shippingColor = sellerShippingInfo.is_free ? '#059669' : '#d97706';
          const sellerInfo = sellerShippingInfo.seller_name ? ` - ${sellerShippingInfo.seller_name}` : '';
          const shippingHTML = `
            <div class="shipping-cost-info" style="display: flex; align-items: center; padding-top: 4px; border-top: 1px solid rgba(133, 100, 4, 0.2);">
              <span style="margin-right: 4px;">🚚</span>
              <span style="color: ${shippingColor}; font-weight: 500;">${sellerShippingInfo.display_text}${sellerInfo}</span>
            </div>`;
          existingSection.insertAdjacentHTML('beforeend', shippingHTML);
          return;
        } else {
          console.log('🔍 Monthly price info with shipping already exists, skipping injection');
          return;
        }
      } else {
        console.log('🔍 Monthly price info already exists, skipping injection to avoid duplicate');
        return;
      }
    }

    // Also check for and remove any legacy monthly-price-section elements
    const legacySection = this.safeQuerySelector(productElement, '.monthly-price-section', 'addMonthlyPriceSectionOnly');
    if (legacySection) {
      legacySection.remove();
      console.log('🧹 Removed legacy monthly-price-section element');
    }

    const sanitizedMonthlyLowPrice = this.sanitizeNumber(monthlyLowPrice);

    if (sanitizedMonthlyLowPrice && sanitizedMonthlyLowPrice > 0) {
      // Find the optimal insertion point - above the buttons section
      let insertionPoint = this.findOptimalInsertionPoint(productElement);

      if (insertionPoint.element) {
        // Create base section HTML
        let sectionHTML = `
          <div class="monthly-price-info" style="background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%); border: 1px solid #ffeeba; border-radius: 6px; padding: 6px; margin: 4px 0; font-size: 11px; color: #856404; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div style="display: flex; align-items: center; margin-bottom: ${sellerShippingInfo ? '4px' : '0'};">
              <span style="margin-right: 4px;">📊</span>
              <span>کمترین قیمت ماه: ${this.formatPrice(sanitizedMonthlyLowPrice)}</span>
            </div>`;

        // Add shipping cost if any seller shipping info exists
        if (sellerShippingInfo) {
          const shippingColor = sellerShippingInfo.is_free ? '#059669' : '#d97706';
          const sellerInfo = sellerShippingInfo.seller_name ? ` - ${sellerShippingInfo.seller_name}` : '';
          sectionHTML += `
            <div class="shipping-cost-info" style="display: flex; align-items: center; padding-top: 4px; border-top: 1px solid rgba(133, 100, 4, 0.2);">
              <span style="margin-right: 4px;">🚚</span>
              <span style="color: ${shippingColor}; font-weight: 500;">${sellerShippingInfo.display_text}${sellerInfo}</span>
            </div>`;
        }

        sectionHTML += '</div>';

        insertionPoint.element.insertAdjacentHTML(insertionPoint.position, sectionHTML);
        console.log(`✅ New monthly-price-info element added using ${insertionPoint.method}${sellerShippingInfo ? ' with shipping info' : ''}`);
      } else {
        console.log('⚠️ Could not find optimal insertion point');
      }
    } else {
      console.log('⚠️ Invalid monthly low price, skipping injection');
    }
  }

  findOptimalInsertionPoint(productElement) {
    console.log('🔍 Finding optimal insertion point for monthly price info');

    // Strategy 1: Find buttons and locate their common parent container
    let addToCartButton = null;
    let deleteButton = null;

    // Find add to cart button - look for links with cart-related text
    const allLinks = this.safeQuerySelectorAll(productElement, 'a', 'findOptimalInsertionPoint');
    for (const link of allLinks) {
      const text = link.textContent || '';
      if (text.includes('سبد') || text.includes('خرید') || link.className.includes('btn')) {
        addToCartButton = link;
        break;
      }
    }

    // Find delete button - look for buttons
    const allButtons = this.safeQuerySelectorAll(productElement, 'button', 'findOptimalInsertionPoint');
    deleteButton = allButtons.find(btn => btn.className.includes('btn') || btn.querySelector('svg'));

    if (addToCartButton && deleteButton) {
      // Find the common parent container that holds both buttons
      let commonParent = addToCartButton.parentElement;
      while (commonParent && commonParent !== productElement) {
        if (commonParent.contains(deleteButton) && commonParent.contains(addToCartButton)) {
          console.log(`✅ Found common buttons container:`, commonParent);
          return {
            element: commonParent,
            position: 'beforebegin',
            method: 'before-buttons-container'
          };
        }
        commonParent = commonParent.parentElement;
      }
    }

    // Strategy 1b: Look for containers with multiple buttons/links
    const potentialContainers = this.safeQuerySelectorAll(productElement, 'div', 'findOptimalInsertionPoint');

    for (const container of potentialContainers) {
      const buttons = container.querySelectorAll('button');
      const buttonLinks = container.querySelectorAll('a[class*="btn"]');
      const totalButtons = buttons.length + buttonLinks.length;

      // Check if this div contains at least 2 interactive elements and is likely the buttons container
      if (totalButtons >= 2 && container.classList.contains('flex')) {
        const hasCartText = container.textContent &&
          (container.textContent.includes('سبد') || container.textContent.includes('خرید'));

        if (hasCartText) {
          console.log(`✅ Found buttons container with ${totalButtons} buttons:`, container);
          return {
            element: container,
            position: 'beforebegin',
            method: 'before-multi-button-container'
          };
        }
      }
    }

    // Strategy 2: Look for price section and insert after it
    const priceSelectors = [
      '[data-testid="price-final"]',
      '.flex.items-center.justify-between', // Price section container
      '[class*="price"]',
      '.pt-1.flex.flex-col' // Price section wrapper from your HTML
    ];

    for (const selector of priceSelectors) {
      const priceElement = this.safeQuerySelector(productElement, selector, 'findOptimalInsertionPoint');
      if (priceElement) {
        // Look for the price section container that contains the price
        let priceContainer = priceElement;
        if (priceElement.closest('.pt-1.flex.flex-col')) {
          priceContainer = priceElement.closest('.pt-1.flex.flex-col');
        }

        console.log(`✅ Found price section with selector: ${selector}`);
        return {
          element: priceContainer,
          position: 'afterend',
          method: 'after-price'
        };
      }
    }

    // Strategy 3: Look for the grow container and insert at the end
    const growContainer = this.safeQuerySelector(productElement, '.grow.flex.flex-col', 'findOptimalInsertionPoint');
    if (growContainer) {
      console.log('✅ Found grow container');
      return {
        element: growContainer,
        position: 'beforeend',
        method: 'end-of-grow'
      };
    }

    // Strategy 4: Fallback to product card container
    const containerElement = this.safeQuerySelector(productElement, 'article, .product-card, .c-product-box', 'findOptimalInsertionPoint');
    if (containerElement) {
      console.log('⚠️ Using fallback container insertion');
      return {
        element: containerElement,
        position: 'beforeend',
        method: 'fallback-container'
      };
    }

    console.log('❌ No suitable insertion point found');
    return { element: null, position: null, method: 'none' };
  }

  /**
   * Check if container contains quantity controls or is absolutely positioned
   */
  isQuantityOrPositionedContainer(container) {
    const style = window.getComputedStyle(container);
    const hasAbsolutePosition = style.position === 'absolute' ||
                               container.className.includes('absolute') ||
                               container.className.includes('top-0') ||
                               container.className.includes('left-0');

    const hasQuantityControls = container.querySelector('[data-testid*="quantity"]') ||
                               container.querySelector('[class*="quantity"]') ||
                               container.querySelector('svg[data-testid*="quantity"]') ||
                               container.querySelector('[class*="ItemQuantity"]');

    return hasAbsolutePosition || hasQuantityControls;
  }

  /**
   * Create a dedicated container for Fresh product price info
   */
  createFreshPriceContainer(cartItem) {
    try {
      console.log('🔄 Creating dedicated Fresh price container');

      // Find the cart item's main content area
      const cartItemGrid = cartItem.querySelector('[class*="CartItem__grid"]') ||
                          cartItem.querySelector('[data-testid="cart-item"]');

      if (!cartItemGrid) {
        console.log('❌ Could not find cart item grid for Fresh container');
        return null;
      }

      // Create a dedicated price info section
      const priceSection = this.createSafeElement('div', {
        className: 'fresh-cart-price-section',
        style: 'margin-top: 12px; padding: 0 8px; width: 100%; clear: both;'
      });

      // Insert after the cart item grid
      cartItemGrid.parentNode.insertBefore(priceSection, cartItemGrid.nextSibling);
      console.log('✅ Created dedicated Fresh price container');
      return priceSection;

    } catch (error) {
      console.error('❌ Error creating Fresh price container:', error);
      return null;
    }
  }

  addCartPriceInfo(cartItem, priceData) {
    if (!this.validateElement(cartItem, 'addCartPriceInfo')) {
      console.log('❌ Cart item validation failed in addCartPriceInfo');
      return;
    }

    // Handle both old and new data structures for backwards compatibility
    let monthlyLowPrice, cartItemDetails;
    if (typeof priceData === 'number') {
      // Old structure - just monthly low price
      monthlyLowPrice = priceData;
      cartItemDetails = null;
    } else if (typeof priceData === 'object' && priceData !== null) {
      // New structure - enhanced data
      monthlyLowPrice = priceData.monthlyLowPrice;
      cartItemDetails = priceData.cartItemDetails;
    } else {
      monthlyLowPrice = null;
      cartItemDetails = null;
    }

    console.log(`🔄 Adding enhanced cart price info - Monthly: ${monthlyLowPrice}, Details:`, cartItemDetails);

    // Fresh products have a specific structure that needs special handling
    const isFreshProduct = window.location.pathname.includes('/fresh/') ||
                          cartItem.closest('[data-testid="cart-item"]')?.querySelector('a[href*="/fresh/product/"]');

    // Remove existing price info elements - be more thorough for Fresh products
    const existingPriceSelectors = [
      '.cart-monthly-price-info',
      '.cart-current-price-info',
      '.cart-fallback-price-info',
      '.cart-price-info-container',
      '.cart-selected-shipping-info',
      '.fresh-cart-price-section' // Remove previous Fresh containers
    ];

    existingPriceSelectors.forEach(selector => {
      // For Fresh products, check the entire document to catch misplaced elements
      const searchRoot = isFreshProduct ? document : cartItem;
      const existingElements = searchRoot.querySelectorAll(selector);

      existingElements.forEach(existingElement => {
        // For Fresh products, only remove if it's within or related to the current cart item
        if (!isFreshProduct || cartItem.contains(existingElement) ||
            existingElement.closest('[data-testid="cart-item"]') === cartItem) {
          existingElement.remove();
          console.log(`🧹 Removed existing ${selector}`);
        }
      });
    });

    // Try multiple selectors to find a good container for the price info

    const containerSelectors = isFreshProduct ? [
      // Fresh-specific selectors - target the cart item grid container but not the quantity controls
      '[data-testid="cart-item"] > div:last-child', // The bottom section of cart item
      '.overflow-hidden:not([class*="quantity"])', // Main content area, not quantity controls
      '[class*="CartItem__grid"] > div:last-child', // Last child of the grid (after image and content)
      '[data-testid="cart-item-content"]',
      '.cart-item-content'
    ] : [
      // Regular product selectors
      '[data-testid="cart-item-content"]',
      '.cart-item-content',
      '.overflow-x-hidden',
      'div[class*="grid"]',
      'div[class*="Grid"]',
      'div[class*="content"]',
      'div[class*="Content"]'
    ];

    let contentContainer = null;
    for (const selector of containerSelectors) {
      contentContainer = this.safeQuerySelector(cartItem, selector, 'addCartPriceInfo');
      if (contentContainer) {
        // For Fresh products, avoid inserting into quantity controls or absolutely positioned elements
        if (isFreshProduct && this.isQuantityOrPositionedContainer(contentContainer)) {
          console.log(`⚠️ Skipping container with quantity controls or absolute positioning: ${selector}`);
          contentContainer = null;
          continue;
        }
        console.log(`✅ Found content container with selector: ${selector}`);
        break;
      }
    }

    // Fresh product fallback: create a dedicated container after the cart item grid
    if (!contentContainer && isFreshProduct) {
      contentContainer = this.createFreshPriceContainer(cartItem);
    }

    // If no specific container found, use the cart item itself
    if (!contentContainer) {
      contentContainer = cartItem;
      console.log('⚠️ Using cart item itself as container');
    }

    // Create and add selected seller shipping box (minimal style) - only if seller supports ship by seller
    if (cartItemDetails?.selected_seller_shipping &&
      (cartItemDetails?.selected_seller_shipping?.is_ship_by_seller === true || cartItemDetails?.is_ship_by_seller === true)) {
      const selectedShippingElement = this.createSelectedSellerShippingElement(cartItemDetails.selected_seller_shipping);
      if (selectedShippingElement) {
        try {
          contentContainer.appendChild(selectedShippingElement);
          console.log('✅ Successfully added selected seller shipping element');
        } catch (error) {
          console.error('❌ Error appending selected seller shipping element:', error);
        }
      }
    }

    // Create and add main price info element (enhanced style)
    const priceInfoElement = this.createEnhancedCartPriceInfoElement(monthlyLowPrice, cartItemDetails);
    if (priceInfoElement) {
      try {
        contentContainer.appendChild(priceInfoElement);
        console.log('✅ Successfully added enhanced cart price info element');
      } catch (error) {
        console.error('❌ Error appending cart price info element:', error);
      }
    } else {
      console.log('❌ Failed to create enhanced cart price info element');
    }
  }

  createEnhancedCartPriceInfoElement(monthlyLowPrice, cartItemDetails) {
    try {
      console.log(`🔄 Creating separated cart price info boxes`);

      // Create a container for both boxes with Fresh-specific positioning
      const mainContainer = this.createSafeElement('div', {
        className: 'cart-price-info-container',
        style: 'position: static !important; transform: none !important; top: auto !important; left: auto !important; margin: 8px 0; display: flex; flex-direction: column; gap: 8px; width: 100%; box-sizing: border-box; z-index: auto;'
      });

      if (!mainContainer) {
        console.log('❌ Failed to create main container');
        return null;
      }

      // Create current price box (with seller info and shipping)
      if (cartItemDetails?.current_price ||
        (cartItemDetails?.shipping_cost &&
          (cartItemDetails?.is_ship_by_seller === true || cartItemDetails?.shipping_cost?.is_ship_by_seller === true))) {
        const currentPriceBox = this.createCurrentPriceBox(cartItemDetails);
        if (currentPriceBox) {
          mainContainer.appendChild(currentPriceBox);
        }
      }

      // Create monthly low price box (separate)
      if (monthlyLowPrice && monthlyLowPrice > 0) {
        const monthlyPriceBox = this.createMonthlyPriceBox(monthlyLowPrice);
        if (monthlyPriceBox) {
          mainContainer.appendChild(monthlyPriceBox);
        }
      }

      // If no data available, show fallback message
      if (!monthlyLowPrice && !cartItemDetails) {
        const fallbackBox = this.createFallbackPriceBox();
        if (fallbackBox) {
          mainContainer.appendChild(fallbackBox);
        }
      }

      console.log('✅ Successfully created separated cart price info boxes');
      return mainContainer;

    } catch (error) {
      console.error('❌ Error creating separated cart price info boxes:', error);
      return null;
    }
  }

  createCurrentPriceBox(cartItemDetails) {
    try {
      // [ShippingCost:UI] Function entry logging
      console.log(`[ShippingCost:UI] ===== createCurrentPriceBox ENTRY =====`);
      console.log(`[ShippingCost:UI] Input cartItemDetails:`, {
        has_cartItemDetails: !!cartItemDetails,
        has_current_price: !!cartItemDetails?.current_price,
        has_shipping_cost: !!cartItemDetails?.shipping_cost,
        shipping_cost_value: cartItemDetails?.shipping_cost?.cost,
        shipping_cost_display: cartItemDetails?.shipping_cost?.display_text,
        shipping_cost_is_free: cartItemDetails?.shipping_cost?.is_free,
        is_ship_by_seller: cartItemDetails?.is_ship_by_seller,
        shipping_cost_obj: cartItemDetails?.shipping_cost,
        full_details: cartItemDetails
      });

      console.log('🔄 Creating current price box');

      const currentPriceBox = this.createSafeElement('div', {
        className: 'cart-current-price-info',
        style: 'position: static !important; transform: none !important; top: auto !important; left: auto !important; background: linear-gradient(135deg, #dbeafe, #bfdbfe); border: 1px solid #93c5fd; border-radius: 6px; padding: 8px 10px; margin-top: 6px; color: #1e40af; font-size: 10px; box-shadow: 0 1px 4px rgba(59, 130, 246, 0.2); display: block; width: 100%; box-sizing: border-box;'
      });

      if (!currentPriceBox) {
        console.log('❌ Failed to create current price box');
        return null;
      }

      // Header
      const headerSection = this.createSafeElement('div', {
        style: 'display: flex; align-items: center; gap: 6px; margin-bottom: 6px;'
      });

      const headerIcon = this.createSafeElement('span', {
        text: '💰',
        style: 'font-size: 11px;'
      });

      const headerText = this.createSafeElement('span', {
        text: ' قیمت فعلی کمترین',
        style: 'font-weight: 600; font-size: 10px; color: #1e40af;'
      });

      if (headerSection && headerIcon && headerText) {
        headerSection.appendChild(headerIcon);
        headerSection.appendChild(headerText);
        currentPriceBox.appendChild(headerSection);
      }

      // Current Price with Seller and Variant Details
      if (cartItemDetails?.current_price) {
        const currentPriceSection = this.createSafeElement('div', {
          style: 'margin-bottom: 6px;'
        });

        const priceText = this.createSafeElement('div', {
          text: cartItemDetails.current_price.display_text,
          style: 'font-weight: 500; font-size: 10px; line-height: 1.3; color: #1e40af; opacity: 0.9;'
        });

        if (currentPriceSection && priceText) {
          currentPriceSection.appendChild(priceText);
          currentPriceBox.appendChild(currentPriceSection);
        }
      }

      // Seller Shipping Cost - only show if seller supports ship by seller
      console.log(`[ShippingCost:UI] ===== SHIPPING DISPLAY CHECK =====`);
      console.log(`[ShippingCost:UI] Checking if should display shipping:`, {
        has_shipping_cost: !!cartItemDetails?.shipping_cost,
        shipping_cost_value: cartItemDetails?.shipping_cost?.cost,
        shipping_cost_display: cartItemDetails?.shipping_cost?.display_text,
        is_ship_by_seller: cartItemDetails?.is_ship_by_seller,
        shipping_cost_is_ship_by_seller: cartItemDetails?.shipping_cost?.is_ship_by_seller,
        condition_met: cartItemDetails?.shipping_cost && (cartItemDetails?.is_ship_by_seller === true || cartItemDetails?.shipping_cost?.is_ship_by_seller === true),
        full_shipping_object: cartItemDetails?.shipping_cost
      });

      if (cartItemDetails?.shipping_cost &&
        (cartItemDetails?.is_ship_by_seller === true || cartItemDetails?.shipping_cost?.is_ship_by_seller === true)) {

        console.log(`[ShippingCost:UI] ===== CREATING SHIPPING UI ELEMENTS =====`);
        console.log(`[ShippingCost:UI] About to create shipping UI with display_text:`, cartItemDetails.shipping_cost.display_text);

        const shippingSection = this.createSafeElement('div', {
          style: 'display: flex; align-items: center; gap: 4px;'
        });

        const shippingIcon = this.createSafeElement('span', {
          text: '🚚',
          style: 'font-size: 11px;'
        });

        const shippingText = this.createSafeElement('span', {
          text: cartItemDetails.shipping_cost.display_text,
          style: `font-size: 9px; font-weight: 400; color: #1e40af; opacity: 0.7;`
        });

        console.log(`[ShippingCost:UI] Created shipping elements:`, {
          shippingSection_created: !!shippingSection,
          shippingIcon_created: !!shippingIcon,
          shippingText_created: !!shippingText,
          shippingText_content: shippingText?.textContent,
          display_text_used: cartItemDetails.shipping_cost.display_text
        });

        if (shippingSection && shippingIcon && shippingText) {
          shippingSection.appendChild(shippingIcon);
          shippingSection.appendChild(shippingText);
          currentPriceBox.appendChild(shippingSection);
          console.log(`[ShippingCost:UI] ===== SHIPPING UI APPENDED SUCCESSFULLY =====`);
        } else {
          console.log(`[ShippingCost:UI] ===== FAILED TO CREATE SHIPPING UI ELEMENTS =====`);
        }
      } else {
        console.log(`[ShippingCost:UI] ===== SHIPPING NOT DISPLAYED =====`);
        console.log(`[ShippingCost:UI] Shipping display condition not met - no shipping cost will be shown`);
      }

      return currentPriceBox;
    } catch (error) {
      console.error('❌ Error creating current price box:', error);
      return null;
    }
  }

  createMonthlyPriceBox(monthlyLowPrice) {
    try {
      console.log('🔄 Creating monthly price box with order page style');

      const monthlyPriceBox = this.createSafeElement('div', {
        className: 'cart-monthly-price-info',
        style: 'position: static !important; transform: none !important; top: auto !important; left: auto !important; background: linear-gradient(135deg, #dbeafe, #bfdbfe); border: 1px solid #93c5fd; border-radius: 6px; padding: 8px 10px; margin-top: 6px; color: #1e40af; font-size: 10px; box-shadow: 0 1px 4px rgba(59, 130, 246, 0.2); display: block; width: 100%; box-sizing: border-box;'
      });

      if (!monthlyPriceBox) {
        console.log('❌ Failed to create monthly price box');
        return null;
      }

      // Create content
      const content = this.createSafeElement('div', {
        style: 'display: flex; align-items: center; gap: 6px;'
      });

      const icon = this.createSafeElement('span', {
        text: '📊',
        style: 'font-size: 11px;'
      });

      const textContainer = this.createSafeElement('div', {
        style: 'flex: 1;'
      });

      const titleText = this.createSafeElement('div', {
        text: 'کمترین قیمت ۳۰ روز اخیر',
        style: 'font-weight: 600; font-size: 10px; margin-bottom: 2px; color: #1e40af;'
      });

      const priceText = this.createSafeElement('div', {
        text: this.formatPrice(monthlyLowPrice),
        style: 'font-weight: 500; font-size: 10px; color: #1e40af; opacity: 0.9;'
      });

      if (content && icon && textContainer && titleText && priceText) {
        textContainer.appendChild(titleText);
        textContainer.appendChild(priceText);
        content.appendChild(icon);
        content.appendChild(textContainer);
        monthlyPriceBox.appendChild(content);
      }

      return monthlyPriceBox;
    } catch (error) {
      console.error('❌ Error creating monthly price box:', error);
      return null;
    }
  }

  createFallbackPriceBox() {
    try {
      const fallbackBox = this.createSafeElement('div', {
        className: 'cart-fallback-price-info',
        style: 'background: #f3f4f6; border: 1px solid #d1d5db; border-radius: 8px; padding: 14px; color: #6b7280; font-size: 12px; text-align: center;'
      });

      if (!fallbackBox) {
        return null;
      }

      const fallbackSection = this.createSafeElement('div', {
        style: 'display: flex; align-items: center; justify-content: center; gap: 8px;'
      });

      const fallbackIcon = this.createSafeElement('span', {
        text: '⚠️',
        style: 'font-size: 14px;'
      });

      const fallbackText = this.createSafeElement('span', {
        text: 'اطلاعات قیمت در دسترس نیست',
        style: 'font-weight: 500;'
      });

      if (fallbackSection && fallbackIcon && fallbackText) {
        fallbackSection.appendChild(fallbackIcon);
        fallbackSection.appendChild(fallbackText);
        fallbackBox.appendChild(fallbackSection);
      }

      return fallbackBox;
    } catch (error) {
      console.error('❌ Error creating fallback price box:', error);
      return null;
    }
  }

  createPriceInfoSection(icon, text, color) {
    try {
      const section = this.createSafeElement('div', {
        style: 'display: flex; align-items: center; margin-bottom: 6px; gap: 8px;'
      });

      const iconElement = this.createSafeElement('span', {
        text: icon,
        style: 'font-size: 14px; flex-shrink: 0;'
      });

      const textElement = this.createSafeElement('span', {
        text: text,
        style: `color: ${color}; font-weight: 500; line-height: 1.4; font-size: 11px;`
      });

      if (section && iconElement && textElement) {
        section.appendChild(iconElement);
        section.appendChild(textElement);
        return section;
      }

      return null;
    } catch (error) {
      console.error('❌ Error creating price info section:', error);
      return null;
    }
  }

  createSelectedSellerShippingElement(selectedShipping) {
    try {
      console.log('🔄 Creating minimal selected seller shipping element');

      // Create minimal container with subtle styling
      const shippingContainer = this.createSafeElement('div', {
        className: 'cart-selected-shipping-info',
        style: `
          background: #f8f9fa;
          border: 1px solid #e9ecef;
          border-radius: 4px;
          padding: 8px 12px;
          margin: 6px 0 4px 0;
          font-size: 11px;
          color: #6c757d;
          display: flex;
          align-items: center;
          gap: 6px;
        `
      });

      if (!shippingContainer) {
        console.log('❌ Failed to create selected shipping container');
        return null;
      }

      // Add shipping icon
      const shippingIcon = this.createSafeElement('span', {
        text: '📦',
        style: 'font-size: 12px; flex-shrink: 0;'
      });

      // Create shipping text with better logic for displaying seller shipping costs
      let shippingText = '';
      if (selectedShipping.no_shipping_info) {
        shippingText = selectedShipping.display_text;
      } else if (selectedShipping.is_free === true || selectedShipping.cost === 0) {
        shippingText = `ارسال انتخابی: رایگان (${selectedShipping.seller_name})`;
      } else if (typeof selectedShipping.cost === 'number' && selectedShipping.cost > 0) {
        shippingText = `ارسال انتخابی: ${this.formatPrice(selectedShipping.cost)} (${selectedShipping.seller_name})`;
      } else if (selectedShipping.display_text && selectedShipping.display_text.includes('ارسال')) {
        // If display_text contains shipping info, use it with seller name
        shippingText = `${selectedShipping.display_text} (${selectedShipping.seller_name})`;
      } else {
        // Fallback: show seller name only if no cost information is available
        shippingText = `فروشنده انتخابی: ${selectedShipping.seller_name}`;
      }

      const textElement = this.createSafeElement('span', {
        text: shippingText,
        style: 'font-weight: 500; line-height: 1.3;'
      });

      if (shippingIcon && textElement) {
        shippingContainer.appendChild(shippingIcon);
        shippingContainer.appendChild(textElement);
      }

      console.log('✅ Successfully created selected seller shipping element');
      return shippingContainer;

    } catch (error) {
      console.error('❌ Error creating selected seller shipping element:', error);
      return null;
    }
  }

  /**
   * Add seller shipping cost to single product page shipping section
   * @param {Object} sellerShippingInfo - Shipping information
   */
  addShippingCostToProductPage(sellerShippingInfo) {
    try {
      if (!sellerShippingInfo || !sellerShippingInfo.is_seller_only) {
        return;
      }

      console.log('🚚 Adding shipping cost to product page:', sellerShippingInfo);

      // Find the shipping section with the specific HTML structure mentioned
      const shippingSection = this.findShippingSection();
      if (!shippingSection) {
        console.log('❌ Could not find shipping section');
        return;
      }

      // Find the "توسط فروشنده" text element
      const sellerShippingElement = this.findSellerShippingElement(shippingSection);
      if (!sellerShippingElement) {
        console.log('❌ Could not find seller shipping element');
        return;
      }

      // Check if shipping cost is already added
      const existingCost = sellerShippingElement.querySelector('.seller-shipping-cost');
      if (existingCost) {
        console.log('🔍 Shipping cost already exists, skipping');
        return;
      }

      // Create shipping cost element
      const shippingCostElement = this.createSafeElement('span', {
        className: 'seller-shipping-cost',
        text: ` (${sellerShippingInfo.display_text})`,
        style: `color: ${sellerShippingInfo.is_free ? '#059669' : '#d97706'}; font-weight: 500; margin-right: 4px;`
      });

      if (shippingCostElement) {
        sellerShippingElement.appendChild(shippingCostElement);
        console.log('✅ Shipping cost added to product page');
      }

    } catch (error) {
      console.error('❌ Error adding shipping cost to product page:', error);
    }
  }

  /**
   * Find the shipping section in product page
   */
  findShippingSection() {
    try {
      console.log('🔍 Looking for shipping section...');

      // First try to find by the specific class structure mentioned by user
      const specificSelector = 'div.border-complete-t-200.py-3';
      const specificElements = document.querySelectorAll(specificSelector);

      for (const element of specificElements) {
        if (element.textContent && element.textContent.includes('روش و هزینه ارسال')) {
          console.log('✅ Found shipping section with specific selector');
          return element;
        }
      }

      // Fallback: Search all divs for shipping text and find the parent container
      console.log('🔄 Trying fallback method...');
      const allDivs = document.querySelectorAll('div');
      for (const element of allDivs) {
        if (element.textContent && element.textContent.includes('روش و هزینه ارسال')) {
          // Look for parent with border or py classes, or return the element itself
          const parent = element.closest('div[class*="border-complete-t-200"], div[class*="py-3"], div[class*="border"]') || element.parentElement || element;
          console.log('✅ Found shipping section with fallback method');
          return parent;
        }
      }

      // Additional fallback for other shipping text variations
      const shippingTexts = ['هزینه ارسال', 'ارسال', 'shipping'];
      for (const text of shippingTexts) {
        for (const element of allDivs) {
          if (element.textContent && element.textContent.includes(text)) {
            const parent = element.closest('div[class*="border"], div[class*="py-"]') || element.parentElement || element;
            console.log(`✅ Found shipping section with text: ${text}`);
            return parent;
          }
        }
      }

      console.log('❌ No shipping section found');
      return null;
    } catch (error) {
      console.error('Error finding shipping section:', error);
      return null;
    }
  }

  /**
   * Find the seller shipping element (توسط فروشنده)
   */
  findSellerShippingElement(shippingSection) {
    try {
      console.log('🔍 Looking for seller shipping element...');

      // First try to find the exact span with classes as shown in user's HTML
      const specificSelectors = [
        'span.text-body-2.text-neutral-500',
        'span[class*="text-body-2"][class*="text-neutral-500"]',
        'span[class*="text-neutral-500"]',
        'span[class*="text-body-2"]'
      ];

      for (const selector of specificSelectors) {
        const elements = shippingSection.querySelectorAll(selector);
        for (const element of elements) {
          if (element.textContent && element.textContent.trim() === 'توسط فروشنده') {
            console.log(`✅ Found seller shipping element with selector: ${selector}`);
            return element;
          }
        }
      }

      // Fallback: Look for the "توسط فروشنده" text in any span or div
      console.log('🔄 Using fallback method to find seller element...');
      const textElements = shippingSection.querySelectorAll('span, div, p');
      for (const element of textElements) {
        if (element.textContent && element.textContent.trim() === 'توسط فروشنده') {
          console.log('✅ Found seller shipping element with fallback method');
          return element;
        }
      }

      // Even more broad fallback
      const allElements = shippingSection.querySelectorAll('*');
      for (const element of allElements) {
        if (element.textContent && element.textContent.includes('توسط فروشنده')) {
          console.log('✅ Found seller shipping element with broad fallback');
          return element;
        }
      }

      console.log('❌ No seller shipping element found');
      return null;
    } catch (error) {
      console.error('Error finding seller shipping element:', error);
      return null;
    }
  }

  createCartPriceInfoElement(monthlyLowPrice) {
    // Keep for backwards compatibility - delegate to enhanced version
    return this.createEnhancedCartPriceInfoElement(monthlyLowPrice, null);
  }

  markProductAsError(productElement) {
    if (!this.validateElement(productElement, 'markProductAsError')) {
      return;
    }

    const container = productElement.tagName === 'ARTICLE' ? productElement : this.safeQuerySelector(productElement, 'article', 'markProductAsError');
    if (!container) {
      return;
    }

    const errorIndicator = this.createSafeElement('div', {
      className: 'seller-error-indicator',
      text: '⚠️',
      style: 'position: absolute; top: 5px; right: 5px; background: #dc3545; color: white; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 12px; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,0.3);'
    });

    if (container.style.position !== 'relative') {
      container.style.position = 'relative';
    }

    container.appendChild(errorIndicator);
  }

  markProductAsUnavailable(productElement) {
    if (!this.validateElement(productElement, 'markProductAsUnavailable')) {
      return;
    }

    const container = productElement.tagName === 'ARTICLE' ? productElement : this.safeQuerySelector(productElement, 'article', 'markProductAsUnavailable');
    if (!container) {
      return;
    }

    const unavailableIndicator = this.createSafeElement('div', {
      className: 'seller-unavailable-indicator',
      text: '❌',
      style: 'position: absolute; top: 5px; left: 5px; background: #6c757d; color: white; border-radius: 4px; padding: 2px 6px; font-size: 10px; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,0.3);'
    });

    if (container.style.position !== 'relative') {
      container.style.position = 'relative';
    }

    container.appendChild(unavailableIndicator);
  }

  addUpdatedIndicator(productElement) {
    if (!this.validateElement(productElement, 'addUpdatedIndicator')) {
      return;
    }

    const existingIndicator = this.safeQuerySelector(productElement, '.seller-updated-indicator', 'addUpdatedIndicator');
    if (existingIndicator) {
      return;
    }

    const container = productElement.tagName === 'ARTICLE' ? productElement : this.safeQuerySelector(productElement, 'article', 'addUpdatedIndicator');
    if (!container) {
      return;
    }

    const updatedIndicator = this.createSafeElement('div', {
      className: 'seller-updated-indicator',
      text: '✓',
      style: 'position: absolute; top: 5px; right: 5px; background: #28a745; color: white; border-radius: 50%; width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; font-size: 12px; z-index: 10; box-shadow: 0 1px 3px rgba(0,0,0,0.3);'
    });

    if (container.style.position !== 'relative') {
      container.style.position = 'relative';
    }

    container.appendChild(updatedIndicator);
  }

  removeUpdatedIndicator(productElement) {
    const indicator = this.safeQuerySelector(productElement, '.seller-updated-indicator', 'removeUpdatedIndicator');
    if (indicator) {
      indicator.remove();
    }
  }

  formatPrice(priceInRials) {
    if (!priceInRials || priceInRials <= 0) return '';
    // Convert Rials to Tomans by dividing by 10
    const priceInTomans = Math.round(priceInRials / 10);
    return priceInTomans.toLocaleString('fa-IR') + ' تومان';
  }

  sanitizeNumber(value) {
    const num = parseFloat(value);
    return isNaN(num) ? 0 : Math.max(0, num);
  }

  removeAllSellerElements() {
    const selectors = [
      '.seller-price-info',
      '.monthly-price-info',
      '.cart-monthly-price-info',
      '.seller-updated-indicator',
      '.seller-error-indicator',
      '.seller-unavailable-indicator'
    ];

    selectors.forEach(selector => {
      const elements = this.safeQuerySelectorAll(document, selector, 'removeAllSellerElements');
      elements.forEach(element => element.remove());
    });
  }

  setupMutationObserver(callback, options = {}) {
    if (this.observer) {
      this.observer.disconnect();
    }

    const defaultOptions = {
      childList: true,
      subtree: true,
      attributes: false
    };

    this.observer = new MutationObserver(callback);
    this.observer.observe(document.body, { ...defaultOptions, ...options });
    this.isObserving = true;
  }

  disconnectObserver() {
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
      this.isObserving = false;
    }
  }

  async waitForCartItemsAndProcess(maxAttempts = 15, interval = 3000) {
    console.log('⏳ Waiting for cart items to load...');

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      console.log(`⏳ Attempt ${attempt}/${maxAttempts}: Checking for cart items...`);

      // Get visible cart items
      const cartItems = this.detectCartItems();

      if (cartItems.length > 0) {
        // Additional check: Make sure the items have content loaded
        let itemsReady = 0;

        for (const item of cartItems) {
          const hasContent = item.querySelector('.overflow-x-hidden') &&
            item.querySelector('h3') && // Product title
            item.textContent.trim().length > 100; // Has substantial content

          if (hasContent) {
            itemsReady++;
          }
        }

        if (itemsReady === cartItems.length) {
          console.log(`✅ Found ${cartItems.length} fully loaded cart items after ${attempt} attempts`);
          return cartItems;
        } else {
          console.log(`⏳ Found ${cartItems.length} cart items but only ${itemsReady} are fully loaded`);
        }
      }

      // Check if cart is empty (has empty cart message)
      const emptyCartIndicators = [
        document.querySelector('[data-testid="empty-cart"]'),
        document.querySelector('.empty-cart'),
        document.querySelector('[class*="empty"]'),
        document.querySelector('[class*="Empty"]')
      ].filter(Boolean);

      if (emptyCartIndicators.length > 0) {
        console.log('ℹ️ Cart appears to be empty');
        return [];
      }

      // Check for loading indicators
      const loadingIndicators = [
        document.querySelector('[class*="loading"]'),
        document.querySelector('[class*="Loading"]'),
        document.querySelector('[class*="spinner"]'),
        document.querySelector('[class*="skeleton"]')
      ].filter(Boolean);

      if (loadingIndicators.length > 0) {
        console.log('⏳ Page still loading, waiting longer...');
        interval = Math.min(interval * 1.2, 2000); // Increase wait time if still loading
      }

      if (attempt < maxAttempts) {
        console.log(`⏳ Cart items not ready, waiting ${interval}ms...`);
        await new Promise(resolve => setTimeout(resolve, interval));
      }
    }

    console.log('⚠️ Cart items not found after maximum attempts');

    // Fallback: return whatever cart items we can find, even if not fully loaded
    const fallbackItems = this.detectCartItems();
    if (fallbackItems.length > 0) {
      console.log(`⚠️ Using ${fallbackItems.length} partially loaded cart items as fallback`);
      return fallbackItems;
    }

    return [];
  }

  removeCartPriceInfo() {
    console.log('🧹 Removing cart price information');

    // Get visible cart items and remove price info from each
    const visibleCartItems = this.detectCartItems();

    visibleCartItems.forEach((cartItem, index) => {
      // Remove all price info elements (both old and new structure)
      const priceInfoSelectors = [
        '.cart-monthly-price-info',
        '.cart-current-price-info',
        '.cart-fallback-price-info',
        '.cart-price-info-container',
        '.cart-selected-shipping-info',
        '.order-current-price-info' // Also remove any stray order elements
      ];

      priceInfoSelectors.forEach(selector => {
        const priceInfo = cartItem.querySelector(selector);
        if (priceInfo) {
          priceInfo.remove();
          console.log(`✅ Removed ${selector} from cart item ${index + 1}`);
        }
      });
    });

    // Also clean up any order elements that might have appeared globally
    document.querySelectorAll('.order-current-price-info').forEach(element => {
      element.remove();
      console.log('🧹 Removed stray order price info element');
    });

    console.log(`✅ Cart price information removed from ${visibleCartItems.length} items`);
  }

  // Order Detail Page Methods
  extractProductIdFromOrderItem(orderItem) {
    if (!this.validateElement(orderItem, 'extractProductIdFromOrderItem')) {
      return null;
    }

    console.log('🔍 Extracting product ID from order item');

    // 1. Check if the item itself is a product link
    if (orderItem.matches('a[href*="/product/"]')) {
      const href = orderItem.getAttribute('href');
      const productId = this.extractProductIdFromUrl(href);
      if (productId) {
        console.log('✅ Found product ID from order item href:', productId);
        return productId;
      }
    }

    // 2. Look for product links within the item
    const productLinks = this.safeQuerySelectorAll(orderItem, 'a[href*="/product/"]', 'extractProductIdFromOrderItem');
    for (const link of productLinks) {
      const href = link.getAttribute('href');
      const productId = this.extractProductIdFromUrl(href);
      if (productId) {
        console.log('✅ Found product ID from order item link:', productId);
        return productId;
      }
    }

    // 3. Check data attributes
    if (orderItem.dataset.productId) {
      console.log('✅ Found product ID from data attribute:', orderItem.dataset.productId);
      return orderItem.dataset.productId;
    }

    console.log('❌ Could not extract product ID from order item');
    return null;
  }

  extractProductIdFromUrl(href) {
    if (!href) return null;

    const patterns = [
      /\/product\/dkp-(\d+)\//,
      /\/product\/(\d+)\//,
      /dkp-(\d+)/,
      /\/dp\/(\d+)\//,
      /product-id[=:](\d+)/,
      /\/(\d{6,})\//,
      /[?&]id=(\d+)/
    ];

    for (const pattern of patterns) {
      const match = href.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }

    return null;
  }

  addOrderPriceInfo(orderItem, priceData) {
    if (!this.validateElement(orderItem, 'addOrderPriceInfo')) {
      console.log('❌ Order item validation failed in addOrderPriceInfo');
      return;
    }

    // Double-check we're on an order page to prevent cart contamination
    const url = window.location.href;
    const isOrderPage = url.includes('/profile/orders/') && /\/profile\/orders\/\d+/.test(url);
    const isCartPage = url.includes('/cart') || url.includes('/checkout');

    if (!isOrderPage || isCartPage) {
      console.log('❌ Not on order page or on cart page - skipping order price info');
      return;
    }

    const { currentLowestPrice, productId } = priceData;

    console.log(`🔄 Adding current price info to order item for product ${productId}`, currentLowestPrice);

    // Remove existing price info
    const existingPriceInfo = this.safeQuerySelector(orderItem, '.order-current-price-info', 'addOrderPriceInfo');
    if (existingPriceInfo) {
      existingPriceInfo.remove();
      console.log('🧹 Removed existing order price info');
    }

    if (!currentLowestPrice || !currentLowestPrice.price) {
      console.log('⚠️ No current lowest price data available');
      return;
    }

    // Create compact price info element
    const priceInfoElement = this.createOrderPriceInfoElement(currentLowestPrice, productId);
    if (!priceInfoElement) {
      console.log('❌ Failed to create order price info element');
      return;
    }

    // Find the best container for the price info - try to place it after the product info but before the rating section
    const containerSelectors = [
      '.overflow-x-hidden', // Content area - better positioning
      '[class*="CartItem"]', // Cart item grid area
      '.h-\\[40px\\]', // The price section container - as fallback
      '[class*="grid"]' // Any grid container
    ];

    let targetContainer = null;
    for (const selector of containerSelectors) {
      targetContainer = this.safeQuerySelector(orderItem, selector, 'addOrderPriceInfo');
      if (targetContainer) {
        console.log(`✅ Found target container with selector: ${selector}`);
        break;
      }
    }

    // Fallback to the order item itself
    if (!targetContainer) {
      targetContainer = orderItem;
      console.log('⚠️ Using order item itself as container');
    }

    try {
      targetContainer.appendChild(priceInfoElement);

      // Add entrance animation
      if (priceInfoElement.animate) {
        priceInfoElement.animate([
          { opacity: 0, transform: 'translateY(5px)' },
          { opacity: 1, transform: 'translateY(0)' }
        ], {
          duration: 250,
          easing: 'ease-out'
        });
      }

      console.log(`✅ Successfully added current price info to order item for product ${productId}`);
    } catch (error) {
      console.error('❌ Error appending order price info element:', error);
    }
  }

  createOrderPriceInfoElement(currentLowestPrice, productId) {
    try {
      const priceInfoElement = this.createSafeElement('div', {
        className: 'order-current-price-info',
        style: 'background: linear-gradient(135deg, #dbeafe, #bfdbfe); border: 1px solid #93c5fd; border-radius: 6px; padding: 8px 10px; margin-top: 6px; color: #1e40af; font-size: 10px; box-shadow: 0 1px 4px rgba(59, 130, 246, 0.2);'
      });

      if (!priceInfoElement) {
        return null;
      }

      // Format price
      const formattedPrice = Math.round(currentLowestPrice.price / 10).toLocaleString('fa-IR');

      // Create content
      const content = this.createSafeElement('div', {
        style: 'display: flex; align-items: center; gap: 6px;'
      });

      const icon = this.createSafeElement('span', {
        text: '💰',
        style: 'font-size: 11px;'
      });

      const textContainer = this.createSafeElement('div', {
        style: 'flex: 1;'
      });

      const titleText = this.createSafeElement('div', {
        text: 'کمترین قیمت فعلی',
        style: 'font-weight: 600; font-size: 10px; margin-bottom: 2px; color: #1e40af;'
      });

      const priceText = this.createSafeElement('div', {
        text: `${formattedPrice} تومان`,
        style: 'font-weight: 500; font-size: 10px; color: #1e40af; opacity: 0.9;'
      });

      // Add seller info if available
      if (currentLowestPrice.seller_name && currentLowestPrice.seller_name !== 'نامشخص') {
        const sellerText = this.createSafeElement('div', {
          text: `فروشنده: ${currentLowestPrice.seller_name}`,
          style: 'font-weight: 400; font-size: 9px; color: #1e40af; opacity: 0.7; margin-top: 1px;'
        });
        if (sellerText) {
          textContainer.appendChild(titleText);
          textContainer.appendChild(priceText);
          textContainer.appendChild(sellerText);
        }
      } else {
        if (titleText && priceText) {
          textContainer.appendChild(titleText);
          textContainer.appendChild(priceText);
        }
      }

      if (content && icon && textContainer) {
        content.appendChild(icon);
        content.appendChild(textContainer);
        priceInfoElement.appendChild(content);
      }

      return priceInfoElement;
    } catch (error) {
      console.error('❌ Error creating order price info element:', error);
      return null;
    }
  }

  removeOrderPriceInfo() {
    console.log('🧹 Removing order price information');

    const priceInfoElements = document.querySelectorAll('.order-current-price-info');
    priceInfoElements.forEach(element => {
      element.remove();
    });

    console.log(`✅ Order price information removed from ${priceInfoElements.length} items`);
  }

  showNotification(options) {
    const notification = document.createElement('div');
    notification.className = `extension-notification notification-${options.type}`;

    const typeStyles = {
      info: 'background: rgba(59, 130, 246, 0.9); color: white;',
      success: 'background: rgba(34, 197, 94, 0.9); color: white;',
      warning: 'background: rgba(245, 158, 11, 0.9); color: white;',
      error: 'background: rgba(239, 68, 68, 0.9); color: white;'
    };

    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      ${typeStyles[options.type] || typeStyles.info}
      padding: 16px 20px;
      border-radius: 8px;
      font-size: 14px;
      z-index: 1000;
      max-width: 350px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.1);
    `;

    let notificationContent = `
      <div style="display: flex; align-items: center; gap: 12px;">
        <div style="font-weight: bold;">${options.title}</div>
      </div>
    `;

    if (options.message) {
      notificationContent += `<div style="margin-top: 8px; opacity: 0.9;">${options.message}</div>`;
    }

    notification.innerHTML = notificationContent;

    // Add action buttons if provided
    if (options.actions && options.actions.length > 0) {
      const actionContainer = document.createElement('div');
      actionContainer.style.cssText = 'margin-top: 12px; display: flex; gap: 8px;';

      options.actions.forEach(action => {
        const button = document.createElement('button');
        button.textContent = action.text;
        button.style.cssText = `
          padding: 6px 12px;
          border: 1px solid rgba(255, 255, 255, 0.3);
          background: rgba(255, 255, 255, 0.2);
          color: white;
          border-radius: 4px;
          font-size: 12px;
          cursor: pointer;
        `;

        button.addEventListener('click', () => {
          if (action.action) action.action();
          notification.remove();
        });

        actionContainer.appendChild(button);
      });

      notification.appendChild(actionContainer);
    }

    document.body.appendChild(notification);

    // Auto-hide if specified
    if (options.autoHide) {
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove();
        }
      }, options.autoHide);
    }

    return notification;
  }

  showErrorDialog(options) {
    const overlay = document.createElement('div');
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 1001;
      display: flex;
      align-items: center;
      justify-content: center;
    `;

    const dialog = document.createElement('div');
    dialog.style.cssText = `
      background: white;
      border-radius: 12px;
      padding: 24px;
      max-width: 400px;
      margin: 20px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    `;

    dialog.innerHTML = `
      <div style="font-size: 18px; font-weight: bold; margin-bottom: 16px; color: #333;">
        ${options.title}
      </div>
      <div style="font-size: 14px; line-height: 1.6; color: #666; margin-bottom: 24px;">
        ${options.message}
      </div>
    `;

    // Add action buttons
    const actionContainer = document.createElement('div');
    actionContainer.style.cssText = 'display: flex; gap: 12px; justify-content: flex-end;';

    options.actions.forEach(action => {
      const button = document.createElement('button');
      button.textContent = action.text;
      button.style.cssText = `
        padding: 10px 20px;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        cursor: pointer;
        ${action.primary ? 'background: #3b82f6; color: white;' : 'background: #f3f4f6; color: #374151;'}
        ${action.danger ? 'background: #ef4444; color: white;' : ''}
      `;

      button.addEventListener('click', () => {
        if (action.action) action.action();
        overlay.remove();
      });

      actionContainer.appendChild(button);
    });

    dialog.appendChild(actionContainer);
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    // Close on overlay click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.remove();
      }
    });
  }

  showStorageErrorNotification(feature) {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(239, 68, 68, 0.9);
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 12px;
      z-index: 1001;
      box-shadow: 0 4px 8px rgba(239, 68, 68, 0.4);
    `;
    notification.textContent = `⚠️ خطا در بارگذاری ${feature}. از تنظیمات پیش‌فرض استفاده می‌شود.`;

    document.body.appendChild(notification);

    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 5000);
  }

  removeAllNotifications() {
    // Remove extension notifications
    const notifications = document.querySelectorAll('.extension-notification');
    notifications.forEach(notification => {
      notification.remove();
    });

    // Remove emergency stop UI
    const emergencyStop = document.getElementById('extension-emergency-stop');
    if (emergencyStop) {
      emergencyStop.remove();
    }
    console.log(`✅ Removed ${notifications.length} notifications and emergency UI`);
  }

  async addMonthlyPriceBelowMainPrice(productData, productId, dataManager) {
    // Multiple strategies to find the main price element
    let priceElement = null;
    let priceContainer = null;

    // Strategy 1: XPath approach
    const xpaths = [
      "//div[@data-testid='buy-box']//div[@class='flex justify-start mr-auto text-h3']",
      "//div[@data-testid='buy-box']//span[@data-testid='price-final']",
      "//div[@data-testid='buy-box']//span[contains(@class,'price')]",
      "//div[@data-testid='buy-box']//div[contains(@class,'text-h3')]"
    ];

    for (const xpath of xpaths) {
      try {
        const result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        if (result.singleNodeValue) {
          priceElement = result.singleNodeValue;
          console.log(`✅ Found price element with XPath: ${xpath}`);
          break;
        }
      } catch (e) {
        console.log(`⚠️ XPath failed: ${xpath}`);
        continue;
      }
    }

    // Strategy 2: CSS selector approach
    if (!priceElement) {
      const selectors = [
        '[data-testid="buy-box"] [data-testid="price-final"]',
        '[data-testid="buy-box"] .flex.justify-start.mr-auto.text-h3',
        '[data-testid="price-final"]',
        '[data-testid="buy-box"] span[class*="price"]',
        '[data-testid="buy-box"] div[class*="text-h3"]'
      ];

      for (const selector of selectors) {
        try {
          priceElement = document.querySelector(selector);
          if (priceElement) {
            console.log(`✅ Found price element with CSS: ${selector}`);
            break;
          }
        } catch (e) {
          continue;
        }
      }
    }

    if (!priceElement) {
      console.log('❌ Could not find main price element with any strategy');
      return;
    }

    // Find the parent container of the price element with multiple fallbacks
    const containerSelectors = [
      '.flex.flex-row.items-center',
      '[data-testid="buy-box"]',
      '.price-container',
      '.price-wrapper'
    ];

    for (const selector of containerSelectors) {
      priceContainer = priceElement.closest(selector);
      if (priceContainer) {
        console.log(`✅ Found price container: ${selector}`);
        break;
      }
    }

    if (!priceContainer) {
      priceContainer = priceElement.parentElement;
      console.log('⚠️ Using price element parent as container');
    }

    if (!priceContainer) {
      console.log('❌ Could not find suitable price container');
      return;
    }

    // Check if monthly price section already exists
    const existingSection = document.querySelector('.monthly-price-main-section');
    if (existingSection) {
      console.log('ℹ️ Monthly price section already exists, updating content');
      existingSection.remove();
    }

    // Get monthly low price
    const monthlyLowPrice = await dataManager.extractMonthlyLowPrice(productData, productId);

    if (monthlyLowPrice && monthlyLowPrice > 0) {
      // Create monthly price section
      const monthlySection = this.createSafeElement('div', {
        className: 'monthly-price-main-section',
        style: 'margin-top: 12px; padding: 12px; background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%); border: 1px solid #ffeeba; border-radius: 8px; font-size: 14px; color: #856404;'
      });

      monthlySection.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 16px;">📊</span>
          <span style="font-weight: 600;">کمترین قیمت 30 روز گذشته: ${dataManager.formatPrice(monthlyLowPrice)}</span>
        </div>
      `;

      // Insert after the price container
      priceContainer.parentNode.insertBefore(monthlySection, priceContainer.nextSibling);
      console.log('✅ Monthly price section added to product detail page');
    }
  }

  addVariantPriceComparison(productData, dataManager) {
    console.log('🚀 addVariantPriceComparison called with:', productData);
    console.log('🔍 dataManager:', dataManager);

    // Remove existing section if it exists
    const existingSection = document.querySelector('.variant-price-comparison-section');
    if (existingSection) {
      existingSection.remove();
      console.log('ℹ️ Removed existing variant comparison section');
    }

    // Extract and sort variants by price
    console.log('🔍 Extracting variants...');
    const variants = dataManager.extractAndSortVariants(productData);
    console.log('🔍 Extracted variants:', variants);
    console.log('🔍 Variants count:', variants?.length);

    if (!variants || variants.length <= 1) {
      console.log('ℹ️ Not enough variants for price comparison:', variants?.length || 0);
      return;
    }

    console.log('✅ Proceeding with variant comparison creation...');

    // Find suitable container for variant comparison - target main content area (Section 2), not buy-box (Section 1)
    const variantSelectors = [
      '.product-detail-container', // Main product container - first priority
      'main[data-testid="pdp-main"]', // Main PDP container
      'main', // Generic main element  
      '[data-testid="product-detail"]', // Product detail section
      '.product-content', // Product content area
      '.pdp-content' // PDP content area
    ];

    let variantContainer = null;
    for (const selector of variantSelectors) {
      const element = document.querySelector(selector);
      if (element) {
        variantContainer = element;
        console.log(`✅ Found variant container: ${selector}`);
        break;
      }
    }

    // Debug: Log all attempted selectors
    console.log('🔍 Debug: Checking variant selectors...');
    variantSelectors.forEach(selector => {
      const element = document.querySelector(selector);
      console.log(`Selector "${selector}": ${element ? 'FOUND' : 'NOT FOUND'}`);
    });

    if (!variantContainer) {
      console.log('❌ Could not find suitable container for variant comparison');

      // Debug: Try to find ANY reasonable container on the page
      console.log('🔍 Searching for any available containers...');
      const discoverySelectors = [
        'body',
        'main',
        '[role="main"]',
        '.container',
        '.content',
        'div[class*="container"]',
        'div[class*="content"]',
        'div[class*="main"]',
        'div[class*="page"]',
        'div[class*="product"]'
      ];

      discoverySelectors.forEach(selector => {
        const element = document.querySelector(selector);
        console.log(`Discovery "${selector}": ${element ? 'FOUND (' + (element.className || element.tagName) + ')' : 'NOT FOUND'}`);
      });

      // As absolute fallback, use body
      console.log('🔄 Using body as last resort container');
      variantContainer = document.body;
    }

    // Check if variant comparison already exists to prevent duplicates
    const existingComparison = variantContainer.querySelector('.variant-price-comparison-section');
    if (existingComparison) {
      console.log('ℹ️ Variant price comparison already exists, removing old one');
      existingComparison.remove();
    }

    // Create variant comparison section
    const comparisonSection = this.createSafeElement('div', {
      className: 'variant-price-comparison-section',
      style: `
        margin-top: 16px; 
        padding: 16px; 
        background: #f8f9fa; 
        border: 1px solid #dee2e6; 
        border-radius: 8px;
        font-size: 13px;
      `
    });

    // Create header
    const header = this.createSafeElement('div', {
      style: `
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 12px;
        font-weight: 600;
        color: #495057;
      `
    });

    const headerIcon = this.createSafeElement('span', {
      text: '🏷️',
      style: 'font-size: 16px;'
    });

    const headerText = this.createSafeElement('span', {
      text: 'مقایسه قیمت انواع تنوع (از ارزان‌ترین)'
    });

    const clickHint = this.createSafeElement('span', {
      text: '🖱️ کلیک برای انتخاب',
      style: 'font-size: 11px; color: #6c757d; margin-right: 8px;'
    });

    header.appendChild(headerIcon);
    header.appendChild(headerText);
    header.appendChild(clickHint);
    comparisonSection.appendChild(header);

    // Create variant list container
    const variantList = this.createSafeElement('div', {
      style: `
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
      `
    });

    // Create variant items
    variants.forEach((variant, index) => {
      const isLowest = index === 0;

      const variantItem = this.createSafeElement('div', {
        className: `variant-item${isLowest ? ' variant-item-selected' : ''}`,
        'data-variant-id': variant.id || index,
        'data-variant-index': index,
        style: `
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 8px 12px;
          background: ${isLowest ? '#d4edda' : 'white'};
          border-radius: 6px;
          border: 2px solid ${isLowest ? '#28a745' : '#e2e8f0'};
          width: calc(50% - 4px);
          min-height: 65px;
          cursor: pointer;
          transition: all 0.2s ease;
          position: relative;
        `
      });

      // Add hover effects
      variantItem.addEventListener('mouseenter', () => {
        const isCurrentlySelected = variantItem.classList.contains('variant-item-selected');
        if (!isCurrentlySelected) {
          variantItem.style.borderColor = '#6366f1';
          variantItem.style.background = '#f8fafc';
        }
        variantItem.style.transform = 'translateY(-1px)';
        variantItem.style.boxShadow = '0 4px 8px rgba(0,0,0,0.1)';

        // Highlight click indicator
        const indicator = variantItem.querySelector('.click-indicator');
        if (indicator) {
          indicator.style.opacity = '1';
          indicator.style.color = '#6366f1';
        }
      });

      variantItem.addEventListener('mouseleave', () => {
        const isCurrentlySelected = variantItem.classList.contains('variant-item-selected');
        if (!isCurrentlySelected) {
          variantItem.style.borderColor = '#e2e8f0';
          variantItem.style.background = 'white';
        } else {
          // Restore selected state styling
          variantItem.style.borderColor = '#28a745';
          variantItem.style.background = '#d4edda';
        }
        variantItem.style.transform = 'translateY(0)';
        variantItem.style.boxShadow = 'none';

        // Reset click indicator
        const indicator = variantItem.querySelector('.click-indicator');
        if (indicator) {
          indicator.style.opacity = '0.7';
          indicator.style.color = '#9ca3af';
        }
      });

      // Left side - Variant info with visual indicators
      const variantInfo = this.createSafeElement('div', {
        style: `
          display: flex;
          align-items: center;
          gap: 8px;
          flex: 1;
          min-width: 0;
        `
      });

      // Show visual indicator - priority: color > size > rank
      if (variant.color && variant.color.hex_code) {
        // Visual color indicator with rank border styling
        const colorIndicator = this.createSafeElement('div', {
          style: `
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: ${variant.color.hex_code};
            border: 2px solid ${isLowest ? '#28a745' : '#fff'};
            box-shadow: 0 0 0 1px ${isLowest ? '#28a745' : '#e2e8f0'};
            flex-shrink: 0;
          `
        });
        variantInfo.appendChild(colorIndicator);
      } else if (variant.size) {
        // Size indicator with rank styling
        const sizeIndicator = this.createSafeElement('div', {
          text: variant.size.title.charAt(0),
          style: `
            width: 14px;
            height: 14px;
            border-radius: 2px;
            background: ${isLowest ? '#28a745' : '#f3f4f6'};
            border: 1px solid ${isLowest ? '#28a745' : '#d1d5db'};
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 8px;
            font-weight: 600;
            color: ${isLowest ? '#fff' : '#374151'};
            flex-shrink: 0;
          `
        });
        variantInfo.appendChild(sizeIndicator);
      } else {
        // Fallback to rank indicator only if no visual variant indicator
        const rankIndicator = this.createSafeElement('span', {
          text: isLowest ? '🏆' : (index === variants.length - 1 ? '⬆️' : '📍'),
          style: `
            font-size: 16px;
            flex-shrink: 0;
          `
        });
        variantInfo.appendChild(rankIndicator);
      }

      // Variant details container
      const variantDetails = this.createSafeElement('div', {
        style: `
          display: flex;
          flex-direction: column;
          gap: 2px;
          min-width: 0;
          flex: 1;
        `
      });

      // Variant name
      const variantName = this.createSafeElement('span', {
        text: variant.display_name,
        style: `
          color: ${isLowest ? '#28a745' : '#374151'};
          font-size: 11px;
          font-weight: ${isLowest ? '600' : '400'};
          line-height: 1.2;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        `
      });

      // Seller name
      const sellerName = this.createSafeElement('span', {
        text: `فروشنده: ${variant.seller_name}`,
        style: `
          color: #6b7280;
          font-size: 9px;
          line-height: 1.1;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        `
      });

      variantDetails.appendChild(variantName);
      variantDetails.appendChild(sellerName);

      // Shipping info
      if (variant.shipping_info) {
        const shippingInfo = this.createSafeElement('span', {
          text: variant.shipping_info.display_text,
          style: `
            color: ${variant.shipping_info.is_free ? '#059669' : '#d97706'};
            font-size: 8px;
            line-height: 1.1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-weight: 500;
          `
        });
        variantDetails.appendChild(shippingInfo);
      }

      // Order limit info
      if (variant.order_limit) {
        const orderLimitInfo = this.createSafeElement('span', {
          text: variant.order_limit.display_text,
          style: `
            color: #dc2626;
            font-size: 8px;
            line-height: 1.1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-weight: 500;
          `
        });
        variantDetails.appendChild(orderLimitInfo);
      }
      variantInfo.appendChild(variantDetails);

      // Right side - Price and click indicator
      const priceSection = this.createSafeElement('div', {
        style: `
          display: flex;
          align-items: center;
          gap: 6px;
          flex-shrink: 0;
        `
      });

      const priceText = this.createSafeElement('div', {
        text: dataManager.formatPrice(variant.price_value),
        style: `
          font-size: 12px;
          font-weight: bold;
          color: ${isLowest ? '#28a745' : '#1f2937'};
          text-align: right;
          line-height: 1.1;
        `
      });

      const clickIndicator = this.createSafeElement('div', {
        className: 'click-indicator',
        text: '▶',
        style: `
          color: #9ca3af;
          font-size: 10px;
          opacity: 0.7;
          transition: all 0.2s ease;
        `
      });

      priceSection.appendChild(priceText);
      priceSection.appendChild(clickIndicator);

      // Add click handler for variant selection
      variantItem.addEventListener('click', () => {
        console.log('🎯 Variant clicked:', variant);

        // Update visual selection state
        this.updateVariantSelection(variantItem, variant, index);

        // Add visual feedback for click
        variantItem.style.transform = 'scale(0.98)';
        setTimeout(() => {
          variantItem.style.transform = 'translateY(-1px)';
        }, 100);

        // Trigger native variant selection if method exists
        if (this.selectNativeVariation) {
          this.selectNativeVariation(variant);
        }
      });

      variantItem.appendChild(variantInfo);
      variantItem.appendChild(priceSection);
      variantList.appendChild(variantItem);
    });

    comparisonSection.appendChild(variantList);

    // Debug: Check if we found the main container
    console.log('🔍 Main container found:', variantContainer);
    console.log('🔍 Main container class:', variantContainer?.className);

    // Flexible insertion strategy for products with or without variant selections

    // Strategy 1: After color/variant selection container (for products with variants)
    const colorVariantContainer = document.querySelector('.w-full.flex.flex-col.gap-5.pt-2');
    console.log('🔍 Color variant container found:', !!colorVariantContainer);

    if (colorVariantContainer) {
      console.log('🔍 Using Strategy 1: After color selection');
      colorVariantContainer.parentNode.insertBefore(comparisonSection, colorVariantContainer.nextSibling);
      console.log('✅ Inserted variant comparison after color selection container');
    } else {
      // Strategy 2: Look for the pdp-variant section and insert at the end
      const pdpVariantSection = document.querySelector('#pdp-variant');
      console.log('🔍 PDP variant section found:', !!pdpVariantSection);

      if (pdpVariantSection) {
        console.log('🔍 Using Strategy 2: At end of pdp-variant section');
        pdpVariantSection.appendChild(comparisonSection);
        console.log('✅ Inserted variant comparison at end of pdp-variant section');
      } else {
        // Strategy 3: Look for left section container (common structure)
        const leftSection = document.querySelector('.styles_InfoSection__leftSection__0vNpX');
        console.log('🔍 Left section found:', !!leftSection);

        if (leftSection) {
          console.log('🔍 Using Strategy 3: At end of left section');
          leftSection.appendChild(comparisonSection);
          console.log('✅ Inserted variant comparison at end of left section');
        } else {
          // Strategy 4: Last resort - use main container
          console.log('🔍 Using Strategy 4: Main container fallback');
          variantContainer.appendChild(comparisonSection);
          console.log('✅ Appended variant comparison to main container (fallback)');
        }
      }
    }

    // Final debug: Check if comparison section is in DOM
    console.log('🔍 Comparison section in DOM:', document.contains(comparisonSection));
    console.log('🔍 Comparison section parent:', comparisonSection.parentNode);
    console.log(`✅ Added enhanced variant price comparison with ${variants.length} variants`);
  }

  // Method to update visual selection state
  updateVariantSelection(selectedItem, variant, selectedIndex) {
    // Find all variant items in the same comparison section
    const comparisonSection = selectedItem.closest('.variant-price-comparison-section');
    if (!comparisonSection) return;

    const allVariantItems = comparisonSection.querySelectorAll('.variant-item');

    // Reset all items to unselected state
    allVariantItems.forEach(item => {
      item.classList.remove('variant-item-selected');
      item.style.background = 'white';
      item.style.borderColor = '#e2e8f0';

      // Reset text colors to unselected state
      this.updateVariantItemTextColors(item, false);
    });

    // Mark selected item
    selectedItem.classList.add('variant-item-selected');
    selectedItem.style.background = '#d4edda';
    selectedItem.style.borderColor = '#28a745';

    // Update text colors for selected state
    this.updateVariantItemTextColors(selectedItem, true);

    console.log('✅ Updated visual selection to variant:', variant.display_name);
  }

  // Helper method to update text colors for variant items
  updateVariantItemTextColors(variantItem, isSelected) {
    // Update variant name color
    const variantNameElements = variantItem.querySelectorAll('span');
    variantNameElements.forEach(span => {
      const text = span.textContent;
      // Check if this span contains the variant name (not seller info or other text)
      if (text && !text.includes('فروشنده:') && !text.includes('ارسال') && !text.includes('محدودیت') && !text.includes('تومان')) {
        span.style.color = isSelected ? '#28a745' : '#374151';
        span.style.fontWeight = isSelected ? '600' : '400';
      }
    });

    // Update price text color
    const priceElements = variantItem.querySelectorAll('div');
    priceElements.forEach(div => {
      const text = div.textContent;
      if (text && text.includes('تومان')) {
        div.style.color = isSelected ? '#28a745' : '#1f2937';
      }
    });

    // Update visual indicators (color dots and size indicators)
    this.updateVariantIndicators(variantItem, isSelected);
  }

  // Helper method to update visual indicators for variant items
  updateVariantIndicators(variantItem, isSelected) {
    const variantInfo = variantItem.querySelector('div[style*="display: flex"][style*="align-items: center"]');
    if (!variantInfo) return;

    // Update color indicators (circular color dots)
    const colorIndicators = variantInfo.querySelectorAll('div[style*="border-radius: 50%"]');
    colorIndicators.forEach(indicator => {
      if (isSelected) {
        indicator.style.border = '2px solid #28a745';
        indicator.style.boxShadow = '0 0 0 1px #28a745';
      } else {
        indicator.style.border = '2px solid #fff';
        indicator.style.boxShadow = '0 0 0 1px #e2e8f0';
      }
    });

    // Update size indicators (square size indicators)
    const sizeIndicators = variantInfo.querySelectorAll('div[style*="border-radius: 2px"]');
    sizeIndicators.forEach(indicator => {
      if (isSelected) {
        indicator.style.background = '#28a745';
        indicator.style.border = '1px solid #28a745';
        indicator.style.color = '#fff';
      } else {
        indicator.style.background = '#f3f4f6';
        indicator.style.border = '1px solid #d1d5db';
        indicator.style.color = '#374151';
      }
    });
  }

  // Enhanced method for native variant selection
  selectNativeVariation(variant) {
    console.log('🎯 Attempting to select native variation:', variant);

    try {
      // Strategy 1: Color variations with RGB background
      if (variant.color && variant.color.hex_code) {
        console.log('🔍 Trying color selection for:', variant.color);
        const success = this.selectColorVariation(variant.color);
        if (success) return;
      }

      // Strategy 2: Size variations (dropdown and button styles)
      if (variant.size) {
        console.log('🔍 Trying size selection for:', variant.size);
        const success = this.selectSizeVariation(variant.size);
        if (success) return;
      }

      // Strategy 3: General text-based selection fallback
      if (variant.display_name) {
        console.log('🔍 Trying text-based selection for:', variant.display_name);
        const success = this.selectTextBasedVariation(variant.display_name);
        if (success) return;
      }

      console.log('⚠️ Could not find native selector for variant');
    } catch (error) {
      console.error('❌ Error selecting native variation:', error);
    }
  }

  // Color variation selection
  selectColorVariation(color) {
    if (!color.hex_code) return false;

    const rgb = this.hexToRgb(color.hex_code);
    if (!rgb) return false;

    const rgbString = `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;

    // Try different color selector patterns
    const colorSelectors = [
      `[style*="${rgbString}"]`,
      `[style*="background: ${color.hex_code}"]`,
      `[style*="background-color: ${color.hex_code}"]`,
      `[style*="background-color:${color.hex_code}"]`,
      `[data-color="${color.hex_code}"]`,
      `.styles_InfoSectionVariationColor__FmtfU [style*="${rgbString}"]`
    ];

    for (const selector of colorSelectors) {
      const element = document.querySelector(selector);
      if (element && this.isClickableElement(element)) {
        element.click();
        console.log('✅ Clicked color variation with selector:', selector);
        return true;
      }
    }

    return false;
  }

  // Size variation selection
  selectSizeVariation(size) {
    const sizeText = size.title || size.display_name || size;

    // Size selection strategies
    const sizeSelectors = [
      // Dropdown options
      `option[value*="${sizeText}"]`,
      `option:contains("${sizeText}")`,
      // Button/span elements
      `button:contains("${sizeText}")`,
      `span:contains("${sizeText}")`,
      `div:contains("${sizeText}")`,
      // Size-specific classes
      `.size-option:contains("${sizeText}")`,
      `.variant-size:contains("${sizeText}")`,
      // General clickable elements containing size text
      `[data-size="${sizeText}"]`,
      `[data-value="${sizeText}"]`
    ];

    for (const selector of sizeSelectors) {
      // Handle pseudo-selector :contains manually
      if (selector.includes(':contains')) {
        const baseSelector = selector.split(':contains')[0];
        const searchText = selector.match(/contains\("([^"]*)"\)/)[1];
        const elements = document.querySelectorAll(baseSelector);

        for (const element of elements) {
          if (element.textContent && element.textContent.trim() === searchText.trim()) {
            if (this.isClickableElement(element)) {
              element.click();
              console.log('✅ Clicked size variation:', searchText);
              return true;
            }
          }
        }
      } else {
        const element = document.querySelector(selector);
        if (element && this.isClickableElement(element)) {
          element.click();
          console.log('✅ Clicked size variation with selector:', selector);
          return true;
        }
      }
    }

    return false;
  }

  // Text-based variation selection fallback
  selectTextBasedVariation(displayName) {
    const cleanName = displayName.split(' - ')[0].trim();
    const elements = document.querySelectorAll('button, span, div, option');

    for (const element of elements) {
      if (element.textContent && element.textContent.trim() === cleanName) {
        if (this.isClickableElement(element)) {
          element.click();
          console.log('✅ Clicked text-based variation:', cleanName);
          return true;
        }
      }
    }

    return false;
  }

  // Helper to check if element is clickable
  isClickableElement(element) {
    return element &&
      typeof element.click === 'function' &&
      element.offsetParent !== null && // is visible
      !element.disabled;
  }

  // Helper method to convert hex to RGB
  hexToRgb(hex) {
    if (!hex) return null;
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  }

  cleanup() {
    this.disconnectObserver();
    this.removeAllSellerElements();

    if (this.scrollHandler) {
      window.removeEventListener('scroll', this.scrollHandler);
      this.scrollHandler = null;
    }
  }
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.DOMManager = DOMManager;
}