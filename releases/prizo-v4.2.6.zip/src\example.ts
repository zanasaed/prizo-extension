// Example TypeScript file to test the configuration
export interface PriceData {
  price: number;
  currency: string;
  timestamp: Date;
}

export class PriceHelper {
  formatPrice(priceData: PriceData): string {
    return `${priceData.price.toLocaleString('fa-IR')} ${priceData.currency}`;
  }
}

export default PriceHelper;