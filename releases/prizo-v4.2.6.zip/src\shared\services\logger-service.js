/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-28
 * LoggerService - Centralized logging service with timestamp and level indicators
 */
/**
 * Enum for log levels
 */
var LogLevel;
(function (LogLevel) {
    LogLevel["INFO"] = "INFO";
    LogLevel["WARN"] = "WARN";
    LogLevel["ERROR"] = "ERROR";
})(LogLevel || (LogLevel = {}));
/**
 * Centralized logging service with structured logging capabilities
 */
class LoggerService {
    constructor() {
        this.logLevels = LogLevel;
    }
    /**
     * Formats a timestamp for logging
     * @returns Formatted timestamp string
     */
    formatTimestamp() {
        const now = new Date();
        return now.toISOString().replace('T', ' ').substring(0, 19);
    }
    /**
     * Formats a log message with timestamp and level
     * @param level - Log level (INFO, WARN, ERROR)
     * @param message - Log message
     * @param metadata - Optional metadata object
     * @returns Formatted log message
     */
    formatLogMessage(level, message, metadata) {
        const timestamp = this.formatTimestamp();
        let formattedMessage = `[${timestamp}] [${level}] ${message}`;
        if (metadata) {
            if (metadata.productId) {
                formattedMessage += ` | Product: ${metadata.productId}`;
            }
            if (metadata.error) {
                const errorMessage = metadata.error instanceof Error
                    ? metadata.error.message
                    : String(metadata.error);
                formattedMessage += ` | Error: ${errorMessage}`;
            }
            if (metadata.details) {
                formattedMessage += ` | Details: ${JSON.stringify(metadata.details)}`;
            }
        }
        return formattedMessage;
    }
    /**
     * Logs an info message
     * @param message - Message to log
     * @param meta - Optional metadata (productId, details, etc.)
     */
    info(message, meta) {
        const formattedMessage = this.formatLogMessage(this.logLevels.INFO, message, meta);
        console.log(formattedMessage);
    }
    /**
     * Logs a warning message
     * @param message - Message to log
     * @param meta - Optional metadata (productId, details, etc.)
     */
    warn(message, meta) {
        const formattedMessage = this.formatLogMessage(this.logLevels.WARN, message, meta);
        console.warn(formattedMessage);
    }
    /**
     * Logs an error message
     * @param message - Message to log
     * @param meta - Optional metadata (productId, error, details, etc.)
     */
    error(message, meta) {
        const formattedMessage = this.formatLogMessage(this.logLevels.ERROR, message, meta);
        console.error(formattedMessage);
    }
}
// Make available globally for browser environment compatibility
if (typeof window !== 'undefined') {
    window.LoggerService = LoggerService;
}
