/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Extension Bridge - Handles all Chrome extension API communication
 */

class ExtensionBridge extends BaseModule {
  constructor(eventBus, domManager) {
    super('ExtensionBridge', eventBus, domManager);

    this.currentTab = null;
    this.isActive = false;
    this.pageType = 'unknown';
  }

  async initializeElements() {
    // No specific elements needed for extension bridge
    this.elements = {};
  }

  async setupEventListeners() {
    // Listen for extension communication requests
    this.on('extension:get-status', () => this.getExtensionStatus());
    this.on('extension:toggle', () => this.handleToggle());
    this.on('extension:update', () => this.handleUpdate());
    this.on('extension:emergency-stop', () => this.handleEmergencyStop());
    this.on('extension:clear-display', () => this.handleClearDisplay());
    this.on('extension:send-message', (data) => this.sendMessageToTab(data));
    this.on('extension:open-tab', (data) => this.openTab(data));
    this.on('extension:test-notification', () => this.handleTestNotification());

    // Listen for feature toggle requests
    this.on('extension:toggle-cart-feature', (data) => this.handleCartFeatureToggle(data));
    this.on('extension:toggle-sort-feature', (data) => this.handleSortFeatureToggle(data));
    this.on('extension:toggle-comparison-feature', (data) => this.handleComparisonFeatureToggle(data));
    this.on('extension:clear-cache', () => this.handleClearCache());
    this.on('extension:reset-all', () => this.handleResetAll());

    // Listen for Smart Cart requests
    this.on('extension:get-smart-cart-items', () => this.getSmartCartItems());
    this.on('extension:clear-smart-cart', () => this.clearSmartCart());
    this.on('extension:remove-smart-cart-item', (data) => this.removeSmartCartItem(data));
    this.on('extension:update-smart-cart-quantity', (data) => this.updateSmartCartQuantity(data));
    this.on('extension:update-smart-cart-variation', (data) => this.updateSmartCartVariation(data));
    this.on('extension:update-smart-cart-seller', (data) => this.updateSmartCartSeller(data));
  }

  async loadInitialData() {
    await this.getCurrentTab();
    await this.getExtensionStatus();
  }

  // Tab management
  async getCurrentTab() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      this.currentTab = tab;

      if (tab && tab.url) {
        this.pageType = this.detectPageTypeFromUrl(tab.url);
        this.emit('extension:tab-detected', {
          tab: tab,
          pageType: this.pageType
        });
        // Update UI with detected page type
        this.emit('ui:update-page-type', { pageType: this.pageType });
      }

      return tab;
    } catch (error) {
      this.error('Error getting current tab:', error);
      return null;
    }
  }

  async openTab(data) {
    try {
      const tab = await chrome.tabs.create({
        url: data.url,
        active: data.active !== false
      });

      this.emit('extension:tab-opened', { tab, url: data.url });
      return { success: true, tab };
    } catch (error) {
      this.error('Error opening tab:', error);
      return { success: false, error: error.message };
    }
  }

  // Extension status management
  async getExtensionStatus() {
    try {
      const tab = this.currentTab || await this.getCurrentTab();

      if (!tab || !tab.url) {
        this.warn('No active tab or URL found');
        return { active: false, pageType: 'unknown' };
      }

      try {
        const response = await chrome.tabs.sendMessage(tab.id, {
          action: 'getStatus'
        });

        if (response) {
          this.isActive = response.active;
          this.pageType = response.pageType || this.pageType;

          this.emit('extension:status-received', { status: response });
          return response;
        }
      } catch (contentScriptError) {
        this.log('Content script not available for status check');
      }

      // Content script not available, return detected status
      const fallbackStatus = {
        active: false,
        pageType: this.pageType
      };

      this.emit('extension:status-fallback', { status: fallbackStatus });
      return fallbackStatus;
    } catch (error) {
      this.error('Error getting extension status:', error);
      return { active: false, pageType: 'unknown', error: error.message };
    }
  }

  // Page type detection
  detectPageTypeFromUrl(url) {
    if (!url) return 'unknown';

    // Check for Digikala specific patterns first (for backward compatibility)
    if (url.includes('digikala.com')) {
      if (url === 'https://www.digikala.com/' || url.includes('/main/')) {
        return 'homepage';
      } else if (url === 'https://www.digikala.com/fresh/' || url === 'https://www.digikala.com/fresh') {
        return 'fresh-homepage';
      } else if (url.includes('/profile/orders/') && /\/profile\/orders\/\d+/.test(url)) {
        return 'order';
      } else if (url.includes('/checkout/cart/')) {
        return 'cart';
      } else if (url.includes('/profile/lists/') || url.includes('/profile/wishlist/')) {
        return 'wishlist';
      } else if (url.includes('/product/dkp-') || url.includes('/fresh/product/dkp-')) {
        return 'product';
      } else if (url.includes('/seller/')) {
        return 'seller';
      } else if (url.includes('/brand/')) {
        return 'brand';
      } else if (url.includes('/search') || url.includes('/fresh/search') ||
                 url.includes('/category') || url.includes('/offers') ||
                 url.includes('/tags')) {
        return url.includes('/offers') ? 'offers' :
               url.includes('/tags') ? 'tags' :
               url.includes('/category') ? 'category' : 'search';
      }
    }

    // Generic patterns for any e-commerce site
    if (url.includes('/cart') || url.includes('/checkout')) {
      return 'cart';
    } else if (url.includes('/product/') || url.includes('/item/')) {
      return 'product';
    } else if (url.includes('/seller/') || url.includes('/store/')) {
      return 'seller';
    } else if (url.includes('/search') || url.includes('/category')) {
      return 'search';
    }

    return 'unknown';
  }

  // Core extension actions
  async handleToggle() {
    this.showLoading(true);
    this.hideError();

    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'toggleStatus'
      });

      if (response && typeof response.active === 'boolean') {
        this.isActive = response.active;

        const successMessage = this.getToggleSuccessMessage(this.isActive, this.pageType);
        this.showSuccess(successMessage);

        this.emit('extension:toggled', {
          isActive: this.isActive,
          pageType: this.pageType,
          response
        });

        return { success: true, active: this.isActive };
      } else {
        throw new Error('Invalid response from content script');
      }
    } catch (error) {
      this.error('Toggle error:', error);
      this.showError('خطا در تغییر وضعیت افزونه. لطفاً صفحه را تازه‌سازی کرده و دوباره تلاش کنید.');
      return { success: false, error: error.message };
    } finally {
      this.showLoading(false);
    }
  }

  async handleUpdate() {
    this.showLoading(true);
    this.hideError();

    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'updatePrices'
      });

      if (response && response.success) {
        const successMessage = this.getUpdateSuccessMessage(this.pageType);
        this.showSuccess(successMessage);

        this.emit('extension:updated', {
          pageType: this.pageType,
          response
        });

        return { success: true };
      } else {
        throw new Error('Update failed');
      }
    } catch (error) {
      this.error('Update error:', error);
      this.showError('خطا در بروزرسانی اطلاعات. لطفاً اتصال اینترنت خود را بررسی کرده و دوباره تلاش کنید.');
      return { success: false, error: error.message };
    } finally {
      this.showLoading(false);
    }
  }

  async handleEmergencyStop() {
    this.showLoading(true);
    this.hideError();

    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      // Try multiple stop actions in sequence for comprehensive stopping
      const stopActions = ['emergencyStop', 'clearDisplay', 'toggleStatus'];
      let success = false;

      for (const action of stopActions) {
        try {
          const response = await chrome.tabs.sendMessage(tab.id, { action });
          if (response && response.success) {
            success = true;
            break;
          }
        } catch (actionError) {
          this.log(`Action ${action} failed, trying next...`);
        }
      }

      if (success) {
        this.isActive = false;
        this.showSuccess('⏹️ پردازش فوراً متوقف شد و همه تغییرات حذف شدند.');
      } else {
        // Force local UI reset even if content script doesn't respond
        this.isActive = false;
        this.showSuccess('⏹️ پردازش متوقف شد (فقط رابط کاربری).');
      }

      this.emit('extension:emergency-stopped', {
        success,
        isActive: this.isActive
      });

      return { success: true, isActive: this.isActive };
    } catch (error) {
      this.error('Emergency stop error:', error);
      // Force local reset as last resort
      this.isActive = false;
      this.showError('خطا در توقف فوری. رابط کاربری ریست شد، لطفاً صفحه را تازه‌سازی کنید.');
      return { success: false, error: error.message };
    } finally {
      this.showLoading(false);
    }
  }

  async handleClearDisplay() {
    this.showLoading(true);
    this.hideError();

    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      // Enhanced clear display with page type detection
      let clearRequest = { action: 'clearDisplay' };

      // Add page type for targeted clearing
      if (this.pageType === 'cart') {
        clearRequest.type = 'cart';
      } else if (this.pageType === 'seller') {
        clearRequest.type = 'seller';
      } else if (this.pageType === 'order') {
        clearRequest.type = 'cart'; // Orders use similar cleanup as cart
      } else if (['search', 'category', 'offers', 'tags', 'product', 'listing', 'wishlist', 'homepage', 'fresh-homepage'].includes(this.pageType)) {
        clearRequest.type = 'monthly';
      }

      let anySuccess = false;

      try {
        // Primary comprehensive clear request
        const response = await chrome.tabs.sendMessage(tab.id, clearRequest);
        if (response && response.success) {
          anySuccess = true;
          this.log('Enhanced clear display successful:', response.message);
        }
      } catch (error) {
        this.warn('Enhanced clear failed, trying fallback methods...', error);

        // Fallback to individual clear actions
        const fallbackActions = ['clearDisplay', 'emergencyStop'];
        for (const action of fallbackActions) {
          try {
            const response = await chrome.tabs.sendMessage(tab.id, { action });
            if (response && response.success) {
              anySuccess = true;
              break;
            }
          } catch (actionError) {
            this.log(`Fallback action ${action} failed, continuing...`);
          }
        }
      }

      if (anySuccess) {
        this.isActive = false;
        this.showSuccess('🧹 تمام نمایش‌ها پاک شد. تغییرات حذف شد ولی تنظیمات حفظ ماند.');
      } else {
        // Force UI reset even if content script doesn't respond
        this.isActive = false;
        this.showSuccess('🧹 نمایش پاک شد (فقط رابط کاربری).');
      }

      this.emit('extension:display-cleared', {
        success: anySuccess,
        pageType: this.pageType,
        isActive: this.isActive
      });

      return { success: anySuccess, isActive: this.isActive };
    } catch (error) {
      this.error('Clear display error:', error);
      this.showError('خطا در پاک کردن نمایش. لطفاً صفحه را تازه‌سازی کنید.');
      return { success: false, error: error.message };
    } finally {
      this.showLoading(false);
    }
  }

  // Feature toggle handlers
  async handleCartFeatureToggle(data) {
    this.showLoading(true);
    this.hideError();

    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'toggleCartFeature',
        enabled: data.enabled
      });

      if (response && response.success) {
        const message = data.enabled ?
          'ویژگی سبد خرید فعال شد! 🛒 کمترین قیمت ۳۰ روز در سبد خرید نمایش داده می‌شود.' :
          'ویژگی سبد خرید غیرفعال شد و اطلاعات قیمت از سبد حذف خواهد شد.';

        this.showSuccess(message);

        this.emit('extension:cart-feature-toggled', {
          enabled: data.enabled,
          response
        });

        return { success: true, enabled: data.enabled };
      } else {
        throw new Error('Failed to toggle cart feature');
      }
    } catch (error) {
      this.error('Cart feature toggle error:', error);
      this.showError('خطا در تنظیم ویژگی سبد خرید. لطفاً دوباره تلاش کنید.');
      return { success: false, error: error.message };
    } finally {
      this.showLoading(false);
    }
  }

  async handleSortFeatureToggle(data) {
    this.showLoading(true);
    this.hideError();

    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'toggleSortFeature',
        enabled: data.enabled
      });

      if (response && response.success) {
        const message = data.enabled ?
          'ویژگی مرتب‌سازی فعال شد! 📊 گزینه "بیشترین تخفیف" به فهرست مرتب‌سازی اضافه شد.' :
          'ویژگی مرتب‌سازی غیرفعال شد.';

        this.showSuccess(message);

        this.emit('extension:sort-feature-toggled', {
          enabled: data.enabled,
          response
        });

        return { success: true, enabled: data.enabled };
      } else {
        throw new Error('Failed to toggle sort feature');
      }
    } catch (error) {
      this.error('Sort feature toggle error:', error);
      this.showError('خطا در تنظیم ویژگی مرتب‌سازی. لطفاً دوباره تلاش کنید.');
      return { success: false, error: error.message };
    } finally {
      this.showLoading(false);
    }
  }

  async handleComparisonFeatureToggle(data) {
    this.showLoading(true);
    this.hideError();

    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'toggleComparisonFeature',
        enabled: data.enabled
      });

      if (response && response.success) {
        const message = data.enabled ?
          'ویژگی مقایسه قیمت فعال شد! 🔍 لینک‌های مقایسه قیمت در صفحات محصولات نمایش داده می‌شود.' :
          'ویژگی مقایسه قیمت غیرفعال شد.';

        this.showSuccess(message);

        this.emit('extension:comparison-feature-toggled', {
          enabled: data.enabled,
          response
        });

        return { success: true, enabled: data.enabled };
      } else {
        throw new Error('Failed to toggle comparison feature');
      }
    } catch (error) {
      this.error('Comparison feature toggle error:', error);
      this.showError('خطا در تنظیم ویژگی مقایسه قیمت. لطفاً دوباره تلاش کنید.');
      return { success: false, error: error.message };
    } finally {
      this.showLoading(false);
    }
  }

  // Test notification
  async handleTestNotification() {
    try {
      this.showLoading(true);
      this.log('Testing notification functionality...');

      // Send message to background script to handle notification
      const response = await chrome.runtime.sendMessage({
        action: 'testNotification'
      });

      this.log('Test notification response:', response);

      if (response && response.success) {
        this.showSuccess('اطلاع‌رسانی تست با موفقیت ارسال شد! ✅ لطفاً پنجره مرورگر را بررسی کنید.');

        this.emit('extension:test-notification-sent', { response });
        return { success: true };
      } else {
        throw new Error(response?.error || 'Failed to send test notification');
      }
    } catch (error) {
      this.error('Test notification error:', error);

      // Try direct notification as fallback
      try {
        this.log('Trying fallback notification method...');

        if (chrome.notifications && chrome.notifications.create) {
          const notificationId = `test_fallback_${Date.now()}`;

          await new Promise((resolve, reject) => {
            chrome.notifications.create(notificationId, {
              type: 'basic',
              iconUrl: chrome.runtime.getURL('icons/active_128.png'),
              title: 'تست اطلاع‌رسانی پریزو 🎯',
              message: 'این یک پیام تست است (روش مستقیم). اطلاع‌رسانی‌های واقعی زمانی که شرایط قیمت برآورده شود ارسال خواهند شد.',
              requireInteraction: true
            }, (notificationId) => {
              if (chrome.runtime.lastError) {
                this.error('Direct notification error:', chrome.runtime.lastError);
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                this.log('Direct notification created successfully:', notificationId);
                resolve(notificationId);
              }
            });
          });

          this.showSuccess('اطلاع‌رسانی تست (روش مستقیم) ارسال شد! ✅');
          return { success: true, fallback: true };
        } else {
          throw new Error('Notifications API not available');
        }
      } catch (fallbackError) {
        this.error('Fallback notification also failed:', fallbackError);
        this.showError(`خطا در ارسال اطلاع‌رسانی تست: ${error.message}. لطفاً اجازه اطلاع‌رسانی را در تنظیمات مرورگر فعال کنید و Extension را در حالت Developer mode اجرا کنید.`);
        return { success: false, error: error.message };
      }
    } finally {
      this.showLoading(false);
    }
  }

  // Generic message sending
  async sendMessageToTab(data) {
    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, data.message);

      this.emit('extension:message-sent', {
        message: data.message,
        response
      });

      return { success: true, response };
    } catch (error) {
      this.error('Error sending message to tab:', error);
      return { success: false, error: error.message };
    }
  }

  // Utility methods
  getToggleSuccessMessage(isActive, pageType) {
    if (isActive) {
      switch (pageType) {
        case 'seller':
          return 'ویژگی‌های فروشنده فعال شد! قیمت‌های واقعی و کمترین قیمت ماهانه نمایش داده می‌شود.';
        case 'product':
          return 'ویژگی‌های محصول فعال شد! کمترین قیمت ماهانه و مقایسه قیمت گزینه‌ها نمایش داده می‌شود.';
        case 'brand':
          return 'ویژگی‌های صفحه برند فعال شد! کمترین قیمت ماهانه برای محصولات این برند نمایش داده می‌شود.';
        case 'cart':
          return 'ویژگی‌های سبد خرید فعال شد! کمترین قیمت ۳۰ روز برای هر محصول نمایش داده می‌شود.';
        case 'order':
          return 'ویژگی‌های سفارش فعال شد! قیمت فعلی کمترین برای هر محصول نمایش داده می‌شود.';
        default:
          return 'کمترین قیمت ماهانه فعال شد! اطلاعات قیمت تاریخی نمایش داده می‌شود.';
      }
    } else {
      return 'ویژگی‌ها غیرفعال شد و صفحه به حالت اصلی بازگردانده شد.';
    }
  }

  getUpdateSuccessMessage(pageType) {
    switch (pageType) {
      case 'seller':
        return 'قیمت‌های فروشنده و اطلاعات ماهانه با موفقیت بروزرسانی شدند.';
      case 'brand':
        return 'کمترین قیمت‌های ماهانه برای محصولات این برند بروزرسانی شدند.';
      case 'cart':
        return 'اطلاعات قیمت برای همه محصولات سبد خرید بروزرسانی شدند.';
      case 'order':
        return 'قیمت‌های فعلی برای همه محصولات سفارش بروزرسانی شدند.';
      case 'wishlist':
        return 'قیمت‌های محصولات لیست علاقه‌مندی‌ها بروزرسانی شدند.';
      case 'product':
        return 'اطلاعات قیمت محصول بروزرسانی شد.';
      default:
        return 'کمترین قیمت‌های ماهانه برای همه محصولات بروزرسانی شدند.';
    }
  }

  // Public API
  getCurrentPageType() {
    return this.pageType;
  }

  isExtensionActive() {
    return this.isActive;
  }

  async refreshStatus() {
    await this.getCurrentTab();
    return await this.getExtensionStatus();
  }

  // Manifest utilities
  getExtensionInfo() {
    try {
      const manifest = chrome.runtime.getManifest();
      return {
        version: manifest.version,
        name: manifest.name,
        description: manifest.description
      };
    } catch (error) {
      this.error('Error getting extension info:', error);
      return null;
    }
  }

  async handleClearCache() {
    this.showLoading(true);
    this.hideError();

    try {
      // Clear extension cache
      await chrome.storage.local.remove(['priceCache', 'imageCache', 'dataCache']);

      this.showSuccess('کش داده‌ها پاک شد. اطلاعات جدید از سرور دریافت می‌شود.');

      this.emit('extension:cache-cleared');
      return { success: true };
    } catch (error) {
      this.error('Clear cache error:', error);
      this.showError('خطا در پاک کردن کش. لطفاً دوباره تلاش کنید.');
      return { success: false, error: error.message };
    } finally {
      this.showLoading(false);
    }
  }

  async handleResetAll() {
    this.showLoading(true);
    this.hideError();

    try {
      // Show confirmation dialog
      const confirmed = await this.showConfirmDialog(
        'ریست کامل',
        'آیا مطمئن هستید که می‌خواهید تمام داده‌ها، تنظیمات و لیست نظارت قیمت پاک شود؟ این عمل قابل بازگشت نیست.',
        'ریست کامل',
        'انصراف'
      );

      if (!confirmed) {
        this.showLoading(false);
        return { success: false, cancelled: true };
      }

      // Clear all extension data
      await chrome.storage.local.clear();

      // Send reset message to content script
      const tab = this.currentTab || await this.getCurrentTab();
      if (tab) {
        try {
          await chrome.tabs.sendMessage(tab.id, { action: 'resetAll' });
        } catch (error) {
          // Content script might not be available, that's okay
          this.log('Content script not available for reset');
        }
      }

      this.showSuccess('ریست کامل انجام شد. همه داده‌ها و تنظیمات پاک شدند.');

      this.emit('extension:reset-complete');

      // Reload the popup after a short delay
      setTimeout(() => {
        window.location.reload();
      }, 1500);

      return { success: true };
    } catch (error) {
      this.error('Reset error:', error);
      this.showError('خطا در ریست کامل. لطفاً دوباره تلاش کنید.');
      return { success: false, error: error.message };
    } finally {
      this.showLoading(false);
    }
  }

  async showConfirmDialog(title, message, confirmText, cancelText) {
    return new Promise((resolve) => {
      // Emit event for modal manager to handle
      this.emit('ui:show-confirm-dialog', {
        title,
        message,
        confirmText,
        cancelText,
        onConfirm: () => resolve(true),
        onCancel: () => resolve(false)
      });
    });
  }

  // Smart Cart methods
  async getSmartCartItems() {
    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'getSmartCartItems'
      });

      if (response && response.success) {
        this.emit('extension:smart-cart-items-received', response);
        return response;
      } else {
        throw new Error(response?.error || 'Failed to get Smart Cart items');
      }
    } catch (error) {
      // Don't log as error if it's just a connection issue (no content script)
      if (error.message.includes('Could not establish connection')) {
        console.log('💡 No content script available, using storage fallback for Smart Cart items');
      } else {
        this.error('Error getting Smart Cart items:', error);
      }

      // Try to get from storage as fallback
      try {
        console.log('🔄 Using storage fallback for Smart Cart items...');
        const result = await chrome.storage.local.get(['digikala_extension_smart_cart_items']);
        const items = result.digikala_extension_smart_cart_items || [];

        console.log(`📦 Storage fallback found ${items.length} items`);

        // Create response object
        const fallbackResponse = { success: true, items, source: 'storage_fallback' };

        // Emit the event so Smart Cart manager gets the data
        this.emit('extension:smart-cart-items-received', fallbackResponse);

        return fallbackResponse;
      } catch (storageError) {
        this.error('Storage fallback failed:', storageError);

        // Even if storage fails, emit empty response
        const emptyResponse = { success: true, items: [], source: 'empty_fallback' };
        this.emit('extension:smart-cart-items-received', emptyResponse);

        return { success: false, error: error.message };
      }
    }
  }

  async clearSmartCart() {
    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'clearSmartCart'
      });

      if (response && response.success) {
        this.emit('extension:smart-cart-cleared', response);
        this.emit('ui:success', { message: 'سبد هوشمند با موفقیت خالی شد' });
        return response;
      } else {
        throw new Error(response?.error || 'Failed to clear Smart Cart');
      }
    } catch (error) {
      // Handle connection errors gracefully
      if (error.message.includes('Could not establish connection')) {
        console.log('💡 No content script available, clearing Smart Cart from storage directly');

        try {
          // Clear from storage directly
          await chrome.storage.local.set({ digikala_extension_smart_cart_items: [] });

          const clearResponse = { success: true, items: [], source: 'storage_direct' };
          this.emit('extension:smart-cart-cleared', clearResponse);
          this.emit('ui:success', { message: 'سبد هوشمند با موفقیت خالی شد' });
          return clearResponse;
        } catch (storageError) {
          this.error('Error clearing Smart Cart from storage:', storageError);
          this.emit('ui:error', { message: 'خطا در خالی کردن سبد هوشمند' });
          return { success: false, error: storageError.message };
        }
      } else {
        this.error('Error clearing Smart Cart:', error);
        this.emit('ui:error', { message: 'خطا در خالی کردن سبد هوشمند' });
        return { success: false, error: error.message };
      }
    }
  }

  async removeSmartCartItem(data) {
    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'removeFromSmartCart',
        itemId: data.itemId
      });

      if (response && response.success) {
        this.emit('extension:smart-cart-item-removed', response);
        this.emit('ui:success', { message: 'محصول از سبد هوشمند حذف شد' });
        return response;
      } else {
        throw new Error(response?.error || 'Failed to remove item from Smart Cart');
      }
    } catch (error) {
      // Handle connection errors gracefully
      if (error.message.includes('Could not establish connection')) {
        console.log('💡 No content script available, removing Smart Cart item from storage directly');

        try {
          // Remove from storage directly
          const result = await chrome.storage.local.get(['digikala_extension_smart_cart_items']);
          const currentItems = result.digikala_extension_smart_cart_items || [];
          const updatedItems = currentItems.filter(item => item.id !== data.itemId);

          await chrome.storage.local.set({ digikala_extension_smart_cart_items: updatedItems });

          const removeResponse = { success: true, items: updatedItems, removedItemId: data.itemId, source: 'storage_direct' };
          this.emit('extension:smart-cart-item-removed', removeResponse);
          this.emit('ui:success', { message: 'محصول از سبد هوشمند حذف شد' });
          return removeResponse;
        } catch (storageError) {
          this.error('Error removing Smart Cart item from storage:', storageError);
          this.emit('ui:error', { message: 'خطا در حذف محصول از سبد هوشمند' });
          return { success: false, error: storageError.message };
        }
      } else {
        this.error('Error removing Smart Cart item:', error);
        this.emit('ui:error', { message: 'خطا در حذف محصول از سبد هوشمند' });
        return { success: false, error: error.message };
      }
    }
  }

  async updateSmartCartQuantity(data) {
    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'update_smart_cart_quantity',
        itemId: data.itemId,
        quantity: data.quantity
      });

      if (response && response.success) {
        this.emit('extension:smart-cart-quantity-updated', response);
        this.emit('ui:success', { message: 'تعداد محصول به‌روزرسانی شد' });
        return response;
      } else {
        throw new Error(response?.error || 'Failed to update quantity in Smart Cart');
      }
    } catch (error) {
      // Handle connection errors gracefully
      if (error.message.includes('Could not establish connection')) {
        console.log('💡 No content script available, updating Smart Cart quantity in storage directly');

        try {
          // Update quantity in storage directly
          const result = await chrome.storage.local.get(['digikala_extension_smart_cart_items']);
          const currentItems = result.digikala_extension_smart_cart_items || [];
          const itemIndex = currentItems.findIndex(item => item.id === data.itemId);

          if (itemIndex !== -1) {
            if (data.quantity <= 0) {
              // Remove item if quantity is 0 or negative
              currentItems.splice(itemIndex, 1);
            } else {
              // Update quantity
              currentItems[itemIndex].quantity = data.quantity;
              currentItems[itemIndex].updatedAt = Date.now();
            }

            await chrome.storage.local.set({ digikala_extension_smart_cart_items: currentItems });

            const updateResponse = { success: true, items: currentItems };
            this.emit('extension:smart-cart-quantity-updated', updateResponse);
            this.emit('ui:success', { message: 'تعداد محصول به‌روزرسانی شد' });
            return updateResponse;
          } else {
            throw new Error('Item not found in Smart Cart');
          }
        } catch (storageError) {
          this.error('Error updating Smart Cart quantity in storage:', storageError);
          this.emit('ui:error', { message: 'خطا در به‌روزرسانی تعداد محصول' });
          return { success: false, error: storageError.message };
        }
      } else {
        this.error('Error updating Smart Cart quantity:', error);
        this.emit('ui:error', { message: 'خطا در به‌روزرسانی تعداد محصول' });
        return { success: false, error: error.message };
      }
    }
  }

  async updateSmartCartVariation(data) {
    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'update_smart_cart_variation',
        itemId: data.itemId,
        variationId: data.variationId,
        optimizeForBestPrice: data.optimizeForBestPrice
      });

      if (response && response.success) {
        this.emit('extension:smart-cart-variation-updated', response);
        this.emit('ui:success', { message: 'تنوع محصول به‌روزرسانی شد' });
        return response;
      } else {
        throw new Error(response?.error || 'Failed to update variation in Smart Cart');
      }
    } catch (error) {
      // Handle connection errors gracefully
      if (error.message.includes('Could not establish connection')) {
        console.log('💡 No content script available, updating Smart Cart variation in storage directly');

        try {
          // Update variation in storage directly
          const result = await chrome.storage.local.get(['digikala_extension_smart_cart_items']);
          const currentItems = result.digikala_extension_smart_cart_items || [];
          const itemIndex = currentItems.findIndex(item => item.id === data.itemId);

          if (itemIndex !== -1) {
            currentItems[itemIndex].variantId = data.variationId === 'all_best_price' ? null : data.variationId;
            currentItems[itemIndex].optimizeForBestPrice = data.optimizeForBestPrice || false;
            currentItems[itemIndex].updatedAt = Date.now();

            await chrome.storage.local.set({ digikala_extension_smart_cart_items: currentItems });

            const updateResponse = { success: true, items: currentItems };
            this.emit('extension:smart-cart-variation-updated', updateResponse);
            this.emit('ui:success', { message: 'تنوع محصول به‌روزرسانی شد' });
            return updateResponse;
          } else {
            throw new Error('Item not found in Smart Cart');
          }
        } catch (storageError) {
          this.error('Error updating Smart Cart variation in storage:', storageError);
          this.emit('ui:error', { message: 'خطا در به‌روزرسانی تنوع محصول' });
          return { success: false, error: storageError.message };
        }
      } else {
        this.error('Error updating Smart Cart variation:', error);
        this.emit('ui:error', { message: 'خطا در به‌روزرسانی تنوع محصول' });
        return { success: false, error: error.message };
      }
    }
  }

  async updateSmartCartSeller(data) {
    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'update_smart_cart_seller',
        itemId: data.itemId,
        sellerId: data.sellerId,
        price: data.price
      });

      if (response && response.success) {
        this.emit('extension:smart-cart-seller-updated', response);
        this.emit('ui:success', { message: 'فروشنده محصول به‌روزرسانی شد' });
        return response;
      } else {
        throw new Error(response?.error || 'Failed to update seller in Smart Cart');
      }
    } catch (error) {
      // Handle connection errors gracefully
      if (error.message.includes('Could not establish connection')) {
        console.log('💡 No content script available, updating Smart Cart seller in storage directly');

        try {
          // Update seller in storage directly
          const result = await chrome.storage.local.get(['digikala_extension_smart_cart_items']);
          const currentItems = result.digikala_extension_smart_cart_items || [];
          const itemIndex = currentItems.findIndex(item => item.id === data.itemId);

          if (itemIndex !== -1) {
            currentItems[itemIndex].selectedSeller = data.sellerId;
            currentItems[itemIndex].price = data.price;
            currentItems[itemIndex].updatedAt = Date.now();

            await chrome.storage.local.set({ digikala_extension_smart_cart_items: currentItems });

            const updateResponse = { success: true, items: currentItems };
            this.emit('extension:smart-cart-seller-updated', updateResponse);
            this.emit('ui:success', { message: 'فروشنده محصول به‌روزرسانی شد' });
            return updateResponse;
          } else {
            throw new Error('Item not found in Smart Cart');
          }
        } catch (storageError) {
          this.error('Error updating Smart Cart seller in storage:', storageError);
          this.emit('ui:error', { message: 'خطا در به‌روزرسانی فروشنده محصول' });
          return { success: false, error: storageError.message };
        }
      } else {
        this.error('Error updating Smart Cart seller:', error);
        this.emit('ui:error', { message: 'خطا در به‌روزرسانی فروشنده محصول' });
        return { success: false, error: error.message };
      }
    }
  }

  // Public API for Smart Cart
  async sendMessage(action, data = {}) {
    try {
      const tab = this.currentTab || await this.getCurrentTab();
      if (!tab) {
        throw new Error('No active tab found');
      }

      const message = { action, ...data };
      const response = await chrome.tabs.sendMessage(tab.id, message);

      this.emit('extension:message-sent', {
        message,
        response
      });

      return response;
    } catch (error) {
      this.error('Error sending message:', error);
      return { success: false, error: error.message };
    }
  }

  // Cleanup
  async cleanup() {
    this.currentTab = null;
    this.isActive = false;
    this.pageType = 'unknown';
  }
}

// Make available globally
window.ExtensionBridge = ExtensionBridge;