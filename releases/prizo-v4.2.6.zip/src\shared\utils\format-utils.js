/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Format Utils - Price formatting and display utilities
 */
class FormatUtils {
  static formatPrice(priceInRials) {
    if (!priceInRials || priceInRials <= 0) return '';
    
    // Convert Rials to Tomans by dividing by 10
    const priceInTomans = Math.round(priceInRials / 10);
    return priceInTomans.toLocaleString('fa-IR') + ' تومان';
  }

  static formatPriceCompact(priceInRials) {
    if (!priceInRials || priceInRials <= 0) return '';
    
    // Convert Rials to Tomans by dividing by 10
    const priceInTomans = Math.round(priceInRials / 10);
    
    if (priceInTomans >= 1000000000) {
      return (priceInTomans / 1000000000).toFixed(1) + 'B تومان';
    } else if (priceInTomans >= 1000000) {
      return (priceInTomans / 1000000).toFixed(1) + 'M تومان';
    } else if (priceInTomans >= 1000) {
      return (priceInTomans / 1000).toFixed(1) + 'K تومان';
    }
    
    return priceInTomans.toLocaleString('fa-IR') + ' تومان';
  }

  static formatDiscount(discountPercent) {
    if (!discountPercent || discountPercent <= 0) return '';
    
    const rounded = Math.round(discountPercent);
    return `${rounded}% تخفیف`;
  }

  static formatNumber(number, locale = 'fa-IR') {
    if (number === null || number === undefined || isNaN(number)) {
      return '0';
    }
    
    return Number(number).toLocaleString(locale);
  }

  static formatDate(date, options = {}) {
    if (!date) return '';
    
    const defaultOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      locale: 'fa-IR'
    };
    
    const formatOptions = { ...defaultOptions, ...options };
    const { locale, ...dateOptions } = formatOptions;
    
    try {
      const dateObj = date instanceof Date ? date : new Date(date);
      return dateObj.toLocaleDateString(locale, dateOptions);
    } catch (error) {
      console.warn('Error formatting date:', error);
      return String(date);
    }
  }

  static formatTime(date, options = {}) {
    if (!date) return '';
    
    const defaultOptions = {
      hour: '2-digit',
      minute: '2-digit',
      locale: 'fa-IR'
    };
    
    const formatOptions = { ...defaultOptions, ...options };
    const { locale, ...timeOptions } = formatOptions;
    
    try {
      const dateObj = date instanceof Date ? date : new Date(date);
      return dateObj.toLocaleTimeString(locale, timeOptions);
    } catch (error) {
      console.warn('Error formatting time:', error);
      return String(date);
    }
  }

  static formatDateTime(date, options = {}) {
    if (!date) return '';
    
    const defaultOptions = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      locale: 'fa-IR'
    };
    
    const formatOptions = { ...defaultOptions, ...options };
    const { locale, ...dateTimeOptions } = formatOptions;
    
    try {
      const dateObj = date instanceof Date ? date : new Date(date);
      return dateObj.toLocaleString(locale, dateTimeOptions);
    } catch (error) {
      console.warn('Error formatting datetime:', error);
      return String(date);
    }
  }

  static formatRelativeTime(date) {
    if (!date) return '';
    
    try {
      const dateObj = date instanceof Date ? date : new Date(date);
      const now = new Date();
      const diffInSeconds = Math.floor((now - dateObj) / 1000);
      
      if (diffInSeconds < 60) {
        return 'همین الان';
      } else if (diffInSeconds < 3600) {
        const minutes = Math.floor(diffInSeconds / 60);
        return `${minutes} دقیقه پیش`;
      } else if (diffInSeconds < 86400) {
        const hours = Math.floor(diffInSeconds / 3600);
        return `${hours} ساعت پیش`;
      } else if (diffInSeconds < 2592000) {
        const days = Math.floor(diffInSeconds / 86400);
        return `${days} روز پیش`;
      } else if (diffInSeconds < 31536000) {
        const months = Math.floor(diffInSeconds / 2592000);
        return `${months} ماه پیش`;
      } else {
        const years = Math.floor(diffInSeconds / 31536000);
        return `${years} سال پیش`;
      }
    } catch (error) {
      console.warn('Error formatting relative time:', error);
      return String(date);
    }
  }

  static formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    const unitIndex = Math.floor(Math.log(bytes) / Math.log(1024));
    const size = bytes / Math.pow(1024, unitIndex);
    
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  }

  static formatPercentage(value, decimalPlaces = 1) {
    if (value === null || value === undefined || isNaN(value)) {
      return '0%';
    }
    
    return `${Number(value).toFixed(decimalPlaces)}%`;
  }

  static formatDuration(seconds) {
    if (!seconds || seconds < 0) return '0 ثانیه';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    
    const parts = [];
    
    if (hours > 0) {
      parts.push(`${hours} ساعت`);
    }
    
    if (minutes > 0) {
      parts.push(`${minutes} دقیقه`);
    }
    
    if (remainingSeconds > 0 || parts.length === 0) {
      parts.push(`${remainingSeconds} ثانیه`);
    }
    
    return parts.join(' و ');
  }

  static truncateText(text, maxLength = 100, suffix = '...') {
    if (!text || typeof text !== 'string') return '';
    
    if (text.length <= maxLength) return text;
    
    return text.substring(0, maxLength - suffix.length) + suffix;
  }

  static capitalizeFirst(text) {
    if (!text || typeof text !== 'string') return '';
    
    return text.charAt(0).toUpperCase() + text.slice(1);
  }

  static formatPhoneNumber(phoneNumber) {
    if (!phoneNumber) return '';
    
    const cleaned = phoneNumber.replace(/\D/g, '');
    
    // Iranian phone number format
    if (cleaned.startsWith('98') && cleaned.length === 12) {
      return `+${cleaned.substring(0, 2)} ${cleaned.substring(2, 5)} ${cleaned.substring(5, 8)} ${cleaned.substring(8)}`;
    } else if (cleaned.startsWith('0') && cleaned.length === 11) {
      return `${cleaned.substring(0, 4)} ${cleaned.substring(4, 7)} ${cleaned.substring(7)}`;
    }
    
    return phoneNumber;
  }

  static formatProductCode(code) {
    if (!code) return '';
    
    const codeStr = String(code);
    
    // Format as groups of 3-4 digits
    if (codeStr.length > 8) {
      return codeStr.replace(/(\d{3,4})(?=\d)/g, '$1-');
    }
    
    return codeStr;
  }

  static formatRating(rating, maxRating = 5) {
    if (!rating || rating < 0) return '0';
    
    const clampedRating = Math.min(rating, maxRating);
    return clampedRating.toFixed(1);
  }

  static formatStars(rating, maxRating = 5) {
    if (!rating || rating < 0) return '☆☆☆☆☆';
    
    const clampedRating = Math.min(rating, maxRating);
    const fullStars = Math.floor(clampedRating);
    const hasHalfStar = clampedRating % 1 >= 0.5;
    const emptyStars = maxRating - fullStars - (hasHalfStar ? 1 : 0);
    
    return '★'.repeat(fullStars) + 
           (hasHalfStar ? '½' : '') + 
           '☆'.repeat(emptyStars);
  }

  static formatCurrency(amount, currency = 'IRR') {
    if (!amount || amount <= 0) return '';
    
    const currencySymbols = {
      'IRR': 'ریال',
      'USD': '$',
      'EUR': '€',
      'GBP': '£'
    };
    
    const symbol = currencySymbols[currency] || currency;
    const formatted = this.formatNumber(amount);
    
    return `${formatted} ${symbol}`;
  }

  static sanitizeNumber(value) {
    const num = parseFloat(value);
    return isNaN(num) ? 0 : Math.max(0, num);
  }

  static extractPrice(priceData) {
    if (!priceData) return 0;
    
    if (typeof priceData === 'number') {
      return priceData;
    }
    
    if (typeof priceData === 'string') {
      const numericValue = parseFloat(priceData.replace(/[^\d.]/g, ''));
      return isNaN(numericValue) ? 0 : numericValue;
    }
    
    if (typeof priceData === 'object') {
      const possibleFields = ['selling_price', 'price', 'amount', 'value', 'rrp_price'];
      
      for (const field of possibleFields) {
        if (priceData[field] && typeof priceData[field] === 'number') {
          return priceData[field];
        }
      }
    }
    
    return 0;
  }

  static formatCompactNumber(number) {
    if (!number || number === 0) return '0';
    
    const absNumber = Math.abs(number);
    
    if (absNumber >= 1000000) {
      return (number / 1000000).toFixed(1) + 'M';
    } else if (absNumber >= 1000) {
      return (number / 1000).toFixed(1) + 'K';
    }
    
    return String(number);
  }

  static pluralize(count, singular, plural) {
    return count === 1 ? singular : plural;
  }
}

window.FormatUtils = FormatUtils;