/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-19
 * Smart Cart API - Unified interface for all cart operations
 * Provides a clean API for popup and fullpage to interact with centralized state
 */

class SmartCartAPI {
  constructor(contextId = 'unknown') {
    this.contextId = contextId;
    this.isSubscribed = false;
    this.stateUpdateCallbacks = new Set();

    // Initialize message listener for state updates
    this.setupMessageListener();

    console.log(`🛒 Smart Cart API initialized for context: ${contextId}`);
  }

  /**
   * Initialize the API and subscribe to state updates
   */
  async initialize() {
    try {
      // Subscribe to state updates from background
      await this.subscribe();
      console.log(`✅ Smart Cart API ready for ${this.contextId}`);
    } catch (error) {
      console.error(`❌ Failed to initialize Smart Cart API for ${this.contextId}:`, error);
      throw error;
    }
  }

  /**
   * Add an item to the cart
   */
  async addItem(productInfo, selectedVariant = null, selectedSeller = null) {
    try {
      const response = await this.sendMessage('smartCart:addItem', {
        productInfo,
        selectedVariant,
        selectedSeller
      });

      if (!response.success) {
        throw new Error(response.error || 'Failed to add item');
      }

      return response.item;
    } catch (error) {
      console.error('❌ Error adding item to cart:', error);
      throw error;
    }
  }

  /**
   * Remove an item from the cart
   */
  async removeItem(itemId) {
    try {
      const response = await this.sendMessage('smartCart:removeItem', { itemId });

      if (!response.success) {
        throw new Error(response.error || 'Failed to remove item');
      }

      return response.success;
    } catch (error) {
      console.error('❌ Error removing item from cart:', error);
      throw error;
    }
  }

  /**
   * Update item quantity
   */
  async updateQuantity(itemId, quantity) {
    try {
      if (quantity < 0) {
        throw new Error('Quantity cannot be negative');
      }

      const response = await this.sendMessage('smartCart:updateQuantity', {
        itemId,
        quantity: parseInt(quantity)
      });

      if (!response.success) {
        throw new Error(response.error || 'Failed to update quantity');
      }

      return response.item;
    } catch (error) {
      console.error('❌ Error updating item quantity:', error);
      throw error;
    }
  }

  /**
   * Increase item quantity by 1
   */
  async increaseQuantity(itemId) {
    const currentState = await this.getState();
    const item = currentState.items.find(item => item.id === itemId);

    if (!item) {
      throw new Error('Item not found');
    }

    const newQuantity = Math.min(item.quantity + 1, item.maxQuantity || 10);
    return await this.updateQuantity(itemId, newQuantity);
  }

  /**
   * Decrease item quantity by 1 (removes if becomes 0)
   */
  async decreaseQuantity(itemId) {
    const currentState = await this.getState();
    const item = currentState.items.find(item => item.id === itemId);

    if (!item) {
      throw new Error('Item not found');
    }

    const newQuantity = Math.max(item.quantity - 1, 0);
    return await this.updateQuantity(itemId, newQuantity);
  }

  /**
   * Change item variant
   */
  async changeVariant(itemId, variantId, variantDetails = null) {
    try {
      const response = await this.sendMessage('smartCart:changeVariant', {
        itemId,
        variantId,
        variantDetails
      });

      if (!response.success) {
        throw new Error(response.error || 'Failed to change variant');
      }

      return response.item;
    } catch (error) {
      console.error('❌ Error changing item variant:', error);
      throw error;
    }
  }

  /**
   * Change item seller
   */
  async changeSeller(itemId, sellerId, sellerDetails = null) {
    try {
      const response = await this.sendMessage('smartCart:changeSeller', {
        itemId,
        sellerId,
        sellerDetails
      });

      if (!response.success) {
        throw new Error(response.error || 'Failed to change seller');
      }

      return response.item;
    } catch (error) {
      console.error('❌ Error changing item seller:', error);
      throw error;
    }
  }

  /**
   * Clear the entire cart
   */
  async clearCart() {
    try {
      const response = await this.sendMessage('smartCart:clearCart');

      if (!response.success) {
        throw new Error(response.error || 'Failed to clear cart');
      }

      return true;
    } catch (error) {
      console.error('❌ Error clearing cart:', error);
      throw error;
    }
  }

  /**
   * Get current cart state
   */
  async getState() {
    try {
      const response = await this.sendMessage('smartCart:getState');

      if (!response.success) {
        throw new Error(response.error || 'Failed to get cart state');
      }

      return response.state;
    } catch (error) {
      console.error('❌ Error getting cart state:', error);
      throw error;
    }
  }

  /**
   * Refresh all cart items with fresh API data
   */
  async refreshItems() {
    try {
      const response = await this.sendMessage('smartCart:refreshItems');

      if (!response.success) {
        throw new Error(response.error || 'Failed to refresh items');
      }

      return true;
    } catch (error) {
      console.error('❌ Error refreshing cart items:', error);
      throw error;
    }
  }

  /**
   * Subscribe to state updates
   */
  async subscribe() {
    if (this.isSubscribed) {
      return;
    }

    try {
      const response = await this.sendMessage('smartCart:subscribe', {
        contextId: this.contextId
      });

      if (!response.success) {
        throw new Error(response.error || 'Failed to subscribe');
      }

      this.isSubscribed = true;
      console.log(`📡 Subscribed to Smart Cart updates: ${this.contextId}`);
    } catch (error) {
      console.error('❌ Error subscribing to updates:', error);
      throw error;
    }
  }

  /**
   * Unsubscribe from state updates
   */
  async unsubscribe() {
    if (!this.isSubscribed) {
      return;
    }

    try {
      const response = await this.sendMessage('smartCart:unsubscribe', {
        contextId: this.contextId
      });

      if (response.success) {
        this.isSubscribed = false;
        console.log(`📡 Unsubscribed from Smart Cart updates: ${this.contextId}`);
      }
    } catch (error) {
      console.warn('⚠️ Error unsubscribing from updates:', error);
    }
  }

  /**
   * Register a callback for state updates
   */
  onStateUpdate(callback) {
    if (typeof callback !== 'function') {
      throw new Error('Callback must be a function');
    }

    this.stateUpdateCallbacks.add(callback);

    // Return unsubscribe function
    return () => {
      this.stateUpdateCallbacks.delete(callback);
    };
  }

  /**
   * Setup message listener for state updates from background
   */
  setupMessageListener() {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
      chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'smartCart:stateUpdate') {
          this.handleStateUpdate(request.update);
          sendResponse({ received: true });
        }
      });
    }
  }

  /**
   * Handle state updates from background service
   */
  handleStateUpdate(update) {
    console.log(`🔄 Smart Cart state update (${this.contextId}):`, update.type);

    // Notify all registered callbacks
    for (const callback of this.stateUpdateCallbacks) {
      try {
        callback(update);
      } catch (error) {
        console.error(`❌ Error in state update callback (${this.contextId}):`, error);
      }
    }
  }

  /**
   * Send message to background service
   */
  async sendMessage(action, data = {}) {
    return new Promise((resolve, reject) => {
      const message = {
        action,
        ...data
      };

      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        if (!response) {
          reject(new Error('No response received from background service'));
          return;
        }

        resolve(response);
      });
    });
  }

  /**
   * Utility method to format price
   */
  formatPrice(price) {
    if (!price || price === 0) return '0 تومان';

    // Convert from rials to tomans
    const tomans = Math.floor(price / 10);
    const formatted = tomans.toLocaleString('fa-IR');
    return `${formatted} تومان`;
  }

  /**
   * Utility method to get cart summary
   */
  async getCartSummary() {
    const state = await this.getState();
    return state.summary;
  }

  /**
   * Utility method to check if product is in cart
   */
  async isProductInCart(productId, variantId = null) {
    const state = await this.getState();
    return state.items.some(item =>
      item.productId === productId &&
      (variantId ? item.variantId === variantId : true)
    );
  }

  /**
   * Utility method to get product from cart
   */
  async getProductFromCart(productId, variantId = null) {
    const state = await this.getState();
    return state.items.find(item =>
      item.productId === productId &&
      (variantId ? item.variantId === variantId : true)
    );
  }

  /**
   * Clean up resources
   */
  cleanup() {
    this.unsubscribe().catch(() => {});
    this.stateUpdateCallbacks.clear();
    console.log(`🧹 Smart Cart API cleaned up: ${this.contextId}`);
  }
}

// Export for different contexts
if (typeof window !== 'undefined') {
  window.SmartCartAPI = SmartCartAPI;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = SmartCartAPI;
}