/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-19
 * Smart Cart Client for Fullpage - Uses centralized state via API
 * Provides detailed cart management with enhanced UI and optimization features
 */

class SmartCartFullpageClient {
  constructor() {
    this.cartAPI = null;
    this.currentItems = [];
    this.currentSummary = {};
    this.loadingItems = [];
    this.optimizationResults = null;
    this.isOptimizing = false;

    // UI Elements will be dynamically created
    this.elements = {};

    this.initialize();
  }

  async initialize() {
    try {
      console.log('🏗️ Initializing Smart Cart Fullpage Client');

      await this.initializeCartAPI();
      this.createUI();
      this.setupEventListeners();

      console.log('✅ Smart Cart Fullpage Client ready');
    } catch (error) {
      console.error('❌ Failed to initialize Smart Cart Fullpage Client:', error);
    }
  }

  /**
   * Initialize Smart Cart API
   */
  async initializeCartAPI() {
    if (typeof SmartCartAPI === 'undefined') {
      throw new Error('SmartCartAPI not available');
    }

    this.cartAPI = new SmartCartAPI('fullpage');
    await this.cartAPI.initialize();

    // Subscribe to state updates
    this.cartAPI.onStateUpdate((update) => {
      this.handleStateUpdate(update);
    });

    console.log('✅ Smart Cart API initialized for fullpage');
  }

  /**
   * Create UI elements dynamically
   */
  createUI() {
    const container = this.createContainer();
    document.body.appendChild(container);

    this.elements = {
      container,
      header: container.querySelector('.cart-header'),
      itemsContainer: container.querySelector('.cart-items-container'),
      summaryContainer: container.querySelector('.cart-summary-container'),
      optimizationContainer: container.querySelector('.optimization-container'),
      emptyState: container.querySelector('.empty-state')
    };

    console.log('🎨 Smart Cart UI created');
  }

  /**
   * Create the main container with full UI
   */
  createContainer() {
    const container = document.createElement('div');
    container.className = 'smart-cart-fullpage';
    container.innerHTML = `
      <div class="smart-cart-fullpage-content">
        ${this.createHeaderHTML()}
        ${this.createMainContentHTML()}
        ${this.createOptimizationSectionHTML()}
      </div>
    `;

    // Add styles
    this.addStyles();

    return container;
  }

  /**
   * Create header HTML
   */
  createHeaderHTML() {
    return `
      <div class="cart-header">
        <div class="cart-header-content">
          <div class="cart-title-section">
            <h2 class="cart-title">
              <span class="cart-icon">🛒</span>
              سبد هوشمند
            </h2>
            <div class="cart-badge" id="cartBadge">0</div>
          </div>
          <div class="cart-actions">
            <button class="btn-secondary" id="refreshCartBtn">
              <span class="btn-icon">🔄</span>
              بروزرسانی
            </button>
            <button class="btn-secondary" id="optimizeCartBtn">
              <span class="btn-icon">🎯</span>
              بهینه‌سازی
            </button>
            <button class="btn-danger" id="clearCartBtn">
              <span class="btn-icon">🗑️</span>
              پاک کردن سبد
            </button>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Create main content HTML
   */
  createMainContentHTML() {
    return `
      <div class="cart-main-content">
        <div class="cart-items-section">
          <div class="cart-items-container" id="cartItemsContainer">
            <!-- Items will be rendered here -->
          </div>
          <div class="empty-state" id="emptyState" style="display: none;">
            <div class="empty-state-content">
              <div class="empty-state-icon">🛒</div>
              <h3 class="empty-state-title">سبد شما خالی است</h3>
              <p class="empty-state-description">
                محصولاتی که با دکمه "افزودن به سبد هوشمند" اضافه کنید اینجا نمایش داده خواهند شد.
              </p>
            </div>
          </div>
        </div>
        <div class="cart-summary-container" id="cartSummaryContainer">
          ${this.createSummaryHTML()}
        </div>
      </div>
    `;
  }

  /**
   * Create summary HTML
   */
  createSummaryHTML() {
    return `
      <div class="cart-summary">
        <h3 class="summary-title">خلاصه سبد</h3>
        <div class="summary-stats">
          <div class="summary-stat">
            <div class="stat-value" id="totalItems">0</div>
            <div class="stat-label">تعداد کل</div>
          </div>
          <div class="summary-stat">
            <div class="stat-value" id="uniqueProducts">0</div>
            <div class="stat-label">محصولات مختلف</div>
          </div>
          <div class="summary-stat">
            <div class="stat-value" id="totalValue">0 تومان</div>
            <div class="stat-label">مجموع قیمت</div>
          </div>
        </div>
        <div class="summary-actions">
          <button class="btn-primary btn-full" id="proceedBtn" disabled>
            ادامه خرید
          </button>
        </div>
      </div>
    `;
  }

  /**
   * Create optimization section HTML
   */
  createOptimizationSectionHTML() {
    return `
      <div class="optimization-container" id="optimizationContainer" style="display: none;">
        <div class="optimization-content">
          <div class="optimization-header">
            <h3 class="optimization-title">
              <span class="optimization-icon">🧮</span>
              نتایج بهینه‌سازی
            </h3>
            <div class="optimization-loading" id="optimizationLoading" style="display: none;">
              <div class="loading-spinner"></div>
              <span>در حال محاسبه...</span>
            </div>
          </div>
          <div class="optimization-results" id="optimizationResults">
            <!-- Results will be rendered here -->
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Setup event listeners
   */
  setupEventListeners() {
    const { container } = this.elements;

    // Header actions
    container.querySelector('#refreshCartBtn')?.addEventListener('click', () => this.refreshCart());
    container.querySelector('#optimizeCartBtn')?.addEventListener('click', () => this.optimizeCart());
    container.querySelector('#clearCartBtn')?.addEventListener('click', () => this.clearCart());
    container.querySelector('#proceedBtn')?.addEventListener('click', () => this.proceedToCheckout());

    // Event delegation for cart items
    container.querySelector('#cartItemsContainer')?.addEventListener('click', (e) => this.handleItemClick(e));
    container.querySelector('#cartItemsContainer')?.addEventListener('change', (e) => this.handleItemChange(e));
  }

  /**
   * Handle state updates from centralized state
   */
  handleStateUpdate(update) {
    console.log(`🔄 Fullpage received state update: ${update.type}`);

    // Update local state
    if (update.items) {
      this.currentItems = update.items;
    }

    // Handle different update types
    switch (update.type) {
      case 'INITIAL_STATE':
      case 'CART_UPDATED':
      case 'STORAGE_SYNC':
        this.renderUI();
        break;

      case 'ITEM_ADDED':
      case 'ITEM_REMOVED':
      case 'QUANTITY_UPDATED':
      case 'VARIANT_CHANGED':
      case 'SELLER_CHANGED':
        this.renderUI();
        this.showNotification(`✅ ${this.getUpdateMessage(update)}`);
        break;

      case 'CART_CLEARED':
        this.renderUI();
        this.showNotification('🧹 سبد پاک شد');
        break;

      case 'LOADING_STATE_CHANGED':
        this.loadingItems = update.loadingItems || [];
        this.updateLoadingStates();
        break;

      case 'REFRESH_COMPLETED':
        this.showNotification('✅ اطلاعات بروزرسانی شد');
        this.renderUI();
        break;

      case 'ITEM_OPTIMIZED':
        this.showNotification(`🎯 بهینه‌سازی شد: ${update.item?.title}`);
        this.renderUI();
        break;
    }
  }

  /**
   * Render the complete UI
   */
  async renderUI() {
    try {
      const summary = await this.cartAPI.getCartSummary();
      this.currentSummary = summary;

      this.updateHeader();
      this.renderCartItems();
      this.updateSummary();
      this.updateEmptyState();
    } catch (error) {
      console.error('❌ Error rendering UI:', error);
    }
  }

  /**
   * Update header with current state
   */
  updateHeader() {
    const badge = this.elements.container.querySelector('#cartBadge');
    if (badge) {
      badge.textContent = this.currentItems.length;
      badge.className = `cart-badge ${this.currentItems.length > 0 ? 'has-items' : ''}`;
    }
  }

  /**
   * Render cart items
   */
  renderCartItems() {
    const container = this.elements.itemsContainer;
    if (!container) return;

    if (this.currentItems.length === 0) {
      container.innerHTML = '';
      return;
    }

    const itemsHTML = this.currentItems.map(item => this.renderCartItem(item)).join('');
    container.innerHTML = itemsHTML;
  }

  /**
   * Render individual cart item with enhanced UI
   */
  renderCartItem(item) {
    const isLoading = this.loadingItems.includes(item.id);
    const needsRefresh = item._apiStatus?.needsRefresh || false;

    return `
      <div class="cart-item ${isLoading ? 'loading' : ''} ${needsRefresh ? 'stale' : ''}" data-item-id="${item.id}">
        <div class="cart-item-content">
          ${this.renderItemImage(item)}
          ${this.renderItemInfo(item)}
          ${this.renderItemControls(item)}
          ${this.renderItemActions(item)}
        </div>
        ${isLoading ? '<div class="item-loading-overlay"><div class="loading-spinner"></div></div>' : ''}
      </div>
    `;
  }

  /**
   * Render item image
   */
  renderItemImage(item) {
    return `
      <div class="cart-item-image">
        ${item.thumbnail ?
          `<img src="${item.thumbnail}" alt="${item.title}" class="item-thumbnail">` :
          `<div class="item-placeholder">📦</div>`
        }
        ${item.bestPriceMode ? '<div class="best-price-badge">🎯</div>' : ''}
      </div>
    `;
  }

  /**
   * Render item information
   */
  renderItemInfo(item) {
    return `
      <div class="cart-item-info">
        <h4 class="item-title">
          <a href="${item.productUrl || `https://www.digikala.com/product/dkp-${item.productId}/`}"
             target="_blank" class="item-link">
            ${item.title || 'در حال بارگذاری...'}
          </a>
        </h4>
        <div class="item-details">
          ${this.renderItemVariant(item)}
          ${this.renderItemSeller(item)}
          <div class="item-price-info">
            <span class="current-price">${this.formatPrice(this.getDisplayedPrice(item))}</span>
            <span class="item-total">مجموع: ${this.formatPrice(this.getDisplayedPrice(item) * item.quantity)}</span>
          </div>
        </div>
        ${this.renderAvailabilityInfo(item)}
      </div>
    `;
  }

  /**
   * Render item controls (quantity, variant, seller selectors)
   */
  renderItemControls(item) {
    return `
      <div class="cart-item-controls">
        <div class="quantity-section">
          <label class="control-label">تعداد:</label>
          <div class="quantity-controls">
            <button class="quantity-btn decrease" data-action="decrease" data-item-id="${item.id}"
                    ${item.quantity <= 1 ? 'disabled' : ''}>−</button>
            <input type="number" class="quantity-input" value="${item.quantity}"
                   min="1" max="${item.maxQuantity || 10}" data-item-id="${item.id}">
            <button class="quantity-btn increase" data-action="increase" data-item-id="${item.id}">+</button>
          </div>
        </div>
        ${this.renderVariantControls(item)}
        ${this.renderSellerControls(item)}
      </div>
    `;
  }

  /**
   * Render variant controls
   */
  renderVariantControls(item) {
    if (!item.variants || item.variants.length <= 1) {
      return this.renderVariantDisplay(item);
    }

    const options = [{
      id: 'all_best_price',
      title: 'همه تنوع‌ها (بهترین قیمت)',
      price: null
    }, ...item.variants];

    const optionsHTML = options.map(variant =>
      `<option value="${variant.id}" ${variant.id === item.variantId ? 'selected' : ''}>
        ${variant.title}${variant.price ? ` - ${this.formatPrice(variant.price)}` : ''}
      </option>`
    ).join('');

    return `
      <div class="variant-section">
        <label class="control-label">تنوع:</label>
        <select class="variant-select" data-item-id="${item.id}">
          ${optionsHTML}
        </select>
      </div>
    `;
  }

  /**
   * Render variant display (when no selection available)
   */
  renderVariantDisplay(item) {
    if (!item.selectedVariant) return '';

    const variantText = this.getVariantDisplayText(item.selectedVariant);
    if (!variantText) return '';

    return `
      <div class="variant-section">
        <label class="control-label">تنوع:</label>
        <div class="variant-display">${variantText}</div>
      </div>
    `;
  }

  /**
   * Render seller controls
   */
  renderSellerControls(item) {
    const availableSellers = this.getAvailableSellersForVariant(item);

    // ALWAYS show seller dropdown - this is an optimization tool, not a checkout requirement
    // Even with one seller, user should be able to choose "All Sellers" for optimization

    // ALWAYS include "All Sellers" as the default option - this is an optimization tool
    let optionsHTML = `<option value="all" ${(item.selectedSellerId === 'all' || !item.selectedSellerId) ? 'selected' : ''}>همه فروشندگان (بهینه‌سازی)</option>`;

    // Add real seller data if available
    if (availableSellers && availableSellers.length > 0) {
      optionsHTML += availableSellers.map(seller =>
        `<option value="${seller.id}" ${seller.id === item.selectedSellerId ? 'selected' : ''}>
          ${seller.name} - ${this.formatPrice(seller.price)}
          ${seller.rating ? ` (⭐${seller.rating})` : ''}
        </option>`
      ).join('');
    }

    return `
      <div class="seller-section">
        <label class="control-label">فروشنده:</label>
        <select class="seller-select" data-item-id="${item.id}">
          ${optionsHTML}
        </select>
      </div>
    `;
  }

  /**
   * Get available sellers for the selected variant
   */
  getAvailableSellersForVariant(item) {
    const allSellers = item.sellers || [];

    // If no variant is selected or "all variants" is selected, return all sellers
    if (!item.variantId || item.variantId === 'all_best_price') {
      return this.deduplicateSellers(allSellers);
    }

    // If we have variant-seller mapping data, filter sellers based on the selected variant
    if (item.variantSellerMap && item.variantSellerMap[item.variantId]) {
      const variantSellerIds = item.variantSellerMap[item.variantId];
      const filteredSellers = allSellers.filter(seller => variantSellerIds.includes(seller.id));
      return this.deduplicateSellers(filteredSellers);
    }

    // If we have variations data with seller information, extract sellers for the selected variant
    if (item.variations && item.variations.length > 0) {
      const selectedVariation = item.variations.find(v => v.id === item.variantId);
      if (selectedVariation && selectedVariation.sellers) {
        return this.deduplicateSellers(selectedVariation.sellers);
      }
    }

    // Fallback: if the variant structure doesn't have seller mapping, return all sellers
    // This maintains backward compatibility
    return this.deduplicateSellers(allSellers);
  }

  /**
   * Get the displayed price based on optimization tool logic:
   * Smart Cart is an optimization tool - price reflects best option within user's filters
   * 1. Default (no filters): Lowest price across all variants and sellers
   * 2. Variant filter: Lowest price for that variant across all sellers
   * 3. Variant + specific seller filter: Exact price for that combination
   */
  getDisplayedPrice(item) {
    const selectedVariant = item.variantId;
    const selectedSeller = item.selectedSellerId;

    // Case 3: Specific variant + specific seller selected (most restrictive filter)
    if (selectedVariant && selectedVariant !== 'all_best_price' && selectedSeller && selectedSeller !== 'all') {
      const availableSellers = this.getAvailableSellersForVariant(item);
      const sellerData = availableSellers.find(seller => seller.id === selectedSeller);
      if (sellerData && sellerData.price) {
        console.log(`💰 Filtered price (variant + seller): ${this.formatPrice(sellerData.price)}`);
        return sellerData.price;
      }
    }

    // Case 2: Variant selected, but "All Sellers" chosen (variant filter only)
    if (selectedVariant && selectedVariant !== 'all_best_price' && (!selectedSeller || selectedSeller === 'all')) {
      const availableSellers = this.getAvailableSellersForVariant(item);
      if (availableSellers.length > 0) {
        const lowestPrice = Math.min(...availableSellers.map(seller => seller.price || Infinity).filter(p => p !== Infinity));
        if (lowestPrice !== Infinity) {
          console.log(`💰 Optimized price for variant ${selectedVariant}: ${this.formatPrice(lowestPrice)}`);
          return lowestPrice;
        }
      }

      // Check if we have variation price data
      if (item.variations && item.variations.length > 0) {
        const selectedVariation = item.variations.find(v => v.id === selectedVariant);
        if (selectedVariation && selectedVariation.price?.selling_price) {
          console.log(`💰 Variant price from API: ${this.formatPrice(selectedVariation.price.selling_price)}`);
          return selectedVariation.price.selling_price;
        }
      }
    }

    // Case 1: Default optimization (no filters applied) - Find absolute best price
    const allSellers = item.sellers || [];
    if (allSellers.length > 0) {
      const lowestPrice = Math.min(...allSellers.map(seller => seller.price || Infinity).filter(p => p !== Infinity));
      if (lowestPrice !== Infinity) {
        console.log(`💰 Fully optimized price (no filters): ${this.formatPrice(lowestPrice)}`);
        return lowestPrice;
      }
    }

    // Check all variations for the lowest price when no seller data
    if (item.variations && item.variations.length > 0) {
      const variationPrices = item.variations
        .map(v => v.price?.selling_price)
        .filter(p => p && p > 0);

      if (variationPrices.length > 0) {
        const lowestVariationPrice = Math.min(...variationPrices);
        console.log(`💰 Optimized variation price: ${this.formatPrice(lowestVariationPrice)}`);
        return lowestVariationPrice;
      }
    }

    // Fallback to item.price if available
    if (item.price && item.price > 0) {
      console.log(`💰 Fallback: Using item.price: ${this.formatPrice(item.price)}`);
      return item.price;
    }

    console.log('💰 No valid price found, returning 0');
    return 0;
  }

  /**
   * Remove duplicate sellers based on seller ID
   */
  deduplicateSellers(sellers) {
    if (!sellers || sellers.length === 0) return [];

    const uniqueSellerMap = new Map();

    sellers.forEach(seller => {
      if (!uniqueSellerMap.has(seller.id)) {
        uniqueSellerMap.set(seller.id, seller);
      } else {
        // If duplicate found, keep the one with more complete data (e.g., has price)
        const existing = uniqueSellerMap.get(seller.id);
        if (seller.price && !existing.price) {
          uniqueSellerMap.set(seller.id, seller);
        }
      }
    });

    const uniqueSellers = Array.from(uniqueSellerMap.values());
    console.log(`🔄 Deduplicated sellers: ${sellers.length} → ${uniqueSellers.length}`);
    return uniqueSellers;
  }

  /**
   * Render item actions
   */
  renderItemActions(item) {
    return `
      <div class="cart-item-actions">
        <button class="action-btn remove-btn" data-action="remove" data-item-id="${item.id}"
                title="حذف از سبد">
          <span class="btn-icon">🗑️</span>
        </button>
        <button class="action-btn refresh-btn" data-action="refresh" data-item-id="${item.id}"
                title="بروزرسانی اطلاعات">
          <span class="btn-icon">🔄</span>
        </button>
        <button class="action-btn optimize-btn" data-action="optimize" data-item-id="${item.id}"
                title="بهینه‌سازی قیمت">
          <span class="btn-icon">🎯</span>
        </button>
      </div>
    `;
  }

  /**
   * Render availability information
   */
  renderAvailabilityInfo(item) {
    if (!item.availability) return '';

    const { isAvailable, stockCount } = item.availability;

    return `
      <div class="availability-info ${isAvailable ? 'available' : 'unavailable'}">
        <span class="availability-status">
          ${isAvailable ? '✅ موجود' : '❌ ناموجود'}
        </span>
        ${stockCount > 0 ? `<span class="stock-count">(${stockCount} عدد)</span>` : ''}
      </div>
    `;
  }

  /**
   * Update summary display
   */
  updateSummary() {
    const summary = this.currentSummary;

    const totalItemsEl = this.elements.container.querySelector('#totalItems');
    const uniqueProductsEl = this.elements.container.querySelector('#uniqueProducts');
    const totalValueEl = this.elements.container.querySelector('#totalValue');
    const proceedBtn = this.elements.container.querySelector('#proceedBtn');

    if (totalItemsEl) totalItemsEl.textContent = summary.totalItems || 0;
    if (uniqueProductsEl) uniqueProductsEl.textContent = summary.uniqueProducts || 0;
    if (totalValueEl) totalValueEl.textContent = this.formatPrice(summary.totalValue || 0);

    if (proceedBtn) {
      proceedBtn.disabled = (summary.totalItems || 0) === 0;
    }
  }

  /**
   * Update empty state
   */
  updateEmptyState() {
    const emptyState = this.elements.emptyState;
    const itemsContainer = this.elements.itemsContainer;

    if (this.currentItems.length === 0) {
      emptyState.style.display = 'flex';
      itemsContainer.style.display = 'none';
    } else {
      emptyState.style.display = 'none';
      itemsContainer.style.display = 'block';
    }
  }

  /**
   * Handle item clicks
   */
  async handleItemClick(event) {
    const action = event.target.closest('[data-action]')?.dataset.action;
    const itemId = event.target.closest('[data-item-id]')?.dataset.itemId;

    if (!action || !itemId) return;

    try {
      switch (action) {
        case 'remove':
          await this.removeItem(itemId);
          break;
        case 'increase':
          await this.increaseQuantity(itemId);
          break;
        case 'decrease':
          await this.decreaseQuantity(itemId);
          break;
        case 'refresh':
          await this.refreshItem(itemId);
          break;
        case 'optimize':
          await this.optimizeItem(itemId);
          break;
      }
    } catch (error) {
      console.error(`❌ Error handling ${action} for item ${itemId}:`, error);
      this.showNotification(`❌ خطا: ${error.message}`);
    }
  }

  /**
   * Handle item changes (dropdowns, inputs)
   */
  async handleItemChange(event) {
    const itemId = event.target.dataset.itemId;
    if (!itemId) return;

    try {
      if (event.target.classList.contains('quantity-input')) {
        const newQuantity = parseInt(event.target.value) || 1;
        await this.cartAPI.updateQuantity(itemId, newQuantity);
      } else if (event.target.classList.contains('variant-select')) {
        const variantId = event.target.value;
        await this.cartAPI.changeVariant(itemId, variantId);
      } else if (event.target.classList.contains('seller-select')) {
        const sellerId = event.target.value;
        await this.cartAPI.changeSeller(itemId, sellerId);
      }
    } catch (error) {
      console.error('❌ Error handling item change:', error);
      this.showNotification(`❌ خطا: ${error.message}`);
    }
  }

  /**
   * Cart operations
   */
  async removeItem(itemId) {
    await this.cartAPI.removeItem(itemId);
  }

  async increaseQuantity(itemId) {
    await this.cartAPI.increaseQuantity(itemId);
  }

  async decreaseQuantity(itemId) {
    await this.cartAPI.decreaseQuantity(itemId);
  }

  async refreshItem(itemId) {
    // Individual item refresh would be implemented here
    this.showNotification('🔄 در حال بروزرسانی...');
  }

  async optimizeItem(itemId) {
    // Individual item optimization would be implemented here
    this.showNotification('🎯 در حال بهینه‌سازی...');
  }

  async refreshCart() {
    try {
      this.showNotification('🔄 در حال بروزرسانی سبد...');
      await this.cartAPI.refreshItems();
    } catch (error) {
      console.error('❌ Error refreshing cart:', error);
      this.showNotification('❌ خطا در بروزرسانی');
    }
  }

  async optimizeCart() {
    if (this.isOptimizing) return;

    try {
      this.isOptimizing = true;
      this.showOptimizationLoading(true);
      this.showNotification('🧮 در حال بهینه‌سازی سبد...');

      // Optimization logic would be implemented here
      // For now, just simulate the process
      await new Promise(resolve => setTimeout(resolve, 2000));

      this.showNotification('✅ بهینه‌سازی کامل شد');
    } catch (error) {
      console.error('❌ Error optimizing cart:', error);
      this.showNotification('❌ خطا در بهینه‌سازی');
    } finally {
      this.isOptimizing = false;
      this.showOptimizationLoading(false);
    }
  }

  async clearCart() {
    const confirmed = confirm('آیا مطمئن هستید که می‌خواهید تمام محصولات را از سبد حذف کنید؟');
    if (!confirmed) return;

    try {
      await this.cartAPI.clearCart();
    } catch (error) {
      console.error('❌ Error clearing cart:', error);
      this.showNotification('❌ خطا در پاک کردن سبد');
    }
  }

  async proceedToCheckout() {
    this.showNotification('🚀 در حال هدایت به صفحه خرید...');
    // Checkout logic would be implemented here
  }

  /**
   * Utility methods
   */
  formatPrice(price) {
    if (!price || price === 0) return '0 تومان';
    const tomans = Math.floor(price / 10);
    return `${tomans.toLocaleString('fa-IR')} تومان`;
  }

  getVariantDisplayText(variant) {
    if (!variant) return null;

    const parts = [];
    if (variant.color) parts.push(`رنگ: ${variant.color.title}`);
    if (variant.size) parts.push(`سایز: ${variant.size.title}`);
    if (variant.warranty) parts.push(`گارانتی: ${variant.warranty.title}`);

    return parts.length > 0 ? parts.join(', ') : null;
  }

  getUpdateMessage(update) {
    switch (update.type) {
      case 'ITEM_ADDED': return `محصول اضافه شد`;
      case 'ITEM_REMOVED': return `محصول حذف شد`;
      case 'QUANTITY_UPDATED': return `تعداد بروزرسانی شد`;
      case 'VARIANT_CHANGED': return `تنوع تغییر کرد`;
      case 'SELLER_CHANGED': return `فروشنده تغییر کرد`;
      default: return 'تغییرات اعمال شد';
    }
  }

  showNotification(message, type = 'info', duration = 3000) {
    // Create and show notification
    const notification = document.createElement('div');
    notification.className = `cart-notification ${type}`;
    notification.textContent = message;

    document.body.appendChild(notification);

    // Auto remove after duration
    setTimeout(() => {
      notification.remove();
    }, duration);
  }

  showOptimizationLoading(show) {
    const loading = this.elements.container.querySelector('#optimizationLoading');
    if (loading) {
      loading.style.display = show ? 'flex' : 'none';
    }
  }

  updateLoadingStates() {
    // Update loading states for individual items
    this.currentItems.forEach(item => {
      const itemElement = this.elements.container.querySelector(`[data-item-id="${item.id}"]`);
      if (itemElement) {
        const isLoading = this.loadingItems.includes(item.id);
        itemElement.classList.toggle('loading', isLoading);
      }
    });
  }

  /**
   * Add styles to the page
   */
  addStyles() {
    if (document.querySelector('#smart-cart-fullpage-styles')) {
      return; // Styles already added
    }

    const styles = document.createElement('style');
    styles.id = 'smart-cart-fullpage-styles';
    styles.textContent = `
      .smart-cart-fullpage {
        position: fixed;
        top: 0;
        right: 0;
        width: 400px;
        height: 100vh;
        background: #ffffff;
        border-left: 1px solid #e5e7eb;
        box-shadow: -2px 0 10px rgba(0, 0, 0, 0.1);
        z-index: 10000;
        font-family: 'Tahoma', sans-serif;
        direction: rtl;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }

      .smart-cart-fullpage-content {
        height: 100%;
        display: flex;
        flex-direction: column;
      }

      .cart-header {
        background: #f8fafc;
        border-bottom: 1px solid #e5e7eb;
        padding: 16px;
        flex-shrink: 0;
      }

      .cart-header-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
      }

      .cart-title-section {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .cart-title {
        margin: 0;
        font-size: 18px;
        font-weight: 600;
        color: #1f2937;
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .cart-icon {
        font-size: 20px;
      }

      .cart-badge {
        background: #3b82f6;
        color: white;
        border-radius: 12px;
        padding: 4px 8px;
        font-size: 12px;
        font-weight: 600;
        min-width: 20px;
        text-align: center;
      }

      .cart-badge.has-items {
        background: #10b981;
      }

      .cart-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
      }

      .btn-primary, .btn-secondary, .btn-danger {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 12px;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
      }

      .btn-primary {
        background: #3b82f6;
        color: white;
      }

      .btn-secondary {
        background: #f3f4f6;
        color: #374151;
        border: 1px solid #d1d5db;
      }

      .btn-danger {
        background: #fee2e2;
        color: #dc2626;
        border: 1px solid #fecaca;
      }

      .btn-primary:hover { background: #2563eb; }
      .btn-secondary:hover { background: #e5e7eb; }
      .btn-danger:hover { background: #fecaca; }

      .btn-primary:disabled {
        background: #d1d5db;
        cursor: not-allowed;
      }

      .btn-full {
        width: 100%;
        justify-content: center;
      }

      .cart-main-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }

      .cart-items-section {
        flex: 1;
        overflow-y: auto;
      }

      .cart-items-container {
        padding: 16px;
      }

      .cart-item {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        margin-bottom: 12px;
        position: relative;
        transition: all 0.2s ease;
      }

      .cart-item.loading {
        opacity: 0.7;
      }

      .cart-item.stale {
        border-color: #fbbf24;
        background: #fffbeb;
      }

      .cart-item-content {
        padding: 12px;
      }

      .cart-item-image {
        position: relative;
        margin-bottom: 8px;
      }

      .item-thumbnail {
        width: 100%;
        height: 120px;
        object-fit: cover;
        border-radius: 6px;
      }

      .item-placeholder {
        width: 100%;
        height: 120px;
        background: #f3f4f6;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: #9ca3af;
      }

      .best-price-badge {
        position: absolute;
        top: 8px;
        right: 8px;
        background: #10b981;
        color: white;
        border-radius: 12px;
        padding: 2px 6px;
        font-size: 10px;
      }

      .cart-item-info {
        margin-bottom: 12px;
      }

      .item-title {
        margin: 0 0 8px 0;
        font-size: 14px;
        line-height: 1.4;
      }

      .item-link {
        color: #1f2937;
        text-decoration: none;
      }

      .item-link:hover {
        color: #3b82f6;
      }

      .item-details {
        display: flex;
        flex-direction: column;
        gap: 4px;
        font-size: 12px;
        color: #6b7280;
      }

      .item-price-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-weight: 500;
      }

      .current-price {
        color: #10b981;
      }

      .item-total {
        color: #059669;
        font-weight: 600;
      }

      .cart-item-controls {
        display: flex;
        flex-direction: column;
        gap: 12px;
        padding: 12px;
        background: #f8fafc;
        border-radius: 6px;
        margin-bottom: 12px;
      }

      .control-label {
        font-size: 11px;
        font-weight: 500;
        color: #374151;
        margin-bottom: 4px;
        display: block;
      }

      .quantity-controls {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .quantity-btn {
        width: 28px;
        height: 28px;
        border: 1px solid #d1d5db;
        background: white;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-weight: bold;
      }

      .quantity-btn:hover:not(:disabled) {
        background: #f3f4f6;
      }

      .quantity-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }

      .quantity-input {
        width: 60px;
        padding: 4px 8px;
        border: 1px solid #d1d5db;
        border-radius: 4px;
        text-align: center;
        font-size: 12px;
      }

      .variant-select, .seller-select {
        width: 100%;
        padding: 6px 8px;
        border: 1px solid #d1d5db;
        border-radius: 4px;
        font-size: 12px;
        background: white;
        cursor: pointer;
        pointer-events: auto;
        position: relative;
        z-index: 10;
      }

      .variant-select:hover, .seller-select:hover {
        border-color: #3b82f6;
      }

      .variant-select:focus, .seller-select:focus {
        outline: none;
        border-color: #3b82f6;
        box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.1);
      }

      .variant-display, .seller-display {
        padding: 6px 8px;
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 4px;
        font-size: 12px;
        color: #374151;
      }

      .seller-rating {
        color: #10b981;
        font-weight: 500;
      }

      .cart-item-actions {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }

      .action-btn {
        padding: 6px;
        border: 1px solid #d1d5db;
        background: white;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .remove-btn:hover { background: #fee2e2; border-color: #fecaca; }
      .refresh-btn:hover { background: #f0f9ff; border-color: #bfdbfe; }
      .optimize-btn:hover { background: #f0fdf4; border-color: #bbf7d0; }

      .availability-info {
        margin-top: 8px;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 500;
      }

      .availability-info.available {
        background: #f0fdf4;
        color: #166534;
        border: 1px solid #bbf7d0;
      }

      .availability-info.unavailable {
        background: #fef2f2;
        color: #991b1b;
        border: 1px solid #fecaca;
      }

      .cart-summary-container {
        border-top: 1px solid #e5e7eb;
        background: #f8fafc;
        padding: 16px;
        flex-shrink: 0;
      }

      .summary-title {
        margin: 0 0 12px 0;
        font-size: 16px;
        font-weight: 600;
        color: #1f2937;
      }

      .summary-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
        margin-bottom: 16px;
      }

      .summary-stat {
        text-align: center;
        padding: 8px;
        background: white;
        border-radius: 6px;
        border: 1px solid #e5e7eb;
      }

      .stat-value {
        font-size: 16px;
        font-weight: 600;
        color: #1f2937;
      }

      .stat-label {
        font-size: 11px;
        color: #6b7280;
        margin-top: 2px;
      }

      .empty-state {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 32px 16px;
      }

      .empty-state-content {
        text-align: center;
      }

      .empty-state-icon {
        font-size: 48px;
        margin-bottom: 16px;
        opacity: 0.5;
      }

      .empty-state-title {
        margin: 0 0 8px 0;
        font-size: 18px;
        color: #374151;
      }

      .empty-state-description {
        margin: 0;
        color: #6b7280;
        font-size: 14px;
        line-height: 1.5;
      }

      .optimization-container {
        background: #f0fdf4;
        border-top: 1px solid #bbf7d0;
        padding: 16px;
        margin-top: auto;
      }

      .optimization-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
      }

      .optimization-title {
        margin: 0;
        font-size: 14px;
        font-weight: 600;
        color: #166534;
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .optimization-loading {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        color: #166534;
      }

      .loading-spinner {
        width: 12px;
        height: 12px;
        border: 2px solid #bbf7d0;
        border-top: 2px solid #16a34a;
        border-radius: 50%;
        animation: spin 1s linear infinite;
      }

      .item-loading-overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255, 255, 255, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
      }

      .cart-notification {
        position: fixed;
        top: 20px;
        right: 420px;
        background: #1f2937;
        color: white;
        padding: 12px 16px;
        border-radius: 6px;
        font-size: 14px;
        z-index: 10001;
        animation: slideIn 0.3s ease;
      }

      .cart-notification.info { background: #3b82f6; }
      .cart-notification.success { background: #10b981; }
      .cart-notification.error { background: #dc2626; }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }

      @keyframes slideIn {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
    `;

    document.head.appendChild(styles);
  }

  /**
   * Cleanup
   */
  cleanup() {
    if (this.cartAPI) {
      this.cartAPI.cleanup();
    }

    if (this.elements.container && this.elements.container.parentNode) {
      this.elements.container.parentNode.removeChild(this.elements.container);
    }

    const styles = document.querySelector('#smart-cart-fullpage-styles');
    if (styles) {
      styles.remove();
    }

    console.log('🧹 Smart Cart Fullpage Client cleaned up');
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.smartCartFullpageClient = new SmartCartFullpageClient();
  });
} else {
  window.smartCartFullpageClient = new SmartCartFullpageClient();
}

// Export for manual initialization
window.SmartCartFullpageClient = SmartCartFullpageClient;