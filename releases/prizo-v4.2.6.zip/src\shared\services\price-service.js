/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Price Service - Handles price calculations, comparisons, and processing
 * Now includes centralized logging via LoggerService for better error tracking and debugging
 */
/**
 * Service for handling price calculations, comparisons, and processing
 */
class PriceService {
    constructor(eventBus, apiService, logger) {
        this.eventBus = eventBus;
        this.apiService = apiService;
        this.priceCache = new Map();
        // Initialize logger with fallback to prevent ReferenceError
        if (logger) {
            this.logger = logger;
        }
        else if (typeof window !== 'undefined' && window.LoggerService) {
            this.logger = new window.LoggerService();
        }
        else {
            // Fallback simple logger when LoggerService is not available
            this.logger = {
                info: (message, metadata = null) => {
                    const logMessage = metadata ? `${message} | ${JSON.stringify(metadata)}` : message;
                    console.log(`[INFO] ${logMessage}`);
                },
                warn: (message, metadata = null) => {
                    const logMessage = metadata ? `${message} | ${JSON.stringify(metadata)}` : message;
                    console.warn(`[WARN] ${logMessage}`);
                },
                error: (message, metadata = null) => {
                    const logMessage = metadata ? `${message} | ${JSON.stringify(metadata)}` : message;
                    console.error(`[ERROR] ${logMessage}`);
                }
            };
        }
    }
    /**
     * Calculate discount between seller and market prices
     * @param productData - The product data containing variant information
     * @param defaultVariantId - The default variant ID (for compatibility)
     * @returns Discount calculation result
     */
    async calculateSellerDiscount(productData, defaultVariantId) {
        const productId = defaultVariantId; // For logging compatibility
        // Early validation with improved error handling
        if (!productData) {
            this.logger.error('Product data is missing', { productId });
            return { discount: 0, sellerPrice: 0, marketPrice: 0 };
        }
        if (!productData.product) {
            this.logger.error('Product object is missing from product data', { productId });
            return { discount: 0, sellerPrice: 0, marketPrice: 0 };
        }
        if (!productData.product.default_variant) {
            this.logger.error('Default variant is missing from product', { productId });
            return { discount: 0, sellerPrice: 0, marketPrice: 0 };
        }
        try {
            const product = productData.product;
            const defaultVariant = product.default_variant;
            this.logger.info('Starting seller discount calculation', { productId });
            // Get seller price (our price)
            const sellerPrice = this.extractPrice(defaultVariant.price);
            // Get market price (competitor price)
            let marketPrice = 0;
            if (defaultVariant.shipping_methods && defaultVariant.shipping_methods.length > 0) {
                const shippingMethod = defaultVariant.shipping_methods[0];
                if (shippingMethod.price) {
                    marketPrice = this.extractPrice(shippingMethod.price);
                }
            }
            // If no market price found, try alternative sources
            if (marketPrice === 0 && product.variants) {
                const otherVariants = product.variants.filter(v => v.id !== defaultVariant.id);
                for (const variant of otherVariants) {
                    const variantPrice = this.extractPrice(variant.price);
                    if (variantPrice > sellerPrice) {
                        marketPrice = variantPrice;
                        break;
                    }
                }
            }
            // Calculate discount percentage
            let discountPercent = 0;
            if (marketPrice > 0 && sellerPrice > 0 && marketPrice > sellerPrice) {
                discountPercent = Math.round(((marketPrice - sellerPrice) / marketPrice) * 100);
            }
            const result = {
                discount: discountPercent,
                sellerPrice: sellerPrice,
                marketPrice: marketPrice
            };
            this.logger.info('Seller discount calculation completed', {
                productId,
                details: { discount: discountPercent, sellerPrice, marketPrice }
            });
            this.eventBus.emit('price:discount-calculated', { productId, result });
            return result;
        }
        catch (error) {
            this.logger.error('Error calculating seller discount', { productId, error });
            this.eventBus.emit('price:calculation-error', { productId, error });
            return { discount: 0, sellerPrice: 0, marketPrice: 0 };
        }
    }
    /**
     * Extract monthly low price from product data
     * @param productData - The product data containing price history
     * @param productId - The product identifier for logging
     * @returns Monthly low price or 0 if not found
     */
    extractMonthlyLowPrice(productData, productId) {
        var _a, _b, _c;
        try {
            if (!productData || !productData.product) {
                this.logger.warn('Invalid product data for monthly low price extraction', { productId });
                return 0;
            }
            const product = productData.product;
            // Check for price history in various locations
            const possibleSources = [
                product.price_history,
                product.monthly_price_history,
                (_a = product.default_variant) === null || _a === void 0 ? void 0 : _a.price_history,
                (_b = product.statistics) === null || _b === void 0 ? void 0 : _b.price_trend
            ];
            for (const source of possibleSources) {
                if (source && Array.isArray(source) && source.length > 0) {
                    // Find minimum price in the last 30 days
                    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
                    const recentPrices = source.filter((entry) => {
                        const entryDate = new Date(entry.date || entry.timestamp || 0).getTime();
                        return entryDate >= thirtyDaysAgo;
                    });
                    if (recentPrices.length > 0) {
                        const minPrice = Math.min(...recentPrices.map((entry) => this.extractPrice(entry.price || entry.value || 0)));
                        if (minPrice > 0) {
                            this.logger.info('Monthly low price found', { productId, details: { price: minPrice } });
                            this.eventBus.emit('price:monthly-low-found', { productId, price: minPrice });
                            return minPrice;
                        }
                    }
                }
            }
            // Fallback: use current price as monthly low
            const currentPrice = this.extractPrice((_c = product.default_variant) === null || _c === void 0 ? void 0 : _c.price);
            if (currentPrice > 0) {
                return currentPrice;
            }
            return 0;
        }
        catch (error) {
            this.logger.error('Error extracting monthly low price', { productId, error });
            return 0;
        }
    }
    /**
     * Extract and sort product variants by price
     * @param productData - The product data containing variants
     * @returns Array of processed and sorted variants
     */
    extractAndSortVariants(productData) {
        try {
            if (!productData || !productData.product || !productData.product.variants) {
                this.logger.warn('Invalid product data or missing variants for variant extraction');
                return [];
            }
            const variants = productData.product.variants
                .map((variant) => {
                var _a;
                return ({
                    id: variant.id,
                    display_name: ((_a = variant.selector_type) === null || _a === void 0 ? void 0 : _a.display_name) || `نوع ${variant.id}`,
                    price_value: this.extractPrice(variant.price),
                    is_available: variant.is_available || false
                });
            })
                .filter((variant) => variant.price_value > 0)
                .sort((a, b) => a.price_value - b.price_value);
            this.logger.info('Successfully extracted and sorted variants', { details: { variantCount: variants.length } });
            return variants;
        }
        catch (error) {
            this.logger.error('Error extracting and sorting variants', { error });
            return [];
        }
    }
    /**
     * Extract numerical price from various price data formats
     * @param priceData - Price data in various formats
     * @returns Extracted price as number or 0 if invalid
     */
    extractPrice(priceData) {
        if (!priceData)
            return 0;
        if (typeof priceData === 'number') {
            return priceData;
        }
        if (typeof priceData === 'string') {
            const numericValue = parseFloat(priceData.replace(/[^\d.]/g, ''));
            return isNaN(numericValue) ? 0 : numericValue;
        }
        if (typeof priceData === 'object') {
            const possibleFields = ['selling_price', 'price', 'amount', 'value', 'rrp_price'];
            for (const field of possibleFields) {
                const fieldValue = priceData[field];
                if (fieldValue && typeof fieldValue === 'number') {
                    return fieldValue;
                }
            }
        }
        return 0;
    }
    /**
     * Format price from Rials to Tomans with Persian locale
     * @param priceInRials - Price in Rials
     * @returns Formatted price string in Tomans
     */
    formatPrice(priceInRials) {
        if (!priceInRials || priceInRials <= 0)
            return '';
        // Convert Rials to Tomans by dividing by 10
        const priceInTomans = Math.round(priceInRials / 10);
        return priceInTomans.toLocaleString('fa-IR') + ' تومان';
    }
    /**
     * Compare variant prices and calculate savings
     * @param variants - Array of processed variants
     * @returns Comparison result or null if insufficient variants
     */
    compareVariantPrices(variants) {
        if (!variants || variants.length <= 1) {
            return null;
        }
        const sortedVariants = [...variants].sort((a, b) => a.price_value - b.price_value);
        const cheapest = sortedVariants[0];
        const mostExpensive = sortedVariants[sortedVariants.length - 1];
        const savings = mostExpensive.price_value - cheapest.price_value;
        const savingsPercent = Math.round((savings / mostExpensive.price_value) * 100);
        return {
            cheapest,
            mostExpensive,
            savings,
            savingsPercent,
            variantCount: variants.length
        };
    }
    /**
     * Cache price data for a product
     * @param productId - Product identifier
     * @param priceData - Price data to cache
     */
    cachePrice(productId, priceData) {
        this.priceCache.set(productId, {
            data: priceData,
            timestamp: Date.now()
        });
    }
    /**
     * Get cached price data if still valid
     * @param productId - Product identifier
     * @param maxAge - Maximum age in milliseconds (default: 5 minutes)
     * @returns Cached data or null if expired/not found
     */
    getCachedPrice(productId, maxAge = 300000) {
        const cached = this.priceCache.get(productId);
        if (cached && (Date.now() - cached.timestamp) < maxAge) {
            return cached.data;
        }
        return null;
    }
    /**
     * Clear the price cache
     */
    clearPriceCache() {
        this.priceCache.clear();
        this.logger.info('Price cache cleared');
    }
}
// Make available globally for browser environment compatibility
if (typeof window !== 'undefined') {
    window.PriceService = PriceService;
}
