/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-18
 * Smart Cart Test - Simple test file for Smart Cart functionality
 */

// Simple test functions for Smart Cart
function testSmartCartFunctionality() {
  console.log('🧪 Testing Smart Cart functionality...');

  // Test 1: Check if Smart Cart Manager is available
  if (typeof SmartCartManager === 'undefined') {
    console.error('❌ SmartCartManager not available');
    return false;
  }

  // Test 2: Check if Smart Cart Button is available
  if (typeof SmartCartButton === 'undefined') {
    console.error('❌ SmartCartButton not available');
    return false;
  }

  console.log('✅ Smart Cart classes are available');

  // Test 3: Try to create instances (with mock services)
  try {
    const mockEventBus = {
      on: () => {},
      off: () => {},
      emit: () => {}
    };

    const mockStorageService = {
      get: async () => [],
      set: async () => true,
      getSetting: () => true
    };

    const smartCartManager = new SmartCartManager(mockEventBus, mockStorageService);
    console.log('✅ SmartCartManager instance created');

    const smartCartButton = new SmartCartButton(mockEventBus, smartCartManager);
    console.log('✅ SmartCartButton instance created');

  } catch (error) {
    console.error('❌ Error creating Smart Cart instances:', error);
    return false;
  }

  console.log('🎉 All Smart Cart tests passed!');
  return true;
}

// Test Smart Cart on product pages
function testSmartCartOnProductPage() {
  console.log('🧪 Testing Smart Cart on product page...');

  // Check if we're on a product page
  const isProductPage = window.location.href.includes('/product/') ||
                       document.querySelector('[data-testid="buy-box"]') ||
                       document.querySelector('.product-buy-box');

  if (!isProductPage) {
    console.log('ℹ️ Not a product page, skipping product-specific tests');
    return true;
  }

  // Test product information extraction
  const testProductInfo = {
    productId: '12345',
    productTitle: 'تست محصول',
    productUrl: window.location.href,
    productImage: 'https://example.com/image.jpg',
    currentPrice: 1000000
  };

  // Test variant detection
  console.log('🔍 Testing variant detection...');
  const variantElements = document.querySelectorAll('.variant-selector, [data-testid="variant-selector"]');
  console.log(`Found ${variantElements.length} potential variant elements`);

  console.log('✅ Product page tests completed');
  return true;
}

// Run tests when called
if (typeof window !== 'undefined') {
  window.testSmartCart = {
    testSmartCartFunctionality,
    testSmartCartOnProductPage,
    runAllTests: () => {
      const test1 = testSmartCartFunctionality();
      const test2 = testSmartCartOnProductPage();
      return test1 && test2;
    }
  };

  console.log('🧪 Smart Cart tests available. Run window.testSmartCart.runAllTests() to test.');
}