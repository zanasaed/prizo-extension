/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Browser Compat Utils - Cross-browser compatibility utilities
 */
class BrowserCompatUtils {
  static getBrowserInfo() {
    const userAgent = navigator.userAgent;
    const isChrome = /Chrome/.test(userAgent) && /Google Inc/.test(navigator.vendor);
    const isFirefox = /Firefox/.test(userAgent);
    const isEdge = /Edg/.test(userAgent);
    const isSafari = /Safari/.test(userAgent) && /Apple Computer/.test(navigator.vendor);
    
    return {
      isChrome,
      isFirefox,
      isEdge,
      isSafari,
      userAgent,
      vendor: navigator.vendor
    };
  }

  static supportsExtensionAPI() {
    return typeof chrome !== 'undefined' && 
           chrome.runtime && 
           chrome.runtime.id;
  }

  static supportsStorageAPI() {
    return typeof chrome !== 'undefined' && 
           chrome.storage && 
           chrome.storage.local;
  }

  static async safeStorageGet(keys, defaultValue = {}) {
    try {
      if (!this.supportsStorageAPI()) {
        console.warn('Storage API not available');
        return defaultValue;
      }

      return await new Promise((resolve, reject) => {
        chrome.storage.local.get(keys, (result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(result);
          }
        });
      });
    } catch (error) {
      console.error('Storage get error:', error);
      return defaultValue;
    }
  }

  static async safeStorageSet(items) {
    try {
      if (!this.supportsStorageAPI()) {
        console.warn('Storage API not available');
        return false;
      }

      return await new Promise((resolve, reject) => {
        chrome.storage.local.set(items, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(true);
          }
        });
      });
    } catch (error) {
      console.error('Storage set error:', error);
      return false;
    }
  }

  static async safeStorageRemove(keys) {
    try {
      if (!this.supportsStorageAPI()) {
        console.warn('Storage API not available');
        return false;
      }

      return await new Promise((resolve, reject) => {
        chrome.storage.local.remove(keys, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(true);
          }
        });
      });
    } catch (error) {
      console.error('Storage remove error:', error);
      return false;
    }
  }

  static getManifestVersion() {
    try {
      if (this.supportsExtensionAPI()) {
        return chrome.runtime.getManifest().manifest_version;
      }
      return null;
    } catch (error) {
      console.warn('Could not get manifest version:', error);
      return null;
    }
  }

  static isManifestV3() {
    return this.getManifestVersion() === 3;
  }

  static supportsServiceWorker() {
    return 'serviceWorker' in navigator;
  }

  static supportsFetch() {
    return typeof fetch !== 'undefined';
  }

  static supportsPromises() {
    return typeof Promise !== 'undefined';
  }

  static supportsAsyncAwait() {
    try {
      eval('async function test() { await Promise.resolve(); }');
      return true;
    } catch (error) {
      return false;
    }
  }

  static supportsES6() {
    try {
      eval('const test = () => {}; class Test {}');
      return true;
    } catch (error) {
      return false;
    }
  }

  static supportsIntersectionObserver() {
    return 'IntersectionObserver' in window;
  }

  static supportsMutationObserver() {
    return 'MutationObserver' in window;
  }

  static supportsResizeObserver() {
    return 'ResizeObserver' in window;
  }

  static supportsWebComponents() {
    return 'customElements' in window;
  }

  static supportsLocalStorage() {
    try {
      const testKey = '__test__';
      localStorage.setItem(testKey, 'test');
      localStorage.removeItem(testKey);
      return true;
    } catch (error) {
      return false;
    }
  }

  static supportsSessionStorage() {
    try {
      const testKey = '__test__';
      sessionStorage.setItem(testKey, 'test');
      sessionStorage.removeItem(testKey);
      return true;
    } catch (error) {
      return false;
    }
  }

  static supportsIndexedDB() {
    return 'indexedDB' in window;
  }

  static createCompatibleFetch() {
    if (this.supportsFetch()) {
      return window.fetch.bind(window);
    }

    // Fallback for older browsers
    return function(url, options = {}) {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open(options.method || 'GET', url);

        if (options.headers) {
          Object.entries(options.headers).forEach(([key, value]) => {
            xhr.setRequestHeader(key, value);
          });
        }

        xhr.onload = function() {
          const response = {
            ok: xhr.status >= 200 && xhr.status < 300,
            status: xhr.status,
            statusText: xhr.statusText,
            json: () => Promise.resolve(JSON.parse(xhr.responseText)),
            text: () => Promise.resolve(xhr.responseText)
          };
          resolve(response);
        };

        xhr.onerror = () => reject(new Error('Network error'));
        xhr.ontimeout = () => reject(new Error('Request timeout'));

        if (options.timeout) {
          xhr.timeout = options.timeout;
        }

        xhr.send(options.body);
      });
    };
  }

  static createCompatiblePromise() {
    if (this.supportsPromises()) {
      return Promise;
    }

    // Simple Promise polyfill for very old browsers
    return class SimplePromise {
      constructor(executor) {
        this.state = 'pending';
        this.value = undefined;
        this.handlers = [];

        const resolve = (value) => {
          if (this.state === 'pending') {
            this.state = 'fulfilled';
            this.value = value;
            this.handlers.forEach(handler => handler.onFulfilled(value));
          }
        };

        const reject = (reason) => {
          if (this.state === 'pending') {
            this.state = 'rejected';
            this.value = reason;
            this.handlers.forEach(handler => handler.onRejected(reason));
          }
        };

        try {
          executor(resolve, reject);
        } catch (error) {
          reject(error);
        }
      }

      then(onFulfilled, onRejected) {
        return new SimplePromise((resolve, reject) => {
          const handler = {
            onFulfilled: (value) => {
              try {
                const result = onFulfilled ? onFulfilled(value) : value;
                resolve(result);
              } catch (error) {
                reject(error);
              }
            },
            onRejected: (reason) => {
              try {
                const result = onRejected ? onRejected(reason) : reason;
                reject(result);
              } catch (error) {
                reject(error);
              }
            }
          };

          if (this.state === 'fulfilled') {
            handler.onFulfilled(this.value);
          } else if (this.state === 'rejected') {
            handler.onRejected(this.value);
          } else {
            this.handlers.push(handler);
          }
        });
      }

      catch(onRejected) {
        return this.then(null, onRejected);
      }

      static resolve(value) {
        return new SimplePromise(resolve => resolve(value));
      }

      static reject(reason) {
        return new SimplePromise((resolve, reject) => reject(reason));
      }
    };
  }

  static addEventListenerCompat(element, event, handler, options) {
    if (element.addEventListener) {
      element.addEventListener(event, handler, options);
    } else if (element.attachEvent) {
      // IE8 and below
      element.attachEvent('on' + event, handler);
    } else {
      element['on' + event] = handler;
    }
  }

  static removeEventListenerCompat(element, event, handler, options) {
    if (element.removeEventListener) {
      element.removeEventListener(event, handler, options);
    } else if (element.detachEvent) {
      // IE8 and below
      element.detachEvent('on' + event, handler);
    } else {
      element['on' + event] = null;
    }
  }

  static getCompatibleAnimationFrame() {
    return window.requestAnimationFrame ||
           window.webkitRequestAnimationFrame ||
           window.mozRequestAnimationFrame ||
           window.oRequestAnimationFrame ||
           window.msRequestAnimationFrame ||
           function(callback) {
             window.setTimeout(callback, 1000 / 60);
           };
  }

  static async safeSendMessage(message) {
    try {
      if (!this.supportsExtensionAPI()) {
        throw new Error('Extension messaging not supported');
      }

      return await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(response);
          }
        });
      });
    } catch (error) {
      console.error('Messaging error:', error);
      throw new Error('Messaging API unavailable');
    }
  }

  static logCompatibilityReport() {
    const report = {
      browser: this.getBrowserInfo(),
      extensionAPI: this.supportsExtensionAPI(),
      storageAPI: this.supportsStorageAPI(),
      manifestVersion: this.getManifestVersion(),
      fetch: this.supportsFetch(),
      promises: this.supportsPromises(),
      asyncAwait: this.supportsAsyncAwait(),
      es6: this.supportsES6(),
      intersectionObserver: this.supportsIntersectionObserver(),
      mutationObserver: this.supportsMutationObserver(),
      localStorage: this.supportsLocalStorage(),
      serviceWorker: this.supportsServiceWorker()
    };

    console.log('🔧 Browser Compatibility Report:', report);
    return report;
  }

  static isCompatible() {
    const required = [
      this.supportsExtensionAPI(),
      this.supportsES6(),
      this.supportsFetch(),
      this.supportsPromises()
    ];

    return required.every(Boolean);
  }
}

window.BrowserCompatUtils = BrowserCompatUtils;