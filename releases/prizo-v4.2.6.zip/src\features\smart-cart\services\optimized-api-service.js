/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-18
 * Optimized API Service for Smart Cart - Handles API requests with advanced optimization
 */
class OptimizedAPIService {
  constructor(eventBus, cacheService) {
    this.eventBus = eventBus;
    this.cacheService = cacheService;

    // Request deduplication
    this.pendingRequests = new Map();
    this.requestQueue = [];
    this.isProcessingQueue = false;

    // Rate limiting configuration
    this.rateLimiter = {
      requests: [],
      maxRequests: 10, // Max 10 requests per window
      windowMs: 30000, // 30 seconds window
      currentWindow: Date.now()
    };

    // Batch processing
    this.batchQueue = [];
    this.batchSize = 5;
    this.batchTimeout = 1000; // Process batch after 1 second
    this.batchTimer = null;

    // Request prioritization
    this.priorityQueues = {
      high: [],
      normal: [],
      low: []
    };

    // Statistics
    this.stats = {
      totalRequests: 0,
      cacheHits: 0,
      cacheMisses: 0,
      batchRequests: 0,
      duplicatePrevented: 0,
      rateLimited: 0
    };
  }

  async fetchProductData(productId, options = {}) {
    const {
      includeVariant = false,
      variantId = null,
      priority = 'normal',
      skipCache = false,
      freshData = false,
      timeout = 8000
    } = options;

    this.stats.totalRequests++;

    // Check cache first (unless skipCache or freshData is true)
    if (!skipCache && !freshData) {
      const cachedData = await this.cacheService.get(productId, variantId, includeVariant);
      if (cachedData) {
        this.stats.cacheHits++;
        console.log(`📋 Cache hit for product ${productId}`);
        return {
          success: true,
          data: cachedData,
          source: 'cache',
          fromCache: true
        };
      }
    }

    this.stats.cacheMisses++;

    // Check for pending requests (deduplication)
    const requestKey = this.generateRequestKey(productId, variantId, includeVariant);
    const pendingRequest = this.pendingRequests.get(requestKey);

    if (pendingRequest) {
      this.stats.duplicatePrevented++;
      console.log(`🔄 Reusing pending request for product ${productId}`);
      return await pendingRequest;
    }

    // Create new request with all optimizations
    const requestPromise = this.executeOptimizedRequest(productId, {
      ...options,
      requestKey,
      includeVariant,
      variantId,
      timeout
    });

    this.pendingRequests.set(requestKey, requestPromise);

    try {
      const result = await requestPromise;

      // Cache successful results (unless it's fresh data and we want to replace cache)
      if (result.success && result.data) {
        const cacheOptions = {
          includeVariant,
          variantId,
          ttl: freshData ? this.cacheService.defaultTTL : undefined,
          priority: priority === 'high' ? 'high' : 'normal'
        };

        await this.cacheService.set(productId, result.data, cacheOptions);
      }

      return result;
    } finally {
      this.pendingRequests.delete(requestKey);
    }
  }

  async executeOptimizedRequest(productId, options) {
    const { priority, timeout, requestKey } = options;

    // Apply rate limiting
    await this.waitForRateLimit();

    // Add request to appropriate priority queue
    const requestInfo = {
      productId,
      options,
      timestamp: Date.now(),
      resolve: null,
      reject: null
    };

    const requestPromise = new Promise((resolve, reject) => {
      requestInfo.resolve = resolve;
      requestInfo.reject = reject;
    });

    this.priorityQueues[priority].push(requestInfo);
    this.processRequestQueue();

    return requestPromise;
  }

  async processRequestQueue() {
    if (this.isProcessingQueue) return;

    this.isProcessingQueue = true;

    try {
      // Process requests by priority: high -> normal -> low
      const priorities = ['high', 'normal', 'low'];

      for (const priority of priorities) {
        while (this.priorityQueues[priority].length > 0) {
          const request = this.priorityQueues[priority].shift();

          try {
            const result = await this.performActualRequest(request.productId, request.options);
            request.resolve(result);
          } catch (error) {
            request.reject(error);
          }

          // Add small delay between requests to be nice to the API
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
    } finally {
      this.isProcessingQueue = false;
    }
  }

  async performActualRequest(productId, options) {
    try {
      console.log(`📡 Fetching fresh data for product: ${productId}`);

      // Use existing API service infrastructure
      const response = await ExtensionCore.BrowserCompat.safeSendMessage({
        action: 'fetchProductData',
        productId: productId,
        pageType: options.pageType || 'product',
        timeout: options.timeout || 8000,
        currentUrl: window.location?.href || options.currentUrl,
        priority: options.priority,
        timestamp: Date.now()
      });

      if (response && response.success) {
        console.log(`✅ Successfully fetched product data for ${productId}`);
        return {
          success: true,
          data: response.data.product || response.data,
          source: 'api',
          fromCache: false,
          timestamp: Date.now()
        };
      } else {
        const errorMsg = response?.error || 'Failed to fetch product data';
        console.log(`❌ API call failed for ${productId}:`, errorMsg);
        throw new Error(errorMsg);
      }
    } catch (error) {
      console.error(`❌ Failed to fetch product data for ${productId}:`, error);
      throw error;
    }
  }

  async waitForRateLimit() {
    const now = Date.now();

    // Clean old requests outside the current window
    if (now - this.rateLimiter.currentWindow >= this.rateLimiter.windowMs) {
      this.rateLimiter.requests = [];
      this.rateLimiter.currentWindow = now;
    }

    // Remove requests older than the window
    this.rateLimiter.requests = this.rateLimiter.requests.filter(
      timestamp => now - timestamp < this.rateLimiter.windowMs
    );

    // Check if we need to wait
    if (this.rateLimiter.requests.length >= this.rateLimiter.maxRequests) {
      const oldestRequest = Math.min(...this.rateLimiter.requests);
      const waitTime = this.rateLimiter.windowMs - (now - oldestRequest) + 100; // +100ms buffer

      if (waitTime > 0) {
        this.stats.rateLimited++;
        console.log(`⏳ Rate limiting: waiting ${waitTime}ms`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
      }
    }

    // Add current request to the limiter
    this.rateLimiter.requests.push(now);
  }

  // Batch request functionality
  async fetchMultipleProducts(productRequests, options = {}) {
    const { priority = 'normal', freshData = false } = options;

    // Check cache for all products first
    const results = {};
    const uncachedRequests = [];

    for (const request of productRequests) {
      const { productId, variantId, includeVariant } = request;

      if (!freshData) {
        const cachedData = await this.cacheService.get(productId, variantId, includeVariant);
        if (cachedData) {
          results[productId] = {
            success: true,
            data: cachedData,
            source: 'cache',
            fromCache: true
          };
          this.stats.cacheHits++;
          continue;
        }
      }

      uncachedRequests.push(request);
      this.stats.cacheMisses++;
    }

    if (uncachedRequests.length === 0) {
      console.log('✅ All products found in cache');
      return results;
    }

    console.log(`🔄 Fetching ${uncachedRequests.length} products not in cache`);

    // Process uncached requests in batches
    const batchResults = await this.processBatchRequests(uncachedRequests, { priority });

    // Merge batch results
    for (const [productId, result] of Object.entries(batchResults)) {
      results[productId] = result;
    }

    return results;
  }

  async processBatchRequests(requests, options = {}) {
    const { priority = 'normal' } = options;
    const results = {};

    // Split into smaller batches to avoid overwhelming the API
    const batches = this.chunkArray(requests, this.batchSize);

    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      const batchPromises = batch.map(request =>
        this.fetchProductData(request.productId, {
          ...request,
          priority,
          skipCache: false // We already checked cache
        })
      );

      const batchResults = await Promise.allSettled(batchPromises);

      // Process batch results
      batchResults.forEach((result, index) => {
        const request = batch[index];
        if (result.status === 'fulfilled') {
          results[request.productId] = result.value;
        } else {
          results[request.productId] = {
            success: false,
            error: result.reason.message,
            fromCache: false
          };
        }
      });

      // Add delay between batches to be respectful to the API
      if (i < batches.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    this.stats.batchRequests++;
    return results;
  }

  // Utility methods
  generateRequestKey(productId, variantId, includeVariant) {
    return `${productId}_${includeVariant ? `variant_${variantId}` : 'default'}`;
  }

  chunkArray(array, chunkSize) {
    const chunks = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  }

  // Refresh a specific product's data
  async refreshProductData(productId, options = {}) {
    console.log(`🔄 Refreshing data for product ${productId}`);

    // Remove from cache first to force fresh fetch
    this.cacheService.delete(productId, options.variantId, options.includeVariant);

    return await this.fetchProductData(productId, {
      ...options,
      freshData: true,
      priority: 'high'
    });
  }

  // Preload products that are likely to be needed
  async preloadProducts(productIds, options = {}) {
    console.log(`🚀 Preloading ${productIds.length} products...`);

    const requests = productIds.map(productId => ({ productId }));
    const results = await this.fetchMultipleProducts(requests, {
      ...options,
      priority: 'low' // Low priority for preloading
    });

    const successCount = Object.values(results).filter(r => r.success).length;
    console.log(`✅ Preloaded ${successCount}/${productIds.length} products`);

    return results;
  }

  // Get service statistics
  getStats() {
    return {
      ...this.stats,
      cacheHitRate: this.stats.totalRequests > 0
        ? ((this.stats.cacheHits / this.stats.totalRequests) * 100).toFixed(2) + '%'
        : '0%',
      pendingRequests: this.pendingRequests.size,
      queueSizes: {
        high: this.priorityQueues.high.length,
        normal: this.priorityQueues.normal.length,
        low: this.priorityQueues.low.length
      }
    };
  }

  // Clear all pending requests and queues
  clearPendingRequests() {
    this.pendingRequests.clear();
    this.priorityQueues.high = [];
    this.priorityQueues.normal = [];
    this.priorityQueues.low = [];
    console.log('🧹 Cleared all pending requests and queues');
  }

  destroy() {
    this.clearPendingRequests();
    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
    }
    console.log('🧹 Optimized API Service destroyed');
  }
}

window.OptimizedAPIService = OptimizedAPIService;