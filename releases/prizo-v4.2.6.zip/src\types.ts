/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-28
 * Type definitions for the Digikala Price Helper extension
 */

/**
 * Interface for price-related data structures
 */
export interface PriceData {
  selling_price?: number;
  price?: number;
  amount?: number;
  value?: number;
  rrp_price?: number;
  [key: string]: any;
}

/**
 * Interface for price history entries
 */
export interface PriceHistoryEntry {
  date?: string;
  timestamp?: string;
  price?: number | PriceData;
  value?: number;
}

/**
 * Interface for shipping method information
 */
export interface ShippingMethod {
  price?: number | PriceData;
  [key: string]: any;
}

/**
 * Interface for selector type information
 */
export interface SelectorType {
  display_name?: string;
  [key: string]: any;
}

/**
 * Interface for product variant data
 */
export interface Variant {
  id: number;
  price: number | PriceData;
  is_available?: boolean;
  selector_type?: SelectorType;
  shipping_methods?: ShippingMethod[];
  price_history?: PriceHistoryEntry[];
  [key: string]: any;
}

/**
 * Interface for processed variant information
 */
export interface ProcessedVariant {
  id: number;
  display_name: string;
  price_value: number;
  is_available: boolean;
}

/**
 * Interface for product statistics
 */
export interface ProductStatistics {
  price_trend?: PriceHistoryEntry[];
  [key: string]: any;
}

/**
 * Interface for the main product object
 */
export interface Product {
  default_variant: Variant;
  variants?: Variant[];
  price_history?: PriceHistoryEntry[];
  monthly_price_history?: PriceHistoryEntry[];
  statistics?: ProductStatistics;
  [key: string]: any;
}

/**
 * Interface for the complete product data structure
 */
export interface ProductData {
  product: Product;
  [key: string]: any;
}

/**
 * Interface for discount calculation results
 */
export interface DiscountResult {
  discount: number;
  sellerPrice: number;
  marketPrice: number;
}

/**
 * Interface for variant comparison results
 */
export interface VariantComparison {
  cheapest: ProcessedVariant;
  mostExpensive: ProcessedVariant;
  savings: number;
  savingsPercent: number;
  variantCount: number;
}

/**
 * Interface for cached price data
 */
export interface CachedPriceData {
  data: any;
  timestamp: number;
}

/**
 * Interface for simple logger fallback
 */
export interface SimpleLogger {
  info: (message: string, metadata?: any) => void;
  warn: (message: string, metadata?: any) => void;
  error: (message: string, metadata?: any) => void;
}

/**
 * Interface for watchlist conditions
 */
export interface WatchConditions {
  priceThreshold?: number; // Price at or below which to notify (in Rials)
  minDiscountPercent?: number; // Minimum discount percentage threshold
  notifyOnLowest30Days?: boolean; // Notify when price approaches lowest in 30 days
}

/**
 * Interface for watchlist entry
 */
export interface WatchlistEntry {
  id: string; // Unique identifier for the watchlist entry
  productId: string; // Product ID
  variantId?: number; // Optional variant ID if watching specific variant
  productTitle: string; // Product title for display
  productUrl?: string; // Product URL
  conditions: WatchConditions; // Watch conditions
  currentPrice?: number; // Current price when added (in Rials)
  createdAt: number; // Timestamp when added
  lastChecked?: number; // Last time conditions were checked
  isActive: boolean; // Whether this watch is active
}

/**
 * Interface for watchlist storage structure
 */
export interface WatchlistStorage {
  watchlist: WatchlistEntry[];
  lastUpdated: number;
}