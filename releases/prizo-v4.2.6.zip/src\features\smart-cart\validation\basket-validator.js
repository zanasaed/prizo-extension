/**
 * @Author: Smart Cart System
 * @Date: 2025-01-18
 * Basket Validator - Validates input data and solutions
 */

class BasketValidator {
  constructor() {
    this.maxProducts = 50; // Safety limit
    this.maxSellersPerProduct = 20; // Safety limit
  }

  /**
   * Validate input basket data
   * @param {Object} basketData - Input data to validate
   * @returns {Object} Validation result with errors if any
   */
  validateInput(basketData) {
    const errors = [];

    try {
      // Check required fields
      if (!basketData) {
        errors.push('Basket data is required');
        return { isValid: false, errors };
      }

      // Validate products array
      const productsValidation = this.validateProducts(basketData.products);
      if (!productsValidation.isValid) {
        errors.push(...productsValidation.errors);
      }

      // Validate sellers object
      const sellersValidation = this.validateSellers(basketData.sellers);
      if (!sellersValidation.isValid) {
        errors.push(...sellersValidation.errors);
      }

      // Validate optimization mode
      const optimizationValidation = this.validateOptimizationMode(basketData.optimizationMode, basketData.maxSellers);
      if (!optimizationValidation.isValid) {
        errors.push(...optimizationValidation.errors);
      }

      // Validate marketplace shipping
      const marketplaceValidation = this.validateMarketplaceShipping(basketData.marketplaceShipping);
      if (!marketplaceValidation.isValid) {
        errors.push(...marketplaceValidation.errors);
      }

      // Cross-validation: ensure all referenced sellers exist
      const crossValidation = this.validateSellerReferences(basketData.products, basketData.sellers);
      if (!crossValidation.isValid) {
        errors.push(...crossValidation.errors);
      }

      // Safety limits
      const limitsValidation = this.validateLimits(basketData);
      if (!limitsValidation.isValid) {
        errors.push(...limitsValidation.errors);
      }

    } catch (error) {
      errors.push(`Validation error: ${error.message}`);
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings: this.generateWarnings(basketData)
    };
  }

  /**
   * Validate products array
   */
  validateProducts(products) {
    const errors = [];

    if (!Array.isArray(products)) {
      errors.push('Products must be an array');
      return { isValid: false, errors };
    }

    if (products.length === 0) {
      errors.push('At least one product is required');
      return { isValid: false, errors };
    }

    const productIds = new Set();

    for (let i = 0; i < products.length; i++) {
      const product = products[i];
      const productPrefix = `Product ${i + 1}`;

      // Required fields
      if (!product.id) {
        errors.push(`${productPrefix}: id is required`);
      } else if (productIds.has(product.id)) {
        errors.push(`${productPrefix}: duplicate product ID '${product.id}'`);
      } else {
        productIds.add(product.id);
      }

      // Sellers array
      if (!Array.isArray(product.sellers)) {
        errors.push(`${productPrefix}: sellers must be an array`);
      } else {
        const sellerValidation = this.validateProductSellers(product.sellers, productPrefix);
        if (!sellerValidation.isValid) {
          errors.push(...sellerValidation.errors);
        }
      }

      // Preferred seller (optional)
      if (product.preferredSeller !== undefined) {
        if (typeof product.preferredSeller !== 'string' || product.preferredSeller.trim() === '') {
          errors.push(`${productPrefix}: preferredSeller must be a non-empty string if specified`);
        }
      }
    }

    return { isValid: errors.length === 0, errors };
  }

  /**
   * Validate sellers for a specific product
   */
  validateProductSellers(sellers, productPrefix) {
    const errors = [];

    if (sellers.length === 0) {
      errors.push(`${productPrefix}: at least one seller is required`);
      return { isValid: false, errors };
    }

    const sellerIds = new Set();

    for (let j = 0; j < sellers.length; j++) {
      const seller = sellers[j];
      const sellerPrefix = `${productPrefix}, Seller ${j + 1}`;

      // Required fields
      if (!seller.sellerId) {
        errors.push(`${sellerPrefix}: sellerId is required`);
      } else if (sellerIds.has(seller.sellerId)) {
        errors.push(`${sellerPrefix}: duplicate seller ID '${seller.sellerId}' for this product`);
      } else {
        sellerIds.add(seller.sellerId);
      }

      if (typeof seller.price !== 'number' || seller.price < 0) {
        errors.push(`${sellerPrefix}: price must be a non-negative number`);
      }

      if (typeof seller.inventory !== 'number' || seller.inventory < 0) {
        errors.push(`${sellerPrefix}: inventory must be a non-negative number`);
      }

      if (typeof seller.shipsDirectly !== 'boolean') {
        errors.push(`${sellerPrefix}: shipsDirectly must be a boolean`);
      }
    }

    return { isValid: errors.length === 0, errors };
  }

  /**
   * Validate sellers object
   */
  validateSellers(sellers) {
    const errors = [];

    if (!sellers || typeof sellers !== 'object') {
      errors.push('Sellers must be an object');
      return { isValid: false, errors };
    }

    const sellerIds = Object.keys(sellers);
    if (sellerIds.length === 0) {
      errors.push('At least one seller must be defined');
      return { isValid: false, errors };
    }

    for (const sellerId of sellerIds) {
      const seller = sellers[sellerId];
      const sellerPrefix = `Seller '${sellerId}'`;

      if (!seller || typeof seller !== 'object') {
        errors.push(`${sellerPrefix}: must be an object`);
        continue;
      }

      if (typeof seller.shippingCost !== 'number' || seller.shippingCost < 0) {
        errors.push(`${sellerPrefix}: shippingCost must be a non-negative number`);
      }
    }

    return { isValid: errors.length === 0, errors };
  }

  /**
   * Validate optimization mode and related parameters
   */
  validateOptimizationMode(mode, maxSellers) {
    const errors = [];
    const validModes = ['COST', 'SELLERS_FIRST', 'MAX_SELLERS'];

    if (!mode) {
      // Default mode is acceptable
      return { isValid: true, errors };
    }

    if (!validModes.includes(mode)) {
      errors.push(`Invalid optimization mode '${mode}'. Valid modes: ${validModes.join(', ')}`);
    }

    if (mode === 'MAX_SELLERS') {
      if (typeof maxSellers !== 'number' || maxSellers < 1) {
        errors.push('maxSellers must be a positive number when optimizationMode is MAX_SELLERS');
      }
    }

    return { isValid: errors.length === 0, errors };
  }

  /**
   * Validate marketplace shipping parameter
   */
  validateMarketplaceShipping(marketplaceShipping) {
    const errors = [];

    if (marketplaceShipping !== undefined) {
      if (typeof marketplaceShipping !== 'number' || marketplaceShipping < 0) {
        errors.push('marketplaceShipping must be a non-negative number if specified');
      }
    }

    return { isValid: errors.length === 0, errors };
  }

  /**
   * Cross-validate that all referenced sellers exist
   */
  validateSellerReferences(products, sellers) {
    const errors = [];
    const availableSellerIds = new Set(Object.keys(sellers));

    for (const product of products) {
      // Check sellers in product.sellers array
      for (const seller of product.sellers) {
        if (!availableSellerIds.has(seller.sellerId)) {
          errors.push(`Product '${product.id}' references unknown seller '${seller.sellerId}'`);
        }
      }

      // Check preferred seller
      if (product.preferredSeller && !availableSellerIds.has(product.preferredSeller)) {
        errors.push(`Product '${product.id}' has unknown preferred seller '${product.preferredSeller}'`);
      }
    }

    return { isValid: errors.length === 0, errors };
  }

  /**
   * Validate safety limits
   */
  validateLimits(basketData) {
    const errors = [];

    if (basketData.products.length > this.maxProducts) {
      errors.push(`Too many products (${basketData.products.length}). Maximum allowed: ${this.maxProducts}`);
    }

    for (const product of basketData.products) {
      if (product.sellers && product.sellers.length > this.maxSellersPerProduct) {
        errors.push(`Product '${product.id}' has too many sellers (${product.sellers.length}). Maximum allowed: ${this.maxSellersPerProduct}`);
      }
    }

    return { isValid: errors.length === 0, errors };
  }

  /**
   * Generate warnings for potential issues
   */
  generateWarnings(basketData) {
    const warnings = [];

    if (!basketData) return warnings;

    // Warn about products with very few sellers
    for (const product of basketData.products || []) {
      if (product.sellers && product.sellers.length === 1) {
        warnings.push(`Product '${product.id}' has only one seller - no optimization possible`);
      }
    }

    // Warn about preferred sellers that limit optimization
    const productsWithPreference = (basketData.products || []).filter(p => p.preferredSeller);
    if (productsWithPreference.length > 0) {
      warnings.push(`${productsWithPreference.length} products have preferred sellers - this may limit optimization`);
    }

    // Warn about large problem sizes
    if (basketData.products && basketData.products.length > 15) {
      warnings.push('Large problem size may result in heuristic (non-optimal) solutions');
    }

    return warnings;
  }

  /**
   * Validate a generated solution
   * @param {Object} solution - Generated solution to validate
   * @param {Object} originalData - Original input data
   * @returns {boolean} True if solution is valid
   */
  validateSolution(solution, originalData) {
    try {
      // Check required solution fields
      if (!solution || !solution.assignments || !Array.isArray(solution.assignments)) {
        console.error('❌ Solution missing assignments array');
        return false;
      }

      // Check that all products are assigned
      const assignedProducts = new Set(solution.assignments.map(a => a.productId));
      const requiredProducts = new Set(originalData.products.map(p => p.id));

      if (assignedProducts.size !== requiredProducts.size) {
        console.error('❌ Solution does not assign all products');
        return false;
      }

      for (const productId of requiredProducts) {
        if (!assignedProducts.has(productId)) {
          console.error(`❌ Product '${productId}' not assigned in solution`);
          return false;
        }
      }

      // Check that assignments are valid
      for (const assignment of solution.assignments) {
        if (!this.validateAssignment(assignment, originalData)) {
          return false;
        }
      }

      // Check cost calculations
      if (typeof solution.totalCost !== 'number' || solution.totalCost < 0) {
        console.error('❌ Invalid total cost in solution');
        return false;
      }

      // Check constraints
      if (!this.validateSolutionConstraints(solution, originalData)) {
        return false;
      }

      return true;

    } catch (error) {
      console.error('❌ Solution validation error:', error);
      return false;
    }
  }

  /**
   * Validate a single assignment
   */
  validateAssignment(assignment, originalData) {
    const product = originalData.products.find(p => p.id === assignment.productId);
    if (!product) {
      console.error(`❌ Assignment references unknown product '${assignment.productId}'`);
      return false;
    }

    const seller = product.sellers.find(s => s.sellerId === assignment.sellerId);
    if (!seller) {
      console.error(`❌ Assignment uses unavailable seller '${assignment.sellerId}' for product '${assignment.productId}'`);
      return false;
    }

    // Check preferred seller constraint
    if (product.preferredSeller && assignment.sellerId !== product.preferredSeller) {
      console.error(`❌ Assignment violates preferred seller constraint for product '${assignment.productId}'`);
      return false;
    }

    // Check inventory
    if (seller.inventory <= 0) {
      console.error(`❌ Assignment uses seller '${assignment.sellerId}' with no inventory for product '${assignment.productId}'`);
      return false;
    }

    return true;
  }

  /**
   * Validate solution constraints
   */
  validateSolutionConstraints(solution, originalData) {
    const sellersUsed = new Set(solution.assignments.map(a => a.sellerId));

    // Check max sellers constraint
    if (originalData.optimizationMode === 'MAX_SELLERS') {
      if (sellersUsed.size > originalData.maxSellers) {
        console.error(`❌ Solution uses ${sellersUsed.size} sellers, exceeds limit of ${originalData.maxSellers}`);
        return false;
      }
    }

    return true;
  }
}

// Browser extension compatibility
if (typeof window !== 'undefined') {
  window.BasketValidator = BasketValidator;
}