/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-16
 * Full-Page Service - Bridge between full-page UI and existing watchlist services
 */

class FullPageService {
  constructor() {
    this.watchlistCache = [];
    this.isInitialized = false;
    this.currentFilter = 'all';
    this.currentSearchQuery = '';

    // Bind methods
    this.handleStorageChange = this.handleStorageChange.bind(this);
    this.init();
  }

  async init() {
    try {
      console.log('🔄 Initializing Full-Page Service');

      // Listen for storage changes
      if (chrome && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener(this.handleStorageChange);
      }

      // Load initial data
      await this.loadWatchlistData();

      this.isInitialized = true;
      console.log('✅ Full-Page Service initialized');
    } catch (error) {
      console.error('❌ Failed to initialize Full-Page Service:', error);
    }
  }

  async loadWatchlistData() {
    try {
      console.log('📋 Loading watchlist data from storage');

      // Get data from Chrome storage using the same key as the existing system
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      this.watchlistCache = result.digikala_extension_watchlist || [];

      console.log(`📊 Loaded ${this.watchlistCache.length} watchlist items`);
      return this.watchlistCache;
    } catch (error) {
      console.error('❌ Error loading watchlist data:', error);
      this.watchlistCache = [];
      return [];
    }
  }

  /**
   * Get watchlist data (alias for loadWatchlistData for API consistency)
   */
  async getWatchlistData() {
    return await this.loadWatchlistData();
  }

  async getWatchlistStats() {
    await this.loadWatchlistData();

    const totalItems = this.watchlistCache.length;
    const activeItems = this.watchlistCache.filter(item => item.isActive).length;
    const alertsCount = this.getAlertsCount();
    const discountsCount = this.getDiscountsCount();

    return {
      totalItems,
      activeItems,
      alertsCount,
      discountsCount
    };
  }

  getAlertsCount() {
    // Count items that have price alerts or conditions that might trigger
    return this.watchlistCache.filter(item => {
      if (!item.isActive) return false;

      // Check if item has any alerting conditions
      const hasConditions = item.conditions && (
        item.conditions.priceThreshold ||
        item.conditions.minDiscountPercent ||
        item.conditions.notifyOnLowest30Days
      );

      return hasConditions;
    }).length;
  }

  getDiscountsCount() {
    // Count items that currently have discounts
    return this.watchlistCache.filter(item => this.hasDiscount(item)).length;
  }

  hasDiscount(item) {
    if (!item.isActive) return false;

    // Priority 1: Check explicit discount percentage from Digikala
    if (item.discountPercent && item.discountPercent > 0) {
      return true;
    }

    // Priority 2: Check if current price is lower than original price (most reliable)
    if (item.currentPrice && item.originalPrice &&
        item.currentPrice < item.originalPrice) {
      const discountPercent = ((item.originalPrice - item.currentPrice) / item.originalPrice) * 100;
      // Only consider it a discount if it's meaningful (>= 1%)
      if (discountPercent >= 1) {
        return true;
      }
    }

    // Priority 3: Check price drop from last known price
    if (item.currentPrice && item.lastKnownPrice &&
        item.currentPrice < item.lastKnownPrice) {
      const discountPercent = ((item.lastKnownPrice - item.currentPrice) / item.lastKnownPrice) * 100;
      // Only consider meaningful drops (>= 2% to avoid minor fluctuations)
      if (discountPercent >= 2) {
        return true;
      }
    }

    // Priority 4: Check price history for sustained drops
    if (item.priceHistory && item.priceHistory.length > 2) {
      const currentPrice = item.currentPrice || item.lastKnownPrice;
      if (currentPrice) {
        // Get historical high price (last 30 entries or available)
        const recentPrices = item.priceHistory.slice(-30).map(entry => entry.price || 0).filter(p => p > 0);
        if (recentPrices.length > 0) {
          const highestRecentPrice = Math.max(...recentPrices);
          const discountFromHigh = ((highestRecentPrice - currentPrice) / highestRecentPrice) * 100;

          // Consider it a discount if current price is at least 5% below recent high
          if (discountFromHigh >= 5) {
            return true;
          }
        }
      }
    }

    // Priority 5: Check if item has special discount flags
    if (item.hasSpecialDiscount || item.isOnSale || item.hasFlashSale) {
      return true;
    }

    // Priority 6: Check for seasonal or promotional indicators
    if (item.promotionalBadge || (item.badges && item.badges.some(badge =>
        badge.includes('تخفیف') || badge.includes('حراج') || badge.includes('فروش ویژه')))) {
      return true;
    }

    return false;
  }

  /**
   * Calculate the discount percentage for display
   */
  getDiscountPercentage(item) {
    if (!item || !item.isActive) return 0;

    // Use explicit discount percentage if available
    if (item.discountPercent && item.discountPercent > 0) {
      return Math.round(item.discountPercent * 10) / 10; // Round to 1 decimal
    }

    // Calculate from original price vs current price
    if (item.currentPrice && item.originalPrice && item.currentPrice < item.originalPrice) {
      const discountPercent = ((item.originalPrice - item.currentPrice) / item.originalPrice) * 100;
      return Math.round(discountPercent * 10) / 10;
    }

    // Calculate from last known price vs current price
    if (item.currentPrice && item.lastKnownPrice && item.currentPrice < item.lastKnownPrice) {
      const discountPercent = ((item.lastKnownPrice - item.currentPrice) / item.lastKnownPrice) * 100;
      // Only return if it's a meaningful discount
      return discountPercent >= 2 ? Math.round(discountPercent * 10) / 10 : 0;
    }

    // Calculate from price history
    if (item.priceHistory && item.priceHistory.length > 2) {
      const currentPrice = item.currentPrice || item.lastKnownPrice;
      if (currentPrice) {
        const recentPrices = item.priceHistory.slice(-30).map(entry => entry.price || 0).filter(p => p > 0);
        if (recentPrices.length > 0) {
          const highestRecentPrice = Math.max(...recentPrices);
          const discountFromHigh = ((highestRecentPrice - currentPrice) / highestRecentPrice) * 100;
          return discountFromHigh >= 5 ? Math.round(discountFromHigh * 10) / 10 : 0;
        }
      }
    }

    return 0;
  }

  async getFilteredWatchlistItems(filter = 'all', searchQuery = '') {
    await this.loadWatchlistData();

    let filteredItems = [...this.watchlistCache];

    // Apply filter
    switch (filter) {
      case 'active':
        filteredItems = filteredItems.filter(item => item.isActive);
        break;
      case 'inactive':
        filteredItems = filteredItems.filter(item => !item.isActive);
        break;
      case 'alerts':
        filteredItems = filteredItems.filter(item => {
          if (!item.isActive) return false;
          return item.conditions && (
            item.conditions.priceThreshold ||
            item.conditions.minDiscountPercent ||
            item.conditions.notifyOnLowest30Days
          );
        });
        break;
      case 'discounts':
        filteredItems = filteredItems.filter(item => {
          return this.hasDiscount(item);
        });
        break;
      case 'highest-price':
        // Sort by current price (highest first), filter out items without price
        filteredItems = filteredItems.filter(item => item.currentPrice || item.lastKnownPrice);
        filteredItems.sort((a, b) => {
          const priceA = a.currentPrice || a.lastKnownPrice || 0;
          const priceB = b.currentPrice || b.lastKnownPrice || 0;
          return priceB - priceA;
        });
        break;
      case 'lowest-price':
        // Sort by current price (lowest first), filter out items without price
        filteredItems = filteredItems.filter(item => item.currentPrice || item.lastKnownPrice);
        filteredItems.sort((a, b) => {
          const priceA = a.currentPrice || a.lastKnownPrice || 0;
          const priceB = b.currentPrice || b.lastKnownPrice || 0;
          return priceA - priceB;
        });
        break;
      case 'newest':
        // Sort by creation date (newest first)
        filteredItems.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        break;
      default:
        // 'all' - no additional filtering
        break;
    }

    // Apply search query
    if (searchQuery && searchQuery.trim()) {
      const query = searchQuery.trim().toLowerCase();
      filteredItems = filteredItems.filter(item =>
        item.productTitle && item.productTitle.toLowerCase().includes(query)
      );
    }

    // Apply default sorting only if no specific sorting was applied by the filter
    if (!['highest-price', 'lowest-price', 'newest'].includes(filter)) {
      // Sort by creation date (newest first)
      filteredItems.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    }

    return filteredItems;
  }

  async updateWatchlistItem(itemId, updates) {
    try {
      const itemIndex = this.watchlistCache.findIndex(item => item.id === itemId);
      if (itemIndex === -1) {
        throw new Error('Item not found');
      }

      // Update the item
      this.watchlistCache[itemIndex] = {
        ...this.watchlistCache[itemIndex],
        ...updates,
        updatedAt: Date.now()
      };

      // Save to storage
      await chrome.storage.local.set({
        'digikala_extension_watchlist': this.watchlistCache
      });

      console.log('✅ Watchlist item updated:', itemId);
      return this.watchlistCache[itemIndex];
    } catch (error) {
      console.error('❌ Error updating watchlist item:', error);
      throw error;
    }
  }

  async removeWatchlistItem(itemId) {
    try {
      const initialLength = this.watchlistCache.length;
      this.watchlistCache = this.watchlistCache.filter(item => item.id !== itemId);

      if (this.watchlistCache.length === initialLength) {
        throw new Error('Item not found');
      }

      // Save to storage
      await chrome.storage.local.set({
        'digikala_extension_watchlist': this.watchlistCache
      });

      console.log('✅ Watchlist item removed:', itemId);
      return true;
    } catch (error) {
      console.error('❌ Error removing watchlist item:', error);
      throw error;
    }
  }

  async toggleWatchlistItem(itemId) {
    try {
      const item = this.watchlistCache.find(item => item.id === itemId);
      if (!item) {
        throw new Error('Item not found');
      }

      return await this.updateWatchlistItem(itemId, {
        isActive: !item.isActive
      });
    } catch (error) {
      console.error('❌ Error toggling watchlist item:', error);
      throw error;
    }
  }

  async refreshWatchlistItem(itemId) {
    try {
      // Send message to background script to refresh specific item
      const response = await chrome.runtime.sendMessage({
        action: 'refreshWatchlistItem',
        productId: itemId
      });

      if (response && response.success) {
        // Reload data after refresh
        await this.loadWatchlistData();
        return true;
      } else if (response?.error === 'throttled') {
        const retryAfter = response.retryAfter || 60;
        return {
          success: false,
          isThrottled: true,
          retryAfter: retryAfter,
          message: `لطفا ${retryAfter} ثانیه صبر کنید`
        };
      } else if (response?.shouldRemoveFromUI) {
        // Product not found in storage, reload to sync UI with actual data
        await this.loadWatchlistData();
        throw new Error('Product was removed from watchlist');
      } else {
        throw new Error(response?.error || 'Failed to refresh item');
      }
    } catch (error) {
      console.error('❌ Error refreshing watchlist item:', error);
      throw error;
    }
  }

  async refreshAllWatchlist() {
    try {
      // Send message to background script to refresh all items
      const response = await chrome.runtime.sendMessage({
        action: 'refreshAllWatchlist'
      });

      if (response && response.success) {
        // Reload data after refresh
        await this.loadWatchlistData();
        return true;
      } else {
        throw new Error(response?.error || 'Failed to refresh watchlist');
      }
    } catch (error) {
      console.error('❌ Error refreshing all watchlist:', error);
      throw error;
    }
  }

  async addWatchlistItem(productData) {
    try {
      // If we only have productId and productUrl, try to fetch product details
      let enhancedProductData = { ...productData };

      if (productData.productUrl && (!productData.productTitle || productData.productTitle === 'محصول جدید')) {
        try {
          console.log('🔄 Fetching product details for:', productData.productId);
          const details = await this.fetchProductDetails(productData.productId, productData.productUrl);
          if (details) {
            enhancedProductData = { ...enhancedProductData, ...details };
            console.log('✅ Product details fetched successfully');
          }
        } catch (error) {
          console.warn('⚠️ Failed to fetch product details, using provided data:', error.message);
        }
      }

      const newItem = {
        id: `${enhancedProductData.productId}_${Date.now()}`,
        productId: enhancedProductData.productId,
        productTitle: enhancedProductData.productTitle || 'محصول جدید',
        productImage: enhancedProductData.productImage || null,
        productUrl: enhancedProductData.productUrl || '',
        conditions: enhancedProductData.conditions || {},
        checkInterval: enhancedProductData.checkInterval || (4 * 60 * 60 * 1000), // 4 hours default
        currentPrice: enhancedProductData.currentPrice || null,
        lastKnownPrice: enhancedProductData.currentPrice || null,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        isActive: true
      };

      // Remove any existing entries for this product
      this.watchlistCache = this.watchlistCache.filter(item => item.productId !== productData.productId);

      // Add new item
      this.watchlistCache.push(newItem);

      // Save to storage
      await chrome.storage.local.set({
        'digikala_extension_watchlist': this.watchlistCache
      });

      console.log('✅ New watchlist item added:', newItem.id);
      return newItem;
    } catch (error) {
      console.error('❌ Error adding watchlist item:', error);
      throw error;
    }
  }

  async fetchProductDetails(productId, productUrl) {
    try {
      // Send message to background script to fetch product data
      const response = await chrome.runtime.sendMessage({
        action: 'fetchProductData',
        productId: productId,
        url: productUrl
      });

      if (response && response.success && response.data) {
        const productData = response.data;

        return {
          productTitle: productData.product?.title_fa || productData.product?.title_en || 'محصول دیجی‌کالا',
          productImage: productData.product?.images?.[0]?.url?.[0] || productData.product?.image || null,
          currentPrice: productData.product?.default_variant?.price?.selling_price ||
                       productData.default_variant?.price?.selling_price || null
        };
      }

      return null;
    } catch (error) {
      console.error('❌ Error fetching product details:', error);
      return null;
    }
  }

  handleStorageChange(changes, namespace) {
    if (namespace === 'local' && changes.digikala_extension_watchlist) {
      console.log('📡 Watchlist storage changed, reloading data');
      this.loadWatchlistData();

      // Trigger UI update
      if (window.prizoUI) {
        window.prizoUI.trigger('watchlistDataChanged');
      }
    }
  }

  formatPrice(price) {
    // Handle null, undefined, or non-numeric values
    if (price === null || price === undefined || isNaN(price)) return 'نامشخص';

    // Convert to number if it's a string
    const numericPrice = typeof price === 'string' ? parseFloat(price) : price;

    // Only return 'نامشخص' if price is explicitly 0 or negative
    if (numericPrice <= 0) return 'نامشخص';

    // Convert from Rials to Tomans and format
    const tomans = Math.round(numericPrice / 10);
    return tomans.toLocaleString('fa-IR') + ' تومان';
  }

  formatConditions(conditions, checkInterval) {
    const tags = [];

    if (conditions.priceThreshold) {
      const price = Math.round(conditions.priceThreshold / 10).toLocaleString('fa-IR');
      tags.push(`<span class="condition-tag price">قیمت ≤ ${price} تومان</span>`);
    }

    if (conditions.minDiscountPercent) {
      tags.push(`<span class="condition-tag discount">تخفیف ≥ ${conditions.minDiscountPercent}%</span>`);
    }

    if (conditions.notifyOnLowest30Days) {
      tags.push(`<span class="condition-tag monthly">نزدیک به کمترین قیمت ۳۰ روز</span>`);
    }

    if (checkInterval && checkInterval !== 3600000) {
      const minutes = checkInterval / (1000 * 60);
      if (minutes < 60) {
        tags.push(`<span class="condition-tag interval">بررسی هر ${minutes} دقیقه</span>`);
      } else {
        const hours = Math.round(minutes / 60);
        tags.push(`<span class="condition-tag interval">بررسی هر ${hours} ساعت</span>`);
      }
    }

    return tags.join(' ');
  }

  getTimeAgo(timestamp) {
    if (!timestamp) return 'هرگز';

    const now = Date.now();
    const diffInSeconds = Math.floor((now - timestamp) / 1000);
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) {
      return 'همین الان';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes} دقیقه پیش`;
    } else if (diffInHours < 24) {
      return `${diffInHours} ساعت پیش`;
    } else {
      return `${diffInDays} روز پیش`;
    }
  }

  resizeDigikalaImage(imageUrl, width = 100, height = 100) {
    if (!imageUrl || typeof imageUrl !== 'string') {
      return imageUrl;
    }

    // Handle images with existing resize parameters
    if (imageUrl.includes('h_') && imageUrl.includes('w_')) {
      const resizedUrl = imageUrl.replace(
        /h_\d+,w_\d+/g,
        `h_${height},w_${width}`
      );
      return resizedUrl;
    }

    // If it doesn't have size parameters but is a Digikala image, add them
    if (imageUrl.includes('dkstatics-public.digikala.com')) {
      const separator = imageUrl.includes('?') ? '&' : '?';
      return `${imageUrl}${separator}x-oss-process=image/resize,m_lfit,h_${height},w_${width}/quality,q_90`;
    }

    // Return original URL if not a Digikala image
    return imageUrl;
  }

  async searchProducts(query) {
    // This would integrate with the existing API to search for products
    // For now, return empty array as this is beyond the current scope
    console.log('🔍 Product search not yet implemented:', query);
    return [];
  }

  // Get history data (placeholder for future implementation)
  async getHistoryData() {
    // This would integrate with price history tracking
    return {
      totalTracked: this.watchlistCache.length,
      priceChanges: 0, // Would be calculated from actual history
      totalSavings: '0'
    };
  }

  // Export watchlist data
  async exportWatchlist(format = 'json') {
    await this.loadWatchlistData();

    if (format === 'json') {
      const data = {
        exportDate: new Date().toISOString(),
        watchlist: this.watchlistCache
      };

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = `prizo-watchlist-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      return true;
    }

    throw new Error('Unsupported export format');
  }

  // Test notification system
  async testNotification() {
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'testNotification'
      });

      return response && response.success;
    } catch (error) {
      console.error('❌ Error testing notification:', error);
      return false;
    }
  }

  // Get extension version
  async getExtensionVersion() {
    try {
      const manifest = chrome.runtime.getManifest();
      return manifest.version;
    } catch (error) {
      console.error('❌ Error getting extension version:', error);
      return 'Unknown';
    }
  }

  // Cleanup
  destroy() {
    if (chrome && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.removeListener(this.handleStorageChange);
    }
    this.watchlistCache = [];
    this.isInitialized = false;
  }
}

// Make it available globally
window.FullPageService = FullPageService;