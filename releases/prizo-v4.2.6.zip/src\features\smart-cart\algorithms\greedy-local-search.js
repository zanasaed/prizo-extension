/**
 * @Author: Smart Cart System
 * @Date: 2025-01-18
 * Greedy + Local Search Optimizer - For larger instances (>12 products)
 * Uses heuristic approach with local improvements
 */

class GreedyLocalSearchOptimizer {
  constructor(costCalculator) {
    this.costCalculator = costCalculator;
    this.maxIterations = 1000;
    this.maxNoImprovementIterations = 50;
  }

  /**
   * Find near-optimal solution using greedy + local search
   * @param {Object} data - Normalized basket data
   * @returns {Object} Near-optimal solution
   */
  async optimize(data) {
    console.log(`🚀 Starting greedy + local search for ${data.products.length} products`);

    const startTime = Date.now();

    try {
      // Phase 1: Generate initial greedy solution
      let currentSolution = this.generateGreedySolution(data);
      if (!currentSolution) {
        throw new Error('Failed to generate initial greedy solution');
      }

      console.log(`📊 Initial greedy solution: cost=${currentSolution.totalCost}, sellers=${currentSolution.sellersUsed.length}`);

      // Phase 2: Apply local search improvements
      const improvedSolution = await this.localSearch(currentSolution, data);

      const duration = Date.now() - startTime;
      console.log(`✅ Optimization completed in ${duration}ms`);
      console.log(`💰 Final solution: cost=${improvedSolution.totalCost}, sellers=${improvedSolution.sellersUsed.length}`);

      return improvedSolution;

    } catch (error) {
      console.error('❌ Greedy + local search failed:', error);
      throw error;
    }
  }

  /**
   * Generate initial solution using greedy approach
   */
  generateGreedySolution(data) {
    const assignments = [];

    switch (data.optimizationMode) {
      case 'COST':
        return this.generateCostGreedySolution(data);
      case 'SELLERS_FIRST':
        return this.generateSellerMinimizingSolution(data);
      case 'MAX_SELLERS':
        return this.generateMaxSellersSolution(data);
      default:
        return this.generateCostGreedySolution(data);
    }
  }

  /**
   * Greedy solution minimizing total cost
   */
  generateCostGreedySolution(data) {
    const assignments = [];

    for (const product of data.products) {
      let bestSeller = null;
      let bestTotalCost = Infinity;

      const candidates = product.preferredSeller
        ? product.sellers.filter(s => s.sellerId === product.preferredSeller)
        : product.sellers;

      for (const seller of candidates) {
        // Calculate total cost if we assign this product to this seller
        const testAssignments = [...assignments, {
          productId: product.id,
          sellerId: seller.sellerId,
          price: seller.price
        }];

        const costs = this.costCalculator.calculateTotalCost(testAssignments, data);

        if (costs.totalCost < bestTotalCost) {
          bestTotalCost = costs.totalCost;
          bestSeller = seller;
        }
      }

      if (!bestSeller) {
        throw new Error(`No available seller for product ${product.id}`);
      }

      assignments.push({
        productId: product.id,
        sellerId: bestSeller.sellerId,
        price: bestSeller.price
      });
    }

    return this.createSolutionFromAssignments(assignments, data);
  }

  /**
   * Greedy solution minimizing number of sellers first
   */
  generateSellerMinimizingSolution(data) {
    const assignments = [];
    const sellersUsed = new Set();

    // Sort products by number of available sellers (ascending)
    const sortedProducts = [...data.products].sort((a, b) => a.sellers.length - b.sellers.length);

    for (const product of sortedProducts) {
      let bestSeller = null;
      let bestScore = Infinity;

      const candidates = product.preferredSeller
        ? product.sellers.filter(s => s.sellerId === product.preferredSeller)
        : product.sellers;

      for (const seller of candidates) {
        // Calculate score: prioritize existing sellers, then cost
        const isNewSeller = !sellersUsed.has(seller.sellerId);
        const newSellerPenalty = isNewSeller ? 1000000 : 0; // Large penalty for new sellers

        const testAssignments = [...assignments, {
          productId: product.id,
          sellerId: seller.sellerId,
          price: seller.price
        }];

        const costs = this.costCalculator.calculateTotalCost(testAssignments, data);
        const score = newSellerPenalty + costs.totalCost;

        if (score < bestScore) {
          bestScore = score;
          bestSeller = seller;
        }
      }

      if (!bestSeller) {
        throw new Error(`No available seller for product ${product.id}`);
      }

      assignments.push({
        productId: product.id,
        sellerId: bestSeller.sellerId,
        price: bestSeller.price
      });

      sellersUsed.add(bestSeller.sellerId);
    }

    return this.createSolutionFromAssignments(assignments, data);
  }

  /**
   * Greedy solution respecting max sellers constraint
   */
  generateMaxSellersSolution(data) {
    if (data.maxSellers >= data.products.length) {
      // No constraint binding, use cost greedy
      return this.generateCostGreedySolution(data);
    }

    // Use a more sophisticated approach for limited sellers
    return this.generateLimitedSellersSolution(data);
  }

  /**
   * Generate solution with limited number of sellers
   */
  generateLimitedSellersSolution(data) {
    // Find the best combination of sellers to use
    const allSellers = Object.keys(data.sellers);
    const bestSellerCombination = this.findBestSellerCombination(data, allSellers);

    // Assign products to the selected sellers
    const assignments = [];

    for (const product of data.products) {
      let bestSeller = null;
      let bestPrice = Infinity;

      const candidates = product.preferredSeller
        ? product.sellers.filter(s => s.sellerId === product.preferredSeller && bestSellerCombination.includes(s.sellerId))
        : product.sellers.filter(s => bestSellerCombination.includes(s.sellerId));

      for (const seller of candidates) {
        if (seller.price < bestPrice) {
          bestPrice = seller.price;
          bestSeller = seller;
        }
      }

      if (!bestSeller) {
        throw new Error(`No available seller in selected combination for product ${product.id}`);
      }

      assignments.push({
        productId: product.id,
        sellerId: bestSeller.sellerId,
        price: bestSeller.price
      });
    }

    return this.createSolutionFromAssignments(assignments, data);
  }

  /**
   * Find best combination of sellers to use (simplified heuristic)
   */
  findBestSellerCombination(data, allSellers) {
    if (allSellers.length <= data.maxSellers) {
      return allSellers;
    }

    // Heuristic: select sellers that cover most products at lowest cost
    const sellerScores = allSellers.map(sellerId => {
      const productsServed = data.products.filter(p =>
        p.sellers.some(s => s.sellerId === sellerId)
      ).length;

      const avgPrice = data.products.reduce((sum, p) => {
        const seller = p.sellers.find(s => s.sellerId === sellerId);
        return sum + (seller ? seller.price : 0);
      }, 0) / productsServed;

      return {
        sellerId,
        score: productsServed / (avgPrice || 1), // Higher score is better
        productsServed
      };
    });

    // Sort by score and take top maxSellers
    sellerScores.sort((a, b) => b.score - a.score);
    return sellerScores.slice(0, data.maxSellers).map(s => s.sellerId);
  }

  /**
   * Apply local search improvements
   */
  async localSearch(initialSolution, data) {
    let currentSolution = initialSolution;
    let bestSolution = initialSolution;
    let iteration = 0;
    let noImprovementCount = 0;

    console.log(`🔍 Starting local search from solution with cost ${currentSolution.totalCost}`);

    while (iteration < this.maxIterations && noImprovementCount < this.maxNoImprovementIterations) {
      iteration++;

      // Try different neighborhood operations
      const neighbors = await this.generateNeighbors(currentSolution, data);
      let improved = false;

      for (const neighbor of neighbors) {
        if (this.isBetterSolution(neighbor, bestSolution, data.optimizationMode)) {
          bestSolution = neighbor;
          currentSolution = neighbor;
          improved = true;
          noImprovementCount = 0;
          console.log(`🎯 Improvement found at iteration ${iteration}: cost=${neighbor.totalCost}`);
          break;
        }
      }

      if (!improved) {
        noImprovementCount++;
      }

      // Yield control occasionally
      if (iteration % 10 === 0) {
        await this.yieldControl();
      }
    }

    console.log(`🏁 Local search completed after ${iteration} iterations`);
    return bestSolution;
  }

  /**
   * Generate neighbor solutions for local search
   */
  async generateNeighbors(solution, data) {
    const neighbors = [];

    // Try reassigning each product to a different seller
    for (let i = 0; i < solution.assignments.length; i++) {
      const product = data.products.find(p => p.id === solution.assignments[i].productId);
      if (!product) continue;

      const currentSellerId = solution.assignments[i].sellerId;

      const candidates = product.preferredSeller
        ? product.sellers.filter(s => s.sellerId === product.preferredSeller)
        : product.sellers;

      for (const seller of candidates) {
        if (seller.sellerId === currentSellerId) continue;

        // Create neighbor by reassigning this product
        const newAssignments = [...solution.assignments];
        newAssignments[i] = {
          productId: product.id,
          sellerId: seller.sellerId,
          price: seller.price
        };

        // Check constraints
        if (this.satisfiesConstraints(newAssignments, data)) {
          const neighbor = this.createSolutionFromAssignments(newAssignments, data);
          neighbors.push(neighbor);
        }
      }
    }

    return neighbors;
  }

  /**
   * Check if assignments satisfy all constraints
   */
  satisfiesConstraints(assignments, data) {
    const sellersUsed = new Set(assignments.map(a => a.sellerId));

    if (data.optimizationMode === 'MAX_SELLERS' && sellersUsed.size > data.maxSellers) {
      return false;
    }

    return true;
  }

  /**
   * Create complete solution from assignments
   */
  createSolutionFromAssignments(assignments, data) {
    const costs = this.costCalculator.calculateTotalCost(assignments, data);
    const sellersUsed = [...new Set(assignments.map(a => a.sellerId))];

    return {
      assignments,
      totalProductCost: costs.productCost,
      totalShippingCost: costs.shippingCost,
      totalCost: costs.totalCost,
      sellersUsed,
      shippingBreakdown: costs.shippingBreakdown
    };
  }

  /**
   * Compare two solutions based on optimization mode
   */
  isBetterSolution(newSolution, currentBest, optimizationMode) {
    if (!currentBest) return true;
    if (!newSolution) return false;

    switch (optimizationMode) {
      case 'COST':
        return newSolution.totalCost < currentBest.totalCost;

      case 'SELLERS_FIRST':
        if (newSolution.sellersUsed.length !== currentBest.sellersUsed.length) {
          return newSolution.sellersUsed.length < currentBest.sellersUsed.length;
        }
        return newSolution.totalCost < currentBest.totalCost;

      case 'MAX_SELLERS':
        return newSolution.totalCost < currentBest.totalCost;

      default:
        return newSolution.totalCost < currentBest.totalCost;
    }
  }

  /**
   * Yield control to prevent browser freezing
   */
  async yieldControl() {
    return new Promise(resolve => setTimeout(resolve, 0));
  }
}

// Browser extension compatibility
if (typeof window !== 'undefined') {
  window.GreedyLocalSearchOptimizer = GreedyLocalSearchOptimizer;
}