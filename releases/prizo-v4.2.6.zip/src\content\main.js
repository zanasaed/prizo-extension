/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Main Extension Orchestrator - Lightweight coordinator replacing monolithic class
 * 
 * This replaces the 4,069-line digikala-price-updater.js with a clean, maintainable orchestrator
 */
class PrizoExtension {
  constructor() {
    this.services = {};
    this.currentController = null;
    this.pageType = this.detectPageType(); // Initialize page type immediately
    this.isInitialized = false;
    this.initializationPromise = null;
    this.pageChangeTimeout = null;
    
    console.log(`🌐 Detected page type: ${this.pageType}`);
  }

  async initialize() {
    if (this.initializationPromise) {
      return this.initializationPromise;
    }

    this.initializationPromise = this._performInitialization();
    return this.initializationPromise;
  }

  // Apply startup delay based on user settings
  async applyStartupDelay() {
    try {
      // Get configured delay from storage - use ExtensionCore for safe storage access
      const result = await ExtensionCore.BrowserCompat.safeStorageGet(['globalDelay', 'networkStabilityCheck'], {
        globalDelay: 1000,
        networkStabilityCheck: true
      });
      
      const globalDelay = result.globalDelay || 1000; // Default 1 second
      const networkStabilityCheck = result.networkStabilityCheck !== undefined ? result.networkStabilityCheck : true;
      
      // Apply base delay
      console.log(`⏳ Applying startup delay: ${globalDelay}ms`);
      await new Promise(resolve => setTimeout(resolve, globalDelay));
      
      // Apply network stability check if enabled
      if (networkStabilityCheck) {
        console.log('🌐 Waiting for network stability...');
        await this.waitForNetworkStability();
      }
    } catch (error) {
      console.warn('⚠️ Startup delay failed, using fallback 1000ms:', error);
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  // Network stability check for extension initialization
  async waitForNetworkStability() {
    const maxWait = 3000; // Max 3 seconds
    const checkInterval = 100;
    let waited = 0;
    
    while (waited < maxWait) {
      // Check if there are active network requests
      try {
        const hasActiveRequests = performance.getEntriesByType('navigation')
          .some(entry => entry.loadEventEnd === 0);
        
        if (!hasActiveRequests) {
          console.log(`✅ Network stability achieved after ${waited}ms`);
          return;
        }
      } catch (perfError) {
        // Performance API might not be available, just wait
      }
      
      await new Promise(resolve => setTimeout(resolve, checkInterval));
      waited += checkInterval;
    }
    
    console.log('⚠️ Network stability timeout, proceeding anyway');
  }

  async _performInitialization() {
    try {
      console.log('🚀 Initializing Prizo Extension v2.0');
      
      // Check browser compatibility (using core.js BrowserCompat)
      if (!ExtensionCore.BrowserCompat.isCompatible()) {
        throw new Error('Browser not compatible with extension requirements');
      }

      // Apply startup delay first for stability
      await this.applyStartupDelay();

      // Initialize core services
      await this.initializeServices();
      
      // Set up global event listeners
      this.setupGlobalListeners();
      
      // Detect and activate page controller
      await this.detectAndActivatePageController();
      
      // Check for persistent mode and auto-activate if enabled
      await this.checkPersistentMode();
      
      // Set up page change monitoring
      this.setupPageChangeMonitoring();
      
      this.isInitialized = true;
      console.log('✅ Prizo Extension initialized successfully');
      
      // Setup message listener for popup communication (exactly like original)
      this.setupMessageListener();

      // Show initialization success notification (only on Digikala pages)
      if (window.location.hostname.includes('digikala.com')) {
        this.services.notificationService?.showSuccess(
          'افزونه آماده است',
          'Prizo با موفقیت بارگذاری شد',
          { duration: 3000 }
        );
      }

      return true;
      
    } catch (error) {
      console.error('❌ Extension initialization failed:', error);
      
      // Show error notification
      if (this.services.notificationService) {
        this.services.notificationService.showError(
          'خطا در بارگذاری',
          'مشکل در راه‌اندازی افزونه. لطفاً صفحه را تازه‌سازی کنید',
          { autoHide: false }
        );
      }
      
      throw error;
    }
  }

  async initializeServices() {
    console.log('🔧 Initializing core services');

    // Initialize EventBus first (other services depend on it)
    this.services.eventBus = new EventBus();
    this.services.eventBus.setDebugMode(false); // Set to true for debugging

    // Initialize Service Registry
    this.serviceRegistry = new window.ServiceRegistry();
    await this.serviceRegistry.initializeServices();

    // Initialize core services first
    this.services.storageService = new StorageService(this.services.eventBus);
    this.services.apiService = new APIService(this.services.eventBus);

    // Get services through registry with fallback to manual initialization
    try {
      this.services.domManager = await this.serviceRegistry.get('domManager').catch(() => null);
    } catch (error) {
      console.warn('⚠️ Failed to get DOMManager from registry, falling back to manual initialization');
      this.services.domManager = window.DOMManager ? new window.DOMManager() : null;
    }

    try {
      this.services.dataManager = await this.serviceRegistry.get('dataManager').catch(() => null);
    } catch (error) {
      console.warn('⚠️ Failed to get DataManager from registry, falling back to manual initialization');
      this.services.dataManager = window.DataManager ? new window.DataManager() : null;
    }

    try {
      this.services.validationManager = await this.serviceRegistry.get('validationManager').catch(() => null);
    } catch (error) {
      console.warn('⚠️ Failed to get ValidationManager from registry, falling back to manual initialization');
      this.services.validationManager = window.ValidationManager ? new window.ValidationManager() : null;
    }

    try {
      this.services.storageManager = await this.serviceRegistry.get('storageManager').catch(() => null);
    } catch (error) {
      console.warn('⚠️ Failed to get StorageManager from registry, falling back to manual initialization');
      this.services.storageManager = window.StorageManager ? new window.StorageManager() : null;
    }

    try {
      this.services.urlSafety = await this.serviceRegistry.get('urlSafety').catch(() => null);
    } catch (error) {
      console.warn('⚠️ Failed to get URLSafetyManager from registry, falling back to manual initialization');
      this.services.urlSafety = window.URLSafetyManager ? new window.URLSafetyManager() : null;
    }

    try {
      this.services.loggerService = await this.serviceRegistry.get('loggerService').catch(() => null);
    } catch (error) {
      console.warn('⚠️ Failed to get LoggerService from registry, falling back to manual initialization');
      this.services.loggerService = window.LoggerService ? new window.LoggerService() : null;
    }

    console.log('🔧 Services initialized via registry:', {
      domManager: !!this.services.domManager,
      dataManager: !!this.services.dataManager,
      validationManager: !!this.services.validationManager,
      storageManager: !!this.services.storageManager,
      urlSafety: !!this.services.urlSafety,
      loggerService: !!this.services.loggerService
    });

    // Initialize remaining services that depend on the core services
    this.services.priceService = new PriceService(this.services.eventBus, this.services.apiService, this.services.loggerService);
    this.services.notificationService = new NotificationService(this.services.eventBus);
    this.services.styleService = new StyleService(this.services.eventBus);

    // Initialize Smart Cart Manager through registry or fallback (with feature flag check)
    try {
      // Check if Smart Cart feature is enabled
      const smartCartSettings = await ExtensionCore.BrowserCompat.safeStorageGet(['smartCartEnabled'], { smartCartEnabled: false });

      if (smartCartSettings.smartCartEnabled) {
        console.log('✅ Smart Cart feature enabled - initializing SmartCartManager');
        this.services.smartCartManager = await this.serviceRegistry.get('smartCartManager').catch(() => {
          return window.SmartCartManager ? new window.SmartCartManager(this.services.eventBus, this.services.storageService) : null;
        });
      } else {
        console.log('🚫 Smart Cart feature disabled - skipping SmartCartManager initialization');
        this.services.smartCartManager = null;
      }
    } catch (error) {
      console.warn('⚠️ Failed to initialize SmartCartManager:', error);
      this.services.smartCartManager = null;
    }

    // Only initialize GlobalSortingService if the sort feature is enabled
    try {
      const sortSettings = await ExtensionCore.BrowserCompat.safeStorageGet(['sortFeatureEnabled'], { sortFeatureEnabled: true });
      if (sortSettings.sortFeatureEnabled) {
        console.log('✅ Sort feature enabled - initializing GlobalSortingService');
        this.services.globalSortingService = new GlobalSortingService(this.services);
      } else {
        console.log('🚫 Sort feature disabled - skipping GlobalSortingService initialization');
        this.services.globalSortingService = null;
      }
    } catch (error) {
      console.warn('⚠️ Failed to check sort feature setting, disabling GlobalSortingService:', error);
      this.services.globalSortingService = null;
    }

    // Initialize welcome guide for first-time users
    try {
      this.services.welcomeGuide = window.FirstTimeWelcome ? new window.FirstTimeWelcome() : null;
    } catch (error) {
      console.warn('⚠️ Failed to initialize FirstTimeWelcome:', error);
      this.services.welcomeGuide = null;
    }
    
    // Initialize services that need it
    await this.services.storageService.initialize();
    this.services.notificationService.initialize();
    this.services.styleService.initialize();

    // Initialize Smart Cart Manager if available and enabled
    if (this.services.smartCartManager) {
      try {
        await this.services.smartCartManager.initialize();
      } catch (error) {
        console.warn('⚠️ Smart Cart Manager initialization failed:', error);
        this.services.smartCartManager = null;
      }
    }

    // Only initialize GlobalSortingService if it was created
    if (this.services.globalSortingService) {
      await this.services.globalSortingService.initialize();
    }

    // Initialize welcome guide (will check if first-time user)
    if (this.services.welcomeGuide) {
      await this.services.welcomeGuide.initialize();
    }
    
    // Set up service event listeners
    this.setupServiceEventListeners();
    
    console.log('✅ Core services initialized');
  }

  setupServiceEventListeners() {
    const { eventBus } = this.services;
    
    // Listen for storage errors
    eventBus.on('storage:error', (error) => {
      console.warn('Storage error:', error);
      this.services.notificationService?.showWarning(
        'خطای ذخیره‌سازی',
        'مشکل در ذخیره تنظیمات. از حالت پیش‌فرض استفاده می‌شود'
      );
    });
    
    // Listen for API errors
    eventBus.on('api:error', (error) => {
      console.warn('API error:', error);
    });
    
    // Listen for controller events
    eventBus.on('controller:error', (error) => {
      console.error('Controller error:', error);
    });

    // Listen for extension setting changes
    eventBus.on('extension:setting-changed', async (data) => {
      console.log('🔧 Extension setting changed:', data);

      if (data.name === 'sortFeatureEnabled') {
        await this.handleSortFeatureSettingChange(data.value);
      } else if (data.name === 'cartFeatureEnabled') {
        await this.handleCartFeatureSettingChange(data.value);
      } else if (data.name === 'smartCartEnabled') {
        await this.handleSmartCartFeatureSettingChange(data.value);
      }
    });
  }

  async handleSortFeatureSettingChange(enabled) {
    try {
      if (enabled && !this.services.globalSortingService) {
        // Feature was enabled - initialize GlobalSortingService
        console.log('✅ Sort feature enabled - initializing GlobalSortingService');
        this.services.globalSortingService = new GlobalSortingService(this.services);
        await this.services.globalSortingService.initialize();
      } else if (!enabled && this.services.globalSortingService) {
        // Feature was disabled - cleanup GlobalSortingService
        console.log('🚫 Sort feature disabled - cleaning up GlobalSortingService');
        if (this.services.globalSortingService.cleanup) {
          this.services.globalSortingService.cleanup();
        }
        this.services.globalSortingService = null;
      }
    } catch (error) {
      console.error('❌ Error handling sort feature setting change:', error);
    }
  }

  async handleCartFeatureSettingChange(enabled) {
    try {
      // If this is a cart page and cart controller exists, handle the setting change
      if (this.currentController && this.pageType === 'cart') {
        if (!enabled) {
          // Feature was disabled - remove cart price info
          console.log('🚫 Cart feature disabled - removing cart price information');
          if (this.services.domManager && typeof this.services.domManager.removeCartPriceInfo === 'function') {
            this.services.domManager.removeCartPriceInfo();
          }
        } else {
          // Feature was enabled - reprocess cart items
          console.log('✅ Cart feature enabled - reprocessing cart items');
          if (this.currentController.isActive) {
            await this.currentController.processInitialElements();
          }
        }
      }
    } catch (error) {
      console.error('❌ Error handling cart feature setting change:', error);
    }
  }

  async handleSmartCartFeatureSettingChange(enabled) {
    try {
      if (enabled && !this.services.smartCartManager) {
        // Feature was enabled - initialize SmartCartManager
        console.log('✅ Smart Cart feature enabled - initializing SmartCartManager');
        try {
          this.services.smartCartManager = await this.serviceRegistry.get('smartCartManager').catch(() => {
            return window.SmartCartManager ? new window.SmartCartManager(this.services.eventBus, this.services.storageService) : null;
          });
          if (this.services.smartCartManager) {
            await this.services.smartCartManager.initialize();
          }
        } catch (error) {
          console.warn('⚠️ Failed to initialize SmartCartManager on enable:', error);
          this.services.smartCartManager = null;
        }
      } else if (!enabled && this.services.smartCartManager) {
        // Feature was disabled - cleanup SmartCartManager and remove all smart cart UI elements
        console.log('🚫 Smart Cart feature disabled - cleaning up SmartCartManager');
        try {
          // Remove all smart cart buttons and UI elements
          this.removeAllSmartCartElements();

          // Cleanup the service
          if (this.services.smartCartManager.cleanup) {
            this.services.smartCartManager.cleanup();
          }
          this.services.smartCartManager = null;
        } catch (error) {
          console.warn('⚠️ Error during SmartCartManager cleanup:', error);
        }
      }
    } catch (error) {
      console.error('❌ Error handling smart cart feature setting change:', error);
    }
  }

  setupGlobalListeners() {
    // Listen for page navigation changes (SPA support)
    window.addEventListener('popstate', () => {
      this.debouncePageChange();
    });

    // Listen for DOM changes that might indicate page changes
    const urlObserver = new MutationObserver(() => {
      if (this.hasURLChanged()) {
        this.debouncePageChange();
      }
    });

    urlObserver.observe(document.head, {
      childList: true,
      subtree: true
    });

    // Listen for extension-specific messages
    this.services.eventBus.on('extension:refresh', () => {
      this.refreshCurrentPage();
    });

    this.services.eventBus.on('extension:settings-changed', () => {
      this.handleSettingsChange();
    });
  }

  debouncePageChange() {
    if (this.pageChangeTimeout) {
      clearTimeout(this.pageChangeTimeout);
    }
    
    this.pageChangeTimeout = setTimeout(() => {
      this.detectAndActivatePageController();
    }, 1000);
  }

  hasURLChanged() {
    const currentURL = window.location.href;
    if (currentURL !== this.lastURL) {
      this.lastURL = currentURL;
      return true;
    }
    return false;
  }

  async checkPersistentMode() {
    try {
      const result = await ExtensionCore.BrowserCompat.safeStorageGet(['persistentMode']);
      const persistentMode = result.persistentMode !== undefined ? result.persistentMode : true;

      console.log(`🔄 Persistent mode check: ${persistentMode}`);

      // Only auto-activate if persistent mode is enabled
      if (persistentMode && this.currentController && !this.currentController.isActive) {
        console.log(`🚀 Auto-activating ${this.pageType} controller (persistent mode enabled)`);
        await this.currentController.activate();
      } else if (!persistentMode) {
        console.log(`🚫 Persistent mode disabled - not auto-activating ${this.pageType} controller`);
      }
    } catch (error) {
      console.error('❌ Error checking persistent mode:', error);
    }
  }

  setupPageChangeMonitoring() {
    this.lastURL = window.location.href;
    
    // Monitor for URL changes in SPAs
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;
    
    history.pushState = (...args) => {
      originalPushState.apply(history, args);
      this.debouncePageChange();
    };
    
    history.replaceState = (...args) => {
      originalReplaceState.apply(history, args);
      this.debouncePageChange();
    };
  }

  async detectAndActivatePageController() {
    try {
      const newPageType = this.detectPageType();
      
      if (newPageType === this.pageType && this.currentController?.isActive) {
        console.log(`📄 Page type unchanged: ${newPageType}`);
        return;
      }
      
      console.log(`📄 Page type changed: ${this.pageType} → ${newPageType}`);
      
      // Deactivate current controller
      if (this.currentController) {
        await this.currentController.deactivate();
        this.currentController = null;
      }
      
      this.pageType = newPageType;
      
      // Activate new controller
      if (newPageType && newPageType !== 'unknown') {
        this.currentController = this.createController(newPageType);
        if (this.currentController) {
          // Check if controller should be auto-activated
          try {
            const result = await ExtensionCore.BrowserCompat.safeStorageGet(['persistentMode']);
            const persistentMode = result.persistentMode !== undefined ? result.persistentMode : true;

            // Only auto-activate if persistent mode is enabled
            if (persistentMode) {
              console.log(`🚀 Auto-activating ${newPageType} controller (persistent mode enabled)`);
              await this.currentController.activate();
            } else {
              console.log(`🚫 Persistent mode disabled - not auto-activating ${newPageType} controller`);
            }
          } catch (error) {
            console.error('❌ Error checking activation during page change:', error);
          }
        }
      }
      
      this.services.eventBus.emit('page:changed', { 
        pageType: newPageType,
        url: window.location.href 
      });
      
    } catch (error) {
      console.error('❌ Error in page controller activation:', error);
    }
  }

  detectPageType() {
    const pathname = window.location.pathname;
    const url = window.location.href;

    console.log(`🔍 Detecting page type - URL: ${url}, Path: ${pathname}`);

    // Order detail pages (add this as high priority check)
    if (pathname.includes('/profile/orders/')) {
      console.log('✅ Path includes /profile/orders/');
      console.log('🔍 Full pathname for regex test:', pathname);
      
      // More flexible pattern matching
      const orderIdPattern = /\/profile\/orders\/\d+/;
      const hasOrderId = orderIdPattern.test(pathname);
      console.log('🔍 Regex test result:', hasOrderId);
      
      // If we have /profile/orders/ in the path, it's likely an order page
      console.log('✅ Detected as order page');
      return 'order';
    }
    // Cart pages (add this as high priority check) - exactly like original
    else if (pathname.includes('/checkout/cart/')) {
      return 'cart';
    }
    // Wishlist pages - exactly like original
    else if (pathname.includes('/profile/lists/') || pathname.includes('/profile/wishlist/')) {
      return 'wishlist';
    }
    // Product detail pages (single product) - including fresh products
    else if (pathname.includes('/product/dkp-') || pathname.includes('/fresh/product/dkp-')) {
      return 'product';
    }
    // Seller pages - exactly like original
    else if (pathname.includes('/seller/')) {
      return 'seller';
    }
    // Brand pages
    else if (pathname.includes('/brand/')) {
      return 'brand';
    }
    // Category pages (from menu navigation) - including fresh categories
    else if (pathname.includes('/search/category-') || pathname.includes('/fresh/category/')) {
      return 'category';
    }
    // Search pages - including fresh search pages
    else if ((pathname.startsWith('/search') || pathname.includes('/fresh/search')) && !pathname.includes('/category') || url.includes('product-list')) {
      return 'search';
    }
    // Tags pages - exactly like original
    else if (pathname.includes('/tags/')) {
      return 'tags';
    }
    // Offers/deals pages - exactly like original
    else if (pathname.includes('/incredible-offers/') || pathname.includes('/fresh-offers/') || url.includes('offers')) {
      return 'offers';
    }
    // Home page - exactly like original
    else if (pathname === '/' || pathname === '/main/') {
      return 'homepage';
    }
    // Fresh homepage
    else if (pathname === '/fresh/' || pathname === '/fresh') {
      return 'fresh-homepage';
    }
    // Default - exactly like original
    else {
      return 'unknown';
    }
  }

  createController(pageType) {
    const controllerMap = {
      'search': ProductListController,
      'category': ProductListController,
      'brand': ProductListController,
      'offers': ProductListController,
      'tags': ProductListController,
      'homepage': ProductListController,
      'fresh-homepage': ProductListController,
      'wishlist': WishlistController,
      'product': ProductDetailController,
      'cart': CartController,
      'order': OrderController,
      'seller': SellerController
    };
    
    const ControllerClass = controllerMap[pageType];
    if (!ControllerClass) {
      console.warn(`⚠️ No controller found for page type: ${pageType}`);
      return null;
    }
    
    try {
      return new ControllerClass(this.services);
    } catch (error) {
      console.error(`❌ Error creating ${pageType} controller:`, error);
      return null;
    }
  }

  async refreshCurrentPage() {
    console.log('🔄 Refreshing current page');
    
    if (this.currentController && this.currentController.refreshAllProducts) {
      await this.currentController.refreshAllProducts();
    } else if (this.currentController && this.currentController.refreshProductDetail) {
      await this.currentController.refreshProductDetail();
    } else {
      // Force re-initialization
      await this.detectAndActivatePageController();
    }
  }

  async handleSettingsChange() {
    console.log('⚙️ Settings changed, updating controllers');
    
    if (this.currentController && this.currentController.handleSettingsChange) {
      await this.currentController.handleSettingsChange();
    }
  }

  // Public API methods for external access
  async updateSettings(newSettings) {
    if (this.services.storageService) {
      await this.services.storageService.saveSettings(newSettings);
      this.services.eventBus.emit('extension:settings-changed', newSettings);
    }
  }

  getSettings() {
    return this.services.storageService?.settings || {};
  }

  showNotification(options) {
    if (this.services.notificationService) {
      return this.services.notificationService.show(options);
    }
  }

  clearAllData() {
    if (this.services.storageService) {
      return this.services.storageService.clearAll();
    }
  }

  getStatus() {
    return {
      isInitialized: this.isInitialized,
      pageType: this.pageType,
      controllerActive: this.currentController?.isActive || false,
      services: Object.keys(this.services),
      url: window.location.href
    };
  }

  getStats() {
    const stats = {
      extension: this.getStatus(),
      storage: this.services.storageService?.getStorageStats(),
      api: this.services.apiService?.getCacheStats(),
      controller: this.currentController?.getProcessingStats()
    };
    
    return stats;
  }

  setupMessageListener() {
    // Remove any existing listener first (exactly like original)
    if (this.messageListener) {
      try {
        chrome.runtime.onMessage.removeListener(this.messageListener);
      } catch (error) {
        console.log('Previous message listener removal failed (expected on first run)');
      }
    }

    this.messageListener = (request, sender, sendResponse) => {
      console.log('📨 Message received:', request);
      
      let responseAlreadySent = false;
      
      // Safe sendResponse wrapper to prevent double-sending (exactly like original)
      const safeSendResponse = (response) => {
        if (!responseAlreadySent) {
          responseAlreadySent = true;
          try {
            sendResponse(response);
          } catch (error) {
            console.error('Failed to send response:', error);
          }
        }
      };

      try {
        if (request.action === 'getStatus') {
          // Get persistent mode from storage and respond (exactly like original)
          console.log(`📨 Responding to getStatus with pageType: ${this.pageType}`);
          ExtensionCore.BrowserCompat.safeStorageGet(['persistentMode', 'sortFeatureEnabled', 'cartFeatureEnabled', 'smartCartEnabled']).then(result => {
            const response = {
              active: this.currentController?.isActive || false,
              pageType: this.pageType,
              persistentMode: result.persistentMode !== undefined ? result.persistentMode : true,
              sortFeatureEnabled: result.sortFeatureEnabled !== undefined ? result.sortFeatureEnabled : true,
              cartFeatureEnabled: result.cartFeatureEnabled !== undefined ? result.cartFeatureEnabled : true,
              smartCartEnabled: result.smartCartEnabled || false
            };
            console.log(`📨 Sending getStatus response:`, response);
            safeSendResponse(response);
          }).catch(error => {
            console.error('❌ Error getting status from storage:', error);
            safeSendResponse({
              active: this.currentController?.isActive || false,
              pageType: this.pageType,
              persistentMode: true,
              sortFeatureEnabled: true,
              cartFeatureEnabled: true,
              smartCartEnabled: false
            });
          });
          return true; // Will respond asynchronously
          
        } else if (request.action === 'toggleStatus') {
          // Toggle the current controller (exactly like original logic)
          if (this.currentController) {
            const wasActive = this.currentController.isActive;
            
            if (!wasActive) {
              // Activate controller
              this.currentController.activate()
                .then(() => {
                  safeSendResponse({ 
                    active: true, 
                    pageType: this.pageType,
                    success: true 
                  });
                })
                .catch(error => {
                  console.error('❌ Toggle status error:', error);
                  safeSendResponse({ 
                    active: false, 
                    error: error.message,
                    success: false 
                  });
                });
            } else {
              // Deactivate controller
              try {
                this.currentController.deactivate();
                safeSendResponse({ 
                  active: false, 
                  pageType: this.pageType,
                  success: true 
                });
              } catch (error) {
                console.error('❌ Deactivate error:', error);
                safeSendResponse({ 
                  active: false, 
                  error: error.message,
                  success: false 
                });
              }
            }
          } else {
            safeSendResponse({ 
              active: false, 
              error: 'No controller available',
              success: false 
            });
          }
          return true; // Will respond asynchronously
          
        } else if (request.action === 'updatePrices') {
          // Force update prices (exactly like original)
          if (this.currentController && this.currentController.isActive) {
            this.currentController.processInitialElements()
              .then(() => {
                safeSendResponse({ success: true });
              })
              .catch(error => {
                console.error('❌ Update prices error:', error);
                safeSendResponse({ success: false, error: error.message });
              });
          } else {
            safeSendResponse({ success: false, error: 'Controller not active' });
          }
          return true; // Will respond asynchronously
          
        } else if (request.action === 'emergencyStop') {
          // Enhanced emergency stop with comprehensive cleanup
          console.log('⏹️ Processing emergency stop request...');
          try {
            // Force stop current controller
            if (this.currentController) {
              this.currentController.deactivate();
              console.log('✅ Controller force stopped');
            }
            
            // Comprehensive element cleanup
            this.clearAllExtensionElements();
            
            // Reset all internal states
            this.isActive = false;
            this.currentController = null;
            
            // Clear any timers or intervals that might be running
            if (window.prizoTimers) {
              Object.values(window.prizoTimers).forEach(timer => {
                if (timer) clearTimeout(timer);
              });
              window.prizoTimers = {};
            }
            
            safeSendResponse({ success: true, message: 'Emergency stop completed successfully' });
          } catch (error) {
            console.error('❌ Emergency stop error:', error);
            // Force cleanup even on error
            try {
              this.clearAllExtensionElements();
              this.isActive = false;
              this.currentController = null;
              safeSendResponse({ success: true, message: 'Emergency stop completed with errors', error: error.message });
            } catch (criticalError) {
              safeSendResponse({ success: false, error: criticalError.message });
            }
          }
          return false;
          
        } else if (request.action === 'clearDisplay') {
          // Enhanced clear display with comprehensive cleanup
          console.log('🧹 Processing clearDisplay request...');
          try {
            // Deactivate current controller if exists
            if (this.currentController) {
              this.currentController.deactivate();
              console.log('✅ Controller deactivated');
            }
            
            // Clear all extension elements
            this.clearAllExtensionElements();
            
            // Additional cleanup for specific action types
            if (request.type) {
              switch (request.type) {
                case 'cart':
                  this.clearCartSpecificElements();
                  break;
                case 'seller':
                  this.clearSellerSpecificElements();
                  break;
                case 'monthly':
                  this.clearMonthlySpecificElements();
                  break;
              }
            }
            
            // Reset internal state
            this.isActive = false;
            
            safeSendResponse({ success: true, message: 'All extension elements cleared' });
          } catch (error) {
            console.error('❌ Clear display error:', error);
            // Even if there's an error, try basic cleanup
            try {
              this.clearAllExtensionElements();
              safeSendResponse({ success: true, message: 'Basic cleanup completed with errors', error: error.message });
            } catch (fallbackError) {
              safeSendResponse({ success: false, error: fallbackError.message });
            }
          }
          return false;
          
        } else if (request.action === 'clearCache') {
          // Clear cache (exactly like original)
          try {
            // Clear API service cache if available
            if (this.services.apiService) {
              this.services.apiService.clearCache?.();
            }
            // Clear storage service cache if available
            if (this.services.storageService) {
              this.services.storageService.clear?.();
            }
            safeSendResponse({ success: true });
          } catch (error) {
            console.error('❌ Clear cache error:', error);
            safeSendResponse({ success: false, error: error.message });
          }
          return false;
          
        } else if (request.action === 'clearAllData') {
          // Clear all data and reset (exactly like original)
          try {
            if (this.currentController) {
              this.currentController.deactivate();
            }
            this.clearAllExtensionElements();
            // Clear caches
            if (this.services.apiService) {
              this.services.apiService.clearCache?.();
            }
            if (this.services.storageService) {
              this.services.storageService.clear?.();
            }
            safeSendResponse({ success: true });
          } catch (error) {
            console.error('❌ Clear all data error:', error);
            safeSendResponse({ success: false, error: error.message });
          }
          return false;
          
        } else if (request.action === 'ping') {
          // Ping response (exactly like original)
          safeSendResponse({ pong: true, pageType: this.pageType });
          return false;
          
        } else if (request.action === 'getPageType') {
          // Get page type (exactly like original)
          console.log(`📨 Responding to getPageType with: ${this.pageType}`);
          safeSendResponse({ pageType: this.pageType });
          return false;
          
        } else if (request.action === 'togglePersistentMode') {
          // Toggle persistent mode (auto activation) - exactly like original
          try {
            const enabled = request.enabled;
            
            // Store in chrome storage for persistence
            ExtensionCore.BrowserCompat.safeStorageSet({ persistentMode: enabled }).then(() => {
              console.log(`🔄 Persistent mode ${enabled ? 'enabled' : 'disabled'}`);
              
              if (enabled) {
                // Auto-activate current controller when persistent mode is enabled
                if (this.currentController && !this.currentController.isActive) {
                  this.currentController.activate()
                    .then(() => {
                      safeSendResponse({ 
                        success: true, 
                        persistentMode: enabled,
                        active: true 
                      });
                    })
                    .catch(error => {
                      console.error('❌ Error activating controller in persistent mode:', error);
                      safeSendResponse({ 
                        success: true, 
                        persistentMode: enabled,
                        active: false 
                      });
                    });
                } else {
                  safeSendResponse({ 
                    success: true, 
                    persistentMode: enabled,
                    active: this.currentController?.isActive || false 
                  });
                }
              } else {
                // Deactivate current controller when persistent mode is disabled
                if (this.currentController && this.currentController.isActive) {
                  this.currentController.deactivate();
                }
                safeSendResponse({ 
                  success: true, 
                  persistentMode: enabled,
                  active: false 
                });
              }
            }).catch(error => {
              console.error('❌ Error saving persistent mode setting:', error);
              safeSendResponse({ success: false, error: 'Failed to save persistent mode setting' });
            });
          } catch (error) {
            console.error('❌ Persistent mode toggle error:', error);
            safeSendResponse({ success: false, error: error.message });
          }
          return true; // Will respond asynchronously
          
        } else if (request.action === 'toggleSortFeature') {
          // Toggle sort feature (exactly like original)
          try {
            const enabled = request.enabled;
            
            if (this.currentController && this.currentController.toggleSortFeature) {
              this.currentController.toggleSortFeature(enabled)
                .then((result) => {
                  safeSendResponse({ success: true, enabled: result.enabled });
                })
                .catch(error => {
                  console.error('❌ Toggle sort feature error:', error);
                  safeSendResponse({ success: false, error: error.message });
                });
            } else {
              // Just save the setting if no controller available
              ExtensionCore.BrowserCompat.safeStorageSet({ sortFeatureEnabled: enabled }).then(() => {
                safeSendResponse({ success: true, enabled: enabled });
              }).catch(error => {
                safeSendResponse({ success: false, error: error.message });
              });
            }
          } catch (error) {
            console.error('❌ Sort feature toggle error:', error);
            safeSendResponse({ success: false, error: error.message });
          }
          return true; // Will respond asynchronously
          
        } else if (request.action === 'showWelcomeGuide') {
          // Show welcome guide manually
          if (this.services.welcomeGuide) {
            this.services.welcomeGuide.showGuideAgain()
              .then(() => {
                safeSendResponse({ success: true, message: 'Welcome guide displayed' });
              })
              .catch((error) => {
                console.error('❌ Error showing welcome guide:', error);
                safeSendResponse({ success: false, error: error.message || 'Failed to show welcome guide' });
              });
          } else {
            safeSendResponse({ success: false, error: 'Welcome guide not available' });
          }
          return true; // Will respond asynchronously
          
        } else if (request.action === 'refreshWatchlistItem') {
          // Forward watchlist item refresh request to background script
          try {
            console.log('📨 Forwarding refreshWatchlistItem to background script:', request.productId);
            chrome.runtime.sendMessage({
              action: 'refreshWatchlistItem',
              productId: request.productId
            }).then(response => {
              console.log('📨 Background script response:', response);
              safeSendResponse(response || { success: false, error: 'No response from background' });
            }).catch(error => {
              console.error('❌ Error forwarding to background script:', error);
              safeSendResponse({ success: false, error: error.message });
            });
          } catch (error) {
            console.error('❌ Error handling refreshWatchlistItem:', error);
            safeSendResponse({ success: false, error: error.message });
          }
          return true; // Will respond asynchronously

        } else if (request.action === 'showWatchlistNotification') {
          // Handle fallback watchlist notifications from background script
          try {
            if (this.services.notificationService && request.notification && request.entry) {
              const actions = [
                {
                  text: 'مشاهده محصول',
                  action: 'view_product',
                  callback: () => {
                    if (request.entry.productUrl) {
                      window.open(request.entry.productUrl, '_blank');
                    }
                  }
                }
              ];

              this.services.notificationService.show({
                type: 'info',
                title: request.notification.title,
                message: request.notification.message,
                actions: actions,
                duration: 8000
              });

              console.log('✅ Fallback watchlist notification displayed');
              safeSendResponse({ success: true });
            } else {
              safeSendResponse({ success: false, error: 'Notification service or data not available' });
            }
          } catch (error) {
            console.error('❌ Error showing fallback watchlist notification:', error);
            safeSendResponse({ success: false, error: error.message });
          }
          return false;

        } else if (request.action === 'getSmartCartItems') {
          // Get Smart Cart items - check if feature is enabled
          ExtensionCore.BrowserCompat.safeStorageGet(['smartCartEnabled'], { smartCartEnabled: false })
            .then(smartCartSettings => {
              if (!smartCartSettings.smartCartEnabled) {
                safeSendResponse({ success: false, error: 'Smart Cart feature is disabled' });
                return;
              }

              if (this.services.smartCartManager) {
                const items = this.services.smartCartManager.getCartItems();
                safeSendResponse({ success: true, items });
              } else {
                safeSendResponse({ success: false, error: 'Smart Cart Manager not available' });
              }
            })
            .catch(error => {
              console.error('❌ Error getting Smart Cart items:', error);
              safeSendResponse({ success: false, error: error.message });
            });
          return true; // Will respond asynchronously

        } else if (request.action === 'clearSmartCart') {
          // Clear Smart Cart - check if feature is enabled
          ExtensionCore.BrowserCompat.safeStorageGet(['smartCartEnabled'], { smartCartEnabled: false })
            .then(smartCartSettings => {
              if (!smartCartSettings.smartCartEnabled) {
                safeSendResponse({ success: false, error: 'Smart Cart feature is disabled' });
                return;
              }

              if (this.services.smartCartManager) {
                this.services.smartCartManager.clearCart()
                  .then(() => {
                    safeSendResponse({ success: true });
                  })
                  .catch((error) => {
                    console.error('❌ Error clearing Smart Cart:', error);
                    safeSendResponse({ success: false, error: error.message });
                  });
              } else {
                safeSendResponse({ success: false, error: 'Smart Cart Manager not available' });
              }
            })
            .catch(error => {
              console.error('❌ Error checking Smart Cart feature status:', error);
              safeSendResponse({ success: false, error: error.message });
            });
          return true; // Will respond asynchronously

        } else if (request.action === 'removeFromSmartCart') {
          // Remove item from Smart Cart - check if feature is enabled
          ExtensionCore.BrowserCompat.safeStorageGet(['smartCartEnabled'], { smartCartEnabled: false })
            .then(smartCartSettings => {
              if (!smartCartSettings.smartCartEnabled) {
                safeSendResponse({ success: false, error: 'Smart Cart feature is disabled' });
                return;
              }

              if (this.services.smartCartManager && request.itemId) {
                this.services.smartCartManager.removeItem(request.itemId)
                  .then(() => {
                    safeSendResponse({ success: true });
                  })
                  .catch((error) => {
                    console.error('❌ Error removing item from Smart Cart:', error);
                    safeSendResponse({ success: false, error: error.message });
                  });
              } else {
                safeSendResponse({ success: false, error: 'Smart Cart Manager not available or no itemId provided' });
              }
            })
            .catch(error => {
              console.error('❌ Error checking Smart Cart feature status:', error);
              safeSendResponse({ success: false, error: error.message });
            });
          return true; // Will respond asynchronously

        } else if (request.action === 'update_smart_cart_quantity') {
          // Update item quantity in Smart Cart - check if feature is enabled
          ExtensionCore.BrowserCompat.safeStorageGet(['smartCartEnabled'], { smartCartEnabled: false })
            .then(smartCartSettings => {
              if (!smartCartSettings.smartCartEnabled) {
                safeSendResponse({ success: false, error: 'Smart Cart feature is disabled' });
                return;
              }

              if (this.services.smartCartManager && request.itemId && request.quantity !== undefined) {
                this.services.smartCartManager.updateItemQuantity(request.itemId, request.quantity)
                  .then(() => {
                    safeSendResponse({ success: true });
                  })
                  .catch((error) => {
                    console.error('❌ Error updating item quantity in Smart Cart:', error);
                    safeSendResponse({ success: false, error: error.message });
                  });
              } else {
                safeSendResponse({ success: false, error: 'Smart Cart Manager not available or missing parameters' });
              }
            })
            .catch(error => {
              console.error('❌ Error checking Smart Cart feature status:', error);
              safeSendResponse({ success: false, error: error.message });
            });
          return true; // Will respond asynchronously

        } else {
          // Unknown action
          safeSendResponse({ success: false, error: 'Unknown action: ' + request.action });
          return false;
        }
      } catch (error) {
        console.error('❌ Message handler error:', error);
        safeSendResponse({ success: false, error: 'Message handler error: ' + error.message });
        return false;
      }
    };

    // Register the message listener (exactly like original)
    try {
      chrome.runtime.onMessage.addListener(this.messageListener);
      console.log('📡 Message listener registered for popup communication');
    } catch (error) {
      console.warn('❌ Failed to register message listener:', error);
    }
  }

  clearAllExtensionElements() {
    // Remove all extension-added elements from the page (including legacy and new elements)
    console.log('🧹 Starting comprehensive extension element cleanup...');
    
    // Core price display elements
    const priceElements = [
      '.monthly-price-section',        // Legacy - kept for cleanup of existing elements
      '.monthly-price-info',           // New preferred class
      '.monthly-price-main-section',
      '.cart-monthly-price-info',
      '.cart-current-price-info',      // Cart current price displays
      '.cart-fallback-price-info',     // Cart fallback price displays
      '.cart-price-info-container',    // Cart price container elements
      '.seller-price-section',
      '.seller-price-info',            // Seller price info sections
      '.seller-updated-indicator',
      '.seller-unavailable-indicator',
      '.seller-shipping-cost',         // Seller shipping cost elements
      '.shipping-cost-info',           // General shipping cost info
      '.cart-selected-shipping-info',  // Cart page selected seller shipping
      '.order-current-price-info',     // Order page current price elements
      '.watchlist-item',               // Watchlist elements from popup
      '.watchlist-header',             // Watchlist headers
      '.watchlist-product-info',       // Watchlist product info
      '.watchlist-title',              // Watchlist titles
      '.watchlist-conditions',         // Watchlist conditions
      '.smart-cart-button-container',  // Smart Cart button containers
      '.smart-cart-button',            // Smart Cart buttons
      '.smart-cart-variant-info'       // Smart Cart variant info
    ];

    // Welcome guide elements
    const welcomeElements = [
      '#prizo-welcome-guide',          // Main welcome guide container
      '.prizo-welcome-overlay',        // Welcome guide overlay
      '.prizo-welcome-modal',          // Welcome guide modal
      '.prizo-welcome-header',         // Welcome guide components
      '.prizo-welcome-content',
      '.prizo-welcome-footer',
      '.prizo-welcome-step-content'
    ];

    // Notification elements
    const notificationElements = [
      '.extension-notification',       // General extension notifications
      '.notification-success',         // Success notifications
      '.notification-error',           // Error notifications
      '.notification-warning',         // Warning notifications
      '.notification-info',            // Info notifications
      '.prizo-notification',           // Prizo-specific notifications
      '.prizo-toast',                  // Toast notifications
      '.extension-toast'               // Extension toast notifications
    ];

    // Style elements added by extension
    const styleElements = [
      '#prizo-welcome-styles',         // Welcome guide styles
      'style[data-prizo]',            // Any extension-added styles
      'style[data-extension="prizo"]' // Alternative style marking
    ];

    // UI control elements that might be injected into pages
    const controlElements = [
      '.extension-controls',           // General extension control panels
      '.prizo-controls',              // Prizo-specific controls
      '.extension-toolbar',           // Extension toolbars
      '.extension-floating-menu',     // Floating menus
      '.extension-overlay-controls',  // Overlay control panels
      '.extension-emergency-stop',    // Emergency stop UI
      '.extension-status-indicator'   // Status indicators
    ];

    // Combine all selectors
    const allExtensionElements = [
      ...priceElements,
      ...welcomeElements, 
      ...notificationElements,
      ...styleElements,
      ...controlElements
    ];

    // Remove elements by selectors
    let removedCount = 0;
    allExtensionElements.forEach(selector => {
      try {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
          element.remove();
          removedCount++;
        });
      } catch (error) {
        console.warn(`⚠️ Error removing elements with selector ${selector}:`, error);
      }
    });

    // Remove elements with data-prizo attributes (comprehensive cleanup)
    try {
      const prizoElements = document.querySelectorAll('[data-prizo], [data-extension="prizo"], [class*="prizo-"]');
      prizoElements.forEach(element => {
        element.remove();
        removedCount++;
      });
    } catch (error) {
      console.warn('⚠️ Error removing prizo data attribute elements:', error);
    }

    // Remove any overlay or modal elements that might be lingering
    try {
      const overlays = document.querySelectorAll('.overlay, .modal-overlay, [style*="z-index: 999"], [style*="z-index: 9999"]');
      overlays.forEach(overlay => {
        // Only remove if it looks like it's from our extension
        if (overlay.innerHTML && (overlay.innerHTML.includes('prizo') || 
                                  overlay.innerHTML.includes('Prizo') ||
                                  overlay.innerHTML.includes('کمترین قیمت') ||
                                  overlay.innerHTML.includes('ماهانه'))) {
          overlay.remove();
          removedCount++;
        }
      });
    } catch (error) {
      console.warn('⚠️ Error removing potential extension overlays:', error);
    }

    // Force cleanup of any remaining extension artifacts
    try {
      // Remove any elements containing extension-specific text
      const textElements = document.querySelectorAll('*');
      const extensionTextPatterns = [
        'کمترین قیمت ۳۰ روز',
        'Prizo',
        'قیمت فروشنده',
        'هزینه ارسال',
        'ارسال انتخابی',
        'فروشنده انتخابی',
        'قیمت فعلی',
        'به‌روزرسانی قیمت',
        'نظارت قیمت',
        'ماهانه',
        'shipping cost',
        'seller price',
        'current price'
      ];
      
      const extensionClassPatterns = [
        'monthly', 'seller', 'cart', 'order', 'prizo', 'watchlist', 'shipping', 'extension'
      ];
      
      textElements.forEach(element => {
        if (element.children.length === 0 && element.textContent) {
          const hasExtensionText = extensionTextPatterns.some(pattern => 
            element.textContent.includes(pattern)
          );
          const hasExtensionClass = extensionClassPatterns.some(pattern => 
            element.classList.toString().includes(pattern)
          );
          
          if (hasExtensionText || hasExtensionClass) {
            const parent = element.parentElement;
            if (parent && (parent.classList.contains('monthly-price-info') ||
                          parent.classList.contains('cart-monthly-price-info') ||
                          parent.classList.contains('seller-price-section') ||
                          parent.classList.contains('seller-price-info') ||
                          parent.classList.contains('shipping-cost-info') ||
                          parent.classList.contains('cart-selected-shipping-info') ||
                          parent.classList.contains('order-current-price-info') ||
                          parent.classList.contains('watchlist-item'))) {
              parent.remove();
              removedCount++;
            }
          }
        }
      });
    } catch (error) {
      console.warn('⚠️ Error in text-based cleanup:', error);
    }

    console.log(`🧹 Extension cleanup completed: ${removedCount} elements removed`);
    
    // Final consistency check - remove any remaining suspicious elements
    const consistencyRemovedCount = this.performConsistencyCheck();
    
    const totalRemoved = removedCount + consistencyRemovedCount;
    console.log(`🧹 Total cleanup completed: ${totalRemoved} elements removed`);

    // Dispatch cleanup event for any listening components
    try {
      window.dispatchEvent(new CustomEvent('prizoCleanupComplete', {
        detail: { removedCount: totalRemoved, basicRemoved: removedCount, consistencyRemoved: consistencyRemovedCount }
      }));
    } catch (error) {
      console.warn('⚠️ Error dispatching cleanup event:', error);
    }
  }

  // Consistency check to ensure no extension elements remain
  performConsistencyCheck() {
    console.log('🔍 Performing final consistency check...');
    
    let consistencyRemovedCount = 0;
    
    try {
      // Check for any remaining elements that might have been missed
      const suspiciousSelectors = [
        // Additional selectors that might be missed
        'div[style*="background: linear-gradient"][style*="monthly"]',
        'div[style*="background: linear-gradient"][style*="cart"]',
        'div[style*="background: linear-gradient"][style*="seller"]',
        'div[style*="background: linear-gradient"][style*="shipping"]',
        '*[class*="monthly-"]:not([class*="digikala"])',
        '*[class*="cart-"]:not([class*="digikala"])',
        '*[class*="seller-"]:not([class*="digikala"])',
        '*[class*="shipping-"]:not([class*="digikala"])',
        '*[class*="watchlist-"]:not([class*="digikala"])',
        '*[class*="order-"]:not([class*="digikala"])',
        '*[class*="extension-"]:not([class*="digikala"])',
        '*[id*="prizo"]',
        '*[data-prizo]',
        '*[data-extension="prizo"]',
        '*[data-watchlist]',
        'button[data-action*="prizo"]',
        'div[data-feature*="prizo"]'
      ];
      
      suspiciousSelectors.forEach(selector => {
        try {
          const elements = document.querySelectorAll(selector);
          elements.forEach(element => {
            // Additional safety check - verify it's actually from our extension
            const isDefinitelyExtension = 
              element.getAttribute('data-prizo') ||
              element.id.includes('prizo') ||
              (element.textContent && (
                element.textContent.includes('کمترین قیمت ۳۰ روز') ||
                element.textContent.includes('Prizo') ||
                element.textContent.includes('ماهانه')
              )) ||
              (element.className && (
                element.className.includes('monthly-price') ||
                element.className.includes('cart-monthly') ||
                element.className.includes('seller-price') ||
                element.className.includes('extension-notification')
              ));
              
            if (isDefinitelyExtension) {
              element.remove();
              consistencyRemovedCount++;
            }
          });
        } catch (selectorError) {
          console.warn(`⚠️ Error with selector ${selector}:`, selectorError);
        }
      });
      
      if (consistencyRemovedCount > 0) {
        console.log(`🔍 Consistency check removed ${consistencyRemovedCount} additional elements`);
      } else {
        console.log('✅ Consistency check: No additional elements found to remove');
      }
      
    } catch (error) {
      console.warn('⚠️ Error in consistency check:', error);
    }
    
    return consistencyRemovedCount;
  }

  // Specific cleanup methods for different page types
  clearCartSpecificElements() {
    console.log('🛍 Clearing cart-specific elements...');
    const cartSelectors = [
      '.cart-monthly-price-info',
      '.cart-current-price-info', 
      '.cart-fallback-price-info',
      '.cart-price-info-container',
      '.cart-selected-shipping-info', // Cart page selected seller shipping
      '.order-current-price-info',    // Order page current price elements
      '[data-cart-prizo]',
      '.cart-item [class*="monthly"]',
      '.cart-item [class*="prizo"]',
      '.order-item [class*="monthly"]', // Order items with monthly price
      '.order-item [class*="prizo"]'    // Order items with prizo data
    ];
    
    this.removeElementsBySelectors(cartSelectors, 'cart');
  }

  clearSellerSpecificElements() {
    console.log('🏦 Clearing seller-specific elements...');
    const sellerSelectors = [
      '.seller-price-section',
      '.seller-updated-indicator',
      '.seller-unavailable-indicator',
      '[data-seller-prizo]',
      '.seller-variant [class*="monthly"]',
      '.seller-variant [class*="prizo"]'
    ];
    
    this.removeElementsBySelectors(sellerSelectors, 'seller');
  }

  clearMonthlySpecificElements() {
    console.log('📈 Clearing monthly price elements...');
    const monthlySelectors = [
      '.monthly-price-section',
      '.monthly-price-info',
      '.monthly-price-main-section',
      '[data-monthly-prizo]',
      '.product-card [class*="monthly"]',
      '.product-item [class*="monthly"]'
    ];
    
    this.removeElementsBySelectors(monthlySelectors, 'monthly');
  }

  removeAllSmartCartElements() {
    console.log('🧹 Removing all Smart Cart elements...');
    const smartCartSelectors = [
      '.smart-cart-button-container',
      '.smart-cart-button',
      '.smart-cart-variant-info',
      '.smart-cart-popup',
      '.smart-cart-overlay',
      '.smart-cart-modal',
      '.smart-cart-notification',
      '[data-smart-cart]',
      '[class*="smart-cart-"]',
      '[id*="smart-cart"]'
    ];

    this.removeElementsBySelectors(smartCartSelectors, 'smart-cart');

    // Also remove from the clearAllExtensionElements list
    try {
      const smartCartElements = document.querySelectorAll('[data-component="smart-cart"], [data-feature="smart-cart"]');
      smartCartElements.forEach(element => {
        element.remove();
      });
    } catch (error) {
      console.warn('⚠️ Error removing smart cart data attribute elements:', error);
    }
  }

  removeElementsBySelectors(selectors, type) {
    let removedCount = 0;
    selectors.forEach(selector => {
      try {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
          element.remove();
          removedCount++;
        });
      } catch (error) {
        console.warn(`⚠️ Error removing ${type} elements with selector ${selector}:`, error);
      }
    });
    console.log(`✅ Removed ${removedCount} ${type}-specific elements`);
  }

  // Cleanup method
  async destroy() {
    console.log('🧹 Destroying Prizo extension');
    
    // Remove message listener (exactly like original)
    if (this.messageListener) {
      try {
        chrome.runtime.onMessage.removeListener(this.messageListener);
        this.messageListener = null;
      } catch (error) {
        console.log('ℹ️ Message listener already removed or invalid');
      }
    }
    
    if (this.currentController) {
      await this.currentController.deactivate();
      this.currentController = null;
    }
    
    // Clean up services
    Object.values(this.services).forEach(service => {
      if (service.cleanup) {
        service.cleanup();
      }
    });
    
    // Clear timeouts
    if (this.pageChangeTimeout) {
      clearTimeout(this.pageChangeTimeout);
    }
    
    this.services = {};
    this.isInitialized = false;
    
    console.log('✅ Extension destroyed');
  }
}

// Global instance
let digikalaExtension = null;

// Initialize extension when DOM is ready
function initializeExtension() {
  if (digikalaExtension) {
    console.log('⚠️ Extension already initialized');
    return;
  }
  
  digikalaExtension = new PrizoExtension();
  
  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      digikalaExtension.initialize().catch(console.error);
    });
  } else {
    // DOM is already ready
    setTimeout(() => {
      digikalaExtension.initialize().catch(console.error);
    }, 100);
  }
}

// Export for external access
window.digikalaExtension = digikalaExtension;
window.PrizoExtension = PrizoExtension;

// Auto-initialize
initializeExtension();

console.log('📦 Prizo Extension v2.0 loaded - Modular Architecture');