/**
 * @Author: Zana Saedpanah
 * @Date:   2025-07-20
 * Storage management module with fallback support
 */

class StorageManager {
  constructor() {
    this.isAvailable = true;
    this.fallbackStorage = new Map();
    this.storagePrefix = 'digikala_extension_';
    this.availabilityCheckPromise = null;
  }

  async checkAvailability() {
    if (this.availabilityCheckPromise) {
      return this.availabilityCheckPromise;
    }

    this.availabilityCheckPromise = this._performAvailabilityCheck()
      .then(result => {
        this.availabilityCheckPromise = null;
        return result;
      })
      .catch(error => {
        this.availabilityCheckPromise = null;
        throw error;
      });

    return this.availabilityCheckPromise;
  }

  async _performAvailabilityCheck() {
    try {
      if (!BrowserCompat.supportsExtensionAPI()) {
        console.log('📱 Extension API not supported, using fallback storage');
        this.isAvailable = false;
        return false;
      }
      
      await chrome.storage.local.get(['test_key']);
      this.isAvailable = true;
      return true;
    } catch (error) {
      console.warn('⚠️ Chrome storage unavailable, using fallback:', error);
      this.isAvailable = false;
      
      if (window.EnhancedErrorHandler) {
        const errorHandler = new window.EnhancedErrorHandler();
        await errorHandler.handleError(error, 'STORAGE_AVAILABILITY_CHECK', {
          rethrow: false
        });
      }
      
      return false;
    }
  }

  validateKey(key) {
    if (typeof key !== 'string' || key.length === 0) {
      throw new Error('Storage key must be a non-empty string');
    }

    if (key.length > 256) {
      throw new Error('Storage key too long (max 256 characters)');
    }

    return this.storagePrefix + key;
  }

  async get(keys, defaultValues = {}) {
    try {
      if (!this.isAvailable) {
        await this.checkAvailability();
      }

      const keyArray = Array.isArray(keys) ? keys : [keys];
      const validatedKeys = keyArray.map(key => this.validateKey(key));

      if (this.isAvailable) {
        const result = await BrowserCompat.safeStorageGet(validatedKeys, {});

        const cleanResult = {};
        keyArray.forEach((originalKey, index) => {
          const validatedKey = validatedKeys[index];
          cleanResult[originalKey] = result[validatedKey] !== undefined
            ? result[validatedKey]
            : defaultValues[originalKey];
        });

        return cleanResult;
      } else {
        const result = {};
        keyArray.forEach(key => {
          const validatedKey = this.validateKey(key);
          result[key] = this.fallbackStorage.has(validatedKey)
            ? this.fallbackStorage.get(validatedKey)
            : defaultValues[key];
        });

        return result;
      }
    } catch (error) {
      console.error('❌ Storage get error:', error);

      const result = {};
      const keyArray = Array.isArray(keys) ? keys : [keys];
      keyArray.forEach(key => {
        result[key] = defaultValues[key];
      });

      return result;
    }
  }

  resetAvailabilityCheck() {
    this.availabilityCheckPromise = null;
    this.isAvailable = true;
  }

  async set(items) {
    try {
      if (!this.isAvailable) {
        await this.checkAvailability();
      }

      const validatedItems = {};
      for (const [key, value] of Object.entries(items)) {
        const validatedKey = this.validateKey(key);

        const serialized = JSON.stringify(value);
        if (serialized.length > 8192) {
          throw new Error(`Value too large for key "${key}" (max 8KB)`);
        }

        validatedItems[validatedKey] = value;
      }

      if (this.isAvailable) {
        const success = await BrowserCompat.safeStorageSet(validatedItems);
        if (success) {
          console.log('✅ Storage set successful:', Object.keys(items));
        } else {
          this.isAvailable = false;
          for (const [key, value] of Object.entries(validatedItems)) {
            this.fallbackStorage.set(key, value);
          }
          console.log('✅ Fallback storage set after API failure:', Object.keys(items));
        }
      } else {
        for (const [key, value] of Object.entries(validatedItems)) {
          this.fallbackStorage.set(key, value);
        }
        console.log('✅ Fallback storage set successful:', Object.keys(items));
      }

      return true;
    } catch (error) {
      console.error('❌ Storage set error:', error);
      throw new Error(`Storage operation failed: ${error.message}`);
    }
  }

  async remove(keys) {
    try {
      if (!this.isAvailable) {
        await this.checkAvailability();
      }

      const keyArray = Array.isArray(keys) ? keys : [keys];
      const validatedKeys = keyArray.map(key => this.validateKey(key));

      if (this.isAvailable) {
        await chrome.storage.local.remove(validatedKeys);
        console.log('✅ Storage remove successful:', keyArray);
      } else {
        validatedKeys.forEach(key => {
          this.fallbackStorage.delete(key);
        });
        console.log('✅ Fallback storage remove successful:', keyArray);
      }

      return true;
    } catch (error) {
      console.error('❌ Storage remove error:', error);
      throw new Error(`Storage remove failed: ${error.message}`);
    }
  }

  async clearByPattern(pattern) {
    try {
      if (!this.isAvailable) {
        await this.checkAvailability();
      }

      if (this.isAvailable) {
        const allStorage = await chrome.storage.local.get(null);
        const keysToRemove = Object.keys(allStorage).filter(key => {
          const cleanKey = key.startsWith(this.storagePrefix)
            ? key.substring(this.storagePrefix.length)
            : key;
          return pattern.test(cleanKey);
        });

        if (keysToRemove.length > 0) {
          await chrome.storage.local.remove(keysToRemove);
          console.log(`✅ Cleared ${keysToRemove.length} items matching pattern`);
        }
      } else {
        const keysToRemove = Array.from(this.fallbackStorage.keys()).filter(key => {
          const cleanKey = key.startsWith(this.storagePrefix)
            ? key.substring(this.storagePrefix.length)
            : key;
          return pattern.test(cleanKey);
        });

        keysToRemove.forEach(key => {
          this.fallbackStorage.delete(key);
        });

        console.log(`✅ Cleared ${keysToRemove.length} fallback items matching pattern`);
      }

      return true;
    } catch (error) {
      console.error('❌ Storage clear error:', error);
      throw new Error(`Storage clear failed: ${error.message}`);
    }
  }
}

// Make available globally
window.StorageManager = StorageManager;