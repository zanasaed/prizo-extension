/**
 * @Author: Zana Saedpanahi
 * @Date: 2025-08-04
 * Validation Manager - Handles input validation, sanitization, and safety checks
 */
class ValidationManager {
  constructor() {
    this.allowedDomains = []; // Allow all domains for general use
    this.urlPatterns = {
      product: /\/(?:product|dp|item|p)\/(?:dkp-)?(\d+)\//,  // Support various product URL patterns
      digikalaApi: /api\.digikala\.com\/v\d+\/product\/(\d+)/,  // Keep Digikala API pattern for reference
      seller: /seller\/(\w+)/,
      genericProduct: /\/(?:product|item)\/(\d+)/  // Generic product pattern
    };
  }

  validateURL(url) {
    if (!url || typeof url !== 'string') {
      return { valid: false, reason: 'Invalid URL format' };
    }

    try {
      const urlObj = new URL(url);
      
      // Allow all domains now - remove the domain restriction
      // if (!this.allowedDomains.some(domain => urlObj.hostname.includes(domain))) {
      //   return { valid: false, reason: 'Domain not allowed' };
      // }

      return { valid: true };
    } catch (error) {
      return { valid: false, reason: 'Malformed URL' };
    }
  }

  validateProductId(productId) {
    if (!productId) {
      return { valid: false, reason: 'Product ID is required' };
    }

    if (typeof productId !== 'string' && typeof productId !== 'number') {
      return { valid: false, reason: 'Product ID must be string or number' };
    }

    const id = String(productId).trim();
    
    if (!/^\d+$/.test(id)) {
      return { valid: false, reason: 'Product ID must contain only digits' };
    }

    if (id.length < 3 || id.length > 12) {
      return { valid: false, reason: 'Product ID length must be between 3-12 characters' };
    }

    return { valid: true, productId: id };
  }

  validateSellerCode(sellerCode) {
    if (!sellerCode) {
      return { valid: false, reason: 'Seller code is required' };
    }

    if (typeof sellerCode !== 'string') {
      return { valid: false, reason: 'Seller code must be a string' };
    }

    const code = sellerCode.trim();
    
    if (!/^[a-zA-Z0-9_-]+$/.test(code)) {
      return { valid: false, reason: 'Seller code contains invalid characters' };
    }

    if (code.length < 2 || code.length > 50) {
      return { valid: false, reason: 'Seller code length must be between 2-50 characters' };
    }

    return { valid: true, sellerCode: code };
  }

  validatePrice(price) {
    if (price === null || price === undefined) {
      return { valid: false, reason: 'Price is required' };
    }

    const numPrice = Number(price);
    
    if (isNaN(numPrice)) {
      return { valid: false, reason: 'Price must be a number' };
    }

    if (numPrice < 0) {
      return { valid: false, reason: 'Price cannot be negative' };
    }

    if (numPrice > 999999999) {
      return { valid: false, reason: 'Price exceeds maximum allowed value' };
    }

    return { valid: true, price: numPrice };
  }

  validateDiscountPercent(discountPercent) {
    if (discountPercent === null || discountPercent === undefined) {
      return { valid: true, discountPercent: 0 };
    }

    const numDiscount = Number(discountPercent);
    
    if (isNaN(numDiscount)) {
      return { valid: false, reason: 'Discount percent must be a number' };
    }

    if (numDiscount < 0 || numDiscount > 100) {
      return { valid: false, reason: 'Discount percent must be between 0-100' };
    }

    return { valid: true, discountPercent: numDiscount };
  }

  validateProductData(productData) {
    if (!productData || typeof productData !== 'object') {
      return { valid: false, reason: 'Product data must be an object' };
    }

    if (!productData.variants || !Array.isArray(productData.variants)) {
      return { valid: false, reason: 'Product data must contain variants array' };
    }

    if (productData.variants.length === 0) {
      return { valid: false, reason: 'Product must have at least one variant' };
    }

    // Validate each variant
    for (let i = 0; i < productData.variants.length; i++) {
      const variant = productData.variants[i];
      
      if (!variant || typeof variant !== 'object') {
        return { valid: false, reason: `Variant ${i} is invalid` };
      }

      if (variant.price && typeof variant.price === 'object') {
        const priceValidation = this.validatePrice(variant.price.selling_price);
        if (!priceValidation.valid) {
          return { valid: false, reason: `Variant ${i} price is invalid: ${priceValidation.reason}` };
        }
      }
    }

    return { valid: true };
  }

  validateAPIResponse(response) {
    if (!response || typeof response !== 'object') {
      return { valid: false, reason: 'Response must be an object' };
    }

    if (typeof response.success !== 'boolean') {
      return { valid: false, reason: 'Response must have success boolean' };
    }

    if (response.success) {
      if (!response.data) {
        return { valid: false, reason: 'Successful response must have data' };
      }
    } else {
      if (!response.error) {
        return { valid: false, reason: 'Failed response must have error message' };
      }
    }

    return { valid: true };
  }

  sanitizeText(text) {
    if (typeof text !== 'string') {
      return String(text || '');
    }

    return text
      .replace(/[<>]/g, match => match === '<' ? '&lt;' : '&gt;')
      .replace(/javascript:|data:|vbscript:/gi, '')
      .trim();
  }

  sanitizeNumber(value, options = {}) {
    const { min = 0, max = Number.MAX_SAFE_INTEGER, defaultValue = 0 } = options;
    
    const num = Number(value);
    
    if (isNaN(num)) {
      return defaultValue;
    }

    return Math.max(min, Math.min(max, num));
  }

  sanitizeHTML(html) {
    if (typeof html !== 'string') {
      return '';
    }

    // Remove script tags and dangerous attributes
    return html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/javascript:|data:|vbscript:/gi, '')
      .replace(/on\w+\s*=/gi, '')
      .trim();
  }

  validateCSS(cssText) {
    if (typeof cssText !== 'string') {
      return { valid: false, reason: 'CSS must be a string' };
    }

    // Check for dangerous CSS
    const dangerousPatterns = [
      /javascript:/gi,
      /expression\s*\(/gi,
      /@import/gi,
      /behavior\s*:/gi,
      /binding\s*:/gi
    ];

    for (const pattern of dangerousPatterns) {
      if (pattern.test(cssText)) {
        return { valid: false, reason: 'CSS contains dangerous content' };
      }
    }

    return { valid: true, css: cssText };
  }

  validateAttributeName(name) {
    if (typeof name !== 'string') {
      return { valid: false, reason: 'Attribute name must be a string' };
    }

    const allowedAttributes = [
      'class', 'id', 'style', 'title', 'alt', 'src', 'href',
      'role', 'tabindex', 'dir', 'lang', 'data-'
    ];

    const isAllowed = allowedAttributes.some(attr => 
      name === attr || 
      (attr.endsWith('-') && name.startsWith(attr)) ||
      name.startsWith('aria-')
    );

    if (!isAllowed) {
      return { valid: false, reason: 'Attribute not allowed' };
    }

    return { valid: true };
  }

  validatePageType(pageType) {
    const allowedPageTypes = [
      'product', 'search', 'category', 'seller', 'cart', 'wishlist', 'unknown'
    ];

    if (!allowedPageTypes.includes(pageType)) {
      return { valid: false, reason: 'Invalid page type' };
    }

    return { valid: true, pageType };
  }

  validateBatchSize(batchSize, options = {}) {
    const { min = 1, max = 50, defaultValue = 10 } = options;
    
    const size = Number(batchSize);
    
    if (isNaN(size)) {
      return { valid: true, batchSize: defaultValue };
    }

    if (size < min || size > max) {
      return { valid: false, reason: `Batch size must be between ${min}-${max}` };
    }

    return { valid: true, batchSize: size };
  }

  validateTimeout(timeout, options = {}) {
    const { min = 1000, max = 60000, defaultValue = 15000 } = options;
    
    const time = Number(timeout);
    
    if (isNaN(time)) {
      return { valid: true, timeout: defaultValue };
    }

    if (time < min || time > max) {
      return { valid: false, reason: `Timeout must be between ${min}-${max}ms` };
    }

    return { valid: true, timeout: time };
  }

  isValidJSON(jsonString) {
    try {
      JSON.parse(jsonString);
      return { valid: true };
    } catch (error) {
      return { valid: false, reason: 'Invalid JSON format' };
    }
  }

  validateStorageKey(key) {
    if (typeof key !== 'string') {
      return { valid: false, reason: 'Storage key must be a string' };
    }

    if (key.length === 0 || key.length > 100) {
      return { valid: false, reason: 'Storage key length must be between 1-100 characters' };
    }

    if (!/^[a-zA-Z0-9_.-]+$/.test(key)) {
      return { valid: false, reason: 'Storage key contains invalid characters' };
    }

    return { valid: true, key };
  }

  validateRetryCount(retryCount, maxRetries = 5) {
    const count = Number(retryCount);
    
    if (isNaN(count)) {
      return { valid: false, reason: 'Retry count must be a number' };
    }

    if (count < 0 || count > maxRetries) {
      return { valid: false, reason: `Retry count must be between 0-${maxRetries}` };
    }

    return { valid: true, retryCount: count };
  }

  extractProductIdFromURL(url) {
    const validation = this.validateURL(url);
    if (!validation.valid) {
      return { valid: false, reason: validation.reason };
    }

    for (const [type, pattern] of Object.entries(this.urlPatterns)) {
      const match = url.match(pattern);
      if (match && match[1]) {
        const productIdValidation = this.validateProductId(match[1]);
        if (productIdValidation.valid) {
          return { valid: true, productId: productIdValidation.productId, type };
        }
      }
    }

    return { valid: false, reason: 'No valid product ID found in URL' };
  }

  validateElementContext(element, context) {
    if (!element) {
      return { valid: false, reason: `Element is null/undefined in context: ${context}` };
    }

    if (!element.parentNode) {
      return { valid: false, reason: `Element is detached from DOM in context: ${context}` };
    }

    if (typeof element.querySelector !== 'function') {
      return { valid: false, reason: `Element is not a valid DOM element in context: ${context}` };
    }

    return { valid: true };
  }

  createValidationReport(validations) {
    const report = {
      valid: true,
      errors: [],
      warnings: [],
      summary: {
        total: validations.length,
        passed: 0,
        failed: 0
      }
    };

    for (const validation of validations) {
      if (validation.valid) {
        report.summary.passed++;
      } else {
        report.summary.failed++;
        report.valid = false;
        report.errors.push(validation.reason || 'Unknown validation error');
      }
    }

    return report;
  }
}

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.ValidationManager = ValidationManager;
}