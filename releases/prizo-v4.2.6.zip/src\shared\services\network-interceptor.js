/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-26
 * Network Interceptor Service
 * Intercepts Digikala's own API requests to avoid duplicate network calls
 */

class NetworkInterceptor {
  constructor() {
    this.interceptedData = new Map();
    this.interceptTimeout = 30000; // 30 seconds
    this.isActive = false;
    this.pendingPromises = new Map();

    // Known Digikala API patterns to intercept
    this.apiPatterns = [
      /api\.digikala\.com\/v[12]\/product\/(\d+)/,
      /www\.digikala\.com\/ajax\/product\/(\d+)/,
      /api\.digikala\.com\/fresh\/v1\/product\/(\d+)/
    ];
  }

  /**
   * Start intercepting network requests
   */
  activate() {
    if (this.isActive) {
      console.log('📡 Network interceptor already active');
      return;
    }

    console.log('🚀 Starting network request interception');
    this.isActive = true;

    // Override the global fetch function
    this.originalFetch = window.fetch;
    window.fetch = this.createFetchInterceptor();

    // Override XMLHttpRequest
    this.originalXHROpen = XMLHttpRequest.prototype.open;
    this.originalXHRSend = XMLHttpRequest.prototype.send;
    this.interceptXHR();

    console.log('✅ Network interceptor activated');
  }

  /**
   * Stop intercepting network requests
   */
  deactivate() {
    if (!this.isActive) {
      console.log('📡 Network interceptor already inactive');
      return;
    }

    console.log('🛑 Stopping network request interception');
    this.isActive = false;

    // Restore original fetch
    if (this.originalFetch) {
      window.fetch = this.originalFetch;
      this.originalFetch = null;
    }

    // Restore original XMLHttpRequest
    if (this.originalXHROpen && this.originalXHRSend) {
      XMLHttpRequest.prototype.open = this.originalXHROpen;
      XMLHttpRequest.prototype.send = this.originalXHRSend;
      this.originalXHROpen = null;
      this.originalXHRSend = null;
    }

    console.log('✅ Network interceptor deactivated');
  }

  /**
   * Create fetch interceptor
   */
  createFetchInterceptor() {
    const interceptor = this;
    const originalFetch = this.originalFetch;

    return async function(resource, options = {}) {
      const url = typeof resource === 'string' ? resource : resource.url;

      if (!interceptor.isActive || !interceptor.shouldIntercept(url)) {
        return originalFetch.call(this, resource, options);
      }

      const productId = interceptor.extractProductId(url);
      if (productId) {
        console.log(`🕵️ Intercepting fetch request for product ${productId}:`, url);
      }

      try {
        const response = await originalFetch.call(this, resource, options);

        if (response.ok && productId) {
          // Clone the response to avoid consuming it
          const clonedResponse = response.clone();
          interceptor.processResponse(url, clonedResponse, productId);
        }

        return response;
      } catch (error) {
        console.error('❌ Error in fetch interceptor:', error);
        throw error;
      }
    };
  }

  /**
   * Intercept XMLHttpRequest
   */
  interceptXHR() {
    const interceptor = this;
    const originalOpen = this.originalXHROpen;
    const originalSend = this.originalXHRSend;

    XMLHttpRequest.prototype.open = function(method, url, ...args) {
      this._interceptedUrl = url;
      return originalOpen.call(this, method, url, ...args);
    };

    XMLHttpRequest.prototype.send = function(...args) {
      if (!interceptor.isActive || !interceptor.shouldIntercept(this._interceptedUrl)) {
        return originalSend.call(this, ...args);
      }

      const productId = interceptor.extractProductId(this._interceptedUrl);
      if (productId) {
        console.log(`🕵️ Intercepting XHR request for product ${productId}:`, this._interceptedUrl);

        // Add event listener for response
        this.addEventListener('load', function() {
          if (this.status === 200 && this.responseText) {
            interceptor.processXHRResponse(this._interceptedUrl, this.responseText, productId);
          }
        });
      }

      return originalSend.call(this, ...args);
    };
  }

  /**
   * Check if URL should be intercepted
   */
  shouldIntercept(url) {
    if (!url || typeof url !== 'string') {
      return false;
    }

    return this.apiPatterns.some(pattern => pattern.test(url));
  }

  /**
   * Extract product ID from URL
   */
  extractProductId(url) {
    for (const pattern of this.apiPatterns) {
      const match = url.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }
    return null;
  }

  /**
   * Process intercepted fetch response
   */
  async processResponse(url, response, productId) {
    try {
      const data = await response.json();
      this.storeInterceptedData(productId, data, url);
    } catch (error) {
      console.warn('⚠️ Failed to parse intercepted response:', error);
    }
  }

  /**
   * Process intercepted XHR response
   */
  processXHRResponse(url, responseText, productId) {
    try {
      const data = JSON.parse(responseText);
      this.storeInterceptedData(productId, data, url);
    } catch (error) {
      console.warn('⚠️ Failed to parse intercepted XHR response:', error);
    }
  }

  /**
   * Store intercepted data with expiration
   */
  storeInterceptedData(productId, data, sourceUrl) {
    const timestamp = Date.now();
    const interceptedEntry = {
      productId,
      data: data, // Preserve full response structure to avoid losing shipping data
      sourceUrl,
      timestamp,
      expiresAt: timestamp + this.interceptTimeout
    };

    this.interceptedData.set(productId, interceptedEntry);

    console.log(`💾 Stored intercepted data for product ${productId} from ${sourceUrl}`);

    // Resolve any pending promises for this product
    if (this.pendingPromises.has(productId)) {
      const resolvers = this.pendingPromises.get(productId);
      resolvers.forEach(resolve => resolve(interceptedEntry.data));
      this.pendingPromises.delete(productId);
    }

    // Emit event for other components
    if (window.ExtensionCore && window.ExtensionCore.EventBus) {
      window.ExtensionCore.EventBus.emit('network-intercepted', {
        productId,
        data: interceptedEntry.data,
        sourceUrl
      });
    }

    // Clean up expired entries
    this.cleanupExpiredEntries();
  }

  /**
   * Get intercepted data for a product
   */
  getInterceptedData(productId) {
    const entry = this.interceptedData.get(productId);

    if (!entry) {
      return null;
    }

    // Check if data is still valid
    if (Date.now() > entry.expiresAt) {
      this.interceptedData.delete(productId);
      return null;
    }

    return entry.data;
  }

  /**
   * Wait for intercepted data (with timeout)
   */
  waitForInterceptedData(productId, timeout = 10000) {
    return new Promise((resolve) => {
      // Check if data is already available
      const existingData = this.getInterceptedData(productId);
      if (existingData) {
        resolve(existingData);
        return;
      }

      // Set up pending promise
      if (!this.pendingPromises.has(productId)) {
        this.pendingPromises.set(productId, []);
      }
      this.pendingPromises.get(productId).push(resolve);

      // Set timeout
      setTimeout(() => {
        const resolvers = this.pendingPromises.get(productId);
        if (resolvers) {
          const index = resolvers.indexOf(resolve);
          if (index > -1) {
            resolvers.splice(index, 1);
            if (resolvers.length === 0) {
              this.pendingPromises.delete(productId);
            }
          }
        }
        resolve(null);
      }, timeout);
    });
  }

  /**
   * Clean up expired intercepted data
   */
  cleanupExpiredEntries() {
    const now = Date.now();
    const expiredKeys = [];

    for (const [productId, entry] of this.interceptedData.entries()) {
      if (now > entry.expiresAt) {
        expiredKeys.push(productId);
      }
    }

    expiredKeys.forEach(key => {
      this.interceptedData.delete(key);
      console.log(`🗑️ Cleaned up expired intercepted data for product ${key}`);
    });
  }

  /**
   * Get all intercepted data (for debugging)
   */
  getAllInterceptedData() {
    const result = {};
    for (const [productId, entry] of this.interceptedData.entries()) {
      result[productId] = {
        sourceUrl: entry.sourceUrl,
        timestamp: entry.timestamp,
        dataSize: JSON.stringify(entry.data).length,
        isExpired: Date.now() > entry.expiresAt
      };
    }
    return result;
  }

  /**
   * Clear all intercepted data
   */
  clearInterceptedData() {
    this.interceptedData.clear();
    this.pendingPromises.clear();
    console.log('🗑️ Cleared all intercepted data');
  }

  /**
   * Check if data is available for a product
   */
  hasDataForProduct(productId) {
    return this.getInterceptedData(productId) !== null;
  }
}

// Export for use in other modules
window.NetworkInterceptor = NetworkInterceptor;

// Create global instance
if (!window.ExtensionCore) {
  window.ExtensionCore = {};
}
window.ExtensionCore.NetworkInterceptor = new NetworkInterceptor();

console.log('📡 Network Interceptor loaded');