/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Comparison Manager - Handles price comparison features and site management
 */

class ComparisonManager extends BaseModule {
  constructor(eventBus, domManager) {
    super('ComparisonManager', eventBus, domManager);

    this.comparisonSites = [];
    this.comparisonFeatureEnabled = false;
  }

  async initializeElements() {
    this.elements = this.domManager.getElements({
      // Comparison feature elements
      comparisonFeatureCheckbox: '#comparisonFeatureMode',
      comparisonToggleSwitchContainer: '#comparisonToggleSwitchContainer',
      comparisonSitesManagement: '#comparisonSitesManagement',

      // Site management elements
      comparisonSitesList: '#comparisonSitesList',
      addSiteBtn: '#addSiteBtn',
      addSiteForm: '#addSiteForm',
      popularSitesSelect: '#popularSites',
      siteNameInput: '#siteName',
      siteUrlInput: '#siteUrl',
      siteIconPreview: '#siteIconPreview',
      siteIconFallback: '#siteIconFallback',
      siteIconStatus: '#siteIconStatus',
      saveSiteBtn: '#saveSiteBtn',
      cancelSiteBtn: '#cancelSiteBtn'
    });

    const validation = this.domManager.validateElements(this.elements, ['comparisonFeatureCheckbox']);
    if (!validation.valid) {
      this.warn('Some comparison elements are missing:', validation.missing);
    }
  }

  async setupEventListeners() {
    // Listen for external events
    this.on('comparison:toggle-feature', (data) => this.handleComparisonFeatureToggle(data));
    this.on('comparison:load-sites', () => this.loadComparisonSites());
    this.on('comparison:add-site', (data) => this.handleAddSite(data));
    this.on('comparison:remove-site', (data) => this.handleRemoveSite(data));
    this.on('comparison:update-site', (data) => this.handleUpdateSite(data));

    // Setup UI event listeners
    this.setupComparisonEventListeners();
  }

  async loadInitialData() {
    await this.loadComparisonFeature();
    await this.loadComparisonSites();
  }

  setupComparisonEventListeners() {
    const {
      comparisonFeatureCheckbox, comparisonToggleSwitchContainer,
      addSiteBtn, saveSiteBtn, cancelSiteBtn,
      siteUrlInput, popularSitesSelect
    } = this.elements;

    // Feature toggle
    if (comparisonFeatureCheckbox) {
      this.domManager.addEventListener(comparisonFeatureCheckbox, 'change', () => this.handleComparisonFeatureToggle());
    }

    if (comparisonToggleSwitchContainer) {
      this.domManager.addEventListener(comparisonToggleSwitchContainer, 'click', () => {
        if (comparisonFeatureCheckbox) {
          comparisonFeatureCheckbox.checked = !comparisonFeatureCheckbox.checked;
          this.updateComparisonToggleSwitch();
          this.handleComparisonFeatureToggle();
        }
      });
    }

    // Site management
    if (addSiteBtn) {
      this.domManager.addEventListener(addSiteBtn, 'click', () => this.toggleAddSiteForm());
    }

    if (saveSiteBtn) {
      this.domManager.addEventListener(saveSiteBtn, 'click', () => this.handleSaveSite());
    }

    if (cancelSiteBtn) {
      this.domManager.addEventListener(cancelSiteBtn, 'click', () => this.hideAddSiteForm());
    }

    if (siteUrlInput) {
      this.domManager.addEventListener(siteUrlInput, 'input', () => this.updateFaviconPreview());
    }

    if (popularSitesSelect) {
      this.domManager.addEventListener(popularSitesSelect, 'change', () => this.handlePopularSiteSelect());
    }
  }

  // Feature management
  async loadComparisonFeature() {
    try {
      const enabled = await this.getStorage('digikala_extension_comparison_feature_enabled', true);
      this.comparisonFeatureEnabled = enabled;

      this.updateComparisonUI();

      this.log('Comparison feature loaded:', this.comparisonFeatureEnabled);
    } catch (error) {
      this.error('Error loading comparison feature:', error);
      this.comparisonFeatureEnabled = false;
    }
  }

  async handleComparisonFeatureToggle() {
    try {
      const { comparisonFeatureCheckbox } = this.elements;
      if (!comparisonFeatureCheckbox) return;

      this.comparisonFeatureEnabled = comparisonFeatureCheckbox.checked;
      this.updateComparisonToggleSwitch();
      this.updateComparisonManagementVisibility();

      // Save to storage
      await this.setStorage('digikala_extension_comparison_feature_enabled', this.comparisonFeatureEnabled);

      const status = this.comparisonFeatureEnabled ? 'فعال' : 'غیرفعال';
      this.showSuccess(`مقایسه قیمت ${status} شد`);

      this.emit('comparison:feature-toggled', {
        enabled: this.comparisonFeatureEnabled
      });

      this.log('Comparison feature toggled:', this.comparisonFeatureEnabled);
    } catch (error) {
      this.error('Error toggling comparison feature:', error);
      this.showError('خطا در تغییر وضعیت مقایسه قیمت');
    }
  }

  updateComparisonUI() {
    const { comparisonFeatureCheckbox } = this.elements;
    if (comparisonFeatureCheckbox) {
      comparisonFeatureCheckbox.checked = this.comparisonFeatureEnabled;
    }

    this.updateComparisonToggleSwitch();
    this.updateComparisonManagementVisibility();
  }

  updateComparisonToggleSwitch() {
    const { comparisonToggleSwitchContainer } = this.elements;
    if (comparisonToggleSwitchContainer) {
      this.domManager.toggleClass(comparisonToggleSwitchContainer, 'active', this.comparisonFeatureEnabled);
    }
  }

  updateComparisonManagementVisibility() {
    const { comparisonSitesManagement } = this.elements;
    if (comparisonSitesManagement) {
      this.domManager.toggle(comparisonSitesManagement, this.comparisonFeatureEnabled);
    }
  }

  // Sites management
  async loadComparisonSites() {
    try {
      const sites = await this.getStorage('digikala_extension_comparison_sites', this.getDefaultComparisonSites());
      this.comparisonSites = sites;

      this.log(`Loaded ${this.comparisonSites.length} comparison sites`);
      this.renderComparisonSites();

      this.emit('comparison:sites-loaded', { sites: this.comparisonSites });
    } catch (error) {
      this.error('Error loading comparison sites:', error);
      this.comparisonSites = this.getDefaultComparisonSites();
      this.log(`Using default comparison sites (${this.comparisonSites.length})`);
      this.renderComparisonSites();
    }
  }

  getDefaultComparisonSites() {
    return [
      {
        id: 'torob',
        name: 'Torob',
        url: 'https://torob.com/search/?query=PRODUCT_NAME',
        faviconUrl: 'https://torob.com/favicon.ico'
      },
      {
        id: 'digikalajet',
        name: 'DigiKala Jet',
        url: 'https://www.digikalajet.com/search/v2/result?q=PRODUCT_NAME',
        faviconUrl: 'https://www.digikalajet.com/favicon.ico'
      },
      {
        id: 'janebi',
        name: 'Janebi',
        url: 'https://janebi.com/search?q=PRODUCT_NAME',
        faviconUrl: 'https://janebi.com/favicon.ico'
      },
      {
        id: 'emalls',
        name: 'Emalls',
        url: 'https://www.emalls.ir/search?q=PRODUCT_NAME',
        faviconUrl: 'https://www.emalls.ir/favicon.ico'
      }
    ];
  }

  async saveComparisonSites() {
    try {
      await this.setStorage('digikala_extension_comparison_sites', this.comparisonSites);
      this.emit('comparison:sites-saved', { sites: this.comparisonSites });
    } catch (error) {
      this.error('Error saving comparison sites:', error);
    }
  }

  renderComparisonSites() {
    const { comparisonSitesList } = this.elements;
    if (!comparisonSitesList) return;

    if (this.comparisonSites.length === 0) {
      this.domManager.setHTML(comparisonSitesList, this.getEmptySitesHTML());
      return;
    }

    const sitesHTML = this.comparisonSites.map(site => this.generateSiteHTML(site)).join('');
    this.domManager.setHTML(comparisonSitesList, sitesHTML);

    this.setupSiteEventHandlers();
  }

  getEmptySitesHTML() {
    return `
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <h4>هیچ سایت مقایسه‌ای تعریف نشده</h4>
        <p>برای شروع مقایسه قیمت، سایت‌های مورد نظر خود را اضافه کنید</p>
      </div>
    `;
  }

  generateSiteHTML(site) {
    return `
      <div class="comparison-site-item" data-site-id="${site.id}">
        <div class="comparison-site-info">
          <div class="comparison-site-icon">
            <img src="${site.faviconUrl}" alt="${site.name}" class="site-favicon">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" style="display: none;" class="site-fallback-icon">
              <path d="M10.59 13.41c.41.39.41 1.03 0 1.42-.39.39-1.03.39-1.42 0a5.003 5.003 0 0 1 0-7.07l3.54-3.54a5.003 5.003 0 0 1 7.07 0 5.003 5.003 0 0 1 0 7.07l-1.49 1.49c.01-.82-.12-1.64-.4-2.42l.47-.48a2.982 2.982 0 0 0 0-4.24 2.982 2.982 0 0 0-4.24 0l-3.53 3.53a2.982 2.982 0 0 0 0 4.24zm2.82-4.24c.39-.39 1.03-.39 1.42 0a5.003 5.003 0 0 1 0 7.07l-3.54 3.54a5.003 5.003 0 0 1-7.07 0 5.003 5.003 0 0 1 0-7.07l1.49-1.49c-.01.82.12 1.64.4 2.42l-.47.48a2.982 2.982 0 0 0 0 4.24 2.982 2.982 0 0 0 4.24 0l3.53-3.53a2.982 2.982 0 0 0 0-4.24.973.973 0 0 1 0-1.42z" />
            </svg>
          </div>
          <div class="comparison-site-details">
            <div class="comparison-site-name">${site.name}</div>
            <div class="comparison-site-url">${this.truncateUrl(site.url)}</div>
          </div>
        </div>
        <div class="comparison-site-actions">
          <button class="comparison-site-action edit" title="ویرایش سایت" data-site-id="${site.id}">
            ✏️
          </button>
          <button class="comparison-site-action delete" title="حذف سایت" data-site-id="${site.id}">
            🗑️
          </button>
        </div>
      </div>
    `;
  }

  setupSiteEventHandlers() {
    const { comparisonSitesList } = this.elements;
    if (!comparisonSitesList) return;

    // Remove site buttons
    const removeButtons = comparisonSitesList.querySelectorAll('.comparison-site-action.delete');
    removeButtons.forEach(btn => {
      this.domManager.addEventListener(btn, 'click', () => {
        const siteId = btn.dataset.siteId;
        this.handleRemoveSite({ id: siteId });
      });
    });

    // Edit site buttons
    const editButtons = comparisonSitesList.querySelectorAll('.comparison-site-action.edit');
    editButtons.forEach(btn => {
      this.domManager.addEventListener(btn, 'click', () => {
        const siteId = btn.dataset.siteId;
        this.handleEditSite(siteId);
      });
    });

    // Handle image error fallback
    const faviconImages = comparisonSitesList.querySelectorAll('.site-favicon');
    faviconImages.forEach(img => {
      this.domManager.addEventListener(img, 'error', () => {
        img.style.display = 'none';
        const fallbackIcon = img.nextElementSibling;
        if (fallbackIcon && fallbackIcon.classList.contains('site-fallback-icon')) {
          fallbackIcon.style.display = 'flex';
        }
      });
    });
  }

  truncateUrl(url) {
    if (url.length > 50) {
      return url.substring(0, 47) + '...';
    }
    return url;
  }

  // Site operations
  async handleAddSite(data) {
    const { name, url } = data;

    if (!this.validateSiteData(name, url)) {
      return false;
    }

    const newSite = {
      id: this.generateSiteId(),
      name: name.trim(),
      url: url.trim(),
      faviconUrl: this.getFaviconUrl(url)
    };

    this.comparisonSites.push(newSite);
    await this.saveComparisonSites();
    this.renderComparisonSites();

    this.showSuccess(`سایت "${name}" با موفقیت اضافه شد`);
    this.emit('comparison:site-added', { site: newSite });

    return true;
  }

  async handleRemoveSite(data) {
    const { id } = data;

    const siteIndex = this.comparisonSites.findIndex(site => site.id === id);
    if (siteIndex === -1) {
      this.warn(`Site not found: ${id}`);
      return false;
    }

    const site = this.comparisonSites[siteIndex];
    const confirmed = confirm(`آیا مطمئن هستید که می‌خواهید سایت "${site.name}" را حذف کنید؟`);

    if (confirmed) {
      this.comparisonSites.splice(siteIndex, 1);
      await this.saveComparisonSites();
      this.renderComparisonSites();

      this.showSuccess(`سایت "${site.name}" حذف شد`);
      this.emit('comparison:site-removed', { site });
    }

    return confirmed;
  }

  async handleUpdateSite(data) {
    const { id, name, url } = data;

    const siteIndex = this.comparisonSites.findIndex(site => site.id === id);
    if (siteIndex === -1) {
      this.warn(`Site not found: ${id}`);
      return false;
    }

    if (!this.validateSiteData(name, url)) {
      return false;
    }

    const oldSite = { ...this.comparisonSites[siteIndex] };
    this.comparisonSites[siteIndex] = {
      ...this.comparisonSites[siteIndex],
      name: name.trim(),
      url: url.trim(),
      faviconUrl: this.getFaviconUrl(url)
    };

    await this.saveComparisonSites();
    this.renderComparisonSites();

    this.showSuccess(`سایت "${name}" به‌روزرسانی شد`);
    this.emit('comparison:site-updated', {
      oldSite,
      newSite: this.comparisonSites[siteIndex]
    });

    return true;
  }

  handleEditSite(siteId) {
    const site = this.comparisonSites.find(s => s.id === siteId);
    if (!site) {
      this.warn(`Site not found: ${siteId}`);
      return;
    }

    // Populate edit form
    const { siteNameInput, siteUrlInput } = this.elements;
    if (siteNameInput) siteNameInput.value = site.name;
    if (siteUrlInput) siteUrlInput.value = site.url;

    this.showAddSiteForm();
    this.currentEditingSite = site;

    this.emit('comparison:site-edit-started', { site });
  }

  // Form management
  toggleAddSiteForm() {
    const { addSiteForm } = this.elements;
    if (!addSiteForm) return;

    const isVisible = this.domManager.getStyle(addSiteForm, 'display') !== 'none';
    if (isVisible) {
      this.hideAddSiteForm();
    } else {
      this.showAddSiteForm();
    }
  }

  showAddSiteForm() {
    const { addSiteForm } = this.elements;
    if (addSiteForm) {
      this.domManager.show(addSiteForm);
      this.clearSiteForm();
    }
  }

  hideAddSiteForm() {
    const { addSiteForm } = this.elements;
    if (addSiteForm) {
      this.domManager.hide(addSiteForm);
      this.clearSiteForm();
      this.currentEditingSite = null;
    }
  }

  clearSiteForm() {
    const { siteNameInput, siteUrlInput, popularSitesSelect } = this.elements;

    if (siteNameInput) siteNameInput.value = '';
    if (siteUrlInput) siteUrlInput.value = '';
    if (popularSitesSelect) popularSitesSelect.value = '';

    this.clearFaviconPreview();
  }

  async handleSaveSite() {
    const { siteNameInput, siteUrlInput } = this.elements;

    if (!siteNameInput || !siteUrlInput) {
      this.showError('فیلدهای ورودی یافت نشدند');
      return;
    }

    const name = siteNameInput.value.trim();
    const url = siteUrlInput.value.trim();

    if (!this.validateSiteData(name, url)) {
      return;
    }

    let success = false;

    if (this.currentEditingSite) {
      // Update existing site
      success = await this.handleUpdateSite({
        id: this.currentEditingSite.id,
        name,
        url
      });
    } else {
      // Add new site
      success = await this.handleAddSite({ name, url });
    }

    if (success) {
      this.hideAddSiteForm();
    }
  }

  handlePopularSiteSelect() {
    const { popularSitesSelect, siteNameInput, siteUrlInput } = this.elements;

    if (!popularSitesSelect) return;

    const selectedValue = popularSitesSelect.value;
    if (!selectedValue) return;

    // Get the selected option element
    const selectedOption = popularSitesSelect.querySelector(`option[value="${selectedValue}"]`);
    if (!selectedOption) return;

    // Read data attributes from the selected option
    const name = selectedOption.getAttribute('data-name');
    const url = selectedOption.getAttribute('data-url');

    if (name && url && siteNameInput && siteUrlInput) {
      siteNameInput.value = name;
      siteUrlInput.value = url;
      this.updateFaviconPreview();
    }
  }

  getPopularSites() {
    return [
      {
        id: 'snappshop',
        name: 'SnappShop',
        url: 'https://snappshop.ir/search?query=PRODUCT_NAME'
      },
      {
        id: 'digikalajet',
        name: 'DigiKala Jet',
        url: 'https://www.digikalajet.com/search/v2/result?q=PRODUCT_NAME'
      },
      {
        id: 'janebi',
        name: 'Janebi',
        url: 'https://janebi.com/search?q=PRODUCT_NAME'
      },
      {
        id: 'emalls',
        name: 'Emalls',
        url: 'https://www.emalls.ir/search?q=PRODUCT_NAME'
      },
      {
        id: 'torob',
        name: 'Torob',
        url: 'https://torob.com/search/?query=PRODUCT_NAME'
      },
      {
        id: 'basalam',
        name: 'Basalam',
        url: 'https://basalam.com/search?q=PRODUCT_NAME'
      },
      {
        id: 'kalamarket',
        name: 'KalaMarket',
        url: 'https://kalamarket.com/search?q=PRODUCT_NAME'
      }
    ];
  }

  // Validation
  validateSiteData(name, url) {
    if (!name) {
      this.showError('نام سایت الزامی است');
      return false;
    }

    if (!url) {
      this.showError('آدرس سایت الزامی است');
      return false;
    }

    if (!url.includes('PRODUCT_NAME')) {
      this.showError('آدرس سایت باید شامل PRODUCT_NAME باشد');
      return false;
    }

    try {
      new URL(url.replace('PRODUCT_NAME', 'test'));
    } catch (error) {
      this.showError('آدرس سایت نامعتبر است');
      return false;
    }

    // Check for duplicates (exclude current editing site)
    const duplicate = this.comparisonSites.find(site =>
      site.name.toLowerCase() === name.toLowerCase() &&
      (!this.currentEditingSite || site.id !== this.currentEditingSite.id)
    );

    if (duplicate) {
      this.showError('سایتی با این نام قبلاً اضافه شده است');
      return false;
    }

    return true;
  }

  // Utilities
  generateSiteId() {
    return `site_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  getFaviconUrl(url) {
    try {
      const domain = new URL(url.replace('PRODUCT_NAME', 'test')).origin;
      return `${domain}/favicon.ico`;
    } catch (error) {
      return null;
    }
  }

  getFaviconUrlAlternatives(url) {
    try {
      const domain = new URL(url.replace('PRODUCT_NAME', 'test')).hostname;
      return [
        `https://${domain}/favicon.ico`,
        `https://www.google.com/s2/favicons?domain=${domain}&sz=16`,
        `https://favicons.githubusercontent.com/${domain}`,
        `https://icon.horse/icon/${domain}`
      ];
    } catch (error) {
      return [];
    }
  }

  updateFaviconPreview() {
    const { siteUrlInput, siteIconPreview, siteIconFallback, siteIconStatus } = this.elements;

    if (!siteUrlInput || !siteIconPreview || !siteIconFallback || !siteIconStatus) {
      return;
    }

    const url = siteUrlInput.value.trim();

    if (!url) {
      this.clearFaviconPreview();
      return;
    }

    try {
      const faviconUrl = this.getFaviconUrl(url);
      if (faviconUrl) {
        siteIconPreview.src = faviconUrl;
        this.domManager.show(siteIconPreview);
        this.domManager.hide(siteIconFallback);
        this.domManager.setText(siteIconStatus, 'در حال بارگذاری آیکون...');
      } else {
        this.clearFaviconPreview();
      }
    } catch (error) {
      this.clearFaviconPreview();
    }
  }

  clearFaviconPreview() {
    const { siteIconPreview, siteIconFallback, siteIconStatus } = this.elements;

    if (siteIconPreview) this.domManager.hide(siteIconPreview);
    if (siteIconFallback) this.domManager.show(siteIconFallback);
    if (siteIconStatus) this.domManager.setText(siteIconStatus, '');
  }

  // Public API
  isFeatureEnabled() {
    return this.comparisonFeatureEnabled;
  }

  getSites() {
    return [...this.comparisonSites];
  }

  getSiteCount() {
    return this.comparisonSites.length;
  }

  // Cleanup
  async cleanup() {
    await this.saveComparisonSites();
    this.comparisonSites = [];
    this.comparisonFeatureEnabled = false;
    this.currentEditingSite = null;
  }
}

// Make available globally
window.ComparisonManager = ComparisonManager;