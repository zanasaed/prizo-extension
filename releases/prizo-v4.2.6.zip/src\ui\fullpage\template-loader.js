/**
 * Template Loader
 * Loads HTML templates dynamically to keep main HTML file under size limit
 */

class TemplateLoader {
  constructor() {
    this.loadedTemplates = new Map();
    this.init();
  }

  init() {
    this.loadContactModal();
  }

  async loadTemplate(templatePath) {
    if (this.loadedTemplates.has(templatePath)) {
      return this.loadedTemplates.get(templatePath);
    }

    try {
      const response = await fetch(templatePath);
      if (!response.ok) {
        throw new Error(`Failed to load template: ${templatePath}`);
      }

      const html = await response.text();
      this.loadedTemplates.set(templatePath, html);
      return html;
    } catch (error) {
      console.error('Template loading error:', error);
      return null;
    }
  }

  async loadContactModal() {
    try {
      const modalHtml = await this.loadTemplate('templates/contact-modal.html');
      if (modalHtml) {
        this.injectTemplate(modalHtml, document.body);
      }
    } catch (error) {
      console.warn('Could not load contact modal template:', error);
    }
  }

  injectTemplate(html, container) {
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;

    // Move all children from temp div to container
    while (tempDiv.firstChild) {
      container.appendChild(tempDiv.firstChild);
    }
  }

  async loadAndInject(templatePath, containerId) {
    const container = document.getElementById(containerId);
    if (!container) {
      console.warn(`Container not found: ${containerId}`);
      return false;
    }

    const html = await this.loadTemplate(templatePath);
    if (html) {
      this.injectTemplate(html, container);
      return true;
    }

    return false;
  }
}

// Initialize template loader when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.templateLoader = new TemplateLoader();
  });
} else {
  window.templateLoader = new TemplateLoader();
}

// Export for use in other scripts if needed
if (typeof module !== 'undefined' && module.exports) {
  module.exports = TemplateLoader;
}