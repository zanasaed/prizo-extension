/**
 * Smart Cart State Manager Service
 * Handles Smart Cart state management and persistence for service worker compatibility
 */

class SmartCartStateManager {
  constructor() {
    this.storageKey = 'digikala_extension_smart_cart_items';
    // Don't store state in instance variables in service worker context
    console.log('🔗 Smart Cart State Manager initialized in background');
  }

  async initialize() {
    // Check if already initialized using storage instead of instance variable
    const initState = await chrome.storage.session.get(['smart_cart_initialized']);
    if (initState.smart_cart_initialized) {
      console.log('✅ Smart Cart State Manager already initialized');
      return true;
    }

    await chrome.storage.session.set({ smart_cart_initialized: false });
    console.log('✅ Smart Cart State Manager ready');
    return true;
  }

  async isReady() {
    const initState = await chrome.storage.session.get(['smart_cart_initialized']);
    return !!initState.smart_cart_initialized;
  }

  async getCartItems() {
    try {
      const result = await chrome.storage.local.get([this.storageKey]);
      const items = result[this.storageKey] || [];
      console.log(`📦 [SmartCartStateManager] Retrieved ${items.length} items`);
      return Array.isArray(items) ? items : [];
    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to get items:', error);
      return [];
    }
  }

  async addItem(productId, variantId = null, quantity = 1) {
    try {
      console.log(`➕ [SmartCartStateManager] Adding item: ${productId}, variant: ${variantId}, qty: ${quantity}`);

      const items = await this.getCartItems();
      const existingIndex = items.findIndex(item =>
        (item.pId || item.productId) === productId &&
        (item.vId || item.variantId) === variantId
      );

      const now = Date.now();

      if (existingIndex !== -1) {
        // Update existing item
        const item = items[existingIndex];
        const oldQty = item.qty || item.quantity || 1;
        item.qty = oldQty + quantity;
        item.quantity = item.qty; // Backward compatibility
        item.ut = now;
        item.updatedAt = now; // Backward compatibility
        console.log(`📈 [SmartCartStateManager] Updated quantity: ${oldQty} → ${item.qty}`);
      } else {
        // Add new item with proper data structure
        const newItem = {
          id: `sc_${productId}_${variantId || 'def'}_${now}`,
          pId: productId, // Primary ID for new format
          productId: productId, // Backward compatibility
          vId: variantId,
          variantId: variantId, // Backward compatibility
          qty: quantity,
          quantity: quantity, // Backward compatibility
          at: now,
          addedAt: now, // Backward compatibility
          ut: now,
          updatedAt: now, // Backward compatibility
          src: 'background',
          _c: {
            t: 'در حال بارگذاری...',
            lf: null,
            nr: true
          }
        };
        items.push(newItem);
        console.log(`✅ [SmartCartStateManager] Added new item: ${productId}`);
      }

      await this.saveCartItems(items);

      // Notify subscribers about cart changes for shipping cost recalculation
      await this.notifySubscribers({
        type: 'ITEM_ADDED',
        productId: productId,
        variantId: variantId,
        quantity: quantity,
        totalItems: items.length
      });

      return items[existingIndex] || items[items.length - 1];
    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to add item:', error);
      throw error;
    }
  }

  async removeItem(itemId) {
    try {
      console.log(`🗑️ [SmartCartStateManager] Removing item: ${itemId}`);

      const items = await this.getCartItems();
      const initialLength = items.length;
      const filteredItems = items.filter(item => item.id !== itemId);

      if (filteredItems.length < initialLength) {
        await this.saveCartItems(filteredItems);
        console.log(`✅ [SmartCartStateManager] Item removed successfully`);
        return true;
      }

      console.warn(`⚠️ [SmartCartStateManager] Item not found: ${itemId}`);
      return false;
    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to remove item:', error);
      throw error;
    }
  }

  async updateQuantity(itemId, newQuantity) {
    try {
      console.log(`🔄 [SmartCartStateManager] Updating quantity: ${itemId} → ${newQuantity}`);

      if (newQuantity <= 0) {
        return await this.removeItem(itemId);
      }

      const items = await this.getCartItems();
      const item = items.find(item => item.id === itemId);

      if (!item) {
        throw new Error(`Item not found: ${itemId}`);
      }

      const oldQty = item.qty || item.quantity || 1;
      item.qty = newQuantity;
      item.quantity = newQuantity; // Backward compatibility
      item.ut = Date.now();
      item.updatedAt = item.ut; // Backward compatibility

      await this.saveCartItems(items);
      console.log(`✅ [SmartCartStateManager] Quantity updated: ${oldQty} → ${newQuantity}`);
      return item;
    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to update quantity:', error);
      throw error;
    }
  }

  async clearCart() {
    try {
      console.log('🧹 [SmartCartStateManager] Clearing cart');
      await this.saveCartItems([]);
      console.log('✅ [SmartCartStateManager] Cart cleared');
      return true;
    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to clear cart:', error);
      throw error;
    }
  }

  async saveCartItems(items) {
    try {
      // Validate and clean data before saving
      const cleanItems = items.map(item => ({
        id: item.id,
        pId: item.pId || item.productId,
        productId: item.pId || item.productId, // Backward compatibility
        vId: item.vId || item.variantId,
        variantId: item.vId || item.variantId, // Backward compatibility
        qty: item.qty || item.quantity || 1,
        quantity: item.qty || item.quantity || 1, // Backward compatibility
        at: item.at || item.addedAt || Date.now(),
        addedAt: item.at || item.addedAt || Date.now(), // Backward compatibility
        ut: item.ut || item.updatedAt || Date.now(),
        updatedAt: item.ut || item.updatedAt || Date.now(), // Backward compatibility
        src: item.src || 'background',
        _c: item._c || {
          t: 'در حال بارگذاری...',
          lf: null,
          nr: true
        }
      }));

      // Check size and optimize if needed
      const serialized = JSON.stringify(cleanItems);
      if (serialized.length > 7000) {
        console.warn(`⚠️ [SmartCartStateManager] Cart size: ${(serialized.length / 1024).toFixed(2)}KB, optimizing...`);
        await this.optimizeCartData(cleanItems);
      }

      await chrome.storage.local.set({ [this.storageKey]: cleanItems });
      console.log(`💾 [SmartCartStateManager] Saved ${cleanItems.length} items (${(serialized.length / 1024).toFixed(2)}KB)`);
    } catch (error) {
      if (error.message?.includes('too large')) {
        console.error('🚨 [SmartCartStateManager] Storage overflow, cleaning up');
        await this.handleStorageOverflow(items);
      } else {
        throw error;
      }
    }
  }

  async optimizeCartData(items) {
    items.forEach(item => {
      if (item._c) {
        item._c = {
          t: item._c.t,
          lf: item._c.lf,
          nr: item._c.nr
        };
      }
      delete item.sellers;
      delete item.variantData;
      delete item.optimization;
    });
  }

  async handleStorageOverflow(items) {
    console.warn('🚨 [SmartCartStateManager] Handling storage overflow');

    // Sort by last updated (newest first)
    items.sort((a, b) => (b.ut || b.updatedAt || 0) - (a.ut || a.updatedAt || 0));

    // Remove oldest items until under 6KB
    while (JSON.stringify(items).length > 6000 && items.length > 1) {
      const removed = items.pop();
      console.log(`🗑️ [SmartCartStateManager] Removed old item: ${removed.pId || removed.productId}`);
    }

    await chrome.storage.local.set({ [this.storageKey]: items });
  }

  async getCartSummary() {
    const items = await this.getCartItems();
    const totalItems = items.reduce((sum, item) => sum + (item.qty || item.quantity || 1), 0);
    const uniqueProducts = new Set(items.map(item => item.pId || item.productId)).size;

    return {
      totalItems,
      uniqueProducts,
      itemCount: items.length
    };
  }

  // Advanced Smart Cart features from the original implementation
  async changeVariant(itemId, variantId, variantDetails) {
    try {
      console.log(`🔄 [SmartCartStateManager] Changing variant: ${itemId} → ${variantId}`);

      const items = await this.getCartItems();
      const item = items.find(item => item.id === itemId);

      if (!item) {
        throw new Error(`Item not found: ${itemId}`);
      }

      // Update variant information
      item.vId = variantId;
      item.variantId = variantId; // Backward compatibility
      item.ut = Date.now();
      item.updatedAt = item.ut; // Backward compatibility

      // Store variant details if provided
      if (variantDetails) {
        item._c = { ...item._c, ...variantDetails };
      }

      await this.saveCartItems(items);

      // Notify subscribers about variant change for shipping cost recalculation
      await this.notifySubscribers({
        type: 'VARIANT_CHANGED',
        itemId: itemId,
        variantId: variantId,
        productId: item.pId || item.productId
      });

      console.log(`✅ [SmartCartStateManager] Variant changed successfully`);
      return item;
    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to change variant:', error);
      throw error;
    }
  }

  async changeSeller(itemId, sellerId, sellerDetails) {
    try {
      console.log(`🔄 [SmartCartStateManager] Changing seller: ${itemId} → ${sellerId}`);

      const items = await this.getCartItems();
      const item = items.find(item => item.id === itemId);

      if (!item) {
        throw new Error(`Item not found: ${itemId}`);
      }

      // Update seller information
      item.sellerId = sellerId;
      item.ut = Date.now();
      item.updatedAt = item.ut; // Backward compatibility

      // Store seller details if provided
      if (sellerDetails) {
        item._c = { ...item._c, seller: sellerDetails };
      }

      await this.saveCartItems(items);

      // Notify subscribers about seller change for shipping cost recalculation
      console.log(`🔧 DBG:cart:shipping - Triggering shipping cost recalculation for seller change`, {
        itemId,
        sellerId,
        productId: item.pId || item.productId,
        shippingCost: sellerDetails?.shippingCost
      });

      await this.notifySubscribers({
        type: 'SELLER_CHANGED',
        itemId: itemId,
        sellerId: sellerId,
        productId: item.pId || item.productId,
        sellerDetails: sellerDetails
      });

      console.log(`✅ [SmartCartStateManager] Seller changed successfully`);
      return item;
    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to change seller:', error);
      throw error;
    }
  }

  async refreshAllItems() {
    try {
      console.log('🔄 [SmartCartStateManager] Refreshing all items');
      const items = await this.getCartItems();

      // Mark all items as needing refresh
      items.forEach(item => {
        item._c.nr = true; // Needs refresh
        item.ut = Date.now();
      });

      await this.saveCartItems(items);
      console.log('✅ [SmartCartStateManager] All items marked for refresh');
      return true;
    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to refresh items:', error);
      throw error;
    }
  }

  getCartState() {
    // Return current cart state for synchronization
    return {
      timestamp: Date.now(),
      storageKey: this.storageKey
    };
  }

  // Subscription methods for real-time updates
  subscribe(contextId, callback) {
    // In a service worker context, we'll use storage events for subscriptions
    console.log(`📡 [SmartCartStateManager] Subscription registered: ${contextId}`);

    // Store subscription callback in session storage for service worker compatibility
    if (typeof callback === 'function') {
      // In service worker context, we can't store function references directly
      // Instead, we'll track subscription IDs and use message passing
      this.storeSubscription(contextId, callback);
    }
  }

  unsubscribe(contextId) {
    console.log(`📡 [SmartCartStateManager] Subscription removed: ${contextId}`);
    this.removeSubscription(contextId);
  }

  async storeSubscription(contextId, callback) {
    try {
      // Store subscription metadata
      const subscriptions = await chrome.storage.session.get(['smart_cart_subscriptions']) || {};
      const currentSubs = subscriptions.smart_cart_subscriptions || {};

      currentSubs[contextId] = {
        id: contextId,
        timestamp: Date.now(),
        active: true
      };

      await chrome.storage.session.set({ smart_cart_subscriptions: currentSubs });

      // Store callback reference if in background context
      if (typeof this.subscriptionCallbacks === 'undefined') {
        this.subscriptionCallbacks = new Map();
      }
      this.subscriptionCallbacks.set(contextId, callback);

    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to store subscription:', error);
    }
  }

  async removeSubscription(contextId) {
    try {
      // Remove from session storage
      const subscriptions = await chrome.storage.session.get(['smart_cart_subscriptions']) || {};
      const currentSubs = subscriptions.smart_cart_subscriptions || {};

      delete currentSubs[contextId];
      await chrome.storage.session.set({ smart_cart_subscriptions: currentSubs });

      // Remove callback reference
      if (this.subscriptionCallbacks) {
        this.subscriptionCallbacks.delete(contextId);
      }

    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to remove subscription:', error);
    }
  }

  async notifySubscribers(updateData) {
    try {
      if (this.subscriptionCallbacks && this.subscriptionCallbacks.size > 0) {
        for (const [contextId, callback] of this.subscriptionCallbacks.entries()) {
          try {
            if (typeof callback === 'function') {
              callback(updateData);
            }
          } catch (callbackError) {
            console.warn(`⚠️ [SmartCartStateManager] Callback error for ${contextId}:`, callbackError);
            // Remove problematic subscription
            this.removeSubscription(contextId);
          }
        }
      }
    } catch (error) {
      console.error('❌ [SmartCartStateManager] Failed to notify subscribers:', error);
    }
  }
}

export { SmartCartStateManager };