/**
 * Centralized Smart Cart State Manager
 * Single source of truth with proper locking and event broadcasting
 */
class SmartCartState {
  constructor() {
    this.cart = [];
    this.subscribers = new Set();
    this.updateLock = null;
    this.storageKey = 'digikala_extension_smart_cart_items';

    // Debug instrumentation
    this.operations = {
      add: 0,
      remove: 0,
      update: 0,
      storage_read: 0,
      storage_write: 0
    };
  }

  /**
   * Subscribe to state changes
   */
  subscribe(callback) {
    this.subscribers.add(callback);
    return () => this.subscribers.delete(callback);
  }

  /**
   * Broadcast state changes to all subscribers
   */
  broadcast(event, data) {
    console.log(`🔄 [SmartCartState] Broadcasting: ${event}`, data);
    this.subscribers.forEach(callback => {
      try {
        callback({ event, data, cart: [...this.cart] });
      } catch (error) {
        console.error('❌ Subscriber error:', error);
      }
    });
  }

  /**
   * Mutex-protected cart operations
   */
  async withLock(operation) {
    while (this.updateLock) {
      await this.updateLock;
    }

    let resolver;
    this.updateLock = new Promise(resolve => resolver = resolve);

    try {
      const result = await operation();
      return result;
    } finally {
      resolver();
      this.updateLock = null;
    }
  }

  /**
   * Load cart from storage
   */
  async loadCart() {
    return this.withLock(async () => {
      console.log('📖 [SmartCartState] Loading cart from storage');
      this.operations.storage_read++;

      try {
        const result = await chrome.storage.local.get([this.storageKey]);
        const cartData = result[this.storageKey] || [];

        this.cart = Array.isArray(cartData) ? cartData : [];
        console.log(`✅ [SmartCartState] Loaded ${this.cart.length} items`);

        this.broadcast('cart_loaded', { itemCount: this.cart.length });
        return [...this.cart];
      } catch (error) {
        console.error('❌ [SmartCartState] Load error:', error);
        this.cart = [];
        return [];
      }
    });
  }

  /**
   * Save cart to storage
   */
  async saveCart() {
    return this.withLock(async () => {
      console.log('💾 [SmartCartState] Saving cart to storage');
      this.operations.storage_write++;

      try {
        const serialized = JSON.stringify(this.cart);
        const sizeKB = (serialized.length / 1024).toFixed(2);

        if (serialized.length > 7000) {
          console.warn(`⚠️ [SmartCartState] Cart size: ${sizeKB}KB (approaching 8KB limit)`);
          await this.optimizeCart();
        }

        await chrome.storage.local.set({ [this.storageKey]: this.cart });
        console.log(`✅ [SmartCartState] Saved ${this.cart.length} items (${sizeKB}KB)`);

        this.broadcast('cart_saved', { itemCount: this.cart.length, sizeKB });
      } catch (error) {
        if (error.message.includes('too large')) {
          console.error('🚨 [SmartCartState] Storage overflow, cleaning up');
          await this.handleOverflow();
          await chrome.storage.local.set({ [this.storageKey]: this.cart });
        } else {
          throw error;
        }
      }
    });
  }

  /**
   * Add item to cart
   */
  async addItem(productId, variantId = null, quantity = 1) {
    return this.withLock(async () => {
      console.log(`➕ [SmartCartState] Adding item: ${productId}, variant: ${variantId}, qty: ${quantity}`);
      this.operations.add++;

      const existingIndex = this.cart.findIndex(item =>
        (item.pId || item.productId) === productId &&
        (item.vId || item.variantId) === variantId
      );

      if (existingIndex !== -1) {
        // Update existing item
        const item = this.cart[existingIndex];
        const oldQty = item.qty || item.quantity || 1;
        const newQty = oldQty + quantity;

        item.qty = newQty;
        item.quantity = newQty; // Backward compatibility
        item.ut = item.updatedAt = Date.now();

        console.log(`📈 [SmartCartState] Updated quantity: ${oldQty} → ${newQty}`);

        await this.saveCart();
        this.broadcast('item_updated', { item, oldQuantity: oldQty, newQuantity: newQty });
        return item;
      } else {
        // Add new item
        const now = Date.now();
        const newItem = {
          id: `sc_${productId}_${variantId || 'def'}_${now}`,
          pId: productId,
          vId: variantId,
          qty: quantity,
          quantity: quantity, // Backward compatibility
          at: now,
          addedAt: now, // Backward compatibility
          ut: now,
          updatedAt: now, // Backward compatibility
          src: 'api',
          _c: {
            t: 'Loading...',
            lf: null,
            nr: true
          }
        };

        this.cart.push(newItem);
        console.log(`✅ [SmartCartState] Added new item: ${productId}`);

        await this.saveCart();
        this.broadcast('item_added', { item: newItem });
        return newItem;
      }
    });
  }

  /**
   * Remove item from cart
   */
  async removeItem(itemId) {
    return this.withLock(async () => {
      console.log(`🗑️ [SmartCartState] Removing item: ${itemId}`);
      this.operations.remove++;

      const initialLength = this.cart.length;
      this.cart = this.cart.filter(item => item.id !== itemId);

      if (this.cart.length < initialLength) {
        await this.saveCart();
        this.broadcast('item_removed', { itemId });
        return true;
      }
      return false;
    });
  }

  /**
   * Update item quantity
   */
  async updateQuantity(itemId, newQuantity) {
    return this.withLock(async () => {
      console.log(`🔄 [SmartCartState] Updating quantity: ${itemId} → ${newQuantity}`);
      this.operations.update++;

      if (newQuantity <= 0) {
        return this.removeItem(itemId);
      }

      const item = this.cart.find(item => item.id === itemId);
      if (!item) {
        throw new Error(`Item ${itemId} not found`);
      }

      const oldQuantity = item.qty || item.quantity || 1;
      item.qty = newQuantity;
      item.quantity = newQuantity; // Backward compatibility
      item.ut = item.updatedAt = Date.now();

      await this.saveCart();
      this.broadcast('quantity_updated', { item, oldQuantity, newQuantity });
      return item;
    });
  }

  /**
   * Get current cart
   */
  getCart() {
    return [...this.cart];
  }

  /**
   * Get cart summary
   */
  getSummary() {
    const totalItems = this.cart.reduce((sum, item) => sum + (item.qty || item.quantity || 1), 0);
    const totalValue = this.cart.reduce((sum, item) => sum + ((item.price || 0) * (item.qty || item.quantity || 1)), 0);
    const uniqueProducts = new Set(this.cart.map(item => item.pId || item.productId)).size;

    return {
      totalItems,
      totalValue,
      uniqueProducts,
      itemCount: this.cart.length
    };
  }

  /**
   * Clear all items
   */
  async clearCart() {
    return this.withLock(async () => {
      console.log('🧹 [SmartCartState] Clearing cart');
      const removedCount = this.cart.length;
      this.cart = [];

      await this.saveCart();
      this.broadcast('cart_cleared', { removedCount });
    });
  }

  /**
   * Optimize cart for storage
   */
  async optimizeCart() {
    console.log('🔧 [SmartCartState] Optimizing cart for storage');

    this.cart.forEach(item => {
      if (item._c) {
        // Keep only essential cached data
        item._c = {
          t: item._c.t,
          lf: item._c.lf,
          nr: item._c.nr
        };
      }

      // Remove heavy optional data
      delete item.sellers;
      delete item.variantData;
      delete item.optimization;
    });

    const newSize = JSON.stringify(this.cart).length;
    console.log(`✅ [SmartCartState] Optimized to ${(newSize/1024).toFixed(2)}KB`);
  }

  /**
   * Handle storage overflow
   */
  async handleOverflow() {
    console.warn('🚨 [SmartCartState] Handling storage overflow');

    // Sort by last updated (newest first)
    this.cart.sort((a, b) => (b.ut || b.updatedAt || 0) - (a.ut || a.updatedAt || 0));

    // Remove oldest items until under 6KB
    while (JSON.stringify(this.cart).length > 6000 && this.cart.length > 1) {
      const removed = this.cart.pop();
      console.log(`🗑️ [SmartCartState] Removed old item: ${removed.pId || removed.productId}`);
    }

    this.broadcast('overflow_cleanup', {
      remainingItems: this.cart.length,
      message: 'Some older items were removed to manage storage space'
    });
  }

  /**
   * Get debug statistics
   */
  getStats() {
    return {
      itemCount: this.cart.length,
      subscriberCount: this.subscribers.size,
      operations: { ...this.operations },
      isLocked: !!this.updateLock,
      cartSizeKB: (JSON.stringify(this.cart).length / 1024).toFixed(2)
    };
  }
}

// Global singleton instance
window.smartCartState = window.smartCartState || new SmartCartState();