/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Integration Example - Shows how to integrate new modular architecture with existing PopupController
 */

// This file demonstrates how to progressively migrate functionality from PopupController to modules

// Wait for core to be initialized
document.addEventListener('DOMContentLoaded', async () => {
  // Wait for popup core to be ready
  if (!window.popupCore) {
    await new Promise(resolve => {
      const checkCore = () => {
        if (window.popupCore) {
          resolve();
        } else {
          setTimeout(checkCore, 10);
        }
      };
      checkCore();
    });
  }

  // Initialize notification manager as an example
  const notificationManager = new NotificationManager(
    window.popupEventBus,
    window.popupDOMManager
  );

  await notificationManager.init();

  // Register the module with the core
  window.popupEventBus.emit('module:register', {
    name: 'NotificationManager',
    module: notificationManager
  });

  // Make it globally accessible for integration
  window.popupNotificationManager = notificationManager;

  console.log('✅ Example integration completed - NotificationManager is ready');

  // Example of how existing PopupController can use the new notification system
  window.popupEventBus.on('popup:ready', (data) => {
    console.log('🎉 PopupController is ready, modules can interact with it');

    // Example: Show a success message using the new system
    notificationManager.success('سیستم جدید آماده است!', {
      title: 'آپگرید موفقیت‌آمیز',
      duration: 3000
    });
  });
});

// Helper function to bridge existing PopupController methods with new architecture
function bridgePopupController(popupController) {
  if (!popupController || !window.popupEventBus) return;

  const originalShowSuccess = popupController.showSuccess;
  const originalShowError = popupController.showError;

  // Override success method to use new notification system
  popupController.showSuccess = function(message) {
    // Call original method for backward compatibility
    if (originalShowSuccess) {
      originalShowSuccess.call(this, message);
    }

    // Also emit event for new system
    window.popupEventBus.emit('ui:success', { message });
  };

  // Override error method to use new notification system
  popupController.showError = function(message) {
    // Call original method for backward compatibility
    if (originalShowError) {
      originalShowError.call(this, message);
    }

    // Also emit event for new system
    window.popupEventBus.emit('ui:error', { message });
  };

  console.log('🔗 PopupController bridged with new architecture');
}

// Auto-bridge when PopupController is created
const originalDOMContentLoaded = document.addEventListener;
document.addEventListener('DOMContentLoaded', () => {
  // Wait a bit for PopupController to be created
  setTimeout(() => {
    if (window.popupController) {
      bridgePopupController(window.popupController);
    }
  }, 100);
});