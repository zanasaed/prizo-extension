/**
 * Watchlist Monitor Service
 * Handles automatic price monitoring and notifications for watchlist items
 */

import { BackgroundLogger } from '../utils/logger.js';

class WatchlistMonitor {
  constructor(backgroundService) {
    this.backgroundService = backgroundService;
    this.watchlistMonitor = null;
    this.monitoringInterval = 4 * 60 * 60 * 1000; // 4 hours (default fallback)
    this.productMonitors = new Map(); // Store individual product monitors
    this.forceCheckThrottles = new Map(); // Track last force-check per product
    this.forceCheckCooldown = 60 * 1000; // 60 seconds throttling
  }

  async startWatchlistMonitoring() {
    BackgroundLogger.info('🔍 Starting reliable alarm-based watchlist monitoring service');

    // Check and request notification permissions if needed
    this.checkNotificationPermissions();

    // Stop any existing monitoring
    await this.stopAllMonitoring();

    // Set up alarm-based monitoring and catch-up logic
    await this.setupAlarmBasedMonitoring();

    BackgroundLogger.info(`✅ Alarm-based monitoring started with catch-up recovery`);
  }

  async stopAllMonitoring() {
    // Clear global monitor if exists
    if (this.watchlistMonitor) {
      clearInterval(this.watchlistMonitor);
      this.watchlistMonitor = null;
    }

    // Clear all individual product monitors (old setTimeout approach)
    for (const [productId, monitor] of this.productMonitors) {
      if (monitor.timeoutId) {
        clearTimeout(monitor.timeoutId);
      }
      BackgroundLogger.info(`⏹️ Stopped monitoring for product ${productId}`);
    }
    this.productMonitors.clear();

    // Clear all alarms
    try {
      const allAlarms = await chrome.alarms.getAll();
      for (const alarm of allAlarms) {
        if (alarm.name.startsWith('watchlist-')) {
          await chrome.alarms.clear(alarm.name);
          BackgroundLogger.info(`🔕 Cleared alarm: ${alarm.name}`);
        }
      }
    } catch (error) {
      console.error('Error clearing alarms:', error);
    }
  }

  async setupAlarmBasedMonitoring() {
    try {
      // Get watchlist from storage
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];

      if (watchlist.length === 0) {
        BackgroundLogger.info('📋 No items in watchlist to monitor');
        return;
      }

      BackgroundLogger.info(`📋 Setting up alarm-based monitoring for ${watchlist.length} watchlist entries`);

      const now = Date.now();

      // Set up individual alarms for each active product
      for (const item of watchlist) {
        if (item.isActive) {
          await this.scheduleProductAlarm(item, now);
        }
      }

      // Set up a master recovery alarm that runs every hour to catch missed updates
      await chrome.alarms.create('watchlist-recovery', {
        delayInMinutes: 60,
        periodInMinutes: 60
      });
      BackgroundLogger.info('🔄 Recovery alarm scheduled for every 60 minutes');

    } catch (error) {
      console.error('Error setting up alarm-based monitors:', error);
    }
  }

  async scheduleProductAlarm(watchlistItem, currentTime = null) {
    const productId = watchlistItem.productId;
    const checkInterval = watchlistItem.checkInterval || this.monitoringInterval;
    const now = currentTime || Date.now();
    const lastChecked = watchlistItem.lastCheckedAt || 0;

    // Calculate when the next check should occur
    const timeSinceLastCheck = now - lastChecked;
    let delayUntilNextCheck;

    if (timeSinceLastCheck >= checkInterval) {
      // Overdue - check immediately (but with a small delay to prevent spam)
      delayUntilNextCheck = Math.random() * 30000; // Random 0-30 seconds
      BackgroundLogger.info(`⚡ Product ${watchlistItem.productTitle} is overdue, checking in ${Math.round(delayUntilNextCheck / 1000)}s`);
    } else {
      // Schedule for the remaining time
      delayUntilNextCheck = checkInterval - timeSinceLastCheck;
    }

    const alarmName = `watchlist-${productId}`;

    // Clear existing alarm for this product
    await chrome.alarms.clear(alarmName);

    // Create new alarm with calculated delay
    const delayInMinutes = Math.max(0.1, delayUntilNextCheck / (60 * 1000)); // Min 0.1 minutes (6 seconds)

    await chrome.alarms.create(alarmName, {
      delayInMinutes: delayInMinutes
    });

    const nextCheckTime = now + delayUntilNextCheck;
    const nextCheckDate = new Date(nextCheckTime);

    BackgroundLogger.info(`⏰ Scheduled alarm for ${watchlistItem.productTitle} at ${nextCheckDate.toLocaleString('fa-IR')} (${Math.round(delayInMinutes)} minutes)`);
  }

  async handleAlarm(alarm) {
    BackgroundLogger.info(`🔔 Alarm triggered: ${alarm.name}`);

    try {
      if (alarm.name === 'watchlist-recovery') {
        // Handle recovery alarm - check for missed updates
        await this.performRecoveryCheck();
      } else if (alarm.name.startsWith('watchlist-')) {
        // Handle individual product alarm
        const productId = alarm.name.replace('watchlist-', '');
        await this.handleProductAlarm(productId);
      }
    } catch (error) {
      console.error(`Error handling alarm ${alarm.name}:`, error);
    }
  }

  async handleProductAlarm(productId) {
    try {
      const watchlistItem = await this.getUpdatedWatchlistItem(productId);
      if (!watchlistItem || !watchlistItem.isActive) {
        BackgroundLogger.info(`⏸️ Product ${productId} no longer active, skipping alarm`);
        return;
      }

      BackgroundLogger.info(`🔍 Processing alarm for product: ${watchlistItem.productTitle}`);

      // Monitor the product
      await this.backgroundService.monitorSingleProduct(watchlistItem);

      // Reschedule the next alarm for this product
      await this.scheduleProductAlarm(watchlistItem);

    } catch (error) {
      console.error(`Error handling product alarm for ${productId}:`, error);

      // Try to reschedule even if monitoring failed
      try {
        const watchlistItem = await this.getUpdatedWatchlistItem(productId);
        if (watchlistItem && watchlistItem.isActive) {
          await this.scheduleProductAlarm(watchlistItem);
        }
      } catch (rescheduleError) {
        console.error(`Failed to reschedule after error for ${productId}:`, rescheduleError);
      }
    }
  }

  async performRecoveryCheck() {
    BackgroundLogger.info('🔄 Performing recovery check for missed updates');

    try {
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];
      const now = Date.now();
      let recoveredCount = 0;

      for (const item of watchlist) {
        if (!item.isActive) continue;

        const checkInterval = item.checkInterval || this.monitoringInterval;
        const lastChecked = item.lastCheckedAt || 0;
        const timeSinceLastCheck = now - lastChecked;

        // If it's been more than 1.5x the check interval, it's likely missed
        if (timeSinceLastCheck > (checkInterval * 1.5)) {
          BackgroundLogger.info(`🚨 Detected missed update for ${item.productTitle}, recovering...`);

          // Ensure alarm exists for this product
          const alarmName = `watchlist-${item.productId}`;
          const existingAlarm = await chrome.alarms.get(alarmName);

          if (!existingAlarm) {
            BackgroundLogger.info(`⚡ Re-creating missing alarm for ${item.productTitle}`);
            await this.scheduleProductAlarm(item, now);
            recoveredCount++;
          }
        }
      }

      if (recoveredCount > 0) {
        BackgroundLogger.info(`✅ Recovery completed: restored ${recoveredCount} missing alarms`);
      } else {
        BackgroundLogger.info('✅ Recovery check completed: no missing alarms found');
      }

    } catch (error) {
      console.error('Error during recovery check:', error);
    }
  }

  async getUpdatedWatchlistItem(productId) {
    try {
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];
      return watchlist.find(item => item.productId === productId);
    } catch (error) {
      console.error(`Error getting watchlist item for ${productId}:`, error);
      return null;
    }
  }

  checkNotificationPermissions() {
    if (typeof chrome !== 'undefined' && chrome.notifications) {
      // Check if we have notification permissions
      chrome.permissions.contains({
        permissions: ['notifications']
      }, (result) => {
        if (!result) {
          BackgroundLogger.info('📢 Notification permissions not granted. Watchlist notifications will be limited.');
        }
      });
    }
  }
}

export { WatchlistMonitor };