/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-26
 * Optimized API Service
 * Uses intercepted network responses before making duplicate requests
 */

class OptimizedAPIService {
  constructor(eventBus) {
    this.eventBus = eventBus;
    this.networkInterceptor = window.ExtensionCore?.NetworkInterceptor;
    this.fallbackAPIService = null; // Will be set to original API service

    // Performance tracking
    this.stats = {
      interceptedRequests: 0,
      fallbackRequests: 0,
      totalRequests: 0,
      timeSaved: 0
    };

    // Initialize network interceptor if available
    this.initializeNetworkInterceptor();
  }

  /**
   * Initialize network interceptor
   */
  initializeNetworkInterceptor() {
    if (this.networkInterceptor) {
      console.log('🔗 Linking OptimizedAPIService with NetworkInterceptor');
      this.networkInterceptor.activate();
    } else {
      console.warn('⚠️ NetworkInterceptor not available, falling back to regular API calls');
    }
  }

  /**
   * Set fallback API service for when interception fails
   */
  setFallbackService(apiService) {
    this.fallbackAPIService = apiService;
    console.log('🔄 Fallback API service configured');
  }

  /**
   * Optimized product data fetching
   */
  async fetchProductData(productId, options = {}) {
    const startTime = Date.now();
    this.stats.totalRequests++;

    try {
      console.log(`📡 Optimized fetch for product ${productId} starting...`);

      // Strategy 1: Check if we already have intercepted data
      let productData = this.getInterceptedData(productId);
      if (productData) {
        this.stats.interceptedRequests++;
        this.stats.timeSaved += Date.now() - startTime;

        console.log(`✅ Using intercepted data for product ${productId} (0ms)`);

        // [ShippingCost:API] Log intercepted data structure for shipping debugging
        console.log(`[ShippingCost:API] Intercepted data structure for ${productId}:`, {
          data_type: typeof productData,
          has_data: !!productData.data,
          has_product: !!productData.data?.product,
          has_variants: !!productData.data?.product?.variants,
          variants_count: productData.data?.product?.variants?.length || 0,
          first_variant_shipping: productData.data?.product?.variants?.[0]?.shipment_methods || null,
          default_variant_shipping: productData.data?.product?.default_variant?.shipment_methods || null,
          intercepted_data_keys: Object.keys(productData),
          product_data_keys: productData.data?.product ? Object.keys(productData.data.product) : null
        });

        this.eventBus?.emit('product:data-fetched', { productId, data: productData });
        return productData;
      }

      // Strategy 2: Wait briefly for interception (page might be loading)
      if (options.waitForInterception !== false) {
        console.log(`⏳ Waiting for potential network interception for product ${productId}...`);

        // Get user's configured startup delay and use it as interception timeout
        const interceptTimeout = await this.getInterceptTimeout(options);
        console.log(`⏱️ Using interception timeout: ${interceptTimeout}ms (based on user delay settings)`);

        productData = await this.waitForInterceptedData(productId, interceptTimeout);

        if (productData) {
          this.stats.interceptedRequests++;
          const timeElapsed = Date.now() - startTime;
          this.stats.timeSaved += Math.max(0, 5000 - timeElapsed); // Assume we saved at least 5s vs full request

          console.log(`✅ Got intercepted data for product ${productId} after waiting (${timeElapsed}ms)`);

          // [ShippingCost:API] Log waited intercepted data structure for shipping debugging
          console.log(`[ShippingCost:API] Waited intercepted data structure for ${productId}:`, {
            data_type: typeof productData,
            has_data: !!productData.data,
            has_product: !!productData.data?.product,
            has_variants: !!productData.data?.product?.variants,
            variants_count: productData.data?.product?.variants?.length || 0,
            first_variant_shipping: productData.data?.product?.variants?.[0]?.shipment_methods || null,
            default_variant_shipping: productData.data?.product?.default_variant?.shipment_methods || null,
            waited_data_keys: Object.keys(productData),
            product_data_keys: productData.data?.product ? Object.keys(productData.data.product) : null,
            wait_time: timeElapsed
          });

          this.eventBus?.emit('product:data-fetched', { productId, data: productData });
          return productData;
        }
      }

      // Strategy 3: Fallback to original API service
      console.log(`🔄 No intercepted data available, falling back to API request for product ${productId}`);
      this.stats.fallbackRequests++;

      if (this.fallbackAPIService) {
        productData = await this.fallbackAPIService.fetchProductData(productId, options);
        const timeElapsed = Date.now() - startTime;
        console.log(`✅ Fallback API request completed for product ${productId} (${timeElapsed}ms)`);
        return productData;
      } else {
        // Direct API call if no fallback service
        productData = await this.performDirectAPICall(productId, options);
        const timeElapsed = Date.now() - startTime;
        console.log(`✅ Direct API request completed for product ${productId} (${timeElapsed}ms)`);
        return productData;
      }

    } catch (error) {
      console.error(`❌ Optimized fetch failed for product ${productId}:`, error);
      this.eventBus?.emit('product:fetch-error', { productId, error });
      throw error;
    }
  }

  /**
   * Get intercepted data if available
   */
  getInterceptedData(productId) {
    if (!this.networkInterceptor) {
      return null;
    }

    try {
      return this.networkInterceptor.getInterceptedData(productId);
    } catch (error) {
      console.warn('⚠️ Failed to get intercepted data:', error);
      return null;
    }
  }

  /**
   * Get interception timeout based on user settings
   */
  async getInterceptTimeout(options = {}) {
    // If explicitly provided in options, use that
    if (options.interceptTimeout && typeof options.interceptTimeout === 'number') {
      return Math.min(Math.max(options.interceptTimeout, 500), 10000); // Clamp between 500ms-10s
    }

    try {
      // Get user's globalDelay setting
      const result = typeof ExtensionCore !== 'undefined' && ExtensionCore.BrowserCompat ?
        await ExtensionCore.BrowserCompat.safeStorageGet(['globalDelay'], { globalDelay: 1000 }) :
        { globalDelay: 1000 };

      let timeout = result.globalDelay || 1000;

      // For interception, we typically want a bit more time than startup delay
      // Add 20% buffer but cap it at reasonable limits
      timeout = Math.floor(timeout * 1.2);

      // Ensure it's within reasonable bounds (min 500ms, max 8s)
      timeout = Math.min(Math.max(timeout, 500), 8000);

      return timeout;
    } catch (error) {
      console.warn('⚠️ Failed to get user delay settings, using default:', error);
      return 1200; // Default with 20% buffer
    }
  }

  /**
   * Wait for intercepted data with timeout
   */
  async waitForInterceptedData(productId, timeout = 3000) {
    if (!this.networkInterceptor) {
      return null;
    }

    try {
      return await this.networkInterceptor.waitForInterceptedData(productId, timeout);
    } catch (error) {
      console.warn('⚠️ Failed to wait for intercepted data:', error);
      return null;
    }
  }

  /**
   * Perform direct API call as last resort
   */
  async performDirectAPICall(productId, options = {}) {
    console.log(`🌐 Making direct API call for product ${productId}`);

    // Use the same approach as RequestManager but simplified
    const endpoints = [
      `https://api.digikala.com/v2/product/${encodeURIComponent(productId)}/`,
      `https://api.digikala.com/v1/product/${encodeURIComponent(productId)}/`,
      `https://www.digikala.com/ajax/product/${encodeURIComponent(productId)}/`
    ];

    for (const endpoint of endpoints) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), options.timeout || 8000);

        const response = await fetch(endpoint, {
          method: 'GET',
          headers: {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://www.digikala.com/',
            'Origin': 'https://www.digikala.com'
          },
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (response.ok) {
          const data = await response.json();
          // Preserve full response structure - don't extract data.data here as it may lose shipping info
          const productData = data;

          // [ShippingCost:API] Log direct API call response structure for shipping debugging
          console.log(`[ShippingCost:API] Direct API response structure for ${productId} from ${endpoint}:`, {
            data_type: typeof productData,
            has_data: !!productData.data,
            has_product: !!productData.data?.product,
            has_variants: !!productData.data?.product?.variants,
            variants_count: productData.data?.product?.variants?.length || 0,
            first_variant_shipping: productData.data?.product?.variants?.[0]?.shipment_methods || null,
            default_variant_shipping: productData.data?.product?.default_variant?.shipment_methods || null,
            direct_response_keys: Object.keys(productData),
            product_data_keys: productData.data?.product ? Object.keys(productData.data.product) : null,
            endpoint_used: endpoint
          });

          // Store in interceptor cache for future use
          if (this.networkInterceptor) {
            this.networkInterceptor.storeInterceptedData(productId, data, endpoint);
          }

          return productData;
        } else {
          console.log(`❌ Direct API call failed: ${response.status} from ${endpoint}`);
        }

      } catch (error) {
        console.log(`❌ Direct API call error for ${endpoint}:`, error.message);
      }
    }

    throw new Error('All direct API calls failed');
  }

  /**
   * Fetch seller data with optimization
   */
  async fetchSellerData(sellerId, options = {}) {
    // For seller data, we can use the same optimization approach
    return this.fetchProductData(sellerId, { ...options, pageType: 'seller' });
  }

  /**
   * Get performance statistics
   */
  getPerformanceStats() {
    const totalTime = this.stats.timeSaved;
    const interceptedRatio = this.stats.totalRequests > 0 ?
      (this.stats.interceptedRequests / this.stats.totalRequests * 100).toFixed(1) : 0;

    return {
      totalRequests: this.stats.totalRequests,
      interceptedRequests: this.stats.interceptedRequests,
      fallbackRequests: this.stats.fallbackRequests,
      interceptedRatio: `${interceptedRatio}%`,
      estimatedTimeSaved: `${(totalTime / 1000).toFixed(1)}s`,
      averageTimeSaved: this.stats.interceptedRequests > 0 ?
        `${(totalTime / this.stats.interceptedRequests).toFixed(0)}ms` : '0ms'
    };
  }

  /**
   * Reset performance statistics
   */
  resetStats() {
    this.stats = {
      interceptedRequests: 0,
      fallbackRequests: 0,
      totalRequests: 0,
      timeSaved: 0
    };
    console.log('📊 Performance statistics reset');
  }

  /**
   * Check if optimization is working
   */
  isOptimizationActive() {
    return this.networkInterceptor?.isActive || false;
  }

  /**
   * Get interceptor status and data
   */
  getInterceptorStatus() {
    if (!this.networkInterceptor) {
      return { active: false, reason: 'NetworkInterceptor not available' };
    }

    return {
      active: this.networkInterceptor.isActive,
      interceptedDataCount: Object.keys(this.networkInterceptor.getAllInterceptedData()).length,
      allData: this.networkInterceptor.getAllInterceptedData()
    };
  }

  /**
   * Manual activation of interceptor (if needed)
   */
  activateInterceptor() {
    if (this.networkInterceptor) {
      this.networkInterceptor.activate();
      console.log('🚀 Network interceptor manually activated');
    } else {
      console.warn('⚠️ Cannot activate interceptor: NetworkInterceptor not available');
    }
  }

  /**
   * Manual deactivation of interceptor
   */
  deactivateInterceptor() {
    if (this.networkInterceptor) {
      this.networkInterceptor.deactivate();
      console.log('🛑 Network interceptor manually deactivated');
    }
  }

  /**
   * Clear all caches
   */
  async clearCache() {
    if (this.networkInterceptor) {
      this.networkInterceptor.clearInterceptedData();
    }

    if (this.fallbackAPIService) {
      await this.fallbackAPIService.clearCache();
    }

    this.resetStats();
    console.log('🧹 All caches cleared');
  }
}

// Export for use in other modules
window.OptimizedAPIService = OptimizedAPIService;

console.log('⚡ Optimized API Service loaded');