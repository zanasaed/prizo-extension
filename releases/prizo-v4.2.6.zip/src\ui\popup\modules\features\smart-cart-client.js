/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-19
 * Smart Cart Client for Popup - Uses centralized state via API
 */

class SmartCartClient extends BaseModule {
  constructor(eventBus, domManager) {
    super('SmartCartClient', eventBus, domManager);

    this.cartAPI = null;
    this.isModalOpen = false;

    // UI Elements
    this.elements = {};

    // Current state
    this.currentItems = [];
    this.currentSummary = {};
    this.loadingItems = [];
  }

  async initializeElements() {
    // UI elements are already in HTML
    this.elements = {
      showCartBtn: document.getElementById('showSmartCartBtn'),
      clearCartBtn: document.getElementById('clearSmartCartBtn'),
      modal: document.getElementById('smartCartModal'),
      closeModalBtn: document.getElementById('closeSmartCartModal'),
      clearAllModalBtn: document.getElementById('clearAllSmartCartBtn'),
      cartItemsContainer: document.getElementById('smartCartItems'),
      cartSummary: {
        itemsCount: document.getElementById('cartItemsCount'),
        totalValue: document.getElementById('cartTotalValue'),
        uniqueProducts: document.getElementById('cartUniqueProducts')
      },
      modalSummary: {
        itemsCount: document.getElementById('modalCartItemsCount'),
        totalValue: document.getElementById('modalCartTotalValue'),
        uniqueProducts: document.getElementById('modalCartUniqueProducts')
      }
    };

    console.log('📋 Smart Cart Client elements initialized');
  }

  async setupEventListeners() {
    this.setupUIEventListeners();
    await this.initializeCartAPI();
  }

  async loadInitialData() {
    // Initial state will be loaded via API subscription
    console.log('📦 Smart Cart Client ready for data');
  }

  /**
   * Initialize Smart Cart API
   */
  async initializeCartAPI() {
    try {
      if (typeof SmartCartAPI === 'undefined') {
        console.error('❌ SmartCartAPI not available');
        return;
      }

      this.cartAPI = new SmartCartAPI('popup');
      await this.cartAPI.initialize();

      // Subscribe to state updates
      this.cartAPI.onStateUpdate((update) => {
        this.handleStateUpdate(update);
      });

      console.log('✅ Smart Cart API initialized for popup');
    } catch (error) {
      console.error('❌ Failed to initialize Smart Cart API:', error);
    }
  }

  /**
   * Setup UI event listeners
   */
  setupUIEventListeners() {
    const { showCartBtn, clearCartBtn, closeModalBtn, clearAllModalBtn, modal, cartItemsContainer } = this.elements;

    // Show cart button
    if (showCartBtn) {
      showCartBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.showModal();
      });
    }

    // Clear cart button
    if (clearCartBtn) {
      clearCartBtn.addEventListener('click', () => this.clearCart());
    }

    // Close modal button
    if (closeModalBtn) {
      closeModalBtn.addEventListener('click', () => this.hideModal());
    }

    // Clear all modal button
    if (clearAllModalBtn) {
      clearAllModalBtn.addEventListener('click', () => this.clearCart());
    }

    // Click outside modal to close
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          this.hideModal();
        }
      });
    }

    // Event delegation for cart item actions
    if (cartItemsContainer) {
      cartItemsContainer.addEventListener('click', (e) => {
        this.handleCartItemClick(e);
      });

      cartItemsContainer.addEventListener('change', (e) => {
        this.handleCartItemChange(e);
      });
    }
  }

  /**
   * Handle state updates from centralized state
   */
  handleStateUpdate(update) {
    console.log(`🔄 Popup received state update: ${update.type}`);

    // Update local state
    if (update.items) {
      this.currentItems = update.items;
    }

    // Update UI based on update type
    switch (update.type) {
      case 'INITIAL_STATE':
      case 'CART_UPDATED':
      case 'STORAGE_SYNC':
        this.updateUI();
        break;

      case 'ITEM_ADDED':
      case 'ITEM_REMOVED':
      case 'QUANTITY_UPDATED':
      case 'VARIANT_CHANGED':
      case 'SELLER_CHANGED':
        this.updateUI();
        if (this.isModalOpen) {
          this.renderCartItems();
        }
        break;

      case 'CART_CLEARED':
        this.updateUI();
        if (this.isModalOpen) {
          this.hideModal();
        }
        break;

      case 'LOADING_STATE_CHANGED':
        this.loadingItems = update.loadingItems || [];
        if (this.isModalOpen) {
          this.renderCartItems();
        }
        break;

      case 'REFRESH_COMPLETED':
      case 'ITEM_API_UPDATED':
        this.updateUI();
        if (this.isModalOpen) {
          this.renderCartItems();
        }
        break;
    }
  }

  /**
   * Update UI with current state
   */
  async updateUI() {
    try {
      if (!this.cartAPI) return;

      const summary = await this.cartAPI.getCartSummary();
      this.currentSummary = summary;

      this.updateSummaryDisplays();
      this.updateButtons();
    } catch (error) {
      console.error('❌ Error updating UI:', error);
    }
  }

  /**
   * Update summary displays
   */
  updateSummaryDisplays() {
    const { itemsCount, totalValue, uniqueProducts } = this.elements.cartSummary;
    const { itemsCount: modalItemsCount, totalValue: modalTotalValue, uniqueProducts: modalUniqueProducts } = this.elements.modalSummary;

    const summary = this.currentSummary;

    // Update main summary
    if (itemsCount) itemsCount.textContent = summary.totalItems || 0;
    if (totalValue) totalValue.textContent = this.formatPrice(summary.totalValue || 0);
    if (uniqueProducts) uniqueProducts.textContent = summary.uniqueProducts || 0;

    // Update modal summary
    if (modalItemsCount) modalItemsCount.textContent = summary.totalItems || 0;
    if (modalTotalValue) modalTotalValue.textContent = this.formatPrice(summary.totalValue || 0);
    if (modalUniqueProducts) modalUniqueProducts.textContent = summary.uniqueProducts || 0;
  }

  /**
   * Update buttons
   */
  updateButtons() {
    const { showCartBtn } = this.elements;
    const itemCount = this.currentItems.length;

    if (showCartBtn) {
      showCartBtn.innerHTML = `<span>🛒</span> مشاهده سبد (${itemCount})`;
    }
  }

  /**
   * Show modal
   */
  async showModal() {
    const { modal, cartItemsContainer } = this.elements;

    if (!modal) return;

    try {
      console.log('📱 Showing Smart Cart modal');

      modal.style.display = 'flex';
      modal.style.visibility = 'visible';
      modal.style.opacity = '1';
      this.isModalOpen = true;

      // Refresh cart data when opening
      await this.cartAPI.refreshItems();

      // Render items
      this.renderCartItems();

      // Update summary
      this.updateUI();

    } catch (error) {
      console.error('❌ Error showing modal:', error);
    }
  }

  /**
   * Hide modal
   */
  hideModal() {
    const { modal } = this.elements;

    if (modal) {
      modal.style.display = 'none';
      this.isModalOpen = false;
    }
  }

  /**
   * Render cart items
   */
  renderCartItems() {
    const { cartItemsContainer } = this.elements;

    if (!cartItemsContainer) return;

    if (this.currentItems.length === 0) {
      cartItemsContainer.innerHTML = '<div class="no-items">سبد خالی است</div>';
      return;
    }

    const itemsHTML = this.currentItems.map(item => this.renderCartItem(item)).join('');
    cartItemsContainer.innerHTML = itemsHTML;

    console.log(`✅ Rendered ${this.currentItems.length} cart items`);
  }

  /**
   * Render individual cart item
   */
  renderCartItem(item) {
    const isLoading = this.loadingItems.includes(item.id);
    const needsRefresh = item._apiStatus?.needsRefresh || false;

    const itemPrice = this.formatPrice(item.price || 0);
    const totalPrice = this.formatPrice((item.price || 0) * item.quantity);
    const addedDate = new Date(item.addedAt).toLocaleDateString('fa-IR');

    // Get variant display text
    const variantText = this.getVariantDisplayText(item.selectedVariant);

    // Get available options
    const availableVariants = this.getAvailableVariants(item);
    const availableSellers = this.getAvailableSellers(item);

    return `
      <div class="smart-cart-item" data-item-id="${item.id}" style="
        background: white;
        border: 1px solid ${needsRefresh ? '#fbbf24' : '#e2e8f0'};
        border-radius: 8px;
        padding: 12px;
        margin-bottom: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        opacity: ${isLoading ? '0.7' : '1'};
        position: relative;
      ">
        ${this.renderItemHeader(item)}
        ${this.renderItemControls(item, availableVariants, availableSellers)}
        ${this.renderItemFooter(item, totalPrice, addedDate)}
        ${isLoading ? this.renderLoadingOverlay() : ''}
      </div>
    `;
  }

  /**
   * Render item header with image and title
   */
  renderItemHeader(item) {
    return `
      <div class="cart-item-header" style="display: flex; gap: 12px; align-items: flex-start;">
        <div class="cart-item-image" style="flex-shrink: 0;">
          ${item.thumbnail ?
            `<img src="${item.thumbnail}" alt="${item.title}" style="width: 48px; height: 48px; border-radius: 6px; object-fit: cover; border: 1px solid #e2e8f0;">` :
            `<div style="width: 48px; height: 48px; border-radius: 6px; background: #f8fafc; display: flex; align-items: center; justify-content: center; color: #64748b; border: 1px solid #e2e8f0;">📦</div>`
          }
        </div>
        <div class="cart-item-info" style="flex: 1; min-width: 0;">
          <div class="cart-item-title" style="
            line-height: 1.4;
            max-height: 2.8em;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            margin-bottom: 6px;
          ">
            <a href="${item.productUrl || `https://www.digikala.com/product/dkp-${item.productId}/`}" target="_blank" style="
              color: #1e293b;
              text-decoration: none;
              font-weight: 500;
              font-size: 13px;
              line-height: 1.4;
            " title="${item.title}">
              ${this.truncateText(item.title || 'در حال بارگذاری...', 80)}
            </a>
          </div>
          ${this.renderVariantInfo(item)}
        </div>
        <button class="remove-cart-item" data-item-id="${item.id}" title="حذف از سبد" style="
          background: #fee2e2;
          color: #dc2626;
          border: 1px solid #fecaca;
          border-radius: 6px;
          padding: 6px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          🗑️
        </button>
      </div>
    `;
  }

  /**
   * Render item controls (quantity, variant, seller)
   */
  renderItemControls(item, availableVariants, availableSellers) {
    return `
      <div class="cart-item-controls" style="
        display: flex;
        gap: 12px;
        align-items: center;
        margin-top: 8px;
        font-size: 11px;
        color: #64748b;
        flex-wrap: wrap;
      ">
        <span class="cart-item-price" style="font-weight: 500; color: ${item.price > 0 ? '#059669' : '#dc2626'};">
          قیمت: ${this.formatPrice(item.price || 0)}
        </span>
        ${this.renderQuantityControls(item)}
        ${this.renderVariantSelector(item, availableVariants)}
        ${this.renderSellerSelector(item, availableSellers)}
      </div>
    `;
  }

  /**
   * Render quantity controls
   */
  renderQuantityControls(item) {
    return `
      <div class="quantity-controls" style="
        display: flex;
        align-items: center;
        gap: 8px;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        padding: 2px;
      ">
        <button class="quantity-decrease" data-item-id="${item.id}"
                ${item.quantity <= 1 ? 'disabled' : ''}
                style="
          background: white;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: ${item.quantity <= 1 ? 'not-allowed' : 'pointer'};
          opacity: ${item.quantity <= 1 ? '0.5' : '1'};
          font-weight: bold;
        ">−</button>
        <span class="quantity-display" style="
          font-weight: 500;
          color: #374151;
          min-width: 20px;
          text-align: center;
          font-size: 12px;
        ">${item.quantity}</span>
        <button class="quantity-increase" data-item-id="${item.id}" style="
          background: white;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          font-weight: bold;
        ">+</button>
      </div>
    `;
  }

  /**
   * Render variant selector
   */
  renderVariantSelector(item, availableVariants) {
    if (availableVariants.length <= 1) {
      return '';
    }

    const variantOptions = availableVariants.map(variant =>
      `<option value="${variant.id}" ${variant.id === item.variantId ? 'selected' : ''}>
        ${variant.title}${variant.price ? ` - ${this.formatPrice(variant.price)}` : ''}
      </option>`
    ).join('');

    return `
      <div class="variant-selector" style="display: flex; align-items: center; gap: 6px;">
        <label style="font-size: 10px; color: #6b7280; font-weight: 500;">تنوع:</label>
        <select class="variant-select" data-item-id="${item.id}" style="
          font-size: 10px;
          padding: 2px 4px;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          background: white;
        ">
          ${variantOptions}
        </select>
      </div>
    `;
  }

  /**
   * Render seller selector
   */
  renderSellerSelector(item, availableSellers) {
    if (availableSellers.length <= 1) {
      const seller = availableSellers[0];
      if (seller) {
        return `
          <div class="seller-info" style="font-size: 10px; color: #6b7280;">
            فروشنده: <span style="color: #059669; font-weight: 500;">${seller.name}</span>
          </div>
        `;
      }
      return '';
    }

    const sellerOptions = availableSellers.map(seller =>
      `<option value="${seller.id}" ${seller.id === item.selectedSellerId ? 'selected' : ''}>
        ${seller.name} - ${this.formatPrice(seller.price)}
      </option>`
    ).join('');

    return `
      <div class="seller-selector" style="display: flex; align-items: center; gap: 6px;">
        <label style="font-size: 10px; color: #6b7280; font-weight: 500;">فروشنده:</label>
        <select class="seller-select" data-item-id="${item.id}" style="
          font-size: 10px;
          padding: 2px 4px;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          background: white;
        ">
          ${sellerOptions}
        </select>
      </div>
    `;
  }

  /**
   * Render item footer with total and metadata
   */
  renderItemFooter(item, totalPrice, addedDate) {
    return `
      <div class="cart-item-footer" style="
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 8px;
        padding-top: 8px;
        border-top: 1px solid #f1f5f9;
        font-size: 11px;
      ">
        <div class="cart-item-total" style="font-weight: 600; color: #059669;">
          مجموع: ${totalPrice}
        </div>
        <div class="cart-item-meta" style="color: #64748b;">
          افزودن: ${addedDate}
        </div>
      </div>
    `;
  }

  /**
   * Render loading overlay
   */
  renderLoadingOverlay() {
    return `
      <div class="loading-overlay" style="
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(255,255,255,0.8);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1;
      ">
        <div style="
          width: 20px;
          height: 20px;
          border: 2px solid #e2e8f0;
          border-top: 2px solid #3b82f6;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        "></div>
      </div>
    `;
  }

  /**
   * Handle cart item clicks
   */
  async handleCartItemClick(event) {
    const removeBtn = event.target.closest('.remove-cart-item');
    const increaseBtn = event.target.closest('.quantity-increase');
    const decreaseBtn = event.target.closest('.quantity-decrease');

    if (removeBtn) {
      const itemId = removeBtn.dataset.itemId;
      await this.removeItem(itemId);
    } else if (increaseBtn) {
      const itemId = increaseBtn.dataset.itemId;
      await this.increaseQuantity(itemId);
    } else if (decreaseBtn) {
      const itemId = decreaseBtn.dataset.itemId;
      await this.decreaseQuantity(itemId);
    }
  }

  /**
   * Handle cart item changes (dropdowns)
   */
  async handleCartItemChange(event) {
    const variantSelect = event.target.closest('.variant-select');
    const sellerSelect = event.target.closest('.seller-select');

    if (variantSelect) {
      const itemId = variantSelect.dataset.itemId;
      const variantId = variantSelect.value;
      await this.changeVariant(itemId, variantId);
    } else if (sellerSelect) {
      const itemId = sellerSelect.dataset.itemId;
      const sellerId = sellerSelect.value;
      await this.changeSeller(itemId, sellerId);
    }
  }

  /**
   * Cart operations using API
   */
  async removeItem(itemId) {
    try {
      await this.cartAPI.removeItem(itemId);
      console.log(`✅ Removed item: ${itemId}`);
    } catch (error) {
      console.error('❌ Error removing item:', error);
    }
  }

  async increaseQuantity(itemId) {
    try {
      await this.cartAPI.increaseQuantity(itemId);
      console.log(`✅ Increased quantity: ${itemId}`);
    } catch (error) {
      console.error('❌ Error increasing quantity:', error);
    }
  }

  async decreaseQuantity(itemId) {
    try {
      await this.cartAPI.decreaseQuantity(itemId);
      console.log(`✅ Decreased quantity: ${itemId}`);
    } catch (error) {
      console.error('❌ Error decreasing quantity:', error);
    }
  }

  async changeVariant(itemId, variantId) {
    try {
      await this.cartAPI.changeVariant(itemId, variantId);
      console.log(`✅ Changed variant: ${itemId} → ${variantId}`);
    } catch (error) {
      console.error('❌ Error changing variant:', error);
    }
  }

  async changeSeller(itemId, sellerId) {
    try {
      await this.cartAPI.changeSeller(itemId, sellerId);
      console.log(`✅ Changed seller: ${itemId} → ${sellerId}`);
    } catch (error) {
      console.error('❌ Error changing seller:', error);
    }
  }

  async clearCart() {
    try {
      const confirmed = confirm('آیا مطمئن هستید که می‌خواهید تمام محصولات را از سبد حذف کنید؟');
      if (!confirmed) return;

      await this.cartAPI.clearCart();
      console.log('✅ Cart cleared');
    } catch (error) {
      console.error('❌ Error clearing cart:', error);
    }
  }

  /**
   * Utility methods
   */
  formatPrice(price) {
    if (!price || price === 0) return '0 تومان';
    const tomans = Math.floor(price / 10);
    return `${tomans.toLocaleString('fa-IR')} تومان`;
  }

  truncateText(text, maxLength) {
    if (!text || text.length <= maxLength) return text;
    return text.substring(0, maxLength - 3) + '...';
  }

  getVariantDisplayText(variant) {
    if (!variant) return null;

    const parts = [];
    if (variant.color) parts.push(`رنگ: ${variant.color.title}`);
    if (variant.size) parts.push(`سایز: ${variant.size.title}`);
    if (variant.warranty) parts.push(`گارانتی: ${variant.warranty.title}`);

    return parts.length > 0 ? parts.join(', ') : null;
  }

  renderVariantInfo(item) {
    const variantText = this.getVariantDisplayText(item.selectedVariant);
    if (!variantText) return '';

    return `
      <div class="cart-item-variant" style="
        font-size: 11px;
        color: #64748b;
        background: #f1f5f9;
        padding: 2px 6px;
        border-radius: 4px;
        display: inline-block;
        margin-bottom: 4px;
      ">${variantText}</div>
    `;
  }

  getAvailableVariants(item) {
    if (!item.variants || item.variants.length <= 1) {
      return [];
    }

    // Add "All Variants (Best Price)" option
    const variants = [{
      id: 'all_best_price',
      title: 'همه تنوع‌ها (بهترین قیمت)',
      price: null
    }];

    // Add actual variants
    return variants.concat(item.variants);
  }

  getAvailableSellers(item) {
    return item.sellers || [];
  }

  /**
   * Cleanup
   */
  cleanup() {
    if (this.cartAPI) {
      this.cartAPI.cleanup();
    }
    super.cleanup();
  }
}

// Register the module
window.SmartCartClient = SmartCartClient;