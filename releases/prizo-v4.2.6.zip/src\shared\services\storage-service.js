/**
 * @Author: Zana Saedpanah
 * @Date: 2025-08-04
 * Storage Service - Enhanced storage management with fallback support
 */
class StorageService {
  constructor(eventBus) {
    this.eventBus = eventBus;
    this.isAvailable = true;
    this.fallbackStorage = new Map();
    this.storagePrefix = 'digikala_extension_';
    this.settings = {};
  }

  async initialize() {
    try {
      await this.checkAvailability();
      await this.loadSettings();
      this.eventBus.emit('storage:initialized');
      console.log('✅ Storage service initialized');
    } catch (error) {
      console.error('❌ Storage service initialization failed:', error);
      this.eventBus.emit('storage:init-error', error);
    }
  }

  async checkAvailability() {
    try {
      if (!ExtensionCore.BrowserCompat.supportsExtensionAPI()) {
        console.log('📱 Extension API not supported, using fallback storage');
        this.isAvailable = false;
        return false;
      }
      
      await chrome.storage.local.get(['test_key']);
      this.isAvailable = true;
      return true;
    } catch (error) {
      console.warn('⚠️ Chrome storage unavailable, using fallback:', error);
      this.isAvailable = false;
      return false;
    }
  }

  async loadSettings() {
    try {
      const defaultSettings = {
        showSellerPrices: true,
        showMonthlyPrices: true,
        showVariantComparison: true,
        showCartPrices: true,
        showOrderPrices: true,
        enableNotifications: true,
        autoUpdate: true,
        updateInterval: 30000,
        maxConcurrentRequests: 5
      };

      const stored = await this.get('settings', defaultSettings);
      this.settings = { ...defaultSettings, ...stored };
      
      this.eventBus.emit('storage:settings-loaded', this.settings);
      console.log('✅ Settings loaded:', this.settings);
    } catch (error) {
      console.error('❌ Failed to load settings:', error);
      this.eventBus.emit('storage:settings-error', error);
    }
  }

  async saveSettings(newSettings) {
    try {
      this.settings = { ...this.settings, ...newSettings };
      await this.set('settings', this.settings);
      this.eventBus.emit('storage:settings-saved', this.settings);
      console.log('✅ Settings saved:', newSettings);
    } catch (error) {
      console.error('❌ Failed to save settings:', error);
      this.eventBus.emit('storage:settings-save-error', error);
      throw error;
    }
  }

  getSetting(key, defaultValue = null) {
    return this.settings[key] !== undefined ? this.settings[key] : defaultValue;
  }

  async setSetting(key, value) {
    const newSettings = { [key]: value };
    await this.saveSettings(newSettings);
  }

  validateKey(key) {
    if (typeof key !== 'string' || key.length === 0) {
      throw new Error('Storage key must be a non-empty string');
    }

    if (key.length > 256) {
      throw new Error('Storage key too long (max 256 characters)');
    }

    return this.storagePrefix + key;
  }

  async get(keys, defaultValues = {}) {
    try {
      if (!this.isAvailable) {
        await this.checkAvailability();
      }

      const keyArray = Array.isArray(keys) ? keys : [keys];
      const validatedKeys = keyArray.map(key => this.validateKey(key));

      if (this.isAvailable) {
        const result = await ExtensionCore.BrowserCompat.safeStorageGet(validatedKeys, {});

        const cleanResult = {};
        keyArray.forEach((originalKey, index) => {
          const validatedKey = validatedKeys[index];
          cleanResult[originalKey] = result[validatedKey] !== undefined
            ? result[validatedKey]
            : defaultValues[originalKey];
        });

        return Array.isArray(keys) ? cleanResult : cleanResult[keys];
      } else {
        const result = {};
        keyArray.forEach(key => {
          const validatedKey = this.validateKey(key);
          result[key] = this.fallbackStorage.has(validatedKey)
            ? this.fallbackStorage.get(validatedKey)
            : defaultValues[key];
        });

        return Array.isArray(keys) ? result : result[keys];
      }
    } catch (error) {
      console.error('❌ Storage get error:', error);
      this.eventBus.emit('storage:get-error', { keys, error });

      const result = {};
      const keyArray = Array.isArray(keys) ? keys : [keys];
      keyArray.forEach(key => {
        result[key] = defaultValues[key];
      });

      return Array.isArray(keys) ? result : result[keys];
    }
  }

  async set(items) {
    try {
      if (!this.isAvailable) {
        await this.checkAvailability();
      }

      const validatedItems = {};
      for (const [key, value] of Object.entries(items)) {
        const validatedKey = this.validateKey(key);

        const serialized = JSON.stringify(value);
        if (serialized.length > 8192) {
          throw new Error(`Value too large for key "${key}" (max 8KB)`);
        }

        validatedItems[validatedKey] = value;
      }

      if (this.isAvailable) {
        const success = await ExtensionCore.BrowserCompat.safeStorageSet(validatedItems);
        if (success) {
          console.log('✅ Storage set successful:', Object.keys(items));
          this.eventBus.emit('storage:set-success', { keys: Object.keys(items) });
        } else {
          this.isAvailable = false;
          for (const [key, value] of Object.entries(validatedItems)) {
            this.fallbackStorage.set(key, value);
          }
          console.log('✅ Fallback storage set after API failure:', Object.keys(items));
        }
      } else {
        for (const [key, value] of Object.entries(validatedItems)) {
          this.fallbackStorage.set(key, value);
        }
        console.log('✅ Fallback storage set successful:', Object.keys(items));
      }

      return true;
    } catch (error) {
      console.error('❌ Storage set error:', error);
      this.eventBus.emit('storage:set-error', { items, error });
      throw new Error(`Storage operation failed: ${error.message}`);
    }
  }

  async remove(keys) {
    try {
      if (!this.isAvailable) {
        await this.checkAvailability();
      }

      const keyArray = Array.isArray(keys) ? keys : [keys];
      const validatedKeys = keyArray.map(key => this.validateKey(key));

      if (this.isAvailable) {
        await chrome.storage.local.remove(validatedKeys);
        console.log('✅ Storage remove successful:', keyArray);
      } else {
        validatedKeys.forEach(key => {
          this.fallbackStorage.delete(key);
        });
        console.log('✅ Fallback storage remove successful:', keyArray);
      }

      this.eventBus.emit('storage:remove-success', { keys: keyArray });
      return true;
    } catch (error) {
      console.error('❌ Storage remove error:', error);
      this.eventBus.emit('storage:remove-error', { keys, error });
      throw new Error(`Storage remove failed: ${error.message}`);
    }
  }

  async clearByPattern(pattern) {
    try {
      if (!this.isAvailable) {
        await this.checkAvailability();
      }

      if (this.isAvailable) {
        const allStorage = await chrome.storage.local.get(null);
        const keysToRemove = Object.keys(allStorage).filter(key => {
          const cleanKey = key.startsWith(this.storagePrefix)
            ? key.substring(this.storagePrefix.length)
            : key;
          return pattern.test(cleanKey);
        });

        if (keysToRemove.length > 0) {
          await chrome.storage.local.remove(keysToRemove);
          console.log(`✅ Cleared ${keysToRemove.length} items matching pattern`);
        }
      } else {
        const keysToRemove = Array.from(this.fallbackStorage.keys()).filter(key => {
          const cleanKey = key.startsWith(this.storagePrefix)
            ? key.substring(this.storagePrefix.length)
            : key;
          return pattern.test(cleanKey);
        });

        keysToRemove.forEach(key => {
          this.fallbackStorage.delete(key);
        });

        console.log(`✅ Cleared ${keysToRemove.length} fallback items matching pattern`);
      }

      this.eventBus.emit('storage:clear-success', { pattern });
      return true;
    } catch (error) {
      console.error('❌ Storage clear error:', error);
      this.eventBus.emit('storage:clear-error', { pattern, error });
      throw new Error(`Storage clear failed: ${error.message}`);
    }
  }

  async clearAll() {
    try {
      await this.clearByPattern(/.*/);
      this.fallbackStorage.clear();
      console.log('🧹 All storage cleared');
      this.eventBus.emit('storage:cleared-all');
    } catch (error) {
      console.error('❌ Failed to clear all storage:', error);
      throw error;
    }
  }

  getStorageStats() {
    return {
      isAvailable: this.isAvailable,
      fallbackSize: this.fallbackStorage.size,
      settings: this.settings
    };
  }
}

window.StorageService = StorageService;