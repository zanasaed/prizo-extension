/**
 * End-to-End Test Scenarios for Smart Cart
 * Manual and automated test cases covering critical user flows
 */

// Playwright E2E Tests
const { test, expect } = require('@playwright/test');

test.describe('Smart Cart E2E Tests', () => {
  test.beforeEach(async ({ page }) => {
    // Setup extension context and navigate to test page
    await page.goto('https://www.digikala.com/product/dkp-12565266/');

    // Wait for extension to load
    await page.waitForTimeout(2000);
  });

  test('Add item to cart from product page', async ({ page }) => {
    // Find Smart Cart button
    const smartCartBtn = await page.locator('.smart-cart-button');
    await expect(smartCartBtn).toBeVisible();

    // Verify initial state
    await expect(smartCartBtn).toContainText('افزودن به سبد هوشمند');

    // Click to add item
    await smartCartBtn.click();

    // Verify success animation
    await expect(smartCartBtn).toContainText('اضافه شد');

    // Wait for state update
    await page.waitForTimeout(1500);

    // Verify button state changed
    await expect(smartCartBtn).toContainText('افزایش تعداد');
  });

  test('Quantity increment behavior', async ({ page }) => {
    // Add item first
    const smartCartBtn = await page.locator('.smart-cart-button');
    await smartCartBtn.click();
    await page.waitForTimeout(1500);

    // Click again to increment
    await smartCartBtn.click();
    await page.waitForTimeout(1000);

    // Should show quantity (2)
    await expect(smartCartBtn).toContainText('(2)');

    // Click once more
    await smartCartBtn.click();
    await page.waitForTimeout(1000);

    // Should show quantity (3)
    await expect(smartCartBtn).toContainText('(3)');
  });

  test('Popup cart management', async ({ page, context }) => {
    // Add item from product page
    const smartCartBtn = await page.locator('.smart-cart-button');
    await smartCartBtn.click();
    await page.waitForTimeout(1500);

    // Open extension popup
    const extensionId = 'your-extension-id'; // Replace with actual ID
    const popupPage = await context.newPage();
    await popupPage.goto(`chrome-extension://${extensionId}/popup.html`);

    // Wait for popup to load
    await popupPage.waitForSelector('#showSmartCartBtn');

    // Verify cart shows 1 item
    const cartItemsCount = await popupPage.locator('#cartItemsCount');
    await expect(cartItemsCount).toContainText('1');

    // Open cart modal
    await popupPage.click('#showSmartCartBtn');
    await popupPage.waitForSelector('#smartCartModal');

    // Verify modal shows cart items
    const modalItems = await popupPage.locator('#smartCartItems .cart-item');
    await expect(modalItems).toHaveCount(1);

    // Test quantity controls
    const qtyIncrease = await popupPage.locator('.qty-increase');
    await qtyIncrease.click();

    // Verify quantity updated
    const qtyInput = await popupPage.locator('.qty-input');
    await expect(qtyInput).toHaveValue('2');
  });

  test('Fullpage cart optimization', async ({ page, context }) => {
    // Add multiple items
    await addTestItems(page, [
      { productId: '12565266', quantity: 2 },
      { productId: '12345678', quantity: 1 },
      { productId: '87654321', quantity: 3 }
    ]);

    // Open fullpage cart
    const fullpagePage = await context.newPage();
    await fullpagePage.goto(`chrome-extension://your-extension-id/fullpage.html`);

    await fullpagePage.waitForSelector('.smart-cart-fullpage');

    // Verify cart loaded
    const cartItems = await fullpagePage.locator('.cart-item');
    await expect(cartItems).toHaveCount(3);

    // Test optimization
    const optimizeBtn = await fullpagePage.locator('#optimizeCartBtn');
    await optimizeBtn.click();

    await fullpagePage.waitForSelector('.optimization-results', { timeout: 10000 });

    // Verify optimization results
    const optimizationResult = await fullpagePage.locator('.optimization-summary');
    await expect(optimizationResult).toBeVisible();
  });

  test('Variant selection flow', async ({ page }) => {
    // Navigate to product with variants
    await page.goto('https://www.digikala.com/product/dkp-variant-product/');

    // Select a color variant
    const colorOption = await page.locator('[data-testid="color-selector"] .color-option').first();
    await colorOption.click();
    await page.waitForTimeout(500);

    // Select a size variant
    const sizeOption = await page.locator('[data-testid="size-selector"] .size-option').first();
    await sizeOption.click();
    await page.waitForTimeout(500);

    // Add to Smart Cart
    const smartCartBtn = await page.locator('.smart-cart-button');
    await smartCartBtn.click();

    // Verify variant info is shown
    const variantInfo = await page.locator('.smart-cart-variant-info');
    await expect(variantInfo).toBeVisible();
    await expect(variantInfo).toContainText('تنوع انتخابی');
  });

  test('Cross-context synchronization', async ({ page, context }) => {
    // Add item in content script
    const smartCartBtn = await page.locator('.smart-cart-button');
    await smartCartBtn.click();
    await page.waitForTimeout(1000);

    // Open popup
    const popupPage = await context.newPage();
    await popupPage.goto(`chrome-extension://your-extension-id/popup.html`);
    await popupPage.waitForTimeout(1000);

    // Verify sync
    const cartCount = await popupPage.locator('#cartItemsCount');
    await expect(cartCount).toContainText('1');

    // Open fullpage
    const fullpagePage = await context.newPage();
    await fullpagePage.goto(`chrome-extension://your-extension-id/fullpage.html`);
    await fullpagePage.waitForTimeout(1000);

    // Verify sync in fullpage
    const fullpageItems = await fullpagePage.locator('.cart-item');
    await expect(fullpageItems).toHaveCount(1);

    // Update quantity in popup
    await popupPage.click('#showSmartCartBtn');
    await popupPage.click('.qty-increase');
    await page.waitForTimeout(1000);

    // Verify sync back to fullpage
    await fullpagePage.reload();
    await fullpagePage.waitForTimeout(1000);
    const updatedQty = await fullpagePage.locator('.qty-input').first();
    await expect(updatedQty).toHaveValue('2');
  });

  test('Error handling and recovery', async ({ page }) => {
    // Simulate network error by blocking API requests
    await page.route('**/api/v1/product/**', route => route.abort());

    // Try to add item
    const smartCartBtn = await page.locator('.smart-cart-button');
    await smartCartBtn.click();

    // Should show error state briefly
    await expect(smartCartBtn).toContainText('خطا در افزودن');

    // Should recover to normal state
    await page.waitForTimeout(3000);
    await expect(smartCartBtn).toContainText('افزودن به سبد هوشمند');

    // Re-enable network and retry
    await page.unroute('**/api/v1/product/**');
    await smartCartBtn.click();

    // Should work normally
    await expect(smartCartBtn).toContainText('اضافه شد');
  });

  test('Storage overflow handling', async ({ page }) => {
    // Add many items to trigger storage optimization
    await addTestItems(page, Array(50).fill(0).map((_, i) => ({
      productId: `product_${i}`,
      quantity: 1
    })));

    // Verify cart still works
    const smartCartBtn = await page.locator('.smart-cart-button');
    await expect(smartCartBtn).toBeVisible();

    // Check console for optimization messages
    const logs = [];
    page.on('console', msg => logs.push(msg.text()));

    await smartCartBtn.click();
    await page.waitForTimeout(2000);

    // Should have optimization logs
    const optimizationLogs = logs.filter(log =>
      log.includes('Optimizing cart') || log.includes('Storage overflow')
    );
    expect(optimizationLogs.length).toBeGreaterThan(0);
  });
});

// Helper Functions
async function addTestItems(page, items) {
  for (const item of items) {
    await page.goto(`https://www.digikala.com/product/dkp-${item.productId}/`);
    await page.waitForTimeout(1000);

    const smartCartBtn = await page.locator('.smart-cart-button');

    for (let i = 0; i < item.quantity; i++) {
      await smartCartBtn.click();
      await page.waitForTimeout(500);
    }
  }
}

// Manual Test Scenarios
const manualTestScenarios = [
  {
    title: "Basic Add/Remove Flow",
    steps: [
      "1. Navigate to any Digikala product page",
      "2. Verify Smart Cart button appears below price",
      "3. Click 'افزودن به سبد هوشمند' button",
      "4. Verify button changes to 'افزایش تعداد (1)'",
      "5. Click button again",
      "6. Verify quantity increases to (2)",
      "7. Open extension popup",
      "8. Verify cart shows 2 items total",
      "9. Click 'نمایش سبد هوشمند' in popup",
      "10. Verify modal opens with 1 product, quantity 2"
    ],
    expectedResult: "Item successfully added and quantity tracked correctly across all contexts"
  },

  {
    title: "Variant Selection",
    steps: [
      "1. Navigate to product with color/size variants",
      "2. Select specific color option",
      "3. Select specific size option",
      "4. Verify Smart Cart button shows variant info",
      "5. Add to cart",
      "6. Change variant selection",
      "7. Add to cart again",
      "8. Open popup cart",
      "9. Verify 2 separate entries for different variants"
    ],
    expectedResult: "Different variants are tracked as separate cart items"
  },

  {
    title: "Cross-Context Sync",
    steps: [
      "1. Add item via product page button",
      "2. Open popup - verify count shows correctly",
      "3. Open fullpage in new tab - verify item appears",
      "4. In fullpage, change quantity to 5",
      "5. Return to popup - verify count updated to 5",
      "6. Return to product page - verify button shows (5)",
      "7. Add one more via product page",
      "8. Check all contexts show quantity 6"
    ],
    expectedResult: "All contexts stay synchronized in real-time"
  },

  {
    title: "Cart Optimization",
    steps: [
      "1. Add 10+ different products to cart",
      "2. Open fullpage cart interface",
      "3. Click 'بهینه‌سازی سبد خرید' button",
      "4. Wait for optimization to complete",
      "5. Verify optimization results shown",
      "6. Verify total savings calculated",
      "7. Apply optimization",
      "8. Verify cart updated with optimal selection"
    ],
    expectedResult: "Cart optimization finds better price combinations and applies them correctly"
  },

  {
    title: "Error Recovery",
    steps: [
      "1. Disconnect internet",
      "2. Try to add item to cart",
      "3. Verify error message appears briefly",
      "4. Verify button returns to normal state",
      "5. Reconnect internet",
      "6. Try adding item again",
      "7. Verify operation succeeds"
    ],
    expectedResult: "Graceful error handling with automatic recovery"
  },

  {
    title: "Storage Limits",
    steps: [
      "1. Add 50+ different products to cart",
      "2. Continue adding until storage optimization triggers",
      "3. Verify console shows optimization messages",
      "4. Verify cart still functions normally",
      "5. Verify oldest items automatically removed if needed",
      "6. Verify no data corruption or errors"
    ],
    expectedResult: "Storage limits handled gracefully without user-facing errors"
  }
];

// Safety/Edge Cases Checklist
const edgeCasesChecklist = [
  {
    case: "Sellers without variants",
    test: "Product with single variant but multiple sellers",
    expectedBehavior: "Should show seller dropdown, variant dropdown disabled"
  },

  {
    case: "Variants without sellers",
    test: "Product with multiple variants but single seller",
    expectedBehavior: "Should show variant dropdown, seller dropdown shows single option"
  },

  {
    case: "Stock = 0",
    test: "Product or variant out of stock",
    expectedBehavior: "Should show 'ناموجود' status, disable add button"
  },

  {
    case: "API errors",
    test: "Network timeout, 500 errors, rate limiting",
    expectedBehavior: "Graceful fallback, retry logic, user notification"
  },

  {
    case: "Rate limit responses",
    test: "Rapid API requests triggering rate limits",
    expectedBehavior: "Request queuing, automatic retry with backoff"
  },

  {
    case: "Invalid product data",
    test: "Malformed API responses, missing price data",
    expectedBehavior: "Data validation, fallback to cached values"
  },

  {
    case: "Storage corruption",
    test: "Invalid JSON in storage, conflicting formats",
    expectedBehavior: "Data migration, corruption recovery"
  },

  {
    case: "Concurrent updates",
    test: "Multiple tabs updating cart simultaneously",
    expectedBehavior: "Proper locking, conflict resolution"
  },

  {
    case: "Large quantities",
    test: "Quantity > 99, negative values, decimal inputs",
    expectedBehavior: "Input validation, range clamping"
  },

  {
    case: "Extension context loss",
    test: "Extension reload, background script restart",
    expectedBehavior: "State persistence, automatic recovery"
  }
];

// Performance Test Suite
const performanceTests = [
  {
    name: "Cart Load Performance",
    description: "Measure time to load and render large cart",
    setup: "Cart with 100 items",
    metric: "Load time < 2 seconds",
    test: async () => {
      const start = performance.now();
      // Load cart with 100 items
      const end = performance.now();
      return end - start;
    }
  },

  {
    name: "API Response Time",
    description: "Measure product data fetch performance",
    setup: "Network throttling enabled",
    metric: "Response time < 1 second",
    test: async () => {
      const start = performance.now();
      // Fetch product data
      const end = performance.now();
      return end - start;
    }
  },

  {
    name: "Optimization Algorithm",
    description: "Measure cart optimization computation time",
    setup: "Cart with 20 products, 3 sellers each",
    metric: "Optimization time < 5 seconds",
    test: async () => {
      const start = performance.now();
      // Run optimization
      const end = performance.now();
      return end - start;
    }
  }
];

module.exports = {
  manualTestScenarios,
  edgeCasesChecklist,
  performanceTests
};