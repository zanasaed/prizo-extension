/**
 * @Author: Zana Saedpanah
 * @Date: 2025-01-18
 * Smart Cart Manager - Manages smart cart functionality for product pages
 */
class SmartCartManager {
  constructor(eventBus, storageService, optimizedAPIService = null, cacheService = null) {
    this.eventBus = eventBus;
    this.storageService = storageService;
    this.optimizedAPIService = optimizedAPIService;
    this.cacheService = cacheService;
    this.storageKey = 'smart_cart_items';
    this.cart = [];
    this.initialized = false;

    // Data refresh settings
    this.refreshSettings = {
      autoRefreshOnOpen: true,
      refreshInterval: 2 * 60 * 1000, // 2 minutes
      maxAge: 5 * 60 * 1000, // 5 minutes
      batchSize: 5
    };

    // Loading states
    this.loadingStates = new Map();
    this.lastRefreshTime = null;
  }

  async initialize() {
    try {
      await this.loadCart();
      this.setupEventListeners();
      this.initialized = true;
      this.eventBus.emit('smart-cart:initialized');
      console.log('✅ Smart Cart Manager initialized with optimized services');

      // Initialize optimized services if available
      if (this.cacheService) {
        await this.cacheService.initialize();
      }
    } catch (error) {
      console.error('❌ Smart Cart Manager initialization failed:', error);
      this.eventBus.emit('smart-cart:init-error', error);
    }
  }

  async loadCart() {
    try {
      const cartData = await this.storageService.get(this.storageKey, []);
      const rawCart = Array.isArray(cartData) ? cartData : [];

      console.log(`📦 Loaded ${rawCart.length} items from Smart Cart storage`);

      // MIGRATION: Clean up contaminated variant IDs from existing cart items
      const migratedCart = this.migrateCartData(rawCart);

      this.cart = migratedCart;

      // Save migrated cart if any changes were made
      const itemsChanged = migratedCart.some((item, index) => {
        const original = rawCart[index];
        return !original || item.vId !== original.vId || item.id !== original.id;
      });

      if (itemsChanged && migratedCart.length > 0) {
        console.log('🔄 Migrated cart data - saving cleaned variant IDs');
        await this.saveCart();
      }
    } catch (error) {
      console.error('❌ Failed to load Smart Cart:', error);
      this.cart = [];
    }
  }

  migrateCartData(cartItems) {
    console.log('🔄 CART MIGRATION - Starting cart data migration');

    return cartItems.map((item, index) => {
      const hasContaminatedVariantId = this.isContaminatedVariantId(item.vId);
      const hasContaminatedItemId = this.isContaminatedItemId(item.id);

      if (!hasContaminatedVariantId && !hasContaminatedItemId) {
        return item; // Item is already clean
      }

      console.log(`🧹 CART MIGRATION - Cleaning item ${index + 1}:`, {
        productId: item.pId,
        oldVariantId: item.vId,
        oldItemId: item.id,
        contaminated: { variantId: hasContaminatedVariantId, itemId: hasContaminatedItemId }
      });

      // Create clean variant ID from contaminated data
      const cleanVariantId = this.extractCleanVariantId(item.vId);

      // Update the item with clean IDs
      const cleanedItem = {
        ...item,
        vId: cleanVariantId,
        id: `sc_${item.pId}_${cleanVariantId || 'def'}_${item.at || Date.now()}`,
        // Mark as migrated
        _migrated: true,
        _migratedAt: Date.now()
      };

      console.log(`✅ CART MIGRATION - Cleaned item:`, {
        productId: cleanedItem.pId,
        newVariantId: cleanedItem.vId,
        newItemId: cleanedItem.id
      });

      return cleanedItem;
    });
  }

  isContaminatedVariantId(variantId) {
    if (!variantId || typeof variantId !== 'string') {
      return false;
    }

    // Check for contamination indicators
    return variantId.includes('فروشنده') ||
           variantId.includes('هزینه') ||
           variantId.includes('تومان') ||
           variantId.includes('🏆') ||
           variantId.includes('ارسال') ||
           variantId.length > 100; // Extremely long IDs are likely contaminated
  }

  isContaminatedItemId(itemId) {
    if (!itemId || typeof itemId !== 'string') {
      return false;
    }

    // Check if item ID contains contaminated variant ID
    return itemId.includes('فروشنده') ||
           itemId.includes('هزینه') ||
           itemId.includes('تومان') ||
           itemId.includes('🏆') ||
           itemId.length > 150; // Extremely long item IDs
  }

  extractCleanVariantId(contaminatedId) {
    if (!contaminatedId || typeof contaminatedId !== 'string') {
      return null;
    }

    // If it's already clean, return as-is
    if (!this.isContaminatedVariantId(contaminatedId)) {
      return contaminatedId;
    }

    // Try to extract meaningful variant info from contaminated ID
    const cleanParts = [];

    // Look for color indicators
    const colorMatch = contaminatedId.match(/(آبی|قرمز|سبز|زرد|مشکی|سفید|خاکستری|نارنجی|بنفش|صورتی|قهوه‌ای)/);
    if (colorMatch) {
      cleanParts.push(colorMatch[1]);
    }

    // Look for size indicators
    const sizeMatch = contaminatedId.match(/(XS|S|M|L|XL|XXL|\d+|کوچک|متوسط|بزرگ)/);
    if (sizeMatch) {
      cleanParts.push(sizeMatch[1]);
    }

    // Look for warranty period
    const warrantyMatch = contaminatedId.match(/(\d+)\s*(سال|ماه)/);
    if (warrantyMatch) {
      cleanParts.push(`${warrantyMatch[1]}${warrantyMatch[2]}`);
    }

    if (cleanParts.length > 0) {
      const cleanId = `variant_${cleanParts.join('_')}`;
      console.log(`🧹 EXTRACTED CLEAN ID: "${contaminatedId}" → "${cleanId}"`);
      return cleanId;
    }

    // Fallback to hash of the contaminated ID for consistency
    let hash = 0;
    for (let i = 0; i < contaminatedId.length; i++) {
      const char = contaminatedId.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }

    const hashId = `variant_${Math.abs(hash).toString(36).substring(0, 8)}`;
    console.log(`🧹 HASH FALLBACK: "${contaminatedId}" → "${hashId}"`);
    return hashId;
  }

  // Manual migration trigger for debugging/testing
  async manualMigration() {
    console.log('🔄 MANUAL MIGRATION - Starting manual cart migration');
    const rawCart = [...this.cart]; // Copy current cart
    const migratedCart = this.migrateCartData(rawCart);
    this.cart = migratedCart;
    await this.saveCart();
    console.log('✅ MANUAL MIGRATION - Cart migration completed');
    return migratedCart;
  }

  async saveCart() {
    try {
      // Check storage size before saving
      const cartData = this.cart;
      const serializedSize = JSON.stringify(cartData).length;

      if (serializedSize > 7000) { // Leave 1KB buffer below 8KB limit
        console.warn(`⚠️ Cart data approaching size limit: ${serializedSize} bytes. Optimizing...`);
        await this.optimizeCartForStorage();
      }

      await this.storageService.set({ [this.storageKey]: this.cart });
      this.eventBus.emit('smart-cart:updated', { itemCount: this.cart.length });
      console.log(`💾 Saved Smart Cart with ${this.cart.length} items (${JSON.stringify(this.cart).length} bytes)`);
    } catch (error) {
      if (error.message.includes('too large')) {
        console.error('❌ Storage size exceeded, removing oldest items');
        await this.handleStorageOverflow();
        // Retry save after cleanup
        await this.storageService.set({ [this.storageKey]: this.cart });
      } else {
        console.error('❌ Failed to save Smart Cart:', error);
        throw error;
      }
    }
  }

  setupEventListeners() {
    this.eventBus.on('smart-cart:add-item', this.handleAddItem.bind(this));
    this.eventBus.on('smart-cart:remove-item', this.handleRemoveItem.bind(this));
    this.eventBus.on('smart-cart:clear', this.handleClearCart.bind(this));
    this.eventBus.on('smart-cart:get-items', this.handleGetItems.bind(this));
    this.eventBus.on('smart-cart:update-quantity', this.handleUpdateQuantity.bind(this));
    this.eventBus.on('smart-cart:refresh-data', this.handleRefreshData.bind(this));
    this.eventBus.on('smart-cart:cart-opened', this.handleCartOpened.bind(this));
    this.eventBus.on('smart-cart:preload-products', this.handlePreloadProducts.bind(this));
  }

  async handleAddItem(data) {
    try {
      await this.addItem(data.productInfo, data.selectedVariant);
    } catch (error) {
      console.error('❌ Error adding item to Smart Cart:', error);
      this.eventBus.emit('smart-cart:add-error', { error: error.message });
    }
  }

  async handleRemoveItem(data) {
    try {
      await this.removeItem(data.cartItemId);
    } catch (error) {
      console.error('❌ Error removing item from Smart Cart:', error);
      this.eventBus.emit('smart-cart:remove-error', { error: error.message });
    }
  }

  async handleClearCart() {
    try {
      await this.clearCart();
    } catch (error) {
      console.error('❌ Error clearing Smart Cart:', error);
      this.eventBus.emit('smart-cart:clear-error', { error: error.message });
    }
  }

  handleGetItems(callback) {
    if (typeof callback === 'function') {
      // Return cart with loading states and ensure API data freshness
      const cartWithStates = this.cart.map(item => ({
        ...item,
        isLoading: this.loadingStates.get(item.id) || false,
        lastRefreshed: this.lastRefreshTime,
        needsApiRefresh: this.itemNeedsApiRefresh(item)
      }));

      console.log('📋 Smart Cart Manager - handleGetItems called:');
      console.log('  Cart items count:', this.cart.length);
      console.log('  Items with loading states:', Array.from(this.loadingStates.keys()).length);
      console.log('  Last refresh time:', this.lastRefreshTime ? new Date(this.lastRefreshTime).toLocaleTimeString() : 'Never');
      console.log('  Cart data being returned:', cartWithStates.map(item => ({
        id: item.id,
        productId: item.pId || item.productId,
        title: item._c?.t || item.productTitle || 'Unknown',
        price: item.price || 0,
        quantity: item.qty || item.quantity || 1,
        isLoading: item.isLoading,
        needsApiRefresh: item.needsApiRefresh
      })));

      callback(cartWithStates);
    }
  }

  async getCartItemsWithFreshApiData(options = {}) {
    const { maxAge = 5 * 60 * 1000, forceRefresh = false } = options;

    if (this.cart.length === 0) {
      return [];
    }

    // Identify items that need API refresh
    const itemsNeedingRefresh = this.cart.filter(item =>
      forceRefresh || this.itemNeedsApiRefresh(item, maxAge)
    );

    if (itemsNeedingRefresh.length > 0) {
      console.log(`🔄 Refreshing ${itemsNeedingRefresh.length} items with API data`);
      await this.refreshCartItemsWithApi(itemsNeedingRefresh.map(item => item.id));
    }

    return this.cart;
  }

  itemNeedsApiRefresh(item, maxAge = 5 * 60 * 1000) {
    if (!item._cached) return true;
    if (item._cached.needsRefresh) return true;
    if (!item._cached.lastFetched) return true;

    const age = Date.now() - item._cached.lastFetched;
    return age > maxAge;
  }

  async handleUpdateQuantity(data) {
    try {
      await this.updateItemQuantity(data.itemId, data.quantity);
    } catch (error) {
      console.error('❌ Error updating item quantity:', error);
      this.eventBus.emit('smart-cart:update-quantity-error', { error: error.message });
    }
  }

  async addItem(productInfo, selectedVariant = null) {
    if (!productInfo || !productInfo.productId) {
      throw new Error('Product information is required');
    }

    // Create a unique operation ID for this transaction
    const operationId = `add_${productInfo.productId}_${Date.now()}`;

    try {
      // Acquire lock for cart operations
      await this.acquireCartLock(operationId);

      // Reload cart to get latest state
      await this.loadCart();

      const cartItem = this.createCartItem(productInfo, selectedVariant);

      // Check if item with same product ID and variant already exists
      const existingIndex = this.cart.findIndex(item =>
        item.pId === cartItem.pId &&
        item.vId === cartItem.vId
      );

      if (existingIndex !== -1) {
        // Update quantity of existing item
        this.cart[existingIndex].qty += cartItem.qty;
        this.cart[existingIndex].ut = Date.now();
        console.log(`📈 Updated quantity for existing item: ${cartItem.pId}`);
      } else {
        // Check storage before adding new item
        const currentSize = JSON.stringify(this.cart).length;
        const estimatedNewSize = currentSize + JSON.stringify(cartItem).length;

        if (estimatedNewSize > 6000) { // Proactive check before hitting 8KB limit
          console.warn(`⚠️ Storage approaching limit. Current: ${currentSize}, Estimated after add: ${estimatedNewSize}`);
          await this.optimizeCartForStorage();

          // If still too large after optimization, remove oldest item to make room
          if (JSON.stringify(this.cart).length + JSON.stringify(cartItem).length > 6000) {
            if (this.cart.length > 0) {
              // Sort by update time and remove oldest
              this.cart.sort((a, b) => (b.ut || 0) - (a.ut || 0));
              const removedItem = this.cart.pop();
              console.log(`🗑️ Removed oldest item to make room for new item: ${removedItem.pId}`);
            }
          }
        }

        // Add new item
        this.cart.push(cartItem);
        console.log(`➕ Added new item to Smart Cart: ${cartItem.pId}`);
      }

      await this.saveCart();

      // Immediately fetch API data for this item to populate display info
      if (this.optimizedAPIService) {
        try {
          await this.fetchAndUpdateCartItem(cartItem);
        } catch (error) {
          console.warn('⚠️ Could not fetch API data immediately for new item:', error);
        }
      }

      this.eventBus.emit('smart-cart:item-added', {
        item: cartItem,
        isUpdate: existingIndex !== -1
      });

      return cartItem;
    } finally {
      await this.releaseCartLock(operationId);
    }
  }

  async acquireCartLock(operationId) {
    const lockKey = 'smart_cart_lock';
    const timeout = 5000; // 5 seconds
    const startTime = Date.now();

    while (Date.now() - startTime < timeout) {
      const lock = await this.storageService.get(lockKey);

      if (!lock || Date.now() - lock.timestamp > 10000) { // 10 second lock timeout
        await this.storageService.set({
          [lockKey]: {
            operationId,
            timestamp: Date.now()
          }
        });
        return;
      }

      // Wait a bit before retrying
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    throw new Error('Failed to acquire cart lock - operation timeout');
  }

  async releaseCartLock(operationId) {
    const lockKey = 'smart_cart_lock';
    const lock = await this.storageService.get(lockKey);

    if (lock && lock.operationId === operationId) {
      await this.storageService.remove(lockKey);
    }
  }

  async removeItem(cartItemId) {
    const initialLength = this.cart.length;
    this.cart = this.cart.filter(item => item.id !== cartItemId);

    if (this.cart.length < initialLength) {
      await this.saveCart();
      this.eventBus.emit('smart-cart:item-removed', { cartItemId });
      console.log(`🗑️ Removed item from Smart Cart: ${cartItemId}`);
      return true;
    }

    return false;
  }

  async updateItemQuantity(cartItemId, newQuantity) {
    console.log(`🔄 Updating quantity for item ${cartItemId} to ${newQuantity}`);

    const item = this.cart.find(item => item.id === cartItemId);
    if (!item) {
      throw new Error(`Item with ID ${cartItemId} not found in cart`);
    }

    if (newQuantity <= 0) {
      // If quantity is 0 or negative, remove the item
      return await this.removeItem(cartItemId);
    }

    // Update the quantity
    const oldQuantity = item.qty;
    item.qty = newQuantity;
    item.ut = Date.now();

    await this.saveCart();
    this.eventBus.emit('smart-cart:quantity-updated', {
      cartItemId,
      oldQuantity,
      newQuantity,
      item
    });

    console.log(`✅ Updated quantity for ${item._c?.t || item.pId}: ${oldQuantity} → ${newQuantity}`);
    return item;
  }

  async handleRefreshData(data = {}) {
    const { productIds = null, force = false } = data;

    try {
      if (productIds) {
        await this.refreshSpecificProducts(productIds, { force });
      } else {
        await this.refreshAllCartData({ force });
      }
    } catch (error) {
      console.error('❌ Error refreshing cart data:', error);
      this.eventBus.emit('smart-cart:refresh-error', { error: error.message });
    }
  }

  async handleCartOpened() {
    console.log('📋 Smart Cart opened - checking for data refresh');

    if (this.refreshSettings.autoRefreshOnOpen) {
      await this.refreshAllCartData({ skipIfRecent: true });
    }
  }

  async handlePreloadProducts(data) {
    const { productIds } = data;

    if (this.optimizedAPIService && productIds?.length > 0) {
      try {
        await this.optimizedAPIService.preloadProducts(productIds, { priority: 'low' });
        console.log(`✅ Preloaded ${productIds.length} products`);
      } catch (error) {
        console.warn('⚠️ Failed to preload products:', error);
      }
    }
  }

  async clearCart() {
    const itemCount = this.cart.length;
    this.cart = [];
    await this.saveCart();
    this.eventBus.emit('smart-cart:cleared', { removedItemCount: itemCount });
    console.log(`🧹 Cleared Smart Cart (${itemCount} items removed)`);
  }

  createCartItem(productInfo, selectedVariant) {
    const now = Date.now();

    // Create ultra-minimal cart item to avoid storage size limits
    const cartItem = {
      id: `sc_${productInfo.productId}_${selectedVariant?.id || 'def'}_${now}`,
      pId: productInfo.productId, // Shortened: Product ID
      vId: selectedVariant?.id || null, // Shortened: Variant ID
      qty: 1, // Shortened: quantity
      at: now, // Shortened: addedAt
      ut: now, // Shortened: updatedAt
      src: 'scb', // Shortened: source = smart_cart_button

      // Minimal cached data (will be refreshed from API)
      _c: {
        t: productInfo.productTitle || 'در حال بارگذاری...', // title
        u: productInfo.productUrl || null, // url
        lf: null, // lastFetched
        nr: true // needsRefresh
      }
    };

    console.log('📦 Created minimal cart item for product:', productInfo.productId, 'variant:', selectedVariant?.id);
    return cartItem;
  }

  extractPriceFromPage() {
    // Fallback price extraction method
    const priceSelectors = [
      '[data-testid="price-final"]',
      '.c-price__value',
      '.price-final',
      '.selling-price',
      '.product-price',
      '[data-testid="price-selling"]'
    ];

    for (const selector of priceSelectors) {
      const priceElement = document.querySelector(selector);
      if (priceElement) {
        const priceText = priceElement.textContent || priceElement.innerText;
        const price = parseInt(priceText.replace(/[^\d]/g, ''));
        if (price && price > 0) {
          console.log('💰 Extracted price from page:', price, 'tomans (converted to', price * 10, 'rials)');
          return price * 10; // Convert from Tomans to Rials
        }
      }
    }

    console.warn('⚠️ Could not extract price from page');
    return 0;
  }

  extractVariantDetails(variant) {
    if (!variant) return null;

    const details = {};

    // Extract common variant properties
    if (variant.color) {
      details.color = {
        title: variant.color.title || variant.color.name,
        code: variant.color.code,
        hex: variant.color.hex
      };
    }

    if (variant.size) {
      details.size = {
        title: variant.size.title || variant.size.name,
        code: variant.size.code
      };
    }

    if (variant.warranty) {
      details.warranty = {
        title: variant.warranty.title_fa || variant.warranty.title,
        months: variant.warranty.months
      };
    }

    // Extract themes (for items like phone models, etc.)
    if (variant.themes && Array.isArray(variant.themes)) {
      details.themes = variant.themes.map(theme => ({
        title: theme.title || theme.name,
        code: theme.code
      }));
    }

    // Add display name if available
    if (variant.selector_type?.display_name) {
      details.displayName = variant.selector_type.display_name;
    }

    return Object.keys(details).length > 0 ? details : null;
  }

  getCartSummary() {
    const totalItems = this.cart.reduce((sum, item) => sum + (item.qty || item.quantity || 1), 0);
    const totalValue = this.cart.reduce((sum, item) => sum + ((item.price || 0) * (item.qty || item.quantity || 1)), 0);
    const uniqueProducts = new Set(this.cart.map(item => item.pId || item.productId)).size;

    return {
      totalItems,
      totalValue,
      uniqueProducts,
      itemCount: this.cart.length
    };
  }

  getCartItems() {
    return [...this.cart];
  }

  isProductInCart(productId, variantId = null) {
    return this.cart.some(item =>
      (item.pId || item.productId) === productId &&
      (item.vId || item.variantId) === variantId
    );
  }

  getProductFromCart(productId, variantId = null) {
    return this.cart.find(item =>
      (item.pId || item.productId) === productId &&
      (item.vId || item.variantId) === variantId
    );
  }

  // Data refresh methods
  async refreshAllCartData(options = {}) {
    const { force = false, skipIfRecent = false } = options;

    if (!this.optimizedAPIService) {
      console.warn('⚠️ Cannot refresh cart data - optimized API service not available');
      return;
    }

    if (this.cart.length === 0) {
      console.log('📋 Cart is empty, no data to refresh');
      return;
    }

    // Check if recent refresh happened
    if (skipIfRecent && this.lastRefreshTime) {
      const timeSinceRefresh = Date.now() - this.lastRefreshTime;
      if (timeSinceRefresh < this.refreshSettings.refreshInterval) {
        console.log(`⏭️ Skipping refresh - last refresh was ${Math.round(timeSinceRefresh / 1000)}s ago`);
        return;
      }
    }

    console.log('🔄 Refreshing all cart data...');
    this.eventBus.emit('smart-cart:refresh-started', { itemCount: this.cart.length });

    const productRequests = this.cart.map(item => ({
      productId: item.pId || item.productId,
      variantId: item.vId || item.variantId,
      includeVariant: !!(item.vId || item.variantId)
    }));

    try {
      // Set loading states
      this.cart.forEach(item => this.loadingStates.set(item.id, true));

      const results = await this.optimizedAPIService.fetchMultipleProducts(productRequests, {
        priority: 'high',
        freshData: force
      });

      await this.updateCartWithFreshData(results);
      this.lastRefreshTime = Date.now();

      console.log('✅ Cart data refresh completed');
      this.eventBus.emit('smart-cart:refresh-completed', {
        refreshedCount: Object.keys(results).length,
        timestamp: this.lastRefreshTime
      });

    } catch (error) {
      console.error('❌ Failed to refresh cart data:', error);
      this.eventBus.emit('smart-cart:refresh-error', { error: error.message });
    } finally {
      // Clear loading states
      this.cart.forEach(item => this.loadingStates.delete(item.id));
    }
  }

  async refreshSpecificProducts(productIds, options = {}) {
    if (!this.optimizedAPIService || !productIds?.length) {
      return;
    }

    console.log(`🔄 Refreshing specific products: ${productIds.join(', ')}`);

    const cartItems = this.cart.filter(item => productIds.includes(item.pId || item.productId));
    const productRequests = cartItems.map(item => ({
      productId: item.pId || item.productId,
      variantId: item.vId || item.variantId,
      includeVariant: !!(item.vId || item.variantId)
    }));

    try {
      // Set loading states for specific items
      cartItems.forEach(item => this.loadingStates.set(item.id, true));

      const results = await this.optimizedAPIService.fetchMultipleProducts(productRequests, {
        priority: 'high',
        freshData: options.force || false
      });

      await this.updateCartWithFreshData(results);

      console.log(`✅ Refreshed ${productIds.length} specific products`);

    } catch (error) {
      console.error('❌ Failed to refresh specific products:', error);
    } finally {
      // Clear loading states
      cartItems.forEach(item => this.loadingStates.delete(item.id));
    }
  }

  async updateCartWithFreshData(apiResults) {
    let updatedCount = 0;

    for (const [productId, result] of Object.entries(apiResults)) {
      if (!result.success || !result.data) continue;

      const cartItems = this.cart.filter(item => (item.pId || item.productId) === productId);

      for (const cartItem of cartItems) {
        const updatedItem = this.mergeProductDataWithCartItem(cartItem, result.data);

        if (updatedItem.hasChanges) {
          updatedCount++;
          cartItem.price = updatedItem.price;
          cartItem.productTitle = updatedItem.productTitle;
          cartItem.productImage = updatedItem.productImage;
          cartItem.availability = updatedItem.availability;
          cartItem.lastRefreshed = Date.now();
          cartItem.dataSource = result.source;

          // Emit individual item update
          this.eventBus.emit('smart-cart:item-data-updated', {
            cartItem,
            previousData: updatedItem.previousData,
            changes: updatedItem.changes
          });
        }
      }
    }

    if (updatedCount > 0) {
      await this.saveCart();
      console.log(`💾 Updated ${updatedCount} cart items with fresh data`);
    }
  }

  mergeProductDataWithCartItem(cartItem, freshData) {
    const changes = [];
    const previousData = {};

    // Check price changes
    const newPrice = this.extractPriceFromProductData(freshData);
    if (newPrice && newPrice !== cartItem.price) {
      changes.push('price');
      previousData.price = cartItem.price;
    }

    // Check title changes
    const newTitle = freshData.title_fa || freshData.title || cartItem.productTitle;
    if (newTitle !== cartItem.productTitle) {
      changes.push('title');
      previousData.productTitle = cartItem.productTitle;
    }

    // Check image changes
    const newImage = this.extractImageFromProductData(freshData);
    if (newImage && newImage !== cartItem.productImage) {
      changes.push('image');
      previousData.productImage = cartItem.productImage;
    }

    // Check availability
    const availability = this.extractAvailabilityFromProductData(freshData);

    return {
      hasChanges: changes.length > 0,
      changes,
      previousData,
      price: newPrice || cartItem.price,
      productTitle: newTitle,
      productImage: newImage || cartItem.productImage,
      availability
    };
  }

  extractPriceFromProductData(productData) {
    // Extract price from actual API response structure
    // Based on real API: data.product.default_variant.price.selling_price
    if (productData.default_variant?.price?.selling_price) {
      return productData.default_variant.price.selling_price;
    }

    // If no default variant, try direct price (fallback for different API endpoints)
    if (productData.price?.selling_price) {
      return productData.price.selling_price;
    }

    // Try variant-specific prices if variants array exists
    if (productData.variants && Array.isArray(productData.variants) && productData.variants.length > 0) {
      const firstVariant = productData.variants[0];
      if (firstVariant.price?.selling_price) {
        return firstVariant.price.selling_price;
      }
    }

    console.warn('⚠️ Could not extract price from product data:', Object.keys(productData));
    return null;
  }

  extractImageFromProductData(productData) {
    // Extract image from actual API response structure
    // Based on real API: data.product.images.main.url[0]
    if (productData.images?.main?.url?.[0]) {
      return productData.images.main.url[0];
    }

    // Try list images if main is not available
    if (productData.images?.list && Array.isArray(productData.images.list) && productData.images.list.length > 0) {
      const firstImage = productData.images.list[0];
      if (firstImage.url?.[0]) {
        return firstImage.url[0];
      }
    }

    // Fallback to simple image field
    if (productData.image) {
      return productData.image;
    }

    return null;
  }

  extractAvailabilityFromProductData(productData) {
    // Extract availability from actual API response structure
    // Based on real API: data.product.default_variant.price.marketable_stock
    const defaultVariant = productData.default_variant;

    return {
      isAvailable: productData.status === 'marketable' && defaultVariant?.price?.marketable_stock > 0,
      stockCount: defaultVariant?.price?.marketable_stock || 0,
      maxCartCount: defaultVariant?.price?.order_limit || 10
    };
  }

  // API-First Data Fetching Methods
  async fetchAndUpdateCartItem(cartItem) {
    if (!this.optimizedAPIService || !cartItem.productId) {
      console.warn('⚠️ Cannot fetch API data - missing service or product ID');
      return null;
    }

    try {
      console.log(`🌐 Fetching API data for product: ${cartItem.productId}`);

      const productRequest = {
        productId: cartItem.pId || cartItem.productId,
        variantId: cartItem.vId || cartItem.variantId,
        includeVariant: !!(cartItem.vId || cartItem.variantId),
        includeSellers: true,
        includePricing: true
      };

      const result = await this.optimizedAPIService.fetchProduct(productRequest.productId, {
        variant: productRequest.variantId,
        priority: 'high',
        freshData: false // Use cache if available
      });

      if (result.success && result.data) {
        // Check if result.data is the full API response or just the product data
        const productData = result.data.product ? result.data.product : result.data;
        this.mergeApiDataWithCartItem(cartItem, productData, result.source);
        await this.saveCart();

        this.eventBus.emit('smart-cart:item-api-updated', {
          cartItem,
          source: result.source,
          timestamp: Date.now()
        });

        console.log(`✅ Updated cart item with API data: ${cartItem.pId || cartItem.productId}`);
        return cartItem;
      } else {
        console.warn('⚠️ API request failed for product:', cartItem.pId || cartItem.productId, result.error);
        return null;
      }
    } catch (error) {
      console.error('❌ Error fetching API data for cart item:', error);
      return null;
    }
  }

  mergeApiDataWithCartItem(cartItem, apiData, source = 'api') {
    const now = Date.now();

    // Extract data from API response
    let price = this.extractPriceFromProductData(apiData);
    const title = apiData.title_fa || apiData.title || cartItem._c?.t || cartItem._cached?.productTitle;
    const image = this.extractImageFromProductData(apiData);
    const availability = this.extractAvailabilityFromProductData(apiData);

    // Get variant-specific data if variant exists
    let variantData = null;
    const variantId = cartItem.vId || cartItem.variantId;
    if (variantId && apiData.variants) {
      variantData = apiData.variants.find(v => v.id === variantId);
      if (variantData) {
        // Use variant-specific price if available
        const variantPrice = this.extractPriceFromProductData(variantData);
        if (variantPrice) {
          price = variantPrice;
        }
      }
    }

    // Update cart item with minimal essential API data only
    cartItem.price = price || 0;

    // Store minimal variant data for UI dropdown (space-optimized)
    if (variantData) {
      cartItem.variantData = {
        id: variantData.id,
        color: variantData.color ? {
          title: variantData.color.title || variantData.color.name
        } : null,
        size: variantData.size ? {
          title: variantData.size.title || variantData.size.name
        } : null,
        warranty: variantData.warranty ? {
          title_fa: variantData.warranty.title_fa || variantData.warranty.title
        } : null
        // Remove: price, seller, properties, themes to save space
      };
    }

    // Store minimal variations array for dropdown (limit to 5 variants max)
    if (apiData.variants && Array.isArray(apiData.variants)) {
      cartItem.variations = apiData.variants.slice(0, 5).map(variant => ({
        id: variant.id,
        color: variant.color ? { title: variant.color.title || variant.color.name } : null,
        size: variant.size ? { title: variant.size.title || variant.size.name } : null,
        warranty: variant.warranty ? { title_fa: variant.warranty.title_fa || variant.warranty.title } : null
        // Remove: price, seller, properties, themes to save space
      }));
    }

    // Store only essential cached metadata (no heavy objects)
    cartItem._c = {
      ...cartItem._c,
      t: title ? title.substring(0, 50) : null, // Truncate title to save space
      lf: now,
      nr: false,
      ds: source
      // Removed: u (url), productImage, availability
    };

    // Store minimal sellers information for optimization (space-optimized)
    const sellers = [];

    // Add the default variant seller (minimal data only)
    if (apiData.default_variant?.seller) {
      const defaultSeller = apiData.default_variant.seller;
      sellers.push({
        id: defaultSeller.id || 'digikala',
        price: price
        // Removed: name, inventory, shipsDirectly, rating, code to save space
      });
    }

    // Add up to 2 more sellers from variants (space-limited)
    if (apiData.variants && Array.isArray(apiData.variants) && sellers.length < 3) {
      for (const variant of apiData.variants.slice(0, 2)) { // Limit to first 2 variants
        if (variant.seller && variant.seller.id !== sellers[0]?.id) {
          const variantPrice = this.extractPriceFromProductData({ default_variant: variant });
          sellers.push({
            id: variant.seller.id,
            price: variantPrice || price
            // Removed: name, inventory, shipsDirectly, rating, code to save space
          });
        }
      }
    }

    // Store only if we have sellers, and limit to essential data
    if (sellers.length > 0) {
      cartItem.sellers = sellers;
    }

    console.log(`📊 Merged API data for ${cartItem.pId || cartItem.productId}: price=${price}, title="${title}"`);
  }

  async refreshCartItemsWithApi(itemIds = null, options = {}) {
    if (!this.optimizedAPIService) {
      console.warn('⚠️ Cannot refresh cart items - API service not available');
      return [];
    }

    const itemsToRefresh = itemIds
      ? this.cart.filter(item => itemIds.includes(item.id))
      : this.cart;

    if (itemsToRefresh.length === 0) {
      console.log('📋 No items to refresh');
      return [];
    }

    console.log(`🔄 Refreshing ${itemsToRefresh.length} cart items with API data`);

    const refreshPromises = itemsToRefresh.map(item => this.fetchAndUpdateCartItem(item));
    const results = await Promise.allSettled(refreshPromises);

    const successful = results.filter(r => r.status === 'fulfilled' && r.value).length;
    console.log(`✅ Successfully refreshed ${successful}/${itemsToRefresh.length} cart items`);

    this.eventBus.emit('smart-cart:api-refresh-completed', {
      totalItems: itemsToRefresh.length,
      successCount: successful,
      timestamp: Date.now()
    });

    return results.map(r => r.status === 'fulfilled' ? r.value : null).filter(Boolean);
  }

  // Enhanced cart summary with refresh info
  getCartSummary() {
    const totalItems = this.cart.reduce((sum, item) => sum + (item.qty || item.quantity || 1), 0);
    const totalValue = this.cart.reduce((sum, item) => sum + ((item.price || 0) * (item.qty || item.quantity || 1)), 0);
    const uniqueProducts = new Set(this.cart.map(item => item.pId || item.productId)).size;
    const loadingItems = Array.from(this.loadingStates.keys()).length;

    return {
      totalItems,
      totalValue,
      uniqueProducts,
      itemCount: this.cart.length,
      loadingItems,
      lastRefreshed: this.lastRefreshTime,
      needsRefresh: this.shouldRefreshData()
    };
  }

  shouldRefreshData() {
    if (!this.lastRefreshTime) return true;

    const timeSinceRefresh = Date.now() - this.lastRefreshTime;
    return timeSinceRefresh > this.refreshSettings.maxAge;
  }

  // Get service statistics
  getServiceStats() {
    const stats = {
      cacheService: this.cacheService?.getCacheStats() || null,
      apiService: this.optimizedAPIService?.getStats() || null,
      smartCart: {
        itemCount: this.cart.length,
        loadingItems: this.loadingStates.size,
        lastRefreshed: this.lastRefreshTime,
        needsRefresh: this.shouldRefreshData()
      }
    };

    return stats;
  }

  async optimizeCartForStorage() {
    console.log('🔧 Optimizing cart data for storage...');
    const originalSize = JSON.stringify(this.cart).length;

    // Aggressive optimization to fit within 8KB limit
    this.cart.forEach(item => {
      // Keep only essential cached data in _c
      if (item._c) {
        const essential = {
          t: item._c.t ? item._c.t.substring(0, 50) : null, // Truncate title to 50 chars
          lf: item._c.lf,
          nr: item._c.nr
        };
        item._c = essential;
      }

      // Remove all heavy non-essential data
      delete item.productTitle; // Duplicate of _c.t
      delete item.productImage; // Not needed for cart functionality
      delete item.availability; // Can be refetched when needed
      delete item.productUrl; // Can be reconstructed
      delete item._cached; // Legacy data
      delete item._migrated; // Migration marker not needed
      delete item._migratedAt; // Migration timestamp not needed

      // Keep minimal variant data for UI dropdowns, remove heavy parts
      if (item.variantData) {
        // Keep only essential variant fields for dropdown
        const minimalVariant = {
          id: item.variantData.id,
          color: item.variantData.color ? {
            title: item.variantData.color.title || item.variantData.color.name
          } : null,
          size: item.variantData.size ? {
            title: item.variantData.size.title || item.variantData.size.name
          } : null,
          warranty: item.variantData.warranty ? {
            title_fa: item.variantData.warranty.title_fa || item.variantData.warranty.title
          } : null
          // Remove: price, seller, properties, themes, etc.
        };
        item.variantData = minimalVariant;
      }

      // Optimize variations array - keep only essential info
      if (item.variations && Array.isArray(item.variations)) {
        item.variations = item.variations.slice(0, 5).map(variant => ({
          id: variant.id,
          color: variant.color ? { title: variant.color.title || variant.color.name } : null,
          size: variant.size ? { title: variant.size.title || variant.size.name } : null,
          warranty: variant.warranty ? { title_fa: variant.warranty.title_fa || variant.warranty.title } : null
          // Remove: price, seller, properties, themes, etc.
        }));
      }

      // Remove large variantDetails object
      delete item.variantDetails;

      // Severely limit sellers array to only essential data
      if (item.sellers && item.sellers.length > 0) {
        // Keep only the best seller (first one, usually cheapest)
        const bestSeller = item.sellers[0];
        item.sellers = [{
          id: bestSeller.id,
          price: bestSeller.price
          // Remove: name, inventory, shipsDirectly, rating, code
        }];
      }

      // Truncate long IDs if needed
      if (item.id && item.id.length > 50) {
        // Keep the essential parts: product ID and timestamp
        const parts = item.id.split('_');
        if (parts.length >= 3) {
          item.id = `sc_${parts[1]}_${parts[parts.length - 1]}`;
        }
      }
    });

    const newSize = JSON.stringify(this.cart).length;
    console.log(`✅ Cart aggressively optimized: ${originalSize} → ${newSize} bytes (${Math.round((originalSize - newSize) / originalSize * 100)}% reduction)`);
  }

  async handleStorageOverflow() {
    console.warn('🚨 Handling storage overflow by removing oldest items');
    const originalLength = this.cart.length;

    // First try aggressive optimization on all items
    await this.optimizeCartForStorage();

    // If still too large, remove oldest items
    if (JSON.stringify(this.cart).length > 7000) {
      // Sort by last updated time and remove oldest items until under limit
      this.cart.sort((a, b) => (b.ut || b.updatedAt || 0) - (a.ut || a.updatedAt || 0));

      // More aggressive removal - keep max 5 items, aim for 5KB to leave buffer
      while (JSON.stringify(this.cart).length > 5000 && this.cart.length > 1) {
        const removedItem = this.cart.pop();
        console.log(`🗑️ Removed old item: ${removedItem.pId || removedItem.productId}`);
      }

      // Hard limit: never store more than 5 items to prevent future overflow
      if (this.cart.length > 5) {
        const itemsToRemove = this.cart.length - 5;
        this.cart = this.cart.slice(0, 5);
        console.log(`🗑️ Hard limit: removed ${itemsToRemove} items, keeping only 5 newest`);
      }
    }

    const finalSize = JSON.stringify(this.cart).length;
    console.log(`✅ Storage overflow handled: ${originalLength} → ${this.cart.length} items, ${finalSize} bytes`);

    // Emit event to notify UI
    this.eventBus.emit('smart-cart:overflow-cleanup', {
      remainingItems: this.cart.length,
      removedItems: originalLength - this.cart.length,
      finalSize: finalSize,
      message: `Cleaned up cart: ${originalLength - this.cart.length} older items removed to fit storage limit`
    });
  }

  cleanup() {
    this.eventBus.off('smart-cart:add-item', this.handleAddItem.bind(this));
    this.eventBus.off('smart-cart:remove-item', this.handleRemoveItem.bind(this));
    this.eventBus.off('smart-cart:clear', this.handleClearCart.bind(this));
    this.eventBus.off('smart-cart:get-items', this.handleGetItems.bind(this));
    this.eventBus.off('smart-cart:update-quantity', this.handleUpdateQuantity.bind(this));
    this.eventBus.off('smart-cart:refresh-data', this.handleRefreshData.bind(this));
    this.eventBus.off('smart-cart:cart-opened', this.handleCartOpened.bind(this));
    this.eventBus.off('smart-cart:preload-products', this.handlePreloadProducts.bind(this));

    // Clean up loading states
    this.loadingStates.clear();

    console.log('🧹 Smart Cart Manager cleaned up');
  }
}

window.SmartCartManager = SmartCartManager;