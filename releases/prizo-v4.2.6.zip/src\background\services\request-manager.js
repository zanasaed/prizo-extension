/**
 * Request Manager Service
 * Handles API requests with caching, deduplication, and retry logic
 */

import { RateLimiter } from '../utils/rate-limiter.js';

class RequestManager {
  constructor() {
    this.cache = new Map();
    this.pendingRequests = new Map();
    this.rateLimiter = new RateLimiter();
    this.requestQueue = [];
    this.isProcessingQueue = false;

    // Cache settings
    this.cacheExpiration = 5 * 60 * 1000; // 5 minutes
    this.maxCacheSize = 100;

    // Request settings
    this.maxRetries = 3;
    this.retryDelay = 1000;

    // API endpoint configuration
    this.apiEndpoints = {
      regular: [
        {
          url: 'https://api.digikala.com/v2/product/{productId}/',
          priority: 1,
          timeout: 5000
        },
        {
          url: 'https://api.digikala.com/v1/product/{productId}/',
          priority: 2,
          timeout: 7000
        },
        {
          url: 'https://www.digikala.com/ajax/product/{productId}/',
          priority: 3,
          timeout: 10000
        }
      ],
      fresh: [
        {
          url: 'https://api.digikala.com/fresh/v1/product/{productId}/?_whid=1',
          priority: 1,
          timeout: 5000
        },
        {
          url: 'https://api.digikala.com/v2/product/{productId}/',
          priority: 2,
          timeout: 7000
        },
        {
          url: 'https://api.digikala.com/v1/product/{productId}/',
          priority: 3,
          timeout: 10000
        }
      ]
    };
  }

  // Generate cache key
  getCacheKey(productId, pageType) {
    return `${productId}_${pageType}`;
  }

  // Check if cached data is valid
  isCacheValid(cacheEntry) {
    if (!cacheEntry) return false;
    return Date.now() - cacheEntry.timestamp < this.cacheExpiration;
  }

  // Get from cache
  getFromCache(productId, pageType) {
    const key = this.getCacheKey(productId, pageType);
    const cacheEntry = this.cache.get(key);

    if (this.isCacheValid(cacheEntry)) {
      console.log(`🔧 DBG:api:cache:hit - ${productId}:${pageType}`);
      return cacheEntry.data;
    }

    if (cacheEntry) {
      this.cache.delete(key);
    }

    console.log(`🔧 DBG:api:cache:miss - ${productId}:${pageType} (expired or not found)`);
    return null;
  }

  // Store in cache
  storeInCache(productId, pageType, data) {
    const key = this.getCacheKey(productId, pageType);

    // Implement LRU cache eviction
    if (this.cache.size >= this.maxCacheSize) {
      const oldestKey = this.cache.keys().next().value;
      this.cache.delete(oldestKey);
    }

    this.cache.set(key, {
      data: data,
      timestamp: Date.now()
    });
  }

  // Deduplicate requests
  async fetchWithDeduplication(productId, pageType, currentUrl = null) {
    const key = this.getCacheKey(productId, pageType);

    // Check cache first
    const cachedData = this.getFromCache(productId, pageType);
    if (cachedData) {
      return { success: true, data: cachedData, source: 'cache' };
    }

    // Check if request is already pending
    if (this.pendingRequests.has(key)) {
      return await this.pendingRequests.get(key);
    }

    // Create new request
    const requestPromise = this.performRequest(productId, pageType, currentUrl);
    this.pendingRequests.set(key, requestPromise);

    try {
      const result = await requestPromise;

      // Cache successful results
      if (result.success) {
        this.storeInCache(productId, pageType, result.data);
      }

      return result;
    } finally {
      this.pendingRequests.delete(key);
    }
  }

  // Detect if current page is in fresh section
  isFreshSection(url) {
    if (!url) {
      try {
        return false; // Default to regular endpoints
      } catch (e) {
        return false;
      }
    }
    return /\/fresh\//.test(url);
  }

  // Get appropriate endpoints based on page type
  getEndpointsForPage(url) {
    const isFresh = this.isFreshSection(url);
    return isFresh ? this.apiEndpoints.fresh : this.apiEndpoints.regular;
  }

  // Perform actual API request with intelligent retry
  async performRequest(productId, pageType, currentUrl = null) {
    console.log(`🌐 [API REQUEST] Starting request for product ID: ${productId}`);
    console.log(`🌐 [API REQUEST] Page type: ${pageType}`);
    console.log(`🌐 [API REQUEST] Current URL: ${currentUrl}`);

    // Wait for rate limiting
    await this.rateLimiter.waitForSlot();

    // Get appropriate endpoints based on current page
    const endpoints = this.getEndpointsForPage(currentUrl);
    const sortedEndpoints = [...endpoints].sort((a, b) => a.priority - b.priority);

    for (const endpoint of sortedEndpoints) {
      const url = endpoint.url.replace('{productId}', encodeURIComponent(productId));
      console.log(`🌐 [API REQUEST] Trying endpoint: ${url}`);

      for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), endpoint.timeout);

          const response = await fetch(url, {
            method: 'GET',
            headers: {
              'Accept': 'application/json, text/plain, */*',
              'Accept-Language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Referer': 'https://www.digikala.com/',
              'Origin': 'https://www.digikala.com',
              'X-Requested-With': 'XMLHttpRequest',
              'Cache-Control': 'no-cache',
              'Pragma': 'no-cache'
            },
            signal: controller.signal
          });

          clearTimeout(timeoutId);

          if (response.ok) {
            const data = await response.json();

            const productData = data.data?.product || data.data || data;
            console.log(`✅ [API RESPONSE] Success from ${endpoint.name}`);
            console.log(`✅ [API RESPONSE] Requested product ID: ${productId}`);
            console.log(`✅ [API RESPONSE] Returned product ID: ${productData.id}`);
            console.log(`✅ [API RESPONSE] Returned product title: ${productData.title_fa || productData.title_en || 'unknown'}`);

            // CRITICAL: Verify the API returned the correct product
            if (productData.id && String(productData.id) !== String(productId)) {
              console.error(`❌ [API RESPONSE] PRODUCT ID MISMATCH!`);
              console.error(`   Requested: ${productId}`);
              console.error(`   Received: ${productData.id}`);
              console.error(`   Title: ${productData.title_fa || productData.title_en}`);
              console.error(`   This is likely the cause of wrong price display!`);
            }

            // Debug: Log shipping-related data
            console.log(`🔧 DBG:api:shipping - Response from ${url}:`, {
              hasDefaultVariant: !!(data.data?.default_variant || data.default_variant),
              hasShipmentMethods: !!(data.data?.default_variant?.shipment_methods || data.default_variant?.shipment_methods),
              dataStructure: Object.keys(data)
            });

            return {
              success: true,
              data: data.data || data,
              source: url
            };
          } else if (response.status === 429) {
            // Rate limited - wait longer before retry
            console.log(`⏳ Rate limited by ${url}, waiting...`);
            await new Promise(resolve => setTimeout(resolve, this.retryDelay * attempt * 2));
            continue;
          } else {
            console.log(`❌ HTTP ${response.status} from ${url}`);
            if (attempt < this.maxRetries) {
              await new Promise(resolve => setTimeout(resolve, this.retryDelay * attempt));
            }
          }

        } catch (error) {
          console.log(`❌ Request failed for ${url}:`, error.message);

          if (error.name === 'AbortError') {
            console.log(`⏰ Request timeout for ${url}`);
          }

          if (attempt < this.maxRetries) {
            await new Promise(resolve => setTimeout(resolve, this.retryDelay * attempt));
          }
        }
      }
    }

    // All endpoints failed
    return {
      success: false,
      error: 'All API endpoints failed after retries'
    };
  }

  // Batch request processing
  async processBatch(requests, currentUrl = null) {
    const results = [];
    const batchSize = 3; // Process 3 requests simultaneously

    for (let i = 0; i < requests.length; i += batchSize) {
      const batch = requests.slice(i, i + batchSize);
      const batchPromises = batch.map(req =>
        this.fetchWithDeduplication(req.productId, req.pageType, currentUrl)
      );

      const batchResults = await Promise.allSettled(batchPromises);
      results.push(...batchResults);

      // Add delay between batches
      if (i + batchSize < requests.length) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    return results;
  }

  // Fetch seller vouchers for a product
  async fetchSellerVouchers(productId, timeout = 8000) {
    try {
      console.log(`🎟️ RequestManager: Fetching seller vouchers for product ${productId}`);

      // Check cache first
      const cacheKey = `vouchers_${productId}`;
      const cachedData = this.cache.get(cacheKey);
      if (cachedData && this.isCacheValid(cachedData)) {
        console.log('📋 Using cached voucher data');
        return cachedData.data;
      }

      // Construct Digikala voucher API URL
      const voucherUrl = `https://api.digikala.com/v1/product/${productId}/seller-vouchers/?productId=${productId}`;

      console.log(`📡 Requesting vouchers from: ${voucherUrl}`);

      // Create abort controller for timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      try {
        const response = await fetch(voucherUrl, {
          method: 'GET',
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9,fa;q=0.8',
            'Referer': `https://www.digikala.com/product/dkp-${productId}/`,
            'Origin': 'https://www.digikala.com'
          },
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (response.ok) {
          const voucherData = await response.json();
          console.log('✅ Successfully fetched voucher data');

          // Cache the voucher data with shorter expiration (2 minutes for vouchers)
          const voucherCacheExpiration = 2 * 60 * 1000;
          this.cache.set(cacheKey, {
            data: voucherData,
            timestamp: Date.now(),
            expiration: voucherCacheExpiration
          });

          return voucherData;
        } else if (response.status === 404) {
          console.log('ℹ️ No vouchers available for this product');
          return { status: 200, data: [] }; // Return empty data for no vouchers
        } else {
          console.log(`❌ HTTP ${response.status} when fetching vouchers`);
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

      } catch (error) {
        clearTimeout(timeoutId);

        if (error.name === 'AbortError') {
          console.log('⏰ Voucher request timeout');
          throw new Error('Voucher request timeout');
        }

        throw error;
      }

    } catch (error) {
      console.error(`❌ Failed to fetch vouchers for product ${productId}:`, error);

      // Return empty result for failed requests to prevent UI errors
      return { status: 200, data: [] };
    }
  }

  // Override isCacheValid to handle voucher expiration
  isCacheValid(cacheEntry) {
    if (!cacheEntry) return false;

    // Use custom expiration if set (for vouchers)
    const expiration = cacheEntry.expiration || this.cacheExpiration;
    return Date.now() - cacheEntry.timestamp < expiration;
  }

  // Clear cache
  clearCache() {
    this.cache.clear();
  }
}

export { RequestManager };