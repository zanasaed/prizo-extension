/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Base Module Class - Foundation for all popup modules
 */

class BaseModule {
  constructor(name, eventBus, domManager) {
    this.name = name;
    this.eventBus = eventBus;
    this.domManager = domManager;
    this.initialized = false;
    this.elements = {};

    this.bindMethods();
  }

  bindMethods() {
    const methods = Object.getOwnPropertyNames(Object.getPrototypeOf(this));
    methods.forEach(method => {
      if (typeof this[method] === 'function' && method !== 'constructor') {
        this[method] = this[method].bind(this);
      }
    });
  }

  async init() {
    if (this.initialized) {
      console.warn(`Module ${this.name} is already initialized`);
      return;
    }

    try {
      await this.initializeElements();
      await this.setupEventListeners();
      await this.loadInitialData();

      this.initialized = true;
      this.emit('module:initialized', { module: this.name });
      console.log(`✅ Module ${this.name} initialized successfully`);
    } catch (error) {
      console.error(`❌ Failed to initialize module ${this.name}:`, error);
      throw error;
    }
  }

  async initializeElements() {
    // Override in child classes to initialize DOM elements
  }

  async setupEventListeners() {
    // Override in child classes to setup event listeners
  }

  async loadInitialData() {
    // Override in child classes to load initial data
  }

  async destroy() {
    try {
      await this.cleanup();
      this.removeEventListeners();
      this.elements = {};
      this.initialized = false;
      this.emit('module:destroyed', { module: this.name });
      console.log(`🗑️ Module ${this.name} destroyed successfully`);
    } catch (error) {
      console.error(`❌ Failed to destroy module ${this.name}:`, error);
    }
  }

  async cleanup() {
    // Override in child classes for custom cleanup
  }

  removeEventListeners() {
    // Override in child classes to remove event listeners
  }

  // Event system methods
  on(event, callback) {
    if (this.eventBus) {
      return this.eventBus.on(event, callback);
    }
  }

  off(event, callback) {
    if (this.eventBus) {
      return this.eventBus.off(event, callback);
    }
  }

  once(event, callback) {
    if (this.eventBus) {
      return this.eventBus.once(event, callback);
    }
  }

  emit(event, data) {
    if (this.eventBus) {
      return this.eventBus.emit(event, { ...data, source: this.name });
    }
  }

  // DOM helper methods
  getElement(id) {
    if (!this.elements[id]) {
      this.elements[id] = this.domManager.getElementById(id);
    }
    return this.elements[id];
  }

  getElementsByClass(className) {
    return this.domManager.getElementsByClassName(className);
  }

  querySelector(selector) {
    return this.domManager.querySelector(selector);
  }

  querySelectorAll(selector) {
    return this.domManager.querySelectorAll(selector);
  }

  // Utility methods
  showLoading(show = true) {
    this.emit('ui:loading', { show, module: this.name });
  }

  showError(message) {
    this.emit('ui:error', { message, module: this.name });
  }

  showSuccess(message) {
    this.emit('ui:success', { message, module: this.name });
  }

  hideError() {
    this.emit('ui:hideError', { module: this.name });
  }

  // Storage helpers
  async getStorage(key, defaultValue = null) {
    try {
      const result = await chrome.storage.local.get(key);
      return result[key] !== undefined ? result[key] : defaultValue;
    } catch (error) {
      console.error(`Failed to get storage for ${key}:`, error);
      return defaultValue;
    }
  }

  async setStorage(key, value) {
    try {
      await chrome.storage.local.set({ [key]: value });
      return true;
    } catch (error) {
      console.error(`Failed to set storage for ${key}:`, error);
      return false;
    }
  }

  // Chrome extension helpers
  async sendMessageToTab(message) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) {
        throw new Error('No active tab found');
      }

      const response = await chrome.tabs.sendMessage(tab.id, message);
      return response;
    } catch (error) {
      console.error(`Failed to send message to tab:`, error);
      return { success: false, error: error.message };
    }
  }

  // Validation helpers
  isInitialized() {
    return this.initialized;
  }

  validateElement(element, elementName) {
    if (!element) {
      console.warn(`Element ${elementName} not found in module ${this.name}`);
      return false;
    }
    return true;
  }

  // Logging helpers
  log(message, ...args) {
    console.log(`[${this.name}] ${message}`, ...args);
  }

  warn(message, ...args) {
    console.warn(`[${this.name}] ${message}`, ...args);
  }

  error(message, ...args) {
    console.error(`[${this.name}] ${message}`, ...args);
  }
}

// Make BaseModule available globally
window.BaseModule = BaseModule;