# Smart Cart Stabilization - Migration Guide

## 🎯 Implementation Priority

### Phase 1: Critical Infrastructure (Week 1)
- [ ] **Deploy centralized state management** (`smart-cart-state.js`)
- [ ] **Replace all storage access** with unified API
- [ ] **Fix storage key inconsistencies** across all files
- [ ] **Add debug instrumentation** to critical paths

### Phase 2: Core Functionality (Week 2)
- [ ] **Implement robust quantity controls** (`quantity-control.js`)
- [ ] **Fix dropdown event handling** (`dropdown.js`)
- [ ] **Deploy unified API** (`smart-cart-api.js`)
- [ ] **Update all components** to use new API

### Phase 3: UI/UX Polish (Week 3)
- [ ] **Fix variant/seller mapping logic**
- [ ] **Implement proper price display logic**
- [ ] **Add loading states** and error handling
- [ ] **Optimize performance** and API usage

### Phase 4: Testing & Validation (Week 4)
- [ ] **Deploy comprehensive test suite**
- [ ] **Run E2E validation scenarios**
- [ ] **Performance testing** and optimization
- [ ] **User acceptance testing**

---

## 🔧 Code Migration Steps

### Step 1: Replace Storage Access

**Before:**
```javascript
// Multiple inconsistent patterns
await chrome.storage.local.set({ digikala_extension_smart_cart_items: items });
await this.storageService.set({ [this.storageKey]: this.cart });
```

**After:**
```javascript
// Unified state management
const cartState = window.smartCartState;
await cartState.addItem(productId, variantId, quantity);
```

### Step 2: Update Component Initialization

**Before:**
```javascript
// Each component manages its own state
class SmartCartManager {
  constructor() {
    this.cartItems = [];
    this.loadCartData();
  }
}
```

**After:**
```javascript
// Use centralized API
class SmartCartManager {
  constructor() {
    this.cartAPI = new UnifiedSmartCartAPI('popup');
    this.cartAPI.subscribe(this.handleStateUpdate.bind(this));
  }
}
```

### Step 3: Replace Quantity Controls

**Before:**
```javascript
// Custom quantity input handling
<input type="number" onchange="updateQuantity(this.value)">
```

**After:**
```javascript
// Robust quantity control component
const qtyControl = new QuantityControl(cartAPI, itemId, currentQuantity);
container.appendChild(qtyControl.element);
```

### Step 4: Update Event Handlers

**Before:**
```javascript
// Event propagation issues
dropdown.addEventListener('click', () => {
  // Dropdown closes unexpectedly
});
```

**After:**
```javascript
// Proper event handling
const dropdown = new SmartDropdown({
  placeholder: 'انتخاب فروشنده'
});
dropdown.onSelectionChange((item) => {
  // Handle selection
});
```

---

## 🐛 Bug Fix Implementation

### Fix #1: State Synchronization

**File:** `src/ui/popup/modules/features/smart-cart-manager.js`

**Problem:**
```javascript
// Race condition in storage updates
chrome.storage.local.set({ digikala_extension_smart_cart_items: this.cartItems });
```

**Solution:**
```javascript
// Use centralized state with locking
await this.cartAPI.addItem(productId, variantId, quantity);
```

### Fix #2: Storage Key Inconsistency

**Files:** Multiple

**Problem:**
```javascript
// Inconsistent keys
'smart_cart_items'  // New manager
'digikala_extension_smart_cart_items'  // Everywhere else
```

**Solution:**
```javascript
// Standardize on single key in centralized state
const STORAGE_KEY = 'digikala_extension_smart_cart_items';
```

### Fix #3: API Request Deduplication

**File:** `src/features/smart-cart/core/smart-cart-api.js`

**Implementation:**
```javascript
// Request deduplication
if (this.requestQueue.has(cacheKey)) {
  return this.requestQueue.get(cacheKey);
}

const requestPromise = this.fetchProductDataInternal(productId, variantId);
this.requestQueue.set(cacheKey, requestPromise);
```

### Fix #4: Quantity Validation

**File:** `src/features/smart-cart/components/quantity-control.js`

**Implementation:**
```javascript
// Robust validation with debouncing
async validateAndUpdate() {
  const newQuantity = parseInt(this.input.value, 10);

  if (isNaN(newQuantity) || newQuantity < 1) {
    this.setInputValue(1);
    return;
  }

  if (newQuantity > 99) {
    this.setInputValue(99);
    newQuantity = 99;
  }

  await this.updateQuantity(newQuantity);
}
```

---

## 📁 File Structure Changes

### New Files Created:
```
src/features/smart-cart/
├── core/
│   ├── smart-cart-state.js      ✅ NEW - Centralized state
│   └── smart-cart-api.js        ✅ NEW - Unified API
├── components/
│   ├── quantity-control.js      ✅ NEW - Robust quantity control
│   └── dropdown.js              ✅ NEW - Fixed dropdown component
└── tests/
    ├── smart-cart.test.js        ✅ NEW - Unit tests
    └── e2e-scenarios.js          ✅ NEW - E2E tests
```

### Files to Update:
```
src/features/smart-cart/
├── smart-cart-manager.js        🔄 UPDATE - Use new API
├── smart-cart-integration.js    🔄 UPDATE - Use new API

src/ui/popup/modules/features/
├── smart-cart-manager.js        🔄 UPDATE - Use new API
└── smart-cart-client.js         🔄 UPDATE - Use new API

src/ui/fullpage/
├── smart-cart-client.js         🔄 UPDATE - Use new API
└── fullpage.js                  🔄 UPDATE - Use new API

src/ui/components/
└── smart-cart-button.js         🔄 UPDATE - Use new API
```

### Files to Deprecate:
```
src/services/
├── smart-cart-state-manager.js  ❌ DEPRECATE - Use new state
└── smart-cart-api.js            ❌ DEPRECATE - Use new API
```

---

## 🧪 Testing Strategy

### 1. Unit Tests
```bash
# Run unit tests
npm test -- --testPathPattern=smart-cart.test.js

# Coverage report
npm run test:coverage
```

### 2. Integration Tests
```bash
# Run integration tests
npm run test:integration

# Specific test suites
npm test -- --testNamePattern="State Sync"
```

### 3. E2E Tests
```bash
# Run Playwright tests
npx playwright test src/features/smart-cart/tests/e2e-scenarios.js

# Run specific scenario
npx playwright test --grep "Add item to cart"
```

### 4. Performance Tests
```bash
# Benchmark cart operations
npm run test:performance

# Memory leak detection
npm run test:memory
```

---

## 🔍 Monitoring and Debugging

### Debug Instrumentation

**Add to all critical operations:**
```javascript
console.log(`🔄 [SmartCart:${context}] ${operation}(${params})`);
```

**Key debug points:**
- Storage read/write operations
- API requests and responses
- State synchronization events
- UI component lifecycle
- Error conditions

### Performance Monitoring

**Track these metrics:**
```javascript
// Cart operation timing
const start = performance.now();
await cartAPI.addItem(productId);
const duration = performance.now() - start;
console.log(`⏱️ addItem took ${duration.toFixed(2)}ms`);

// Memory usage
const memUsage = performance.memory?.usedJSHeapSize || 0;
console.log(`💾 Memory usage: ${(memUsage / 1024 / 1024).toFixed(2)}MB`);
```

---

## 🚀 Deployment Checklist

### Pre-Deployment
- [ ] All unit tests passing
- [ ] Integration tests passing
- [ ] E2E scenarios validated
- [ ] Performance benchmarks met
- [ ] Code review completed
- [ ] Documentation updated

### Deployment Steps
1. **Backup current implementation**
2. **Deploy core infrastructure** (state management)
3. **Gradually migrate components** (one at a time)
4. **Validate each migration step**
5. **Monitor error rates** and performance
6. **Rollback plan** ready if needed

### Post-Deployment
- [ ] Monitor error logs for 48 hours
- [ ] Validate user feedback
- [ ] Performance metrics stable
- [ ] Memory usage within bounds
- [ ] Storage operations successful
- [ ] Cross-context sync working

---

## 🎯 Success Metrics

### Reliability Targets
- **Error rate**: < 0.1% of operations
- **State sync**: 100% consistency across contexts
- **Storage operations**: 99.9% success rate
- **Memory leaks**: Zero detected

### Performance Targets
- **Cart load time**: < 2 seconds for 100 items
- **API response time**: < 1 second average
- **Optimization time**: < 5 seconds for complex carts
- **Storage usage**: < 80% of 8KB limit

### User Experience Targets
- **Button responsiveness**: < 200ms click response
- **Quantity updates**: Real-time across all contexts
- **Error recovery**: Automatic with user notification
- **Offline graceful**: Cached data available

---

## 🆘 Rollback Plan

### Immediate Rollback (< 1 hour)
1. **Revert to previous version** from backup
2. **Clear corrupted storage** if needed
3. **Notify users** of temporary issues
4. **Investigate root cause**

### Partial Rollback (Component-level)
1. **Disable problematic component**
2. **Fall back to old implementation**
3. **Maintain other improvements**
4. **Fix and re-deploy component**

### Emergency Procedures
- **Disable extension** if critical issues
- **Clear all storage** to reset state
- **Redirect to fallback UI**
- **Emergency hotfix deployment**