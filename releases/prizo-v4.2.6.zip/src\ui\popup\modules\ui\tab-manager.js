/**
 * @Author: Zana Saedpanah
 * @Date: 2025-09-15
 * Tab Manager - Handles tab navigation and switching functionality
 */

class TabManager extends BaseModule {
  constructor(eventBus, domManager) {
    super('TabManager', eventBus, domManager);

    this.activeTab = 0;
    this.tabItems = null;
    this.tabContents = null;
    this.tabNavigation = null;
    this.resizeHandler = null;
  }

  async initializeElements() {
    this.elements = this.domManager.getElements({
      tabNavigation: '#tabNavigation',
      clearMessagesBtn: '#clearMessagesBtn'
    });

    // Get tab items and contents using querySelectorAll
    this.tabItems = this.domManager.querySelectorAll('.tab-item');
    this.tabContents = this.domManager.querySelectorAll('.tab-content');
    this.tabNavigation = this.elements.tabNavigation;

    if (!this.tabItems || this.tabItems.length === 0) {
      this.warn('No tab items found');
    }

    if (!this.tabContents || this.tabContents.length === 0) {
      this.warn('No tab contents found');
    }

    this.log(`Initialized with ${this.tabItems?.length || 0} tabs`);
  }

  async setupEventListeners() {
    // Listen for external tab switch requests
    this.on('tab:switch', (data) => this.handleTabSwitchRequest(data));
    this.on('tab:refresh-current', () => this.refreshCurrentTab());

    // Setup UI event listeners
    this.setupTabEventListeners();
    this.setupResizeHandler();

    // Listen for system messages events
    this.on('messages:clear', () => this.clearSystemMessages());
  }

  async loadInitialData() {
    await this.loadActiveTab();
    this.initializeTabIndicator();
  }

  setupTabEventListeners() {
    if (!this.tabItems) return;

    this.tabItems.forEach((tab, index) => {
      // Click handler
      this.domManager.addEventListener(tab, 'click', (e) => {
        e.preventDefault();
        this.switchToTab(index);
      });

      // Keyboard navigation
      this.domManager.addEventListener(tab, 'keydown', (e) => {
        this.handleTabKeydown(e, index);
      });
    });

    // Clear messages button
    const { clearMessagesBtn } = this.elements;
    if (clearMessagesBtn) {
      this.domManager.addEventListener(clearMessagesBtn, 'click', () => {
        this.emit('messages:clear-requested');
      });
    }
  }

  setupResizeHandler() {
    this.resizeHandler = () => {
      this.updateTabIndicator(this.activeTab);
    };

    window.addEventListener('resize', this.resizeHandler);
  }

  handleTabKeydown(e, index) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      this.switchToTab(index);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      const nextIndex = (index + 1) % this.tabItems.length;
      this.tabItems[nextIndex].focus();
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      const prevIndex = index === 0 ? this.tabItems.length - 1 : index - 1;
      this.tabItems[prevIndex].focus();
    }
  }

  // Tab management methods
  async loadActiveTab() {
    try {
      const activeTab = await this.getStorage('activeTab', 0);
      this.activeTab = activeTab;
      this.switchToTab(this.activeTab);
      this.log(`Loaded active tab: ${this.activeTab}`);
    } catch (error) {
      this.error('Error loading active tab:', error);
      this.activeTab = 0;
      this.switchToTab(0);
    }
  }

  async saveActiveTab(tabIndex) {
    try {
      await this.setStorage('activeTab', tabIndex);
    } catch (error) {
      this.error('Error saving active tab:', error);
    }
  }

  switchToTab(index) {
    if (!this.tabItems || !this.tabContents) {
      this.warn('Cannot switch tabs - elements not initialized');
      return;
    }

    // Validate index
    if (index < 0 || index >= this.tabItems.length) {
      this.warn(`Invalid tab index: ${index}`);
      return;
    }

    this.log(`Switching to tab ${index}`);

    // Update active states for tab items
    this.tabItems.forEach((tab, i) => {
      const isActive = i === index;
      this.domManager.toggleClass(tab, 'active', isActive);
      tab.setAttribute('aria-selected', isActive.toString());
      tab.setAttribute('tabindex', isActive ? '0' : '-1');
    });

    // Update active states for tab contents
    this.tabContents.forEach((content, i) => {
      const isActive = i === index;
      this.domManager.toggleClass(content, 'active', isActive);
      content.setAttribute('aria-hidden', (!isActive).toString());
    });

    // Update tab navigation indicator
    if (this.tabNavigation) {
      this.tabNavigation.setAttribute('data-active-tab', index.toString());
      this.updateTabIndicator(index);
    }

    // Update internal state
    const previousTab = this.activeTab;
    this.activeTab = index;

    // Save to storage
    this.saveActiveTab(index);

    // Emit events
    this.emit('tab:switched', {
      previousTab,
      currentTab: index,
      tabData: this.getTabData(index)
    });

    // Handle specific tab logic
    this.handleTabSpecificLogic(index);
  }

  getTabData(index) {
    if (!this.tabItems || index >= this.tabItems.length) {
      return null;
    }

    const tabItem = this.tabItems[index];
    return {
      index,
      element: tabItem,
      dataset: tabItem.dataset.tab || '',
      title: tabItem.getAttribute('title') || '',
      ariaLabel: tabItem.getAttribute('aria-label') || ''
    };
  }

  handleTabSpecificLogic(index) {
    // Handle specific logic for each tab
    switch (index) {
      case 0: // Watchlist tab
        this.emit('watchlist:tab-activated');
        break;
      case 1: // Features tab
        this.emit('features:tab-activated');
        break;
      case 2: // Configuration tab
        this.emit('config:tab-activated');
        break;
      case 3: // Messages tab
        this.emit('messages:tab-activated');
        break;
      case 4: // About tab
        this.emit('about:tab-activated');
        break;
      default:
        this.emit('tab:unknown-activated', { index });
    }
  }

  initializeTabIndicator() {
    if (!this.tabNavigation || !this.tabItems) {
      this.warn('Cannot initialize tab indicator - elements missing');
      return;
    }

    // Set the initial position
    this.updateTabIndicator(this.activeTab);
    this.log('Tab indicator initialized');
  }

  updateTabIndicator(index) {
    if (!this.tabNavigation || !this.tabItems) return;

    // Get the direction of the document
    const isRTL = this.isRTLMode();
    const totalTabs = this.tabItems.length;

    // Validate index
    if (index < 0 || index >= totalTabs) {
      this.warn(`Invalid tab index for indicator: ${index}`);
      return;
    }

    // Calculate position based on RTL or LTR
    let translateValue;
    if (isRTL) {
      // In RTL mode, tabs are positioned right-to-left
      // Tab 0 (rightmost) = 0%, Tab 1 = -100%, Tab 2 = -200%, etc.
      translateValue = -(index * 100);
    } else {
      // In LTR mode, tabs are positioned left-to-right
      // Tab 0 (leftmost) = 0%, Tab 1 = 100%, Tab 2 = 200%, etc.
      translateValue = index * 100;
    }

    // Set CSS custom property for precise control
    this.tabNavigation.style.setProperty('--tab-indicator-position', `${translateValue}%`);

    this.log(`Tab indicator updated: Tab=${index}, RTL=${isRTL}, Transform=${translateValue}%`);

    // Emit indicator updated event
    this.emit('tab:indicator-updated', { index, translateValue, isRTL });
  }

  isRTLMode() {
    return document.documentElement.dir === 'rtl' ||
      document.body.dir === 'rtl' ||
      getComputedStyle(document.body).direction === 'rtl';
  }

  // Event handlers
  handleTabSwitchRequest(data) {
    if (typeof data.index === 'number') {
      this.switchToTab(data.index);
    } else if (typeof data.tabName === 'string') {
      const index = this.getTabIndexByName(data.tabName);
      if (index !== -1) {
        this.switchToTab(index);
      } else {
        this.warn(`Tab with name '${data.tabName}' not found`);
      }
    }
  }

  refreshCurrentTab() {
    this.handleTabSpecificLogic(this.activeTab);
    this.emit('tab:refreshed', { index: this.activeTab });
  }

  clearSystemMessages() {
    // This is handled by delegating to the messages module
    this.emit('messages:clear-requested');
  }

  // Utility methods
  getTabIndexByName(tabName) {
    if (!this.tabItems) return -1;

    for (let i = 0; i < this.tabItems.length; i++) {
      const tab = this.tabItems[i];
      if (tab.dataset.tab === tabName) {
        return i;
      }
    }
    return -1;
  }

  getCurrentTab() {
    return {
      index: this.activeTab,
      data: this.getTabData(this.activeTab)
    };
  }

  getTabCount() {
    return this.tabItems ? this.tabItems.length : 0;
  }

  isTabActive(index) {
    return this.activeTab === index;
  }

  getTabNames() {
    if (!this.tabItems) return [];

    return Array.from(this.tabItems).map(tab => tab.dataset.tab || '');
  }

  // Public API methods
  async goToTab(index) {
    this.switchToTab(index);
  }

  async goToTabByName(tabName) {
    const index = this.getTabIndexByName(tabName);
    if (index !== -1) {
      this.switchToTab(index);
      return true;
    }
    return false;
  }

  async nextTab() {
    const nextIndex = (this.activeTab + 1) % this.getTabCount();
    this.switchToTab(nextIndex);
  }

  async previousTab() {
    const prevIndex = this.activeTab === 0 ? this.getTabCount() - 1 : this.activeTab - 1;
    this.switchToTab(prevIndex);
  }

  // Accessibility methods
  focusActiveTab() {
    if (this.tabItems && this.tabItems[this.activeTab]) {
      this.tabItems[this.activeTab].focus();
    }
  }

  updateTabAccessibility(index, options = {}) {
    if (!this.tabItems || !this.tabItems[index]) return;

    const tab = this.tabItems[index];

    if (options.label) {
      tab.setAttribute('aria-label', options.label);
    }

    if (options.title) {
      tab.setAttribute('title', options.title);
    }

    if (options.disabled !== undefined) {
      tab.setAttribute('aria-disabled', options.disabled.toString());
      this.domManager.toggleClass(tab, 'disabled', options.disabled);
    }
  }

  // Badge management for tabs (e.g., message count)
  updateTabBadge(index, badgeData) {
    if (!this.tabItems || !this.tabItems[index]) return;

    const tab = this.tabItems[index];
    let badge = tab.querySelector('.tab-badge');

    if (badgeData.count > 0) {
      if (!badge) {
        badge = this.domManager.createElement('span', {
          className: 'tab-badge',
          parent: tab
        });
      }

      this.domManager.setText(badge, badgeData.count.toString());
      this.domManager.removeClass(badge, 'hidden');

      if (badgeData.type) {
        badge.className = `tab-badge ${badgeData.type}`;
      }
    } else {
      if (badge) {
        this.domManager.addClass(badge, 'hidden');
      }
    }

    this.emit('tab:badge-updated', { index, badgeData });
  }

  // Cleanup
  async cleanup() {
    if (this.resizeHandler) {
      window.removeEventListener('resize', this.resizeHandler);
      this.resizeHandler = null;
    }

    this.tabItems = null;
    this.tabContents = null;
    this.tabNavigation = null;
  }

  removeEventListeners() {
    // Event listeners are managed by DOMManager and will be cleaned up automatically
    if (this.resizeHandler) {
      window.removeEventListener('resize', this.resizeHandler);
    }
  }

  // Debug utilities
  logTabStats() {
    this.log('Tab Statistics:', {
      totalTabs: this.getTabCount(),
      activeTab: this.activeTab,
      tabNames: this.getTabNames(),
      isRTL: this.isRTLMode()
    });
  }
}

// Make available globally
window.TabManager = TabManager;