/**
 * @Author: Zana Saedpanah
 * @Date:   2025-06-17 11:51:23
 * @Last Modified by:   Zana Saedpanah
 * @Last Modified time: 2025-07-07 11:29:52
 */


class PopupController {
  constructor() {
    this.statusElement = document.getElementById('status');
    this.pageTypeElement = document.getElementById('pageType');
    this.loadingElement = document.getElementById('loading');
    this.errorElement = document.getElementById('error');
    this.persistentSection = document.getElementById('persistentSection');
    this.persistentModeCheckbox = document.getElementById('persistentMode');
    this.toggleSwitchContainer = document.getElementById('toggleSwitchContainer');

    // Legacy button references removed - using only global Main buttons

    // Sorting feature elements
    this.sortFeatureSection = document.getElementById('sortFeatureSection');
    this.sortFeatureCheckbox = document.getElementById('sortFeatureMode');
    this.sortToggleSwitchContainer = document.getElementById('sortToggleSwitchContainer');
    this.sortFeatureEnabled = false;

    // Cart feature elements
    this.cartFeatureSection = document.getElementById('cartFeatureSection');
    this.cartFeatureCheckbox = document.getElementById('cartFeatureMode');
    this.cartToggleSwitchContainer = document.getElementById('cartToggleSwitchContainer');
    this.cartFeatureEnabled = false;

    // Legacy cart button references removed - using only global Main buttons

    // Welcome guide button
    this.showWelcomeGuideBtn = document.getElementById('showWelcomeGuide');

    // Tab navigation elements
    this.tabNavigation = document.getElementById('tabNavigation');
    this.tabItems = document.querySelectorAll('.tab-item');
    this.tabContents = document.querySelectorAll('.tab-content');
    this.messagesBadge = document.getElementById('messagesBadge');
    this.clearMessagesBtn = document.getElementById('clearMessagesBtn');

    // Tab state
    this.activeTab = 0;
    this.systemMessages = [];

    // Global control buttons
    this.toggleMainBtn = document.getElementById('toggleMainBtn');
    this.updateMainBtn = document.getElementById('updateMainBtn');
    this.emergencyStopMainBtn = document.getElementById('emergencyStopMainBtn');
    this.clearDisplayMainBtn = document.getElementById('clearDisplayMainBtn');
    this.clearCacheMainBtn = document.getElementById('clearCacheMainBtn');
    this.resetAllMainBtn = document.getElementById('resetAllMainBtn');

    // Watchlist management elements
    this.openFullPageBtn = document.getElementById('openFullPageBtn');
    this.testNotificationBtn = document.getElementById('testNotificationBtn');
    this.showWatchlistBtn = document.getElementById('showWatchlistBtn');
    this.refreshWatchlistBtn = document.getElementById('refreshWatchlistBtn');
    this.watchlistSummary = document.getElementById('watchlistSummary');
    this.watchlistStats = document.getElementById('watchlistStats');
    this.totalItemsCount = document.getElementById('totalItemsCount');
    this.activeItemsCount = document.getElementById('activeItemsCount');
    this.lastUpdateText = document.getElementById('lastUpdateText');

    // Modal elements
    this.watchlistModal = document.getElementById('watchlistModal');
    this.closeWatchlistModal = document.getElementById('closeWatchlistModal');
    this.clearAllWatchlistBtn = document.getElementById('clearAllWatchlistBtn');
    this.watchlistLoading = document.getElementById('watchlistLoading');
    this.watchlistEmpty = document.getElementById('watchlistEmpty');
    this.watchlistItems = document.getElementById('watchlistItems');

    // Edit modal elements
    this.editWatchlistModal = document.getElementById('editWatchlistModal');
    this.closeEditModal = document.getElementById('closeEditModal');
    this.editProductTitle = document.getElementById('editProductTitle');

    // Comparison sites elements
    this.comparisonSitesList = document.getElementById('comparisonSitesList');
    this.addSiteBtn = document.getElementById('addSiteBtn');
    this.addSiteForm = document.getElementById('addSiteForm');
    this.popularSitesSelect = document.getElementById('popularSites');
    this.siteNameInput = document.getElementById('siteName');
    this.siteUrlInput = document.getElementById('siteUrl');
    this.siteIconPreview = document.getElementById('siteIconPreview');
    this.siteIconFallback = document.getElementById('siteIconFallback');
    this.siteIconStatus = document.getElementById('siteIconStatus');
    this.saveSiteBtn = document.getElementById('saveSiteBtn');
    this.cancelSiteBtn = document.getElementById('cancelSiteBtn');
    this.comparisonSites = [];
    
    // Comparison feature toggle elements
    this.comparisonFeatureCheckbox = document.getElementById('comparisonFeatureMode');
    this.comparisonToggleSwitchContainer = document.getElementById('comparisonToggleSwitchContainer');
    this.comparisonSitesManagement = document.getElementById('comparisonSitesManagement');
    this.comparisonFeatureEnabled = false;
    this.editPriceThreshold = document.getElementById('editPriceThreshold');
    this.editDiscountThreshold = document.getElementById('editDiscountThreshold');
    this.editNotifyLowest30Days = document.getElementById('editNotifyLowest30Days');
    this.editCheckInterval = document.getElementById('editCheckInterval');
    this.cancelEditBtn = document.getElementById('cancelEditBtn');
    this.saveEditBtn = document.getElementById('saveEditBtn');

    this.isActive = false;
    this.pageType = 'unknown';
    this.persistentMode = false;
    this.currentEditingEntry = null;
    this.watchlistCache = [];
    this.workingFaviconUrl = null;
    this.initTabs();
    this.init();
  }

  async init() {
    // Load extension version and update about section
    this.loadExtensionVersion();

    // Check if we're on a valid page and get status
    const status = await this.getExtensionStatus();
    if (!status) {
      this.showError('افزونه در حال بارگذاری است یا صفحه آماده نیست');
      this.updatePageTypeDisplay('unsupported');
      return;
    }

    // Handle homepage specifically
    if (status.pageType === 'homepage') {
      this.addSystemMessage('info', 'این صفحه اصلی فروشگاه است. افزونه در صفحات محصول و لیست‌ها فعال می‌شود.');
    } else if (status.pageType === 'fresh-homepage') {
      this.addSystemMessage('info', 'این صفحه اصلی فروشگاه است. افزونه در صفحات محصول فعال می‌شود.');
    } else if (status.pageType === 'general') {
      this.addSystemMessage('info', 'افزونه آماده استفاده است. ویژگی‌های نظارت قیمت و مقایسه قیمت در دسترس هستند.');
    }

    this.isActive = status.active;
    this.pageType = status.pageType;
    this.persistentMode = status.persistentMode;

    // Load all features
    await this.loadSortFeature();
    await this.loadCartFeature();
    await this.loadDelaySettings();
    await this.loadComparisonFeature();
    await this.loadComparisonSites();

    // Update UI based on page type
    this.updatePageTypeDisplay();
    this.updateUI();
    this.setupEventListeners();
    this.loadSystemMessages();
  }




  // Add cart feature loading method
  async loadCartFeature() {
    try {
      const result = await chrome.storage.local.get(['cartFeatureEnabled']);
      this.cartFeatureEnabled = result.cartFeatureEnabled !== false; // Default enabled
      console.log('🛒 Cart feature loaded:', this.cartFeatureEnabled);
    } catch (error) {
      console.error('❌ Error loading cart feature:', error);
      this.cartFeatureEnabled = false;
    }
  }

  // Load delay settings
  async loadDelaySettings() {
    try {
      const result = await chrome.storage.local.get(['globalDelay', 'networkStabilityCheck']);
      this.globalDelay = result.globalDelay || 1000;
      this.networkStabilityCheck = result.networkStabilityCheck || false;
      console.log('⏳ Delay settings loaded:', { globalDelay: this.globalDelay, networkStabilityCheck: this.networkStabilityCheck });
    } catch (error) {
      console.error('❌ Error loading delay settings:', error);
      this.globalDelay = 1000;
      this.networkStabilityCheck = false;
    }
  }

  // Load settings from storage when content script is not available
  async loadSettingsFromStorage() {
    try {
      const result = await chrome.storage.local.get([
        'persistentMode',
        'sortFeatureEnabled',
        'cartFeatureEnabled'
      ]);

      this.persistentMode = result.persistentMode || false;
      this.sortFeatureEnabled = result.sortFeatureEnabled || false;
      this.cartFeatureEnabled = result.cartFeatureEnabled !== undefined ? result.cartFeatureEnabled : true;

      console.log('📂 Settings loaded from storage:', {
        persistentMode: this.persistentMode,
        sortFeatureEnabled: this.sortFeatureEnabled,
        cartFeatureEnabled: this.cartFeatureEnabled
      });
    } catch (error) {
      console.error('❌ Error loading settings from storage:', error);
      // Use defaults
      this.persistentMode = false;
      this.sortFeatureEnabled = false;
      this.cartFeatureEnabled = true;
    }
  }
  /**
   * Load extension version from manifest and update the about section
   */
  loadExtensionVersion() {
    try {
      const manifest = chrome.runtime.getManifest();
      const versionElement = document.getElementById('extensionVersion');
      const sourceElement = document.getElementById('sourceLink');

      if (versionElement) {
        versionElement.textContent = `v${manifest.version}`;
      }

      // Set up source link - you can modify this URL as needed
      if (sourceElement) {
        sourceElement.href = 'https://github.com/zanadeveloper/prizo-extension';
        sourceElement.target = '_blank';
        sourceElement.rel = 'noopener noreferrer';
      }
    } catch (error) {
      console.error('Failed to load extension version:', error);
      const versionElement = document.getElementById('extensionVersion');
      if (versionElement) {
        versionElement.textContent = 'نامشخص';
      }
    }
  }

  async getExtensionStatus() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (!tab.url) {
        return null;
      }

      try {
        const response = await chrome.tabs.sendMessage(tab.id, {
          action: 'getStatus'
        });
        return response;
      } catch (error) {
        // Content script not available, return default status
        console.log('Content script not available for status check');
        return {
          active: false,
          pageType: this.detectPageTypeFromUrl(tab.url),
          persistentMode: this.persistentMode,
          sortFeatureEnabled: this.sortFeatureEnabled,
          cartFeatureEnabled: this.cartFeatureEnabled
        };
      }
    } catch (error) {
      console.error('Error getting status:', error);
      return null;
    }
  }

  detectPageTypeFromUrl(url) {
    if (!url) return 'unknown';

    // Check for Digikala specific patterns first (for backward compatibility)
    if (url.includes('digikala.com')) {
      if (url === 'https://www.digikala.com/' || url.includes('/main/')) {
        return 'homepage';
      } else if (url === 'https://www.digikala.com/fresh/' || url === 'https://www.digikala.com/fresh') {
        return 'fresh-homepage';
      } else if (url.includes('/profile/orders/') && /\/profile\/orders\/\d+/.test(url)) {
        return 'order';
      } else if (url.includes('/checkout/cart/')) {
        return 'cart';
      } else if (url.includes('/profile/lists/') || url.includes('/profile/wishlist/')) {
        return 'wishlist';
      } else if (url.includes('/product/dkp-') || url.includes('/fresh/product/dkp-')) {
        return 'product';
      } else if (url.includes('/seller/')) {
        return 'seller';
      } else if (url.includes('/search') || url.includes('/fresh/search') || url.includes('/category') ||
        url.includes('/incredible-offers') || url.includes('/tags')) {
        return 'listing';
      }
      return 'digikala-other';
    }

    // Generic patterns for any e-commerce site
    if (url.includes('/product/') || url.includes('/item/') || url.includes('/p/')) {
      return 'product';
    } else if (url.includes('/cart') || url.includes('/basket') || url.includes('/shopping-cart')) {
      return 'cart';
    } else if (url.includes('/search') || url.includes('/category') || url.includes('/shop') || url.includes('/store')) {
      return 'listing';
    } else if (url.includes('/order') || url.includes('/purchase')) {
      return 'order';
    } else if (url.includes('/wishlist') || url.includes('/favorites') || url.includes('/saved')) {
      return 'wishlist';
    } else if (url.includes('/seller') || url.includes('/vendor') || url.includes('/merchant')) {
      return 'seller';
    }

    return 'general';
  }

  // Tab functionality
  initTabs() {
    this.loadActiveTab();
    this.setupTabEventListeners();
    this.initializeTabIndicator();
  }

  async loadActiveTab() {
    try {
      const result = await chrome.storage.local.get(['activeTab']);
      this.activeTab = result.activeTab || 0;
      this.switchToTab(this.activeTab);
    } catch (error) {
      console.error('Error loading active tab:', error);
      this.activeTab = 0;
      this.switchToTab(0);
    }
  }

  /**
   * Initialize tab indicator positioning
   */
  initializeTabIndicator() {
    if (this.tabNavigation && this.tabItems) {
      // Set the initial position
      this.updateTabIndicator(this.activeTab);
      
      // Also handle window resize to recalculate if needed
      window.addEventListener('resize', () => {
        this.updateTabIndicator(this.activeTab);
      });
    }
  }

  async saveActiveTab(tabIndex) {
    try {
      await chrome.storage.local.set({ activeTab: tabIndex });
    } catch (error) {
      console.error('Error saving active tab:', error);
    }
  }

  setupTabEventListeners() {
    if (!this.tabItems) return;

    this.tabItems.forEach((tab, index) => {
      tab.addEventListener('click', (e) => {
        e.preventDefault();
        this.switchToTab(index);
      });

      // Keyboard navigation
      tab.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          this.switchToTab(index);
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          const nextIndex = (index + 1) % this.tabItems.length;
          this.tabItems[nextIndex].focus();
        } else if (e.key === 'ArrowLeft') {
          e.preventDefault();
          const prevIndex = index === 0 ? this.tabItems.length - 1 : index - 1;
          this.tabItems[prevIndex].focus();
        }
      });
    });

    // Clear messages button
    if (this.clearMessagesBtn) {
      this.clearMessagesBtn.addEventListener('click', () => this.clearSystemMessages());
    }
  }

  switchToTab(index) {
    if (!this.tabItems || !this.tabContents) return;

    // Update active states
    this.tabItems.forEach((tab, i) => {
      tab.classList.toggle('active', i === index);
      tab.setAttribute('aria-selected', i === index);
      tab.setAttribute('tabindex', i === index ? '0' : '-1');
    });

    this.tabContents.forEach((content, i) => {
      content.classList.toggle('active', i === index);
      content.setAttribute('aria-hidden', i !== index);
    });

    // Update tab navigation indicator with RTL-aware positioning
    if (this.tabNavigation) {
      this.tabNavigation.setAttribute('data-active-tab', index.toString());
      this.updateTabIndicator(index);
    }

    this.activeTab = index;
    this.saveActiveTab(index);

    // Refresh watchlist if switching to watchlist tab
    if (index === 0) {
      this.loadWatchlistSummary();
    }
  }

  /**
   * Update tab indicator position with RTL-aware calculations
   */
  updateTabIndicator(index) {
    if (!this.tabNavigation || !this.tabItems) return;

    // Get the direction of the document
    const isRTL = document.documentElement.dir === 'rtl' || 
                  document.body.dir === 'rtl' || 
                  getComputedStyle(document.body).direction === 'rtl';

    const totalTabs = this.tabItems.length;
    
    // Calculate position based on RTL or LTR
    let translateValue;
    if (isRTL) {
      // In RTL mode, tabs are positioned right-to-left
      // Tab 0 (rightmost) = 0%, Tab 1 = -100%, Tab 2 = -200%, Tab 3 = -300%
      translateValue = -(index * 100);
    } else {
      // In LTR mode, tabs are positioned left-to-right  
      // Tab 0 (leftmost) = 0%, Tab 1 = 100%, Tab 2 = 200%, Tab 3 = 300%
      translateValue = index * 100;
    }
    
    // Set CSS custom property for more precise control
    this.tabNavigation.style.setProperty('--tab-indicator-position', `${translateValue}%`);

    console.log(`🎯 Tab indicator: Tab=${index}, RTL=${isRTL}, Transform=${translateValue}%`);
  }

  // System messages functionality
  async loadSystemMessages() {
    try {
      const result = await chrome.storage.local.get(['systemMessages']);
      this.systemMessages = result.systemMessages || [];
      this.updateMessagesBadge();
      this.renderSystemMessages();
    } catch (error) {
      console.error('Error loading system messages:', error);
      this.systemMessages = [];
    }
  }

  async saveSystemMessages() {
    try {
      await chrome.storage.local.set({ systemMessages: this.systemMessages });
      this.updateMessagesBadge();
    } catch (error) {
      console.error('Error saving system messages:', error);
    }
  }

  addSystemMessage(type, message) {
    const timestamp = new Date().toISOString();
    const messageObj = {
      id: Date.now(),
      type: type, // 'error', 'warning', 'info', 'success'
      message: message,
      timestamp: timestamp
    };

    this.systemMessages.unshift(messageObj);

    // Keep only last 50 messages
    if (this.systemMessages.length > 50) {
      this.systemMessages = this.systemMessages.slice(0, 50);
    }

    this.saveSystemMessages();
    this.renderSystemMessages();
  }

  updateMessagesBadge() {
    if (!this.messagesBadge) return;

    const unreadCount = this.systemMessages.length;
    if (unreadCount > 0) {
      this.messagesBadge.textContent = unreadCount > 99 ? '99+' : unreadCount.toString();
      this.messagesBadge.classList.remove('hidden');
    } else {
      this.messagesBadge.classList.add('hidden');
    }
  }

  renderSystemMessages() {
    const messagesContainer = document.getElementById('messagesContainer');
    if (!messagesContainer) return;

    if (this.systemMessages.length === 0) {
      messagesContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">💬</div>
          <h4>بدون پیام</h4>
          <p>هیچ پیام سیستمی وجود ندارد</p>
        </div>
      `;
      return;
    }

    const messagesHTML = this.systemMessages.map(msg => {
      const date = new Date(msg.timestamp);
      const timeAgo = this.getTimeAgo(date);

      const icons = {
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️',
        success: '✅'
      };

      return `
        <div class="message-item ${msg.type}">
          <div class="message-meta">
            <span>${icons[msg.type] || 'ℹ️'} ${this.getTypeLabel(msg.type)}</span>
            <span>${timeAgo}</span>
          </div>
          <div class="message-text">${msg.message}</div>
        </div>
      `;
    }).join('');

    messagesContainer.innerHTML = messagesHTML;
  }

  getTypeLabel(type) {
    const labels = {
      error: 'خطا',
      warning: 'هشدار',
      info: 'اطلاعات',
      success: 'موفقیت'
    };
    return labels[type] || 'پیام';
  }

  getTimeAgo(date) {
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);

    if (diffInSeconds < 60) {
      return 'همین حالا';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} دقیقه پیش`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} ساعت پیش`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} روز پیش`;
    }
  }

  async clearSystemMessages() {
    this.systemMessages = [];
    await this.saveSystemMessages();
    this.renderSystemMessages();
  }

  updatePageTypeDisplay(forcePageType = null) {
    const pageType = forcePageType || this.pageType;

    const pageTypeNames = {
      'seller': '🏪 صفحه فروشنده',
      'search': '🔍 صفحه جستجو',
      'category': '📂 صفحه دسته‌بندی',
      'brand': '🏷️ صفحه برند',
      'offers': '🎯 پیشنهادات شگفت‌انگیز',
      'tags': '🏷️ صفحه برچسب‌ها',
      'product': '📦 صفحه محصول',
      'cart': '🛒 سبد خرید',
      'order': '📋 جزئیات سفارش',
      'home': '🏠 صفحه اصلی',
      'homepage': '🏠 صفحه اصلی',
      'fresh-homepage': '🥬 صفحه اصلی سوپرمارکت',
      'wishlist': '❤️ لیست علاقه‌مندی‌ها',
      'listing': '📋 فهرست محصولات',
      'unknown': '❓ صفحه نامشخص',
      'unsupported': '❌ صفحه پشتیبانی نشده'
    };

    this.pageTypeElement.textContent = pageTypeNames[pageType] || '❓ صفحه نامشخص';

    // Show/hide relevant sections based on page type
    const sellerSections = document.querySelectorAll('.seller-only');
    const monthlySections = document.querySelectorAll('.monthly-only');
    const cartSections = document.querySelectorAll('.cart-only');

    if (pageType === 'seller') {
      // Seller pages: Show both seller features and monthly features
      sellerSections.forEach(el => el.style.display = 'block');
      monthlySections.forEach(el => el.style.display = 'block');
      cartSections.forEach(el => el.style.display = 'none');

      // Update checkboxes
      if (this.persistentModeCheckbox) {
        this.persistentModeCheckbox.checked = this.persistentMode;
      }
      if (this.sortFeatureCheckbox) {
        this.sortFeatureCheckbox.checked = this.sortFeatureEnabled;
      }
    } else if (['search', 'category', 'brand', 'offers', 'tags', 'product', 'listing', 'wishlist'].includes(pageType)) {
      // Monthly-only pages: Show only monthly features
      sellerSections.forEach(el => el.style.display = 'none');
      monthlySections.forEach(el => el.style.display = 'block');
      cartSections.forEach(el => el.style.display = 'none');

      // Update checkboxes
      if (this.persistentModeCheckbox) {
        this.persistentModeCheckbox.checked = this.persistentMode;
      }
      if (this.sortFeatureCheckbox) {
        this.sortFeatureCheckbox.checked = this.sortFeatureEnabled;
      }
    } else if (pageType === 'cart') {
      // Cart pages: Show only cart features
      sellerSections.forEach(el => el.style.display = 'none');
      monthlySections.forEach(el => el.style.display = 'none');
      cartSections.forEach(el => el.style.display = 'block');

      // Update cart feature checkbox
      if (this.cartFeatureCheckbox) {
        this.cartFeatureCheckbox.checked = this.cartFeatureEnabled;
      }
    } else if (pageType === 'order') {
      // Order pages: Similar to cart pages, show cart features
      sellerSections.forEach(el => el.style.display = 'none');
      monthlySections.forEach(el => el.style.display = 'none');
      cartSections.forEach(el => el.style.display = 'block');

      // Update cart feature checkbox for order pages
      if (this.cartFeatureCheckbox) {
        this.cartFeatureCheckbox.checked = this.cartFeatureEnabled;
      }
    } else if (pageType === 'homepage' || pageType === 'fresh-homepage') {
      // Homepage or Fresh Homepage: Show helpful information and all settings
      sellerSections.forEach(el => el.style.display = 'none');
      monthlySections.forEach(el => el.style.display = 'block');
      cartSections.forEach(el => el.style.display = 'none');

      // Update checkboxes
      if (this.persistentModeCheckbox) {
        this.persistentModeCheckbox.checked = this.persistentMode;
      }
      if (this.sortFeatureCheckbox) {
        this.sortFeatureCheckbox.checked = this.sortFeatureEnabled;
      }
    } else {
      // Unsupported/unknown page type: Show core information and settings
      sellerSections.forEach(el => el.style.display = 'none');
      monthlySections.forEach(el => el.style.display = 'block');
      cartSections.forEach(el => el.style.display = 'none');

      // Show helpful guide for homepage and unsupported pages
      const homepageGuide = document.getElementById('homepageGuide');
      if (homepageGuide) {
        homepageGuide.style.display = 'block';
      }

      if (pageType === 'unsupported') {
        this.showError('این صفحه توسط افزونه پشتیبانی نمی‌شود. برای مشاهده راهنمای کامل، به بخش "چگونه از افزونه استفاده کنم؟" در پیش روی مراجعه کنید.');
      }
    }

    // Show/hide homepage guide based on page type
    const homepageGuide = document.getElementById('homepageGuide');
    if (homepageGuide) {
      if (['homepage', 'fresh-homepage', 'unknown', 'unsupported'].includes(pageType)) {
        homepageGuide.style.display = 'block';
      } else {
        homepageGuide.style.display = 'none';
      }
    }
  }

  setupEventListeners() {
    // Legacy seller page event listeners removed - using only global Main buttons

    // Welcome guide button
    if (this.showWelcomeGuideBtn) {
      this.showWelcomeGuideBtn.addEventListener('click', () => this.handleShowWelcomeGuide());
    }

    // Main control button event listeners
    if (this.toggleMainBtn) {
      this.toggleMainBtn.addEventListener('click', () => this.handleToggle());
    }
    if (this.updateMainBtn) {
      this.updateMainBtn.addEventListener('click', () => this.handleUpdate());
    }
    if (this.emergencyStopMainBtn) {
      this.emergencyStopMainBtn.addEventListener('click', () => this.handleEmergencyStop());
    }
    if (this.clearDisplayMainBtn) {
      this.clearDisplayMainBtn.addEventListener('click', () => this.handleClearDisplay());
    }
    if (this.clearCacheMainBtn) {
      this.clearCacheMainBtn.addEventListener('click', () => this.handleClearCache());
    }
    if (this.resetAllMainBtn) {
      this.resetAllMainBtn.addEventListener('click', () => this.handleResetAll());
    }

    // Comparison sites event listeners
    if (this.addSiteBtn) {
      this.addSiteBtn.addEventListener('click', () => this.showAddSiteForm());
    }
    if (this.popularSitesSelect) {
      this.popularSitesSelect.addEventListener('change', () => this.handlePopularSiteSelection());
    }
    if (this.saveSiteBtn) {
      this.saveSiteBtn.addEventListener('click', () => this.handleSaveSite());
    }
    if (this.cancelSiteBtn) {
      this.cancelSiteBtn.addEventListener('click', () => this.hideAddSiteForm());
    }

    // Favicon preview functionality
    if (this.siteUrlInput) {
      this.siteUrlInput.addEventListener('input', () => this.updateFaviconPreview());
    }

    // Add error handler for favicon preview
    if (this.siteIconPreview) {
      this.siteIconPreview.addEventListener('error', () => {
        this.siteIconPreview.style.display = 'none';
        if (this.siteIconFallback) {
          this.siteIconFallback.style.display = 'inline-block';
        }
      });
    }

    // Comparison feature toggle event listeners
    if (this.comparisonFeatureCheckbox) {
      this.comparisonFeatureCheckbox.addEventListener('change', () => this.handleComparisonFeatureToggle());
    }
    if (this.comparisonToggleSwitchContainer) {
      this.comparisonToggleSwitchContainer.addEventListener('click', () => {
        this.comparisonFeatureCheckbox.checked = !this.comparisonFeatureCheckbox.checked;
        this.updateComparisonToggleSwitch();
        this.handleComparisonFeatureToggle();
      });
    }

    // Consolidated event listeners for legacy buttons (keep for compatibility)
    const buttonMappings = [
      { buttons: [this.toggleMonthlyBtn, this.toggleCartBtn], handler: () => this.handleToggle() },
      { buttons: [this.updateMonthlyBtn, this.updateCartBtn], handler: () => this.handleUpdate() },
      { buttons: [this.emergencyStopMonthlyBtn, this.emergencyStopCartBtn], handler: () => this.handleEmergencyStop() },
      { buttons: [this.clearDisplayMonthlyBtn, this.clearDisplayCartBtn], handler: () => this.handleClearDisplay() },
      { buttons: [this.clearCacheMonthlyBtn, this.clearCacheCartBtn], handler: () => this.handleClearCache() },
      { buttons: [this.resetAllMonthlyBtn, this.resetAllCartBtn], handler: () => this.handleResetAll() }
    ];

    buttonMappings.forEach(({ buttons, handler }) => {
      buttons.forEach(button => {
        if (button) {
          button.addEventListener('click', handler);
        }
      });
    });

    // Persistent mode toggle with custom switch
    if (this.toggleSwitchContainer && this.persistentModeCheckbox) {
      this.toggleSwitchContainer.addEventListener('click', () => {
        this.persistentModeCheckbox.checked = !this.persistentModeCheckbox.checked;
        this.updateToggleSwitch();
        this.handlePersistentModeToggle();
      });
    }

    // Sort feature toggle with custom switch
    if (this.sortToggleSwitchContainer && this.sortFeatureCheckbox) {
      this.sortToggleSwitchContainer.addEventListener('click', () => {
        this.sortFeatureCheckbox.checked = !this.sortFeatureCheckbox.checked;
        this.updateSortToggleSwitch();
        this.handleSortFeatureToggle();
      });
    }

    // Cart feature toggle with custom switch
    if (this.cartToggleSwitchContainer && this.cartFeatureCheckbox) {
      this.cartToggleSwitchContainer.addEventListener('click', () => {
        this.cartFeatureCheckbox.checked = !this.cartFeatureCheckbox.checked;
        this.updateCartToggleSwitch();
        this.handleCartFeatureToggle();
      });
    }

    // Delay settings event listeners
    const globalDelayRange = document.getElementById('globalDelayRange');
    const globalDelayValue = document.getElementById('globalDelayValue');
    const networkStabilityCheckbox = document.getElementById('networkStabilityCheck');
    const networkStabilityToggleContainer = document.getElementById('networkStabilityToggleContainer');

    if (globalDelayRange && globalDelayValue) {
      globalDelayRange.value = this.globalDelay;
      globalDelayValue.textContent = this.globalDelay;

      globalDelayRange.addEventListener('input', () => {
        const value = parseInt(globalDelayRange.value);
        globalDelayValue.textContent = value;
        this.handleDelayChange(value);
      });
    }

    if (networkStabilityCheckbox && networkStabilityToggleContainer) {
      networkStabilityCheckbox.checked = this.networkStabilityCheck;

      networkStabilityToggleContainer.addEventListener('click', () => {
        networkStabilityCheckbox.checked = !networkStabilityCheckbox.checked;
        this.updateNetworkStabilityToggleSwitch();
        this.handleNetworkStabilityToggle();
      });
    }

    // Update toggle switch appearance initially
    this.updateToggleSwitch();
    this.updateSortToggleSwitch();
    this.updateCartToggleSwitch();
    this.updateNetworkStabilityToggleSwitch();

    // Setup watchlist event listeners
    this.setupWatchlistEventListeners();
  }

  updateToggleSwitch() {
    if (this.toggleSwitchContainer && this.persistentModeCheckbox) {
      if (this.persistentModeCheckbox.checked) {
        this.toggleSwitchContainer.classList.add('active');
      } else {
        this.toggleSwitchContainer.classList.remove('active');
      }
    }
  }

  updateUI() {
    if (this.isActive) {
      this.statusElement.innerHTML = '<span>وضعیت: فعال</span><div class="status-icon">🟢</div>';
      this.statusElement.className = 'status active';

      // Update main toggle button
      if (this.toggleMainBtn) {
        this.toggleMainBtn.textContent = 'غیرفعال‌سازی کامل';
        this.toggleMainBtn.className = 'btn-danger';
      }
      if (this.updateMainBtn) this.updateMainBtn.style.display = 'inline-flex';

      // Legacy button updates removed - using only global Main buttons
    } else {
      // Inactive state - reset main button
      if (this.toggleMainBtn) {
        this.toggleMainBtn.textContent = 'فعال‌سازی';
        this.toggleMainBtn.className = 'btn-primary';
      }
      if (this.updateMainBtn) this.updateMainBtn.style.display = 'none';
    }
  }

  async handleToggle() {
    this.showLoading(true);
    this.hideError();

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'toggleStatus'
      });

      if (response && typeof response.active === 'boolean') {
        this.isActive = response.active;
        this.updateUI();

        if (this.isActive) {
          if (this.pageType === 'seller') {
            this.showSuccess('ویژگی‌های فروشنده فعال شد! قیمت‌های واقعی و کمترین قیمت ماهانه نمایش داده می‌شود.');
          } else if (this.pageType === 'product') {
            this.showSuccess('ویژگی‌های محصول فعال شد! کمترین قیمت ماهانه و مقایسه قیمت گزینه‌ها نمایش داده می‌شود.');
          } else if (this.pageType === 'cart') {
            this.showSuccess('ویژگی‌های سبد خرید فعال شد! کمترین قیمت ۳۰ روز برای هر محصول نمایش داده می‌شود.');
          } else if (this.pageType === 'order') {
            this.showSuccess('ویژگی‌های سفارش فعال شد! قیمت فعلی کمترین برای هر محصول نمایش داده می‌شود.');
          } else {
            this.showSuccess('کمترین قیمت ماهانه فعال شد! اطلاعات قیمت تاریخی نمایش داده می‌شود.');
          }
        } else {
          this.showSuccess('ویژگی‌ها غیرفعال شد و صفحه به حالت اصلی بازگردانده شد.');
        }
      } else {
        throw new Error('پاسخ نامعتبر از اسکریپت محتوا');
      }
    } catch (error) {
      console.error('Toggle error:', error);
      this.showError('خطا در تغییر وضعیت افزونه. لطفاً صفحه را تازه‌سازی کرده و دوباره تلاش کنید.');
    } finally {
      this.showLoading(false);
    }
  }


  // Add cart feature toggle switch methods
  updateCartToggleSwitch() {
    if (this.cartToggleSwitchContainer && this.cartFeatureCheckbox) {
      if (this.cartFeatureCheckbox.checked) {
        this.cartToggleSwitchContainer.classList.add('active');
      } else {
        this.cartToggleSwitchContainer.classList.remove('active');
      }
    }
  }

  async handleCartFeatureToggle() {
    this.showLoading(true);
    this.hideError();

    try {
      const enabled = this.cartFeatureCheckbox.checked;
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'toggleCartFeature',
        enabled: enabled
      });

      if (response && response.success) {
        this.cartFeatureEnabled = enabled;

        if (enabled) {
          this.showSuccess('ویژگی سبد خرید فعال شد! <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" style="vertical-align: middle; margin: 0 4px;"><path d="M7 18c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12L8.1 13h7.45c.75 0 1.41-.42 1.75-1.03L21.7 4H5.21l-.94-2H1zm16 16c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg> کمترین قیمت ۳۰ روز در سبد خرید نمایش داده می‌شود.');
        } else {
          this.showSuccess('ویژگی سبد خرید غیرفعال شد و اطلاعات قیمت از سبد حذف خواهد شد.');
        }
      } else {
        throw new Error('خطا در تنظیم ویژگی سبد خرید');
      }
    } catch (error) {
      console.error('Cart feature toggle error:', error);
      this.showError('خطا در تنظیم ویژگی سبد خرید. لطفاً دوباره تلاش کنید.');
      // Revert checkbox and switch state
      this.cartFeatureCheckbox.checked = this.cartFeatureEnabled;
      this.updateCartToggleSwitch();
    } finally {
      this.showLoading(false);
    }
  }

  async handleUpdate() {
    this.showLoading(true);
    this.hideError();

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'updatePrices'
      });

      if (response && response.success) {
        if (this.pageType === 'seller') {
          this.showSuccess('قیمت‌های فروشنده و اطلاعات ماهانه با موفقیت بروزرسانی شدند.');
        } else if (this.pageType === 'cart') {
          this.showSuccess('اطلاعات قیمت برای همه محصولات سبد خرید بروزرسانی شدند.');
        } else if (this.pageType === 'order') {
          this.showSuccess('قیمت‌های فعلی برای همه محصولات سفارش بروزرسانی شدند.');
        } else if (this.pageType === 'wishlist') {
          this.showSuccess('قیمت‌های محصولات لیست علاقه‌مندی‌ها بروزرسانی شدند.');
        } else if (this.pageType === 'product') {
          this.showSuccess('اطلاعات قیمت محصول بروزرسانی شد.');
        } else {
          this.showSuccess('کمترین قیمت‌های ماهانه برای همه محصولات بروزرسانی شدند.');
        }
      } else {
        throw new Error('بروزرسانی ناموفق');
      }
    } catch (error) {
      console.error('Update error:', error);
      this.showError('خطا در بروزرسانی اطلاعات. لطفاً اتصال اینترنت خود را بررسی کرده و دوباره تلاش کنید.');
    } finally {
      this.showLoading(false);
    }
  }




  async handleEmergencyStop() {
    this.showLoading(true);
    this.hideError();

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // Try multiple stop actions in sequence for comprehensive stopping
      const stopActions = ['emergencyStop', 'clearDisplay', 'toggleStatus'];
      let success = false;

      for (const action of stopActions) {
        try {
          const response = await chrome.tabs.sendMessage(tab.id, { action });
          if (response && response.success) {
            success = true;
            break;
          }
        } catch (actionError) {
          console.log(`Action ${action} failed, trying next...`);
        }
      }

      if (success) {
        this.isActive = false;
        this.updateUI();
        this.showSuccess('⏹️ پردازش فوراً متوقف شد و همه تغییرات حذف شدند.');
      } else {
        // Force local UI reset even if content script doesn't respond
        this.isActive = false;
        this.updateUI();
        this.showSuccess('⏹️ پردازش متوقف شد (فقط رابط کاربری).');
      }
    } catch (error) {
      console.error('Emergency stop error:', error);
      // Force local reset as last resort
      this.isActive = false;
      this.updateUI();
      this.showError('خطا در توقف فوری. رابط کاربری ریست شد، لطفاً صفحه را تازه‌سازی کنید.');
    } finally {
      this.showLoading(false);
    }
  }

  async handleClearDisplay() {
    this.showLoading(true);
    this.hideError();

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // Enhanced clear display with page type detection
      let clearRequest = { action: 'clearDisplay' };

      // Add page type for targeted clearing
      if (this.pageType === 'cart') {
        clearRequest.type = 'cart';
      } else if (this.pageType === 'seller') {
        clearRequest.type = 'seller';
      } else if (this.pageType === 'order') {
        clearRequest.type = 'cart'; // Orders use similar cleanup as cart
      } else if (['search', 'category', 'brand', 'offers', 'tags', 'product', 'listing', 'wishlist', 'homepage', 'fresh-homepage'].includes(this.pageType)) {
        clearRequest.type = 'monthly';
      }

      let anySuccess = false;

      try {
        // Primary comprehensive clear request
        const response = await chrome.tabs.sendMessage(tab.id, clearRequest);
        if (response && response.success) {
          anySuccess = true;
          console.log('✅ Enhanced clear display successful:', response.message);
        }
      } catch (error) {
        console.warn('⚠️ Enhanced clear failed, trying fallback methods...', error);

        // Fallback to individual clear actions
        const fallbackActions = ['clearDisplay', 'emergencyStop'];
        for (const action of fallbackActions) {
          try {
            const response = await chrome.tabs.sendMessage(tab.id, { action });
            if (response && response.success) {
              anySuccess = true;
              break;
            }
          } catch (actionError) {
            console.log(`Fallback action ${action} failed, continuing...`);
          }
        }
      }

      if (anySuccess) {
        this.isActive = false;
        this.updateUI();
        this.showSuccess('🧹 تمام نمایش‌ها پاک شد. تغییرات حذف شد ولی تنظیمات حفظ ماند.');
      } else {
        // Force UI reset even if content script doesn't respond
        this.isActive = false;
        this.updateUI();
        this.showSuccess('🧹 رابط کاربری پاک شد. صفحه را تازه‌سازی کنید.');
      }
    } catch (error) {
      console.error('Clear display error:', error);
      this.showError('خطا در پاک کردن نمایش. لطفاً دوباره تلاش کنید.');
    } finally {
      this.showLoading(false);
    }
  }

  async handleClearCache() {
    this.showLoading(true);
    this.hideError();

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      let contentCacheCleared = false;
      let backgroundCacheCleared = false;

      // Clear content script cache
      try {
        const contentResponse = await chrome.tabs.sendMessage(tab.id, {
          action: 'clearCache'
        });
        contentCacheCleared = contentResponse && contentResponse.success;
      } catch (contentError) {
        console.log('Content script cache clear failed (may be normal):', contentError);
      }

      // Clear background cache
      try {
        const backgroundResponse = await chrome.runtime.sendMessage({
          action: 'clearCache'
        });
        backgroundCacheCleared = backgroundResponse && backgroundResponse.success;
      } catch (backgroundError) {
        console.log('Background cache clear failed:', backgroundError);
      }

      if (contentCacheCleared || backgroundCacheCleared) {
        this.showSuccess('🗑️ کش داده‌ها پاک شد. محصولات در بروزرسانی بعدی دوباره پردازش می‌شوند.');
      } else {
        throw new Error('خطا در پاک کردن کش');
      }
    } catch (error) {
      console.error('Clear cache error:', error);
      this.showError('خطا در پاک کردن کش. لطفاً دوباره تلاش کنید.');
    } finally {
      this.showLoading(false);
    }
  }

  async handleResetAll() {
    this.showLoading(true);
    this.hideError();

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      const response = await chrome.tabs.sendMessage(tab.id, {
        action: 'clearAllData'
      });

      if (response && response.success) {
        // Reset all UI state
        this.isActive = false;
        this.persistentMode = false;
        this.sortFeatureEnabled = false;
        this.cartFeatureEnabled = false;

        // Reset checkboxes
        if (this.persistentModeCheckbox) {
          this.persistentModeCheckbox.checked = false;
        }
        if (this.sortFeatureCheckbox) {
          this.sortFeatureCheckbox.checked = false;
        }
        if (this.cartFeatureCheckbox) {
          this.cartFeatureCheckbox.checked = false;
        }

        // Clear watchlist data
        try {
          await chrome.storage.local.remove([
            'digikala_extension_watchlist',
            'globalDelay',
            'networkStabilityCheck'
          ]);
          console.log('✅ Watchlist and settings data cleared');
        } catch (storageError) {
          console.warn('⚠️ Error clearing storage data:', storageError);
        }

        // Update UI components
        this.updateToggleSwitch();
        this.updateSortToggleSwitch();
        this.updateCartToggleSwitch();
        this.updateUI();

        // Clear watchlist display if visible
        if (this.watchlistContainer) {
          this.watchlistContainer.innerHTML = '<p style="text-align: center; color: #666; padding: 20px;">لیست نظارت قیمت خالی است</p>';
        }

        this.showSuccess('<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" style="vertical-align: middle; margin-left: 4px;"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg> ریست کامل انجام شد! همه داده‌ها، تنظیمات، لیست نظارت و ویژگی‌ها پاک شدند.');
      } else {
        throw new Error('خطا در ریست کامل');
      }
    } catch (error) {
      console.error('Reset all error:', error);
      this.showError('خطا در ریست کامل. لطفاً صفحه را تازه‌سازی کنید.');
    } finally {
      this.showLoading(false);
    }
  }

  async handlePersistentModeToggle() {
    this.showLoading(true);
    this.hideError();

    try {
      const enabled = this.persistentModeCheckbox.checked;
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (!tab) {
        throw new Error('هیچ تب فعالی یافت نشد');
      }

      // Check if current tab is a page where content script should be loaded
      const isSupportedPage = tab.url && (
        tab.url.includes('/seller/') ||
        tab.url.includes('/product/') ||
        tab.url.includes('/search/') ||
        tab.url.includes('/cart/') ||
        tab.url.includes('/profile/favorites/') ||
        tab.url.includes('/item/') ||
        tab.url.includes('/shop/') ||
        tab.url.includes('/category/') ||
        tab.url.includes('/listing/')
      );

      if (isSupportedPage) {
        try {
          const response = await chrome.tabs.sendMessage(tab.id, {
            action: 'togglePersistentMode',
            enabled: enabled
          });

          if (response && response.success) {
            this.persistentMode = enabled;

            if (enabled) {
              this.isActive = true; // Auto-activate when persistent mode is enabled
              this.updateUI();
              this.showSuccess('حالت خودکار فعال شد! 🎉 از این پس در همه صفحات پشتیبانی شده، کمترین قیمت ماهانه به صورت خودکار نمایش داده می‌شود.');
            } else {
              this.isActive = false;
              this.updateUI();
              this.showSuccess('حالت خودکار غیرفعال شد. حالا باید برای هر صفحه به صورت دستی ویژگی‌ها را فعال کنید.');
            }
          } else {
            throw new Error('پاسخ نامعتبر از محتوا اسکریپت');
          }
        } catch (messageError) {
          // Handle content script communication errors (expected on pages without content script)
          console.log('Content script not available on current tab, using fallback storage:', messageError.message);

          // Still update the persistent mode setting even if current tab doesn't respond
          this.persistentMode = enabled;

          // Store the setting for future use
          await chrome.storage.local.set({
            'digikala_extension_persistent_mode': enabled
          });

          if (enabled) {
            this.showSuccess('حالت خودکار فعال شد! 🎉 تنظیم در تب‌های آینده اعمال می‌شود.');
          } else {
            this.showSuccess('حالت خودکار غیرفعال شد.');
          }
        }
      } else {
        // Not a supported page - just update the setting
        this.persistentMode = enabled;

        // Store the setting
        await chrome.storage.local.set({
          'digikala_extension_persistent_mode': enabled
        });

        const pageMessage = 'تنظیم ذخیره شد. در صفحات فروشگاهی به صورت خودکار فعال می‌شود.';

        if (enabled) {
          this.showSuccess('حالت خودکار فعال شد! 🎉 ' + pageMessage);
        } else {
          this.showSuccess('حالت خودکار غیرفعال شد. ' + pageMessage);
        }
      }
    } catch (error) {
      console.error('Persistent mode toggle error:', error);
      this.showError('خطا در تنظیم حالت خودکار: ' + error.message);
      // Revert checkbox and switch state
      this.persistentModeCheckbox.checked = this.persistentMode;
      this.updateToggleSwitch();
    } finally {
      this.showLoading(false);
    }
  }

  // Add these new methods to the PopupController class:

  async loadSortFeature() {
    try {
      const result = await chrome.storage.local.get(['sortFeatureEnabled']);
      this.sortFeatureEnabled = result.sortFeatureEnabled || false;
      console.log('🎯 Sort feature loaded:', this.sortFeatureEnabled);
    } catch (error) {
      console.error('❌ Error loading sort feature:', error);
      this.sortFeatureEnabled = false;
    }
  }

  updateSortToggleSwitch() {
    if (this.sortToggleSwitchContainer && this.sortFeatureCheckbox) {
      if (this.sortFeatureCheckbox.checked) {
        this.sortToggleSwitchContainer.classList.add('active');
      } else {
        this.sortToggleSwitchContainer.classList.remove('active');
      }
    }
  }

  async handleSortFeatureToggle() {
    this.showLoading(true);
    this.hideError();

    try {
      const enabled = this.sortFeatureCheckbox.checked;

      // Save to storage directly without requiring content script
      await chrome.storage.local.set({ sortFeatureEnabled: enabled });
      this.sortFeatureEnabled = enabled;

      // Try to notify content script if available
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab.url) {
          await chrome.tabs.sendMessage(tab.id, {
            action: 'toggleSortFeature',
            enabled: enabled
          });
        }
      } catch (error) {
        // Content script not available - that's okay, settings are saved
        console.log('Content script not available, but settings saved');
      }

      if (enabled) {
        this.showSuccess('گزینه "بیشترین تخفیف" فعال شد! 🎯 در صفحات فهرست محصولات در دسترس خواهد بود.');
      } else {
        this.showSuccess('گزینه "بیشترین تخفیف" غیرفعال شد و از فهرست مرتب‌سازی حذف خواهد شد.');
      }
    } catch (error) {
      console.error('Sort feature toggle error:', error);
      this.showError('خطا در تنظیم گزینه مرتب‌سازی. لطفاً دوباره تلاش کنید.');
      // Revert checkbox and switch state
      this.sortFeatureCheckbox.checked = this.sortFeatureEnabled;
      this.updateSortToggleSwitch();
    } finally {
      this.showLoading(false);
    }
  }

  showLoading(show) {
    if (show) {
      this.loadingElement.classList.add('show');
      this.disableAllButtons(true);
    } else {
      this.loadingElement.classList.remove('show');
      this.disableAllButtons(false);
    }
  }

  disableAllButtons(disable) {
    // Get all button elements dynamically - only existing Main buttons
    const allButtons = [
      'toggleMainBtn', 'updateMainBtn', 'emergencyStopMainBtn', 'clearDisplayMainBtn', 'clearCacheMainBtn', 'resetAllMainBtn'
    ].map(prop => this[prop]).filter(Boolean);

    allButtons.forEach(button => {
      button.disabled = disable;
    });

    // Handle checkboxes and toggle switches
    const checkboxes = [this.persistentModeCheckbox, this.sortFeatureCheckbox, this.cartFeatureCheckbox];
    const containers = [this.toggleSwitchContainer, this.sortToggleSwitchContainer, this.cartToggleSwitchContainer];

    checkboxes.forEach(checkbox => {
      if (checkbox) checkbox.disabled = disable;
    });

    containers.forEach(container => {
      if (container) {
        container.style.pointerEvents = disable ? 'none' : 'auto';
        container.style.opacity = disable ? '0.5' : '1';
      }
    });
  }


  async handleShowWelcomeGuide() {
    try {
      // Send message to content script to show welcome guide
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        await chrome.tabs.sendMessage(tabs[0].id, {
          action: 'showWelcomeGuide'
        });

        // Show success message
        this.showSuccess('راهنمای مقدماتی در صفحه نمایش داده شد');

        // Close popup after a short delay
        setTimeout(() => {
          window.close();
        }, 1500);
      }
    } catch (error) {
      console.error('❌ Error showing welcome guide:', error);
      this.showError('خطا در نمایش راهنمای مقدماتی');
    }
  }

  showError(message) {
    // Add to system messages
    this.addSystemMessage('error', message);

    // Show in legacy error element for backwards compatibility
    if (this.errorElement) {
      this.errorElement.innerHTML = `<strong>⚠️ خطا:</strong> ${message}`;
      this.errorElement.style.display = 'block';
      setTimeout(() => this.hideError(), 8000);
    }
  }

  hideError() {
    if (this.errorElement) {
      this.errorElement.style.display = 'none';
    }
  }

  showSuccess(message) {
    // Add to system messages
    this.addSystemMessage('success', message);

    // Temporarily show success message in the status
    const originalHTML = this.statusElement?.innerHTML;
    const originalClass = this.statusElement?.className;

    if (this.statusElement) {
      this.statusElement.innerHTML = `<span>${message}</span><div class="status-icon">✅</div>`;
      this.statusElement.className = 'status active';

      setTimeout(() => {
        this.statusElement.innerHTML = originalHTML;
        this.statusElement.className = originalClass;
      }, 3000);
    }
  }

  // Handle delay settings changes
  async handleDelayChange(value) {
    try {
      await chrome.storage.local.set({ globalDelay: value });
      this.globalDelay = value;
      console.log('⏳ Global delay updated:', value);
    } catch (error) {
      console.error('❌ Error updating global delay:', error);
    }
  }

  async handleNetworkStabilityToggle() {
    try {
      const enabled = document.getElementById('networkStabilityCheck').checked;
      await chrome.storage.local.set({ networkStabilityCheck: enabled });
      this.networkStabilityCheck = enabled;
      console.log('🌐 Network stability check updated:', enabled);
    } catch (error) {
      console.error('❌ Error updating network stability setting:', error);
    }
  }

  updateNetworkStabilityToggleSwitch() {
    const container = document.getElementById('networkStabilityToggleContainer');
    const checkbox = document.getElementById('networkStabilityCheck');

    if (container && checkbox) {
      if (checkbox.checked) {
        container.classList.add('active');
      } else {
        container.classList.remove('active');
      }
    }
  }

  // Setup watchlist-specific event listeners
  setupWatchlistEventListeners() {
    // Watchlist management event listeners
    if (this.openFullPageBtn) {
      this.openFullPageBtn.addEventListener('click', () => this.openFullPageMode());
    }

    if (this.testNotificationBtn) {
      this.testNotificationBtn.addEventListener('click', () => this.handleTestNotification());
    }

    if (this.showWatchlistBtn) {
      this.showWatchlistBtn.addEventListener('click', () => this.showWatchlistModal());
    }

    if (this.refreshWatchlistBtn) {
      this.refreshWatchlistBtn.addEventListener('click', () => this.refreshWatchlist());
    }

    if (this.closeWatchlistModal) {
      this.closeWatchlistModal.addEventListener('click', () => this.hideWatchlistModal());
    }

    if (this.clearAllWatchlistBtn) {
      this.clearAllWatchlistBtn.addEventListener('click', () => this.clearAllWatchlistItems());
    }

    if (this.closeEditModal) {
      this.closeEditModal.addEventListener('click', () => this.hideEditModal());
    }

    if (this.cancelEditBtn) {
      this.cancelEditBtn.addEventListener('click', () => this.hideEditModal());
    }

    if (this.saveEditBtn) {
      this.saveEditBtn.addEventListener('click', () => this.saveWatchlistEdit());
    }

    // Close modals on overlay click
    if (this.watchlistModal) {
      this.watchlistModal.addEventListener('click', (e) => {
        if (e.target === this.watchlistModal) {
          this.hideWatchlistModal();
        }
      });
    }

    if (this.editWatchlistModal) {
      this.editWatchlistModal.addEventListener('click', (e) => {
        if (e.target === this.editWatchlistModal) {
          this.hideEditModal();
        }
      });
    }

    // Load and display watchlist count on init
    this.loadWatchlistSummary();

    // Add event delegation for watchlist action buttons
    this.setupWatchlistEventDelegation();

    // Setup tab event listeners if not already done in initTabs
    if (this.tabItems && !this.tabEventListenersSetup) {
      this.setupTabEventListeners();
      this.tabEventListenersSetup = true;
    }
  }

  setupWatchlistEventDelegation() {
    // Remove existing event delegation marker to ensure fresh setup
    if (this.watchlistItems) {
      this.watchlistItems.hasEventListener = false;
    }

    // Setup enhanced tooltip accessibility
    this.setupTooltipAccessibility();

    // Event delegation for dynamically generated watchlist buttons
    if (this.watchlistItems && !this.watchlistItems.hasEventListener) {
      const handleWatchlistClick = async (e) => {
        try {
          const target = e.target.closest('button');
          if (!target) return;

          const itemId = target.getAttribute('data-item-id');
          const productUrl = target.getAttribute('data-product-url');
          const isActive = target.getAttribute('data-active') === 'true';

          console.log('Watchlist button clicked:', {
            targetClass: target.className,
            itemId,
            productUrl,
            isActive
          });

          // Prevent default and stop propagation for all button clicks
          e.preventDefault();
          e.stopPropagation();

          if (target.classList.contains('watchlist-refresh-btn')) {
            const productId = target.getAttribute('data-product-id');
            if (productId) {
              await this.forceCheckWatchlistItem(productId, target);
            }
          } else if (target.classList.contains('watchlist-edit-btn') && itemId) {
            await this.editWatchlistItem(itemId);
          } else if (target.classList.contains('watchlist-toggle-btn') && itemId) {
            await this.toggleWatchlistItem(itemId);
          } else if (target.classList.contains('watchlist-remove-btn') && itemId) {
            await this.removeWatchlistItem(itemId);
          } else if (target.classList.contains('watchlist-view-btn') && productUrl) {
            window.open(productUrl, '_blank');
          } else {
            console.warn('Unknown watchlist button type or missing required attributes:', {
              classes: target.className,
              itemId,
              productUrl
            });
          }
        } catch (error) {
          console.error('Error handling watchlist button click:', error);
          this.showError('خطا در پردازش درخواست: ' + error.message);
        }
      };

      // Keyboard event handler for accessibility
      const handleWatchlistKeydown = async (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          await handleWatchlistClick(e);
        }
      };

      // Remove any existing event listeners first
      this.watchlistItems.removeEventListener('click', this.watchlistClickHandler);
      this.watchlistItems.removeEventListener('keydown', this.watchlistKeydownHandler);

      // Add new event listeners and store references for later cleanup
      this.watchlistItems.addEventListener('click', handleWatchlistClick);
      this.watchlistItems.addEventListener('keydown', handleWatchlistKeydown);
      this.watchlistClickHandler = handleWatchlistClick;
      this.watchlistKeydownHandler = handleWatchlistKeydown;
      this.watchlistItems.hasEventListener = true;

      console.log('Enhanced watchlist event delegation with keyboard support set up successfully');
    }
  }

  // Enhanced tooltip accessibility for watchlist buttons
  setupTooltipAccessibility() {
    // Handle tooltip visibility for keyboard navigation
    document.addEventListener('focusin', (e) => {
      if (e.target.matches('.action-btn[title]')) {
        // Enhanced focus handling for tooltips
        e.target.setAttribute('data-tooltip-visible', 'true');
      }
    });

    document.addEventListener('focusout', (e) => {
      if (e.target.matches('.action-btn[title]')) {
        // Hide tooltip when focus is lost
        e.target.removeAttribute('data-tooltip-visible');
      }
    });

    // Handle Escape key to hide tooltips
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const focusedBtn = document.querySelector('.action-btn:focus[data-tooltip-visible]');
        if (focusedBtn) {
          focusedBtn.removeAttribute('data-tooltip-visible');
        }
      }
    });
  }

  // Watchlist management methods
  async loadWatchlistSummary() {
    try {
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];
      this.watchlistCache = watchlist;

      const activeCount = watchlist.filter(item => item.isActive).length;
      const totalCount = watchlist.length;

      if (this.showWatchlistBtn) {
        this.showWatchlistBtn.innerHTML = `<span>👁️</span> مشاهده لیست (${activeCount})`;
      }

      if (this.watchlistSummary) {
        if (totalCount > 0) {
          const lastCheck = Math.max(...watchlist.map(item => item.lastCheckedAt || 0));
          let lastCheckText = 'هرگز';
          
          if (lastCheck > 0) {
            const lastCheckDate = new Date(lastCheck);
            const now = new Date();
            const diffInHours = (now - lastCheckDate) / (1000 * 60 * 60);
            
            if (diffInHours < 1) {
              const minutes = Math.round(diffInHours * 60);
              lastCheckText = `${minutes} دقیقه پیش`;
            } else if (diffInHours < 24) {
              lastCheckText = `${Math.round(diffInHours)} ساعت پیش`;
            } else {
              const days = Math.round(diffInHours / 24);
              lastCheckText = `${days} روز پیش`;
            }
          }

          // Update individual elements
          if (this.totalItemsCount) {
            this.totalItemsCount.textContent = totalCount.toLocaleString('fa-IR');
          }
          if (this.activeItemsCount) {
            this.activeItemsCount.textContent = activeCount.toLocaleString('fa-IR');
          }
          if (this.lastUpdateText) {
            this.lastUpdateText.textContent = lastCheckText;
          }
          
          this.watchlistSummary.style.display = 'block';
        } else {
          this.watchlistSummary.style.display = 'none';
        }
      }
    } catch (error) {
      console.error('Error loading watchlist summary:', error);
    }
  }

  // Open full-page UI mode in a new tab
  async openFullPageMode() {
    try {
      // Get the extension's URL for the full-page UI
      const fullPageUrl = chrome.runtime.getURL('src/ui/fullpage/fullpage.html');

      // Create a new tab with the full-page UI
      await chrome.tabs.create({
        url: fullPageUrl,
        active: true
      });

      // Close the popup window
      window.close();
    } catch (error) {
      console.error('Failed to open full-page mode:', error);
      this.showError('خطا در باز کردن نمای تمام‌صفحه');
    }
  }

  async handleTestNotification() {
    try {
      this.showLoading(true);
      console.log('Testing notification functionality...');

      // Send message to background script to handle notification
      const response = await chrome.runtime.sendMessage({
        action: 'testNotification'
      });

      console.log('Test notification response:', response);

      if (response && response.success) {
        this.showSuccess('اطلاع‌رسانی تست با موفقیت ارسال شد! ✅ لطفاً پنجره مرورگر را بررسی کنید.');
      } else {
        throw new Error(response?.error || 'Failed to send test notification');
      }
    } catch (error) {
      console.error('Test notification error:', error);

      // Try direct notification as fallback for older versions
      try {
        console.log('Trying fallback notification method...');

        if (chrome.notifications && chrome.notifications.create) {
          const notificationId = `test_fallback_${Date.now()}`;

          await new Promise((resolve, reject) => {
            chrome.notifications.create(notificationId, {
              type: 'basic',
              iconUrl: chrome.runtime.getURL('icons/active_128.png'),
              title: 'تست اطلاع‌رسانی پریزو 🎯',
              message: 'این یک پیام تست است (روش مستقیم). اطلاع‌رسانی‌های واقعی زمانی که شرایط قیمت برآورده شود ارسال خواهند شد.',
              requireInteraction: true
            }, (notificationId) => {
              if (chrome.runtime.lastError) {
                console.error('Direct notification error:', chrome.runtime.lastError);
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                console.log('Direct notification created successfully:', notificationId);
                resolve(notificationId);
              }
            });
          });

          this.showSuccess('اطلاع‌رسانی تست (روش مستقیم) ارسال شد! ✅');
        } else {
          throw new Error('Notifications API not available in any context');
        }
      } catch (fallbackError) {
        console.error('Fallback notification also failed:', fallbackError);
        this.showError(`خطا در ارسال اطلاع‌رسانی تست: ${error.message}. لطفاً اجازه اطلاع‌رسانی را در تنظیمات مرورگر فعال کنید و Extension را در حالت Developer mode اجرا کنید.`);
      }
    } finally {
      this.showLoading(false);
    }
  }

  async showWatchlistModal() {
    if (this.watchlistModal) {
      this.watchlistModal.style.display = 'flex';
      await this.loadWatchlistItems();
    }
  }

  hideWatchlistModal() {
    if (this.watchlistModal) {
      this.watchlistModal.style.display = 'none';
    }
  }

  showEditModal() {
    if (this.editWatchlistModal) {
      this.editWatchlistModal.style.display = 'flex';
    }
  }

  hideEditModal() {
    if (this.editWatchlistModal) {
      this.editWatchlistModal.style.display = 'none';
    }
    this.currentEditingEntry = null;
  }

  async loadWatchlistItems() {
    try {
      console.log('Loading watchlist items...');

      // Show loading state
      if (this.watchlistLoading) {
        this.watchlistLoading.style.display = 'flex';
      }
      if (this.watchlistEmpty) {
        this.watchlistEmpty.style.display = 'none';
      }
      if (this.watchlistItems) {
        this.watchlistItems.style.display = 'none';
      }

      // Load watchlist from storage
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];
      this.watchlistCache = watchlist;

      console.log(`Loaded ${watchlist.length} watchlist items from storage`);

      // Hide loading state
      if (this.watchlistLoading) {
        this.watchlistLoading.style.display = 'none';
      }

      if (watchlist.length === 0) {
        // Show empty state
        console.log('Showing empty state - no watchlist items');
        if (this.watchlistEmpty) {
          this.watchlistEmpty.style.display = 'flex';
        }
      } else {
        // Show watchlist items
        console.log('Rendering watchlist items');
        if (this.watchlistItems) {
          this.watchlistItems.style.display = 'block';
          this.renderWatchlistItems(watchlist);

          // Re-setup event delegation after rendering new content
          // Use setTimeout to ensure DOM is fully rendered
          setTimeout(() => {
            this.setupWatchlistEventDelegation();
          }, 0);
        }
      }
    } catch (error) {
      console.error('Error loading watchlist items:', error);
      if (this.watchlistLoading) {
        this.watchlistLoading.style.display = 'none';
      }
      this.showError('خطا در بارگذاری لیست نظارت: ' + error.message);
    }
  }

  renderWatchlistItems(watchlist) {
    if (!this.watchlistItems) return;

    this.watchlistItems.innerHTML = watchlist.map(item => {
      const conditions = this.formatConditions(item.conditions, item.checkInterval);
      const lastChecked = item.lastCheckedAt ?
        new Date(item.lastCheckedAt).toLocaleDateString('fa-IR', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }) : 'هرگز';

      const lastKnownPrice = item.lastKnownPrice ?
        `${Math.round(item.lastKnownPrice / 10).toLocaleString('fa-IR')} تومان` : 'نامشخص';

      return `
        <div class="watchlist-item ${item.isActive ? '' : 'disabled'}">
          <div class="watchlist-header">
            <div class="watchlist-product-info">
              <h4 class="watchlist-title">${item.productTitle}</h4>
              <div class="watchlist-conditions">${conditions}</div>
            </div>
            <div class="watchlist-product-image">
              ${item.productImage ? `
                <img src="${this.resizeDigikalaImage(item.productImage, 100, 100)}" alt="${item.productTitle}" class="product-image" />
                <div class="image-fallback" style="display: none;">
                  <span>📦</span>
                </div>
              ` : `
                <div class="image-fallback">
                  <span>📦</span>
                </div>
              `}
            </div>
          </div>
          
          <div class="watchlist-status">
            <div class="status-indicator ${item.isActive ? '' : 'inactive'}"></div>
            <div class="status-info">
              <div class="status-line">آخرین بررسی: ${lastChecked}</div>
              <div class="status-line price-info">آخرین قیمت: ${lastKnownPrice}</div>
            </div>
          </div>
          
          <div class="watchlist-actions">
            <button class="action-btn watchlist-refresh-btn" 
                    data-product-id="${item.productId}"
                    title="بررسی مجدد" 
                    aria-label="بررسی مجدد قیمت محصول ${item.productTitle}"
                    tabindex="0"
                    role="button">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21.5 2v6h-6"></path>
                <path d="M21.34 15.57a10 10 0 1 1-.57-8.38l-4.86 4.86"></path>
              </svg>
            </button>
            <button class="action-btn watchlist-edit-btn" 
                    data-item-id="${item.id}"
                    title="ویرایش شرایط نظارت" 
                    aria-label="ویرایش شرایط نظارت برای ${item.productTitle}"
                    tabindex="0"
                    role="button">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
            </button>
            <button class="action-btn toggle watchlist-toggle-btn ${item.isActive ? '' : 'disabled'}" 
                    data-item-id="${item.id}" 
                    data-active="${item.isActive}"
                    title="${item.isActive ? 'متوقف کردن نظارت' : 'فعال کردن نظارت'}" 
                    aria-label="${item.isActive ? 'متوقف کردن' : 'فعال کردن'} نظارت قیمت برای ${item.productTitle}"
                    tabindex="0"
                    role="button">
              ${item.isActive ? 
                `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="6" y="4" width="4" height="16"></rect>
                  <rect x="14" y="4" width="4" height="16"></rect>
                </svg>` : 
                `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <polygon points="5,3 19,12 5,21 5,3"></polygon>
                </svg>`
              }
            </button>
            <button class="action-btn danger watchlist-remove-btn" 
                    data-item-id="${item.id}"
                    title="حذف از لیست نظارت" 
                    aria-label="حذف ${item.productTitle} از لیست نظارت"
                    tabindex="0"
                    role="button">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="3,6 5,6 21,6"></polyline>
                <path d="m19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"></path>
                <line x1="10" y1="11" x2="10" y2="17"></line>
                <line x1="14" y1="11" x2="14" y2="17"></line>
              </svg>
            </button>
            ${item.productUrl ? `
            <button class="action-btn watchlist-view-btn" 
                    data-product-url="${item.productUrl}"
                    title="نمایش محصول" 
                    aria-label="نمایش محصول ${item.productTitle} در دیجی‌کالا"
                    tabindex="0"
                    role="button">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
              </svg>
            </button>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');

    // Add error handling for product images
    this.setupProductImageErrorHandling();
  }

  setupProductImageErrorHandling() {
    // Add error handlers for all product images
    const productImages = this.watchlistItems.querySelectorAll('.product-image');
    productImages.forEach(img => {
      img.addEventListener('error', () => {
        img.style.display = 'none';
        const fallback = img.nextElementSibling;
        if (fallback && fallback.classList.contains('image-fallback')) {
          fallback.style.display = 'flex';
        }
      });
    });
  }

  formatConditions(conditions, checkInterval) {
    const tags = [];

    if (conditions.priceThreshold) {
      const price = Math.round(conditions.priceThreshold / 10).toLocaleString('fa-IR');
      tags.push(`<span class="condition-tag price">قیمت ≤ ${price} تومان</span>`);
    }

    if (conditions.minDiscountPercent) {
      tags.push(`<span class="condition-tag discount">تخفیف ≥ ${conditions.minDiscountPercent}%</span>`);
    }

    if (conditions.notifyOnLowest30Days) {
      tags.push(`<span class="condition-tag monthly">نزدیک به کمترین قیمت ۳۰ روز</span>`);
    }

    // Add CheckInterval as a condition tag
    if (checkInterval) {
      const intervalText = this.formatCheckInterval(checkInterval);
      tags.push(`<span class="condition-tag interval">بررسی هر: ${intervalText}</span>`);
    }

    return tags.length > 0 ? tags.join('') : '<span class="condition-tag">بدون شرط</span>';
  }

  formatCheckInterval(intervalMs) {
    // Default to 4 hours for backward compatibility
    const interval = intervalMs || (4 * 60 * 60 * 1000);

    const hours = Math.floor(interval / (60 * 60 * 1000));
    const minutes = Math.floor((interval % (60 * 60 * 1000)) / (60 * 1000));

    if (hours === 0) {
      return `${minutes} دقیقه`;
    } else if (minutes === 0) {
      return `${hours} ساعت`;
    } else {
      return `${hours} ساعت و ${minutes} دقیقه`;
    }
  }

  async editWatchlistItem(itemId) {
    if (!itemId) {
      console.error('No item ID provided for editing');
      this.showError('خطا: شناسه محصول معتبر نیست');
      return;
    }

    try {
      console.log(`Opening edit modal for watchlist item: ${itemId}`);

      const item = this.watchlistCache.find(entry => entry.id === itemId);
      if (!item) {
        throw new Error(`Watchlist entry with ID ${itemId} not found in cache`);
      }

      this.currentEditingEntry = item;

      // Populate form fields
      if (this.editProductTitle) {
        this.editProductTitle.textContent = item.productTitle;
      }

      if (this.editPriceThreshold) {
        this.editPriceThreshold.value = item.conditions.priceThreshold ?
          Math.round(item.conditions.priceThreshold / 10) : '';
      }

      if (this.editDiscountThreshold) {
        this.editDiscountThreshold.value = item.conditions.minDiscountPercent || '';
      }

      if (this.editNotifyLowest30Days) {
        this.editNotifyLowest30Days.checked = item.conditions.notifyOnLowest30Days || false;
      }

      if (this.editCheckInterval) {
        // Use item's check interval or default to 4 hours for backward compatibility
        this.editCheckInterval.value = item.checkInterval || (4 * 60 * 60 * 1000);
      }

      console.log(`Edit modal populated for item:`, {
        id: item.id,
        title: item.productTitle,
        conditions: item.conditions,
        checkInterval: item.checkInterval
      });

      this.showEditModal();
    } catch (error) {
      console.error('Error opening edit modal:', error);
      this.showError('خطا در باز کردن فرم ویرایش: ' + error.message);
    }
  }

  async saveWatchlistEdit() {
    if (!this.currentEditingEntry) {
      console.error('No entry selected for editing');
      this.showError('خطا: هیچ محصولی برای ویرایش انتخاب نشده');
      return;
    }

    try {
      this.showLoading(true);
      console.log(`Saving edit for watchlist entry: ${this.currentEditingEntry.id}`);

      // Get form values
      const priceThreshold = this.editPriceThreshold.value ?
        parseFloat(this.editPriceThreshold.value) * 10 : null;
      const discountThreshold = this.editDiscountThreshold.value ?
        parseFloat(this.editDiscountThreshold.value) : null;
      const notifyOnLowest30Days = this.editNotifyLowest30Days.checked;
      const checkInterval = parseInt(this.editCheckInterval.value);

      // Validation
      if (!priceThreshold && !discountThreshold && !notifyOnLowest30Days) {
        this.showError('لطفاً حداقل یک شرط برای نظارت قیمت تعیین کنید');
        return;
      }

      if (priceThreshold && priceThreshold < 0) {
        this.showError('آستانه قیمت نمی‌تواند منفی باشد');
        return;
      }

      if (discountThreshold && (discountThreshold < 0 || discountThreshold > 100)) {
        this.showError('درصد تخفیف باید بین ۰ تا ۱۰۰ باشد');
        return;
      }

      // Validate check interval
      if (!checkInterval || checkInterval < 1800000 || checkInterval > 86400000) {
        this.showError('فاصله زمانی بررسی باید بین ۳۰ دقیقه تا ۲۴ ساعت باشد');
        return;
      }

      // Update the entry
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      let watchlist = result['digikala_extension_watchlist'] || [];

      const entryIndex = watchlist.findIndex(entry => entry.id === this.currentEditingEntry.id);
      if (entryIndex !== -1) {
        const oldConditions = { ...watchlist[entryIndex].conditions };
        const oldCheckInterval = watchlist[entryIndex].checkInterval;
        watchlist[entryIndex].conditions = {
          priceThreshold,
          minDiscountPercent: discountThreshold,
          notifyOnLowest30Days
        };
        watchlist[entryIndex].checkInterval = checkInterval;

        await chrome.storage.local.set({ 'digikala_extension_watchlist': watchlist });

        console.log(`Successfully updated watchlist entry ${this.currentEditingEntry.id}:`, {
          oldConditions,
          newConditions: watchlist[entryIndex].conditions,
          oldCheckInterval,
          newCheckInterval: checkInterval
        });

        this.hideEditModal();
        this.showSuccess('شرایط نظارت با موفقیت بروزرسانی شد');

        // Refresh the display
        await this.loadWatchlistItems();
        await this.loadWatchlistSummary();
      } else {
        throw new Error('Entry not found in watchlist');
      }
    } catch (error) {
      console.error('Error saving watchlist edit:', error);
      this.showError('خطا در ذخیره تغییرات: ' + error.message);
    } finally {
      this.showLoading(false);
    }
  }

  async toggleWatchlistItem(itemId) {
    if (!itemId) {
      console.error('No item ID provided for toggle');
      this.showError('خطا: شناسه محصول معتبر نیست');
      return;
    }

    try {
      this.showLoading(true);
      console.log(`Toggling watchlist item: ${itemId}`);

      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      let watchlist = result['digikala_extension_watchlist'] || [];

      const entryIndex = watchlist.findIndex(entry => entry.id === itemId);
      if (entryIndex !== -1) {
        const wasActive = watchlist[entryIndex].isActive;
        watchlist[entryIndex].isActive = !wasActive;

        await chrome.storage.local.set({ 'digikala_extension_watchlist': watchlist });

        const status = watchlist[entryIndex].isActive ? 'فعال' : 'متوقف';
        console.log(`Successfully toggled watchlist item ${itemId}: ${wasActive} → ${watchlist[entryIndex].isActive}`);

        this.showSuccess(`نظارت قیمت ${status} شد`);

        // Refresh the display
        await this.loadWatchlistItems();
        await this.loadWatchlistSummary();
      } else {
        throw new Error(`Watchlist entry with ID ${itemId} not found`);
      }
    } catch (error) {
      console.error('Error toggling watchlist item:', error);
      this.showError('خطا در تغییر وضعیت نظارت: ' + error.message);
    } finally {
      this.showLoading(false);
    }
  }

  async removeWatchlistItem(itemId) {
    if (!itemId) {
      console.error('No item ID provided for removal');
      this.showError('خطا: شناسه محصول معتبر نیست');
      return;
    }

    // Use custom confirmation dialog
    const confirmed = await this.showCustomConfirm('آیا از حذف این محصول از لیست نظارت اطمینان دارید؟');
    if (!confirmed) {
      return;
    }

    try {
      this.showLoading(true);
      console.log(`Removing watchlist item: ${itemId}`);

      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      let watchlist = result['digikala_extension_watchlist'] || [];

      const originalLength = watchlist.length;
      const itemToRemove = watchlist.find(entry => entry.id === itemId);

      if (!itemToRemove) {
        throw new Error(`Watchlist entry with ID ${itemId} not found`);
      }

      watchlist = watchlist.filter(entry => entry.id !== itemId);

      if (watchlist.length === originalLength) {
        throw new Error('Failed to remove item from watchlist');
      }

      await chrome.storage.local.set({ 'digikala_extension_watchlist': watchlist });

      console.log(`Successfully removed watchlist item ${itemId}:`, itemToRemove.productTitle);
      this.showSuccess('محصول از لیست نظارت حذف شد');

      // Refresh the display
      await this.loadWatchlistItems();
      await this.loadWatchlistSummary();
    } catch (error) {
      console.error('Error removing watchlist item:', error);
      this.showError('خطا در حذف محصول از لیست نظارت: ' + error.message);
    } finally {
      this.showLoading(false);
    }
  }

  async refreshWatchlist() {
    const refreshBtn = this.refreshWatchlistBtn;
    const originalContent = refreshBtn ? refreshBtn.innerHTML : '';
    const originalDisabled = refreshBtn ? refreshBtn.disabled : false;

    try {
      console.log('🔄 Starting watchlist refresh...');
      
      // Disable refresh button and show spinner
      if (refreshBtn) {
        refreshBtn.disabled = true;
        refreshBtn.innerHTML = '<span class="animate-spin">⟲</span>';
        refreshBtn.classList.add('loading');
      }
      
      // Load current watchlist
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result['digikala_extension_watchlist'] || [];
      
      if (watchlist.length === 0) {
        await this.loadWatchlistSummary();
        if (this.watchlistModal.style.display !== 'none') {
          await this.loadWatchlistItems();
        }
        this.showSuccess('لیست نظارت خالی است');
        return;
      }

      // Show progress
      const activeItems = watchlist.filter(item => item.isActive);
      if (activeItems.length === 0) {
        await this.loadWatchlistSummary();
        if (this.watchlistModal.style.display !== 'none') {
          await this.loadWatchlistItems();
        }
        this.showSuccess('هیچ محصول فعالی در لیست نظارت وجود ندارد');
        return;
      }
      
      this.showSuccess(`در حال بروزرسانی ${activeItems.length} محصول فعال...`);
      
      // Force check all active items
      let successCount = 0;
      let errorCount = 0;
      
      for (const item of activeItems) {
        try {
          console.log(`🔍 Force checking product: ${item.productTitle}`);
          
          const response = await chrome.runtime.sendMessage({
            type: 'WATCH_FORCE_CHECK',
            productId: item.productId
          });

          if (response.ok) {
            successCount++;
            console.log(`✅ Updated ${item.productTitle}: ${response.lastKnownPrice} Rials`);
          } else {
            errorCount++;
            console.warn(`⚠️ Failed to update ${item.productTitle}: ${response.error}`);
          }
        } catch (error) {
          errorCount++;
          console.error(`❌ Error checking ${item.productTitle}:`, error);
        }
        
        // Small delay to prevent overwhelming the server
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      
      // Refresh UI with updated data
      await this.loadWatchlistSummary();
      if (this.watchlistModal.style.display !== 'none') {
        await this.loadWatchlistItems();
      }
      
      // Show results
      if (errorCount === 0) {
        this.showSuccess(`✅ همه ${successCount} محصول با موفقیت بروزرسانی شدند`);
      } else if (successCount > 0) {
        this.showSuccess(`✅ ${successCount} محصول بروزرسانی شد، ${errorCount} محصول دچار خطا شد`);
      } else {
        this.showError(`❌ خطا در بروزرسانی تمام محصولات (${errorCount} خطا)`);
      }
      
      console.log(`🔄 Watchlist refresh completed: ${successCount} success, ${errorCount} errors`);
      
    } catch (error) {
      console.error('❌ Error refreshing watchlist:', error);
      this.showError('خطا در بروزرسانی لیست نظارت: ' + error.message);
      
      // Still refresh the UI display
      try {
        await this.loadWatchlistSummary();
        if (this.watchlistModal.style.display !== 'none') {
          await this.loadWatchlistItems();
        }
      } catch (uiError) {
        console.error('❌ Error refreshing UI after failure:', uiError);
      }
    } finally {
      // Restore refresh button state
      if (refreshBtn) {
        refreshBtn.disabled = originalDisabled;
        refreshBtn.innerHTML = originalContent;
        refreshBtn.classList.remove('loading');
      }
    }
  }

  async clearAllWatchlistItems() {
    try {
      const result = await chrome.storage.local.get(['digikala_extension_watchlist']);
      const watchlist = result.digikala_extension_watchlist || [];

      if (watchlist.length === 0) {
        this.showError('هیچ محصولی در لیست نظارت موجود نیست');
        return;
      }

      // Show custom confirmation dialog
      const confirmed = await this.showCustomConfirm(`آیا مطمئن هستید که می‌خواهید همه ${watchlist.length} محصول را از لیست نظارت حذف کنید؟`);
      if (!confirmed) {
        return;
      }

      this.showLoading(true);
      console.log(`🗑️ Clearing all watchlist items (${watchlist.length} items)`);

      // Clear the watchlist
      await chrome.storage.local.set({
        'digikala_extension_watchlist': []
      });

      // Refresh UI elements
      await this.loadWatchlistItems();
      await this.loadWatchlistSummary();

      this.showSuccess(`همه ${watchlist.length} محصول از لیست نظارت حذف شدند`);
      console.log('✅ All watchlist items cleared successfully');

    } catch (error) {
      console.error('Error clearing all watchlist items:', error);
      this.showError('خطا در پاک کردن لیست نظارت: ' + error.message);
    } finally {
      this.showLoading(false);
    }
  }

  async forceCheckWatchlistItem(productId, buttonElement) {
    if (!buttonElement) return;

    // Store original state before try block
    const originalContent = buttonElement.innerHTML;
    const originalDisabled = buttonElement.disabled;

    try {
      // Disable button and show spinner

      buttonElement.disabled = true;
      buttonElement.innerHTML = '<span class="spinner"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" class="animate-spin"><path d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/></svg></span>';
      buttonElement.classList.add('loading');

      // Send force check request to background
      const response = await chrome.runtime.sendMessage({
        type: 'WATCH_FORCE_CHECK',
        productId: productId
      });

      if (response.ok) {
        // Success - update the UI with new data
        this.showSuccess('قیمت محصول با موفقیت بروزرسانی شد');

        // Update the item's display with new price and timestamp
        await this.updateWatchlistItemDisplay(productId, response.lastKnownPrice, response.lastCheckedAt);

        // Log successful update
        console.log(`✅ Force check completed for product ${productId}:`, {
          price: response.lastKnownPrice,
          checked: new Date(response.lastCheckedAt)
        });
      } else {
        // Handle different error cases
        if (response.error === 'throttled') {
          const retryAfter = response.retryAfter || 60;
          this.showError(`لطفاً ${retryAfter} ثانیه صبر کنید و دوباره تلاش کنید`);
        } else if (response.error && response.error.includes('ساختار قیمت')) {
          // Price extraction failed - more user-friendly message
          this.showError('محصول در حال حاضر موجود نیست یا قیمت آن قابل دسترسی نمی‌باشد');
          console.warn(`⚠️ Price extraction failed for product ${productId}:`, response.debugInfo);
        } else {
          this.showError('خطا در بررسی قیمت: ' + (response.error || 'خطای نامشخص'));
        }

        console.warn(`⚠️ Force check failed for product ${productId}:`, response.error);
      }

    } catch (error) {
      console.error('Error in force check:', error);
      this.showError('خطا در ارتباط با سرویس: ' + error.message);
    } finally {
      // Re-enable button and restore original content
      if (buttonElement) {
        buttonElement.disabled = originalDisabled;
        buttonElement.innerHTML = originalContent;
        buttonElement.classList.remove('loading');
      }
    }
  }

  async updateWatchlistItemDisplay(productId, lastKnownPrice, lastCheckedAt) {
    try {
      // Find the watchlist item in the DOM by productId
      const watchlistItem = document.querySelector(`[data-product-id="${productId}"]`)?.closest('.watchlist-item');
      if (!watchlistItem) return;

      // Update the status info section
      const statusInfo = watchlistItem.querySelector('.status-info');
      if (statusInfo) {
        const lastChecked = new Date(lastCheckedAt).toLocaleDateString('fa-IR', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });

        const formattedPrice = lastKnownPrice ?
          `${Math.round(lastKnownPrice / 10).toLocaleString('fa-IR')} تومان` : 'نامشخص';

        statusInfo.innerHTML = `
          <span>آخرین بررسی: ${lastChecked}</span>
          <span class="price-info">آخرین قیمت: ${formattedPrice}</span>
        `;
      }

      // Add a brief highlight animation to show the update
      watchlistItem.style.transition = 'background-color 0.3s ease';
      watchlistItem.style.backgroundColor = '#f0f9ff';

      setTimeout(() => {
        watchlistItem.style.backgroundColor = '';
      }, 1000);

    } catch (error) {
      console.error('Error updating watchlist item display:', error);
    }
  }

  // Comparison Feature Management Methods

  async loadComparisonFeature() {
    try {
      const result = await chrome.storage.local.get(['digikala_extension_comparison_feature_enabled']);
      this.comparisonFeatureEnabled = result.digikala_extension_comparison_feature_enabled !== undefined 
        ? result.digikala_extension_comparison_feature_enabled 
        : true; // Default to enabled

      if (this.comparisonFeatureCheckbox) {
        this.comparisonFeatureCheckbox.checked = this.comparisonFeatureEnabled;
      }
      
      this.updateComparisonToggleSwitch();
      this.updateComparisonManagementVisibility();
      
      console.log('📂 Comparison feature loaded:', this.comparisonFeatureEnabled);
    } catch (error) {
      console.error('Error loading comparison feature:', error);
      this.comparisonFeatureEnabled = true; // Default to enabled on error
      this.updateComparisonToggleSwitch();
      this.updateComparisonManagementVisibility();
    }
  }

  updateComparisonToggleSwitch() {
    const container = this.comparisonToggleSwitchContainer;
    const checkbox = this.comparisonFeatureCheckbox;
    
    if (container && checkbox) {
      if (checkbox.checked) {
        container.classList.add('active');
      } else {
        container.classList.remove('active');
      }
    }
  }

  updateComparisonManagementVisibility() {
    if (this.comparisonSitesManagement) {
      if (this.comparisonFeatureEnabled) {
        this.comparisonSitesManagement.style.display = 'block';
      } else {
        this.comparisonSitesManagement.style.display = 'none';
      }
    }
  }

  async handleComparisonFeatureToggle() {
    try {
      this.comparisonFeatureEnabled = this.comparisonFeatureCheckbox.checked;
      this.updateComparisonToggleSwitch();
      this.updateComparisonManagementVisibility();

      // Save to storage
      await chrome.storage.local.set({
        'digikala_extension_comparison_feature_enabled': this.comparisonFeatureEnabled
      });

      const status = this.comparisonFeatureEnabled ? 'فعال' : 'غیرفعال';
      this.showSuccess(`مقایسه قیمت ${status} شد`);

      console.log('✅ Comparison feature toggled:', this.comparisonFeatureEnabled);
    } catch (error) {
      console.error('Error toggling comparison feature:', error);
      this.showError('خطا در تغییر وضعیت مقایسه قیمت');
    }
  }

  // Comparison Sites Management Methods

  async loadComparisonSites() {
    try {
      const result = await chrome.storage.local.get(['digikala_extension_comparison_sites']);
      this.comparisonSites = result.digikala_extension_comparison_sites || this.getDefaultComparisonSites();
      console.log(`📋 Loaded ${this.comparisonSites.length} comparison sites`);
      this.renderComparisonSites();
    } catch (error) {
      console.error('Error loading comparison sites:', error);
      this.comparisonSites = this.getDefaultComparisonSites();
      console.log(`📋 Using default comparison sites (${this.comparisonSites.length})`);
      this.renderComparisonSites();
    }
  }

  getDefaultComparisonSites() {
    return [
      {
        id: 'torob',
        name: 'Torob',
        url: 'https://torob.com/search/?query=PRODUCT_NAME',
        faviconUrl: 'https://torob.com/favicon.ico'
      }
    ];
  }

  // Get favicon URL for a website
  getFaviconUrl(url) {
    try {
      const domain = new URL(url.replace('PRODUCT_NAME', 'test')).origin;
      return `${domain}/favicon.ico`;
    } catch (error) {
      return null;
    }
  }

  // Alternative favicon services
  getFaviconUrlAlternatives(url) {
    try {
      const domain = new URL(url.replace('PRODUCT_NAME', 'test')).hostname;
      return [
        `https://${domain}/favicon.ico`,
        `https://www.google.com/s2/favicons?domain=${domain}&sz=16`,
        `https://favicons.githubusercontent.com/${domain}`,
        `https://icon.horse/icon/${domain}`
      ];
    } catch (error) {
      return [];
    }
  }

  updateFaviconPreview() {
    const url = this.siteUrlInput?.value.trim();
    
    if (!url || !this.siteIconPreview || !this.siteIconFallback || !this.siteIconStatus) {
      return;
    }

    // Reset to fallback first and clear working favicon URL
    this.siteIconPreview.style.display = 'none';
    this.siteIconFallback.style.display = 'inline-block';
    this.siteIconStatus.textContent = 'در حال بارگیری آیکون...';
    this.workingFaviconUrl = null;

    if (!url.includes('http')) {
      this.siteIconStatus.textContent = 'لطفاً URL کامل وارد کنید';
      return;
    }

    // Try to load favicon
    const faviconUrls = this.getFaviconUrlAlternatives(url);
    this.tryLoadFavicon(faviconUrls, 0);
  }

  tryLoadFavicon(urls, index) {
    if (index >= urls.length) {
      this.siteIconStatus.textContent = 'آیکون یافت نشد، از آیکون پیش‌فرض استفاده می‌شود';
      return;
    }

    const img = new Image();
    img.onload = () => {
      if (this.siteIconPreview && this.siteIconFallback && this.siteIconStatus) {
        this.siteIconPreview.src = urls[index];
        this.siteIconPreview.style.display = 'inline-block';
        this.siteIconFallback.style.display = 'none';
        this.siteIconStatus.textContent = 'آیکون سایت بارگیری شد ✅';
        // Save the working favicon URL for later use
        this.workingFaviconUrl = urls[index];
      }
    };
    
    img.onerror = () => {
      // Try next URL
      this.tryLoadFavicon(urls, index + 1);
    };
    
    // Set timeout for each attempt
    setTimeout(() => {
      if (!img.complete) {
        img.src = ''; // Cancel loading
        this.tryLoadFavicon(urls, index + 1);
      }
    }, 3000);
    
    img.src = urls[index];
  }

  resetFaviconPreview() {
    if (this.siteIconPreview) {
      this.siteIconPreview.style.display = 'none';
      this.siteIconPreview.src = '';
    }
    if (this.siteIconFallback) {
      this.siteIconFallback.style.display = 'inline-block';
    }
    if (this.siteIconStatus) {
      this.siteIconStatus.textContent = 'آیکون سایت به‌طور خودکار از URL دریافت می‌شود';
    }
    // Reset working favicon URL
    this.workingFaviconUrl = null;
  }

  renderComparisonSites() {
    if (!this.comparisonSitesList) return;

    if (this.comparisonSites.length === 0) {
      this.comparisonSitesList.innerHTML = `
        <div class="empty-comparison-sites">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M10.59 13.41c.41.39.41 1.03 0 1.42-.39.39-1.03.39-1.42 0a5.003 5.003 0 0 1 0-7.07l3.54-3.54a5.003 5.003 0 0 1 7.07 0 5.003 5.003 0 0 1 0 7.07l-1.49 1.49c.01-.82-.12-1.64-.4-2.42l.47-.48a2.982 2.982 0 0 0 0-4.24 2.982 2.982 0 0 0-4.24 0l-3.53 3.53a2.982 2.982 0 0 0 0 4.24zm2.82-4.24c.39-.39 1.03-.39 1.42 0a5.003 5.003 0 0 1 0 7.07l-3.54 3.54a5.003 5.003 0 0 1-7.07 0 5.003 5.003 0 0 1 0-7.07l1.49-1.49c-.01.82.12 1.64.4 2.42l-.47.48a2.982 2.982 0 0 0 0 4.24 2.982 2.982 0 0 0 4.24 0l3.53-3.53a2.982 2.982 0 0 0 0-4.24.973.973 0 0 1 0-1.42z"/>
          </svg>
          <div>هنوز سایتی برای مقایسه قیمت اضافه نشده است</div>
        </div>
      `;
      return;
    }

    // Clear existing content
    this.comparisonSitesList.innerHTML = '';

    // Create each site item with proper event listeners
    this.comparisonSites.forEach(site => {
      const siteItem = document.createElement('div');
      siteItem.className = 'comparison-site-item';
      siteItem.setAttribute('data-site-id', site.id);

      // Create favicon HTML
      const faviconHtml = site.faviconUrl 
        ? `<img src="${site.faviconUrl}" alt="${site.name}" style="width: 16px; height: 16px;" onerror="this.style.display='none'; this.nextElementSibling.style.display='inline-block';">
           <span style="font-size: 14px; display: none;"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M10.59 13.41c.41.39.41 1.03 0 1.42-.39.39-1.03.39-1.42 0a5.003 5.003 0 0 1 0-7.07l3.54-3.54a5.003 5.003 0 0 1 7.07 0 5.003 5.003 0 0 1 0 7.07l-1.49 1.49c.01-.82-.12-1.64-.4-2.42l.47-.48a2.982 2.982 0 0 0 0-4.24 2.982 2.982 0 0 0-4.24 0l-3.53 3.53a2.982 2.982 0 0 0 0 4.24zm2.82-4.24c.39-.39 1.03-.39 1.42 0a5.003 5.003 0 0 1 0 7.07l-3.54 3.54a5.003 5.003 0 0 1-7.07 0 5.003 5.003 0 0 1 0-7.07l1.49-1.49c-.01.82.12 1.64.4 2.42l-.47.48a2.982 2.982 0 0 0 0 4.24 2.982 2.982 0 0 0 4.24 0l3.53-3.53a2.982 2.982 0 0 0 0-4.24.973.973 0 0 1 0-1.42z"/></svg></span>`
        : `<span style="font-size: 14px;"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M10.59 13.41c.41.39.41 1.03 0 1.42-.39.39-1.03.39-1.42 0a5.003 5.003 0 0 1 0-7.07l3.54-3.54a5.003 5.003 0 0 1 7.07 0 5.003 5.003 0 0 1 0 7.07l-1.49 1.49c.01-.82-.12-1.64-.4-2.42l.47-.48a2.982 2.982 0 0 0 0-4.24 2.982 2.982 0 0 0-4.24 0l-3.53 3.53a2.982 2.982 0 0 0 0 4.24zm2.82-4.24c.39-.39 1.03-.39 1.42 0a5.003 5.003 0 0 1 0 7.07l-3.54 3.54a5.003 5.003 0 0 1-7.07 0 5.003 5.003 0 0 1 0-7.07l1.49-1.49c-.01.82.12 1.64.4 2.42l-.47.48a2.982 2.982 0 0 0 0 4.24 2.982 2.982 0 0 0 4.24 0l3.53-3.53a2.982 2.982 0 0 0 0-4.24.973.973 0 0 1 0-1.42z"/></svg></span>`;

      siteItem.innerHTML = `
        <div class="comparison-site-info">
          <div class="comparison-site-icon">${faviconHtml}</div>
          <div class="comparison-site-details">
            <div class="comparison-site-name">${site.name}</div>
            <div class="comparison-site-url" title="${site.url}">${site.url}</div>
          </div>
        </div>
        <div class="comparison-site-actions">
          <button class="comparison-site-action edit" title="ویرایش">
            ✏️
          </button>
          <button class="comparison-site-action delete" title="حذف">
            🗑️
          </button>
        </div>
      `;

      // Add event listeners to buttons
      const editBtn = siteItem.querySelector('.comparison-site-action.edit');
      const deleteBtn = siteItem.querySelector('.comparison-site-action.delete');

      if (editBtn) {
        editBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log(`🔧 Edit button clicked for site: ${site.name} (${site.id})`);
          this.editComparisonSite(site.id);
        });
      }

      if (deleteBtn) {
        deleteBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log(`🗑️ Delete button clicked for site: ${site.name} (${site.id})`);
          this.deleteComparisonSite(site.id);
        });
      }

      this.comparisonSitesList.appendChild(siteItem);
    });
  }

  handlePopularSiteSelection() {
    const selectedOption = this.popularSitesSelect.selectedOptions[0];
    if (selectedOption && selectedOption.value !== '') {
      const siteName = selectedOption.getAttribute('data-name');
      const siteUrl = selectedOption.getAttribute('data-url');
      
      // Populate the form fields
      this.siteNameInput.value = siteName;
      this.siteUrlInput.value = siteUrl;
      
      // Update favicon preview
      this.updateFaviconPreview();
      
      // Reset dropdown to default
      this.popularSitesSelect.selectedIndex = 0;
    }
  }

  showAddSiteForm() {
    this.addSiteForm.style.display = 'block';
    this.addSiteBtn.style.display = 'none';
    this.resetFaviconPreview();
    this.siteNameInput.focus();
  }

  hideAddSiteForm() {
    this.addSiteForm.style.display = 'none';
    this.addSiteBtn.style.display = 'flex';
    this.siteNameInput.value = '';
    this.siteUrlInput.value = '';
    if (this.popularSitesSelect) {
      this.popularSitesSelect.selectedIndex = 0;
    }
    this.resetFaviconPreview();
    
    // Reset editing state
    this.editingSiteId = null;
    
    // Reset save button
    if (this.saveSiteBtn) {
      this.saveSiteBtn.textContent = 'ذخیره';
      
      // Remove old event listeners and add the original save listener
      this.saveSiteBtn.onclick = null;
      this.saveSiteBtn.replaceWith(this.saveSiteBtn.cloneNode(true));
      this.saveSiteBtn = document.getElementById('saveSiteBtn');
      
      if (this.saveSiteBtn) {
        this.saveSiteBtn.addEventListener('click', () => this.handleSaveSite());
      }
    }
    
    console.log('📝 Form reset to add mode');
  }

  async handleSaveSite() {
    const name = this.siteNameInput.value.trim();
    const url = this.siteUrlInput.value.trim();

    if (!name || !url) {
      this.showError('لطفاً نام سایت و آدرس جستجو را وارد کنید');
      return;
    }

    if (!url.includes('PRODUCT_NAME')) {
      this.showError('آدرس جستجو باید شامل PRODUCT_NAME باشد');
      return;
    }

    try {
      // Validate URL format
      new URL(url.replace('PRODUCT_NAME', 'test'));
    } catch (error) {
      this.showError('آدرس وارد شده معتبر نیست');
      return;
    }

    try {
      // Use the working favicon URL from preview, or fallback to basic method
      const faviconUrl = this.workingFaviconUrl || this.getFaviconUrl(url);
      
      const newSite = {
        id: Date.now().toString(),
        name: name,
        url: url,
        faviconUrl: faviconUrl
      };

      this.comparisonSites.push(newSite);
      await chrome.storage.local.set({
        'digikala_extension_comparison_sites': this.comparisonSites
      });

      this.renderComparisonSites();
      this.hideAddSiteForm();
      this.showSuccess('سایت جدید با موفقیت اضافه شد');
    } catch (error) {
      console.error('Error saving comparison site:', error);
      this.showError('خطا در ذخیره سایت جدید');
    }
  }

  async deleteComparisonSite(siteId) {
    try {
      // Find the site to get its name for confirmation
      const site = this.comparisonSites.find(s => s.id === siteId);
      if (!site) {
        console.error('Site not found for deletion:', siteId);
        this.showError('سایت یافت نشد');
        return;
      }

      // Show custom confirmation dialog
      const confirmed = await this.showCustomConfirm(`آیا مطمئن هستید که می‌خواهید سایت "${site.name}" را حذف کنید؟`);
      if (!confirmed) {
        console.log('Site deletion cancelled by user');
        return;
      }

      console.log(`🗑️ Deleting site: ${site.name} (${siteId})`);
      
      // Remove the site from the array
      this.comparisonSites = this.comparisonSites.filter(s => s.id !== siteId);
      
      // Save to storage
      await chrome.storage.local.set({
        'digikala_extension_comparison_sites': this.comparisonSites
      });

      // Re-render the list
      this.renderComparisonSites();
      this.showSuccess(`سایت "${site.name}" حذف شد`);
      
      console.log('✅ Site deleted successfully');
    } catch (error) {
      console.error('Error deleting comparison site:', error);
      this.showError('خطا در حذف سایت');
    }
  }

  editComparisonSite(siteId) {
    console.log(`🔧 Starting edit for site ID: ${siteId}`);
    
    const site = this.comparisonSites.find(s => s.id === siteId);
    if (!site) {
      console.error('Site not found for editing:', siteId);
      this.showError('سایت یافت نشد');
      return;
    }

    console.log(`📝 Editing site: ${site.name}`);

    // Populate form with existing data
    if (this.siteNameInput) this.siteNameInput.value = site.name;
    if (this.siteUrlInput) this.siteUrlInput.value = site.url;
    
    // Show the form
    this.showAddSiteForm();
    
    // Update favicon preview after setting URL
    setTimeout(() => this.updateFaviconPreview(), 100);

    // Store editing state
    this.editingSiteId = siteId;

    // Change save button to update mode
    if (this.saveSiteBtn) {
      this.saveSiteBtn.textContent = 'بروزرسانی';
      
      // Remove old event listeners and add new one
      this.saveSiteBtn.onclick = null;
      this.saveSiteBtn.replaceWith(this.saveSiteBtn.cloneNode(true));
      this.saveSiteBtn = document.getElementById('saveSiteBtn');
      
      if (this.saveSiteBtn) {
        this.saveSiteBtn.addEventListener('click', () => this.handleUpdateSite());
      }
    }

    console.log('✅ Edit form populated and ready');
  }

  async handleUpdateSite() {
    const name = this.siteNameInput.value.trim();
    const url = this.siteUrlInput.value.trim();

    if (!name || !url) {
      this.showError('لطفاً نام سایت و آدرس جستجو را وارد کنید');
      return;
    }

    if (!url.includes('PRODUCT_NAME')) {
      this.showError('آدرس جستجو باید شامل PRODUCT_NAME باشد');
      return;
    }

    try {
      // Validate URL format
      new URL(url.replace('PRODUCT_NAME', 'test'));
    } catch (error) {
      this.showError('آدرس وارد شده معتبر نیست');
      return;
    }

    try {
      const siteIndex = this.comparisonSites.findIndex(s => s.id === this.editingSiteId);
      if (siteIndex !== -1) {
        this.comparisonSites[siteIndex].name = name;
        this.comparisonSites[siteIndex].url = url;
        this.comparisonSites[siteIndex].faviconUrl = this.getFaviconUrl(url);

        await chrome.storage.local.set({
          'digikala_extension_comparison_sites': this.comparisonSites
        });

        this.renderComparisonSites();
        this.hideAddSiteForm();
        this.showSuccess('سایت بروزرسانی شد');

        console.log('✅ Site updated successfully');
      }
    } catch (error) {
      console.error('Error updating comparison site:', error);
      this.showError('خطا در بروزرسانی سایت');
    }
  }

  // Custom confirmation dialog
  showCustomConfirm(message, onConfirm, onCancel = null) {
    return new Promise((resolve) => {
      // Create overlay
      const overlay = document.createElement('div');
      overlay.className = 'custom-confirm-overlay';
      overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        backdrop-filter: blur(2px);
      `;

      // Create dialog
      const dialog = document.createElement('div');
      dialog.className = 'custom-confirm-dialog';
      dialog.style.cssText = `
        background: white;
        border-radius: 12px;
        padding: 24px;
        min-width: 320px;
        max-width: 400px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        font-family: IRANSans, Tahoma, sans-serif;
        text-align: center;
        direction: rtl;
      `;

      // Create message
      const messageEl = document.createElement('p');
      messageEl.textContent = message;
      messageEl.style.cssText = `
        margin: 0 0 24px 0;
        font-size: 14px;
        line-height: 1.5;
        color: #374151;
      `;

      // Create buttons container
      const buttonsContainer = document.createElement('div');
      buttonsContainer.style.cssText = `
        display: flex;
        gap: 12px;
        justify-content: center;
      `;

      // Create confirm button
      const confirmBtn = document.createElement('button');
      confirmBtn.textContent = 'تأیید';
      confirmBtn.style.cssText = `
        background: #ef4444;
        color: white;
        border: none;
        border-radius: 8px;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        font-family: IRANSans, Tahoma, sans-serif;
        transition: all 0.2s ease;
      `;

      // Create cancel button
      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = 'انصراف';
      cancelBtn.style.cssText = `
        background: #f3f4f6;
        color: #374151;
        border: none;
        border-radius: 8px;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        font-family: IRANSans, Tahoma, sans-serif;
        transition: all 0.2s ease;
      `;

      // Add hover effects
      confirmBtn.addEventListener('mouseenter', () => {
        confirmBtn.style.background = '#dc2626';
      });
      confirmBtn.addEventListener('mouseleave', () => {
        confirmBtn.style.background = '#ef4444';
      });

      cancelBtn.addEventListener('mouseenter', () => {
        cancelBtn.style.background = '#e5e7eb';
      });
      cancelBtn.addEventListener('mouseleave', () => {
        cancelBtn.style.background = '#f3f4f6';
      });

      // Handle confirm
      confirmBtn.addEventListener('click', () => {
        document.body.removeChild(overlay);
        if (onConfirm) onConfirm();
        resolve(true);
      });

      // Handle cancel
      const handleCancel = () => {
        document.body.removeChild(overlay);
        if (onCancel) onCancel();
        resolve(false);
      };

      cancelBtn.addEventListener('click', handleCancel);
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) handleCancel();
      });

      // ESC key handler
      const handleEsc = (e) => {
        if (e.key === 'Escape') {
          document.removeEventListener('keydown', handleEsc);
          handleCancel();
        }
      };
      document.addEventListener('keydown', handleEsc);

      // Assemble dialog
      buttonsContainer.appendChild(cancelBtn);
      buttonsContainer.appendChild(confirmBtn);
      dialog.appendChild(messageEl);
      dialog.appendChild(buttonsContainer);
      overlay.appendChild(dialog);
      document.body.appendChild(overlay);

      // Focus confirm button
      confirmBtn.focus();
    });
  }

  /**
   * Resize Digikala image URL by modifying the URL parameters
   * @param {string} imageUrl - Original image URL
   * @param {number} width - Desired width
   * @param {number} height - Desired height
   * @returns {string} - Resized image URL
   */
  resizeDigikalaImage(imageUrl, width = 100, height = 100) {
    if (!imageUrl || typeof imageUrl !== 'string') {
      return imageUrl;
    }
    
    // Check if this is a Digikala image URL with size parameters
    if (imageUrl.includes('dkstatics-public.digikala.com') && imageUrl.includes('x-oss-process=image/resize')) {
      // Replace existing size parameters with new ones
      const resizedUrl = imageUrl.replace(
        /h_\d+,w_\d+/g,
        `h_${height},w_${width}`
      );
      return resizedUrl;
    }
    
    // If it doesn't have size parameters but is a Digikala image, add them
    if (imageUrl.includes('dkstatics-public.digikala.com')) {
      const separator = imageUrl.includes('?') ? '&' : '?';
      return `${imageUrl}${separator}x-oss-process=image/resize,m_lfit,h_${height},w_${width}/quality,q_90`;
    }
    
    // Return original URL if not a Digikala image
    return imageUrl;
  }
}

// Initialize popup when DOM is ready
let popupController;
document.addEventListener('DOMContentLoaded', () => {
  popupController = new PopupController();
});